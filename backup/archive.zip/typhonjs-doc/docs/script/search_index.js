window.esdocSearchIndex = [
  [
    "\n/**\n * @external {canvasrenderingcontext2d} https:/developer.mozilla.org/en-us/docs/web/api/canvasrenderingcontext2d\n */\n\n/**\n * @external {documentfragment} https:/developer.mozilla.org/en-us/docs/web/api/documentfragment\n */\n\n/**\n * @external {element} https:/developer.mozilla.org/en-us/docs/web/api/element\n */\n\n/**\n * @external {event} https:/developer.mozilla.org/en-us/docs/web/api/event\n */\n\n/**\n * @external {node} https:/developer.mozilla.org/en-us/docs/web/api/node\n */\n\n/**\n * @external {nodelist} https:/developer.mozilla.org/en-us/docs/web/api/nodelist\n */\n\n/**\n * @external {xmlhttprequest} https:/developer.mozilla.org/en/docs/web/api/xmlhttprequest\n */\n\n/**\n * @external {audiocontext} https:/developer.mozilla.org/en/docs/web/api/audiocontext\n */\n~audiocontext",
    "https://developer.mozilla.org/en/docs/Web/API/AudioContext",
    "\n/**\n * @external {CanvasRenderingContext2D} https:/developer.mozilla.org/en-US/docs/Web/API/CanvasRenderingContext2D\n */\n\n/**\n * @external {DocumentFragment} https:/developer.mozilla.org/en-US/docs/Web/API/DocumentFragment\n */\n\n/**\n * @external {Element} https:/developer.mozilla.org/en-US/docs/Web/API/Element\n */\n\n/**\n * @external {Event} https:/developer.mozilla.org/en-US/docs/Web/API/Event\n */\n\n/**\n * @external {Node} https:/developer.mozilla.org/en-US/docs/Web/API/Node\n */\n\n/**\n * @external {NodeList} https:/developer.mozilla.org/en-US/docs/Web/API/NodeList\n */\n\n/**\n * @external {XMLHttpRequest} https:/developer.mozilla.org/en/docs/Web/API/XMLHttpRequest\n */\n\n/**\n * @external {AudioContext} https:/developer.mozilla.org/en/docs/Web/API/AudioContext\n */\n~AudioContext",
    "external"
  ],
  [
    "\n/**\n * @external {canvasrenderingcontext2d} https:/developer.mozilla.org/en-us/docs/web/api/canvasrenderingcontext2d\n */\n\n/**\n * @external {documentfragment} https:/developer.mozilla.org/en-us/docs/web/api/documentfragment\n */\n\n/**\n * @external {element} https:/developer.mozilla.org/en-us/docs/web/api/element\n */\n\n/**\n * @external {event} https:/developer.mozilla.org/en-us/docs/web/api/event\n */\n\n/**\n * @external {node} https:/developer.mozilla.org/en-us/docs/web/api/node\n */\n\n/**\n * @external {nodelist} https:/developer.mozilla.org/en-us/docs/web/api/nodelist\n */\n\n/**\n * @external {xmlhttprequest} https:/developer.mozilla.org/en/docs/web/api/xmlhttprequest\n */\n\n/**\n * @external {audiocontext} https:/developer.mozilla.org/en/docs/web/api/audiocontext\n */\n~canvasrenderingcontext2d",
    "https://developer.mozilla.org/en-US/docs/Web/API/CanvasRenderingContext2D",
    "\n/**\n * @external {CanvasRenderingContext2D} https:/developer.mozilla.org/en-US/docs/Web/API/CanvasRenderingContext2D\n */\n\n/**\n * @external {DocumentFragment} https:/developer.mozilla.org/en-US/docs/Web/API/DocumentFragment\n */\n\n/**\n * @external {Element} https:/developer.mozilla.org/en-US/docs/Web/API/Element\n */\n\n/**\n * @external {Event} https:/developer.mozilla.org/en-US/docs/Web/API/Event\n */\n\n/**\n * @external {Node} https:/developer.mozilla.org/en-US/docs/Web/API/Node\n */\n\n/**\n * @external {NodeList} https:/developer.mozilla.org/en-US/docs/Web/API/NodeList\n */\n\n/**\n * @external {XMLHttpRequest} https:/developer.mozilla.org/en/docs/Web/API/XMLHttpRequest\n */\n\n/**\n * @external {AudioContext} https:/developer.mozilla.org/en/docs/Web/API/AudioContext\n */\n~CanvasRenderingContext2D",
    "external"
  ],
  [
    "\n/**\n * @external {canvasrenderingcontext2d} https:/developer.mozilla.org/en-us/docs/web/api/canvasrenderingcontext2d\n */\n\n/**\n * @external {documentfragment} https:/developer.mozilla.org/en-us/docs/web/api/documentfragment\n */\n\n/**\n * @external {element} https:/developer.mozilla.org/en-us/docs/web/api/element\n */\n\n/**\n * @external {event} https:/developer.mozilla.org/en-us/docs/web/api/event\n */\n\n/**\n * @external {node} https:/developer.mozilla.org/en-us/docs/web/api/node\n */\n\n/**\n * @external {nodelist} https:/developer.mozilla.org/en-us/docs/web/api/nodelist\n */\n\n/**\n * @external {xmlhttprequest} https:/developer.mozilla.org/en/docs/web/api/xmlhttprequest\n */\n\n/**\n * @external {audiocontext} https:/developer.mozilla.org/en/docs/web/api/audiocontext\n */\n~documentfragment",
    "https://developer.mozilla.org/en-US/docs/Web/API/DocumentFragment",
    "\n/**\n * @external {CanvasRenderingContext2D} https:/developer.mozilla.org/en-US/docs/Web/API/CanvasRenderingContext2D\n */\n\n/**\n * @external {DocumentFragment} https:/developer.mozilla.org/en-US/docs/Web/API/DocumentFragment\n */\n\n/**\n * @external {Element} https:/developer.mozilla.org/en-US/docs/Web/API/Element\n */\n\n/**\n * @external {Event} https:/developer.mozilla.org/en-US/docs/Web/API/Event\n */\n\n/**\n * @external {Node} https:/developer.mozilla.org/en-US/docs/Web/API/Node\n */\n\n/**\n * @external {NodeList} https:/developer.mozilla.org/en-US/docs/Web/API/NodeList\n */\n\n/**\n * @external {XMLHttpRequest} https:/developer.mozilla.org/en/docs/Web/API/XMLHttpRequest\n */\n\n/**\n * @external {AudioContext} https:/developer.mozilla.org/en/docs/Web/API/AudioContext\n */\n~DocumentFragment",
    "external"
  ],
  [
    "\n/**\n * @external {canvasrenderingcontext2d} https:/developer.mozilla.org/en-us/docs/web/api/canvasrenderingcontext2d\n */\n\n/**\n * @external {documentfragment} https:/developer.mozilla.org/en-us/docs/web/api/documentfragment\n */\n\n/**\n * @external {element} https:/developer.mozilla.org/en-us/docs/web/api/element\n */\n\n/**\n * @external {event} https:/developer.mozilla.org/en-us/docs/web/api/event\n */\n\n/**\n * @external {node} https:/developer.mozilla.org/en-us/docs/web/api/node\n */\n\n/**\n * @external {nodelist} https:/developer.mozilla.org/en-us/docs/web/api/nodelist\n */\n\n/**\n * @external {xmlhttprequest} https:/developer.mozilla.org/en/docs/web/api/xmlhttprequest\n */\n\n/**\n * @external {audiocontext} https:/developer.mozilla.org/en/docs/web/api/audiocontext\n */\n~element",
    "https://developer.mozilla.org/en-US/docs/Web/API/Element",
    "\n/**\n * @external {CanvasRenderingContext2D} https:/developer.mozilla.org/en-US/docs/Web/API/CanvasRenderingContext2D\n */\n\n/**\n * @external {DocumentFragment} https:/developer.mozilla.org/en-US/docs/Web/API/DocumentFragment\n */\n\n/**\n * @external {Element} https:/developer.mozilla.org/en-US/docs/Web/API/Element\n */\n\n/**\n * @external {Event} https:/developer.mozilla.org/en-US/docs/Web/API/Event\n */\n\n/**\n * @external {Node} https:/developer.mozilla.org/en-US/docs/Web/API/Node\n */\n\n/**\n * @external {NodeList} https:/developer.mozilla.org/en-US/docs/Web/API/NodeList\n */\n\n/**\n * @external {XMLHttpRequest} https:/developer.mozilla.org/en/docs/Web/API/XMLHttpRequest\n */\n\n/**\n * @external {AudioContext} https:/developer.mozilla.org/en/docs/Web/API/AudioContext\n */\n~Element",
    "external"
  ],
  [
    "\n/**\n * @external {canvasrenderingcontext2d} https:/developer.mozilla.org/en-us/docs/web/api/canvasrenderingcontext2d\n */\n\n/**\n * @external {documentfragment} https:/developer.mozilla.org/en-us/docs/web/api/documentfragment\n */\n\n/**\n * @external {element} https:/developer.mozilla.org/en-us/docs/web/api/element\n */\n\n/**\n * @external {event} https:/developer.mozilla.org/en-us/docs/web/api/event\n */\n\n/**\n * @external {node} https:/developer.mozilla.org/en-us/docs/web/api/node\n */\n\n/**\n * @external {nodelist} https:/developer.mozilla.org/en-us/docs/web/api/nodelist\n */\n\n/**\n * @external {xmlhttprequest} https:/developer.mozilla.org/en/docs/web/api/xmlhttprequest\n */\n\n/**\n * @external {audiocontext} https:/developer.mozilla.org/en/docs/web/api/audiocontext\n */\n~event",
    "https://developer.mozilla.org/en-US/docs/Web/API/Event",
    "\n/**\n * @external {CanvasRenderingContext2D} https:/developer.mozilla.org/en-US/docs/Web/API/CanvasRenderingContext2D\n */\n\n/**\n * @external {DocumentFragment} https:/developer.mozilla.org/en-US/docs/Web/API/DocumentFragment\n */\n\n/**\n * @external {Element} https:/developer.mozilla.org/en-US/docs/Web/API/Element\n */\n\n/**\n * @external {Event} https:/developer.mozilla.org/en-US/docs/Web/API/Event\n */\n\n/**\n * @external {Node} https:/developer.mozilla.org/en-US/docs/Web/API/Node\n */\n\n/**\n * @external {NodeList} https:/developer.mozilla.org/en-US/docs/Web/API/NodeList\n */\n\n/**\n * @external {XMLHttpRequest} https:/developer.mozilla.org/en/docs/Web/API/XMLHttpRequest\n */\n\n/**\n * @external {AudioContext} https:/developer.mozilla.org/en/docs/Web/API/AudioContext\n */\n~Event",
    "external"
  ],
  [
    "\n/**\n * @external {canvasrenderingcontext2d} https:/developer.mozilla.org/en-us/docs/web/api/canvasrenderingcontext2d\n */\n\n/**\n * @external {documentfragment} https:/developer.mozilla.org/en-us/docs/web/api/documentfragment\n */\n\n/**\n * @external {element} https:/developer.mozilla.org/en-us/docs/web/api/element\n */\n\n/**\n * @external {event} https:/developer.mozilla.org/en-us/docs/web/api/event\n */\n\n/**\n * @external {node} https:/developer.mozilla.org/en-us/docs/web/api/node\n */\n\n/**\n * @external {nodelist} https:/developer.mozilla.org/en-us/docs/web/api/nodelist\n */\n\n/**\n * @external {xmlhttprequest} https:/developer.mozilla.org/en/docs/web/api/xmlhttprequest\n */\n\n/**\n * @external {audiocontext} https:/developer.mozilla.org/en/docs/web/api/audiocontext\n */\n~node",
    "https://developer.mozilla.org/en-US/docs/Web/API/Node",
    "\n/**\n * @external {CanvasRenderingContext2D} https:/developer.mozilla.org/en-US/docs/Web/API/CanvasRenderingContext2D\n */\n\n/**\n * @external {DocumentFragment} https:/developer.mozilla.org/en-US/docs/Web/API/DocumentFragment\n */\n\n/**\n * @external {Element} https:/developer.mozilla.org/en-US/docs/Web/API/Element\n */\n\n/**\n * @external {Event} https:/developer.mozilla.org/en-US/docs/Web/API/Event\n */\n\n/**\n * @external {Node} https:/developer.mozilla.org/en-US/docs/Web/API/Node\n */\n\n/**\n * @external {NodeList} https:/developer.mozilla.org/en-US/docs/Web/API/NodeList\n */\n\n/**\n * @external {XMLHttpRequest} https:/developer.mozilla.org/en/docs/Web/API/XMLHttpRequest\n */\n\n/**\n * @external {AudioContext} https:/developer.mozilla.org/en/docs/Web/API/AudioContext\n */\n~Node",
    "external"
  ],
  [
    "\n/**\n * @external {canvasrenderingcontext2d} https:/developer.mozilla.org/en-us/docs/web/api/canvasrenderingcontext2d\n */\n\n/**\n * @external {documentfragment} https:/developer.mozilla.org/en-us/docs/web/api/documentfragment\n */\n\n/**\n * @external {element} https:/developer.mozilla.org/en-us/docs/web/api/element\n */\n\n/**\n * @external {event} https:/developer.mozilla.org/en-us/docs/web/api/event\n */\n\n/**\n * @external {node} https:/developer.mozilla.org/en-us/docs/web/api/node\n */\n\n/**\n * @external {nodelist} https:/developer.mozilla.org/en-us/docs/web/api/nodelist\n */\n\n/**\n * @external {xmlhttprequest} https:/developer.mozilla.org/en/docs/web/api/xmlhttprequest\n */\n\n/**\n * @external {audiocontext} https:/developer.mozilla.org/en/docs/web/api/audiocontext\n */\n~nodelist",
    "https://developer.mozilla.org/en-US/docs/Web/API/NodeList",
    "\n/**\n * @external {CanvasRenderingContext2D} https:/developer.mozilla.org/en-US/docs/Web/API/CanvasRenderingContext2D\n */\n\n/**\n * @external {DocumentFragment} https:/developer.mozilla.org/en-US/docs/Web/API/DocumentFragment\n */\n\n/**\n * @external {Element} https:/developer.mozilla.org/en-US/docs/Web/API/Element\n */\n\n/**\n * @external {Event} https:/developer.mozilla.org/en-US/docs/Web/API/Event\n */\n\n/**\n * @external {Node} https:/developer.mozilla.org/en-US/docs/Web/API/Node\n */\n\n/**\n * @external {NodeList} https:/developer.mozilla.org/en-US/docs/Web/API/NodeList\n */\n\n/**\n * @external {XMLHttpRequest} https:/developer.mozilla.org/en/docs/Web/API/XMLHttpRequest\n */\n\n/**\n * @external {AudioContext} https:/developer.mozilla.org/en/docs/Web/API/AudioContext\n */\n~NodeList",
    "external"
  ],
  [
    "\n/**\n * @external {canvasrenderingcontext2d} https:/developer.mozilla.org/en-us/docs/web/api/canvasrenderingcontext2d\n */\n\n/**\n * @external {documentfragment} https:/developer.mozilla.org/en-us/docs/web/api/documentfragment\n */\n\n/**\n * @external {element} https:/developer.mozilla.org/en-us/docs/web/api/element\n */\n\n/**\n * @external {event} https:/developer.mozilla.org/en-us/docs/web/api/event\n */\n\n/**\n * @external {node} https:/developer.mozilla.org/en-us/docs/web/api/node\n */\n\n/**\n * @external {nodelist} https:/developer.mozilla.org/en-us/docs/web/api/nodelist\n */\n\n/**\n * @external {xmlhttprequest} https:/developer.mozilla.org/en/docs/web/api/xmlhttprequest\n */\n\n/**\n * @external {audiocontext} https:/developer.mozilla.org/en/docs/web/api/audiocontext\n */\n~xmlhttprequest",
    "https://developer.mozilla.org/en/docs/Web/API/XMLHttpRequest",
    "\n/**\n * @external {CanvasRenderingContext2D} https:/developer.mozilla.org/en-US/docs/Web/API/CanvasRenderingContext2D\n */\n\n/**\n * @external {DocumentFragment} https:/developer.mozilla.org/en-US/docs/Web/API/DocumentFragment\n */\n\n/**\n * @external {Element} https:/developer.mozilla.org/en-US/docs/Web/API/Element\n */\n\n/**\n * @external {Event} https:/developer.mozilla.org/en-US/docs/Web/API/Event\n */\n\n/**\n * @external {Node} https:/developer.mozilla.org/en-US/docs/Web/API/Node\n */\n\n/**\n * @external {NodeList} https:/developer.mozilla.org/en-US/docs/Web/API/NodeList\n */\n\n/**\n * @external {XMLHttpRequest} https:/developer.mozilla.org/en/docs/Web/API/XMLHttpRequest\n */\n\n/**\n * @external {AudioContext} https:/developer.mozilla.org/en/docs/Web/API/AudioContext\n */\n~XMLHttpRequest",
    "external"
  ],
  [
    "\n/**\n * @external {infinity} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/infinity\n */\n\n/**\n * @external {nan} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/nan\n */\n\n/**\n * @external {undefined} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/undefined\n */\n\n/**\n * @external {null} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/null\n */\n\n/ fundamental objects\n/**\n * @external {object} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/object\n */\n/**\n * @external {object} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/object\n */\n\n/**\n * @external {function} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/function\n */\n/**\n * @external {function} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/function\n */\n\n/**\n * @external {boolean} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/boolean\n */\n/**\n * @external {boolean} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/boolean\n */\n\n/**\n * @external {symbol} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/symbol\n */\n\n/**\n * @external {error} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/error\n */\n\n/**\n * @external {evalerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/evalerror\n */\n\n/**\n * @external {internalerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/internalerror\n */\n\n/**\n * @external {rangeerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/rangeerror\n */\n\n/**\n * @external {referenceerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/referenceerror\n */\n\n/**\n * @external {syntaxerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/syntaxerror\n */\n\n/**\n * @external {typeerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/typeerror\n */\n\n/**\n * @external {urierror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/urierror\n */\n\n/ numbers and dates\n/**\n * @external {number} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/number\n */\n/**\n * @external {number} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/number\n */\n\n/**\n * @external {date} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/date\n */\n\n/ text processing\n/**\n * @external {string} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/string\n */\n/**\n * @external {string} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/string\n */\n\n/**\n * @external {regexp} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/regexp\n */\n\n/ indexed collections\n/**\n * @external {array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/array\n */\n\n/**\n * @external {int8array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int8array\n */\n/**\n * @external {uint8array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint8array\n */\n\n/**\n * @external {uint8clampedarray} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint8clampedarray\n */\n\n/**\n * @external {int16array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int16array\n */\n\n/**\n * @external {uint16array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint16array\n */\n\n/**\n * @external {int32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int32array\n */\n\n/**\n * @external {uint32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint32array\n */\n\n/**\n * @external {float32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/float32array\n */\n\n/**\n * @external {float64array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/float64array\n */\n\n/ keyed collections\n/**\n * @external {map} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/map\n */\n\n/**\n * @external {set} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/set\n */\n\n/**\n * @external {weakmap} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/weakmap\n */\n\n/**\n * @external {weakset} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/weakset\n */\n\n/ structured data\n/**\n * @external {arraybuffer} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/arraybuffer\n */\n\n/**\n * @external {dataview} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/dataview\n */\n\n/**\n * @external {json} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/json\n */\n\n/ control abstraction objects\n/**\n * @external {promise} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/promise\n */\n\n/**\n * @external {generator} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/generator\n */\n\n/**\n * @external {generatorfunction} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/generatorfunction\n */\n\n/ reflection\n/**\n * @external {reflect} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/reflect\n */\n\n/**\n * @external {proxy} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/proxy\n */\n~array",
    "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array",
    "\n/**\n * @external {Infinity} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Infinity\n */\n\n/**\n * @external {NaN} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/NaN\n */\n\n/**\n * @external {undefined} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/undefined\n */\n\n/**\n * @external {null} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/null\n */\n\n/ Fundamental objects\n/**\n * @external {Object} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object\n */\n/**\n * @external {object} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object\n */\n\n/**\n * @external {Function} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function\n */\n/**\n * @external {function} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function\n */\n\n/**\n * @external {Boolean} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean\n */\n/**\n * @external {boolean} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean\n */\n\n/**\n * @external {Symbol} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Symbol\n */\n\n/**\n * @external {Error} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Error\n */\n\n/**\n * @external {EvalError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/EvalError\n */\n\n/**\n * @external {InternalError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/InternalError\n */\n\n/**\n * @external {RangeError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RangeError\n */\n\n/**\n * @external {ReferenceError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ReferenceError\n */\n\n/**\n * @external {SyntaxError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/SyntaxError\n */\n\n/**\n * @external {TypeError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/TypeError\n */\n\n/**\n * @external {URIError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/URIError\n */\n\n/ Numbers and dates\n/**\n * @external {Number} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number\n */\n/**\n * @external {number} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number\n */\n\n/**\n * @external {Date} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Date\n */\n\n/ Text processing\n/**\n * @external {String} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String\n */\n/**\n * @external {string} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String\n */\n\n/**\n * @external {RegExp} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RegExp\n */\n\n/ Indexed collections\n/**\n * @external {Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array\n */\n\n/**\n * @external {Int8Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int8Array\n */\n/**\n * @external {Uint8Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint8Array\n */\n\n/**\n * @external {Uint8ClampedArray} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint8ClampedArray\n */\n\n/**\n * @external {Int16Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int16Array\n */\n\n/**\n * @external {Uint16Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint16Array\n */\n\n/**\n * @external {Int32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int32Array\n */\n\n/**\n * @external {Uint32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint32Array\n */\n\n/**\n * @external {Float32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Float32Array\n */\n\n/**\n * @external {Float64Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Float64Array\n */\n\n/ Keyed collections\n/**\n * @external {Map} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Map\n */\n\n/**\n * @external {Set} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Set\n */\n\n/**\n * @external {WeakMap} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakMap\n */\n\n/**\n * @external {WeakSet} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakSet\n */\n\n/ Structured data\n/**\n * @external {ArrayBuffer} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ArrayBuffer\n */\n\n/**\n * @external {DataView} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/DataView\n */\n\n/**\n * @external {JSON} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/JSON\n */\n\n/ Control abstraction objects\n/**\n * @external {Promise} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Promise\n */\n\n/**\n * @external {Generator} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Generator\n */\n\n/**\n * @external {GeneratorFunction} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/GeneratorFunction\n */\n\n/ Reflection\n/**\n * @external {Reflect} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Reflect\n */\n\n/**\n * @external {Proxy} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Proxy\n */\n~Array",
    "external"
  ],
  [
    "\n/**\n * @external {infinity} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/infinity\n */\n\n/**\n * @external {nan} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/nan\n */\n\n/**\n * @external {undefined} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/undefined\n */\n\n/**\n * @external {null} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/null\n */\n\n/ fundamental objects\n/**\n * @external {object} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/object\n */\n/**\n * @external {object} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/object\n */\n\n/**\n * @external {function} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/function\n */\n/**\n * @external {function} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/function\n */\n\n/**\n * @external {boolean} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/boolean\n */\n/**\n * @external {boolean} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/boolean\n */\n\n/**\n * @external {symbol} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/symbol\n */\n\n/**\n * @external {error} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/error\n */\n\n/**\n * @external {evalerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/evalerror\n */\n\n/**\n * @external {internalerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/internalerror\n */\n\n/**\n * @external {rangeerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/rangeerror\n */\n\n/**\n * @external {referenceerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/referenceerror\n */\n\n/**\n * @external {syntaxerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/syntaxerror\n */\n\n/**\n * @external {typeerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/typeerror\n */\n\n/**\n * @external {urierror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/urierror\n */\n\n/ numbers and dates\n/**\n * @external {number} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/number\n */\n/**\n * @external {number} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/number\n */\n\n/**\n * @external {date} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/date\n */\n\n/ text processing\n/**\n * @external {string} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/string\n */\n/**\n * @external {string} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/string\n */\n\n/**\n * @external {regexp} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/regexp\n */\n\n/ indexed collections\n/**\n * @external {array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/array\n */\n\n/**\n * @external {int8array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int8array\n */\n/**\n * @external {uint8array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint8array\n */\n\n/**\n * @external {uint8clampedarray} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint8clampedarray\n */\n\n/**\n * @external {int16array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int16array\n */\n\n/**\n * @external {uint16array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint16array\n */\n\n/**\n * @external {int32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int32array\n */\n\n/**\n * @external {uint32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint32array\n */\n\n/**\n * @external {float32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/float32array\n */\n\n/**\n * @external {float64array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/float64array\n */\n\n/ keyed collections\n/**\n * @external {map} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/map\n */\n\n/**\n * @external {set} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/set\n */\n\n/**\n * @external {weakmap} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/weakmap\n */\n\n/**\n * @external {weakset} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/weakset\n */\n\n/ structured data\n/**\n * @external {arraybuffer} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/arraybuffer\n */\n\n/**\n * @external {dataview} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/dataview\n */\n\n/**\n * @external {json} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/json\n */\n\n/ control abstraction objects\n/**\n * @external {promise} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/promise\n */\n\n/**\n * @external {generator} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/generator\n */\n\n/**\n * @external {generatorfunction} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/generatorfunction\n */\n\n/ reflection\n/**\n * @external {reflect} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/reflect\n */\n\n/**\n * @external {proxy} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/proxy\n */\n~arraybuffer",
    "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ArrayBuffer",
    "\n/**\n * @external {Infinity} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Infinity\n */\n\n/**\n * @external {NaN} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/NaN\n */\n\n/**\n * @external {undefined} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/undefined\n */\n\n/**\n * @external {null} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/null\n */\n\n/ Fundamental objects\n/**\n * @external {Object} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object\n */\n/**\n * @external {object} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object\n */\n\n/**\n * @external {Function} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function\n */\n/**\n * @external {function} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function\n */\n\n/**\n * @external {Boolean} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean\n */\n/**\n * @external {boolean} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean\n */\n\n/**\n * @external {Symbol} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Symbol\n */\n\n/**\n * @external {Error} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Error\n */\n\n/**\n * @external {EvalError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/EvalError\n */\n\n/**\n * @external {InternalError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/InternalError\n */\n\n/**\n * @external {RangeError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RangeError\n */\n\n/**\n * @external {ReferenceError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ReferenceError\n */\n\n/**\n * @external {SyntaxError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/SyntaxError\n */\n\n/**\n * @external {TypeError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/TypeError\n */\n\n/**\n * @external {URIError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/URIError\n */\n\n/ Numbers and dates\n/**\n * @external {Number} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number\n */\n/**\n * @external {number} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number\n */\n\n/**\n * @external {Date} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Date\n */\n\n/ Text processing\n/**\n * @external {String} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String\n */\n/**\n * @external {string} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String\n */\n\n/**\n * @external {RegExp} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RegExp\n */\n\n/ Indexed collections\n/**\n * @external {Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array\n */\n\n/**\n * @external {Int8Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int8Array\n */\n/**\n * @external {Uint8Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint8Array\n */\n\n/**\n * @external {Uint8ClampedArray} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint8ClampedArray\n */\n\n/**\n * @external {Int16Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int16Array\n */\n\n/**\n * @external {Uint16Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint16Array\n */\n\n/**\n * @external {Int32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int32Array\n */\n\n/**\n * @external {Uint32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint32Array\n */\n\n/**\n * @external {Float32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Float32Array\n */\n\n/**\n * @external {Float64Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Float64Array\n */\n\n/ Keyed collections\n/**\n * @external {Map} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Map\n */\n\n/**\n * @external {Set} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Set\n */\n\n/**\n * @external {WeakMap} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakMap\n */\n\n/**\n * @external {WeakSet} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakSet\n */\n\n/ Structured data\n/**\n * @external {ArrayBuffer} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ArrayBuffer\n */\n\n/**\n * @external {DataView} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/DataView\n */\n\n/**\n * @external {JSON} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/JSON\n */\n\n/ Control abstraction objects\n/**\n * @external {Promise} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Promise\n */\n\n/**\n * @external {Generator} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Generator\n */\n\n/**\n * @external {GeneratorFunction} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/GeneratorFunction\n */\n\n/ Reflection\n/**\n * @external {Reflect} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Reflect\n */\n\n/**\n * @external {Proxy} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Proxy\n */\n~ArrayBuffer",
    "external"
  ],
  [
    "\n/**\n * @external {infinity} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/infinity\n */\n\n/**\n * @external {nan} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/nan\n */\n\n/**\n * @external {undefined} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/undefined\n */\n\n/**\n * @external {null} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/null\n */\n\n/ fundamental objects\n/**\n * @external {object} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/object\n */\n/**\n * @external {object} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/object\n */\n\n/**\n * @external {function} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/function\n */\n/**\n * @external {function} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/function\n */\n\n/**\n * @external {boolean} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/boolean\n */\n/**\n * @external {boolean} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/boolean\n */\n\n/**\n * @external {symbol} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/symbol\n */\n\n/**\n * @external {error} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/error\n */\n\n/**\n * @external {evalerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/evalerror\n */\n\n/**\n * @external {internalerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/internalerror\n */\n\n/**\n * @external {rangeerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/rangeerror\n */\n\n/**\n * @external {referenceerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/referenceerror\n */\n\n/**\n * @external {syntaxerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/syntaxerror\n */\n\n/**\n * @external {typeerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/typeerror\n */\n\n/**\n * @external {urierror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/urierror\n */\n\n/ numbers and dates\n/**\n * @external {number} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/number\n */\n/**\n * @external {number} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/number\n */\n\n/**\n * @external {date} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/date\n */\n\n/ text processing\n/**\n * @external {string} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/string\n */\n/**\n * @external {string} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/string\n */\n\n/**\n * @external {regexp} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/regexp\n */\n\n/ indexed collections\n/**\n * @external {array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/array\n */\n\n/**\n * @external {int8array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int8array\n */\n/**\n * @external {uint8array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint8array\n */\n\n/**\n * @external {uint8clampedarray} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint8clampedarray\n */\n\n/**\n * @external {int16array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int16array\n */\n\n/**\n * @external {uint16array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint16array\n */\n\n/**\n * @external {int32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int32array\n */\n\n/**\n * @external {uint32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint32array\n */\n\n/**\n * @external {float32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/float32array\n */\n\n/**\n * @external {float64array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/float64array\n */\n\n/ keyed collections\n/**\n * @external {map} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/map\n */\n\n/**\n * @external {set} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/set\n */\n\n/**\n * @external {weakmap} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/weakmap\n */\n\n/**\n * @external {weakset} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/weakset\n */\n\n/ structured data\n/**\n * @external {arraybuffer} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/arraybuffer\n */\n\n/**\n * @external {dataview} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/dataview\n */\n\n/**\n * @external {json} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/json\n */\n\n/ control abstraction objects\n/**\n * @external {promise} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/promise\n */\n\n/**\n * @external {generator} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/generator\n */\n\n/**\n * @external {generatorfunction} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/generatorfunction\n */\n\n/ reflection\n/**\n * @external {reflect} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/reflect\n */\n\n/**\n * @external {proxy} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/proxy\n */\n~boolean",
    "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean",
    "\n/**\n * @external {Infinity} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Infinity\n */\n\n/**\n * @external {NaN} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/NaN\n */\n\n/**\n * @external {undefined} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/undefined\n */\n\n/**\n * @external {null} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/null\n */\n\n/ Fundamental objects\n/**\n * @external {Object} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object\n */\n/**\n * @external {object} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object\n */\n\n/**\n * @external {Function} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function\n */\n/**\n * @external {function} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function\n */\n\n/**\n * @external {Boolean} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean\n */\n/**\n * @external {boolean} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean\n */\n\n/**\n * @external {Symbol} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Symbol\n */\n\n/**\n * @external {Error} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Error\n */\n\n/**\n * @external {EvalError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/EvalError\n */\n\n/**\n * @external {InternalError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/InternalError\n */\n\n/**\n * @external {RangeError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RangeError\n */\n\n/**\n * @external {ReferenceError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ReferenceError\n */\n\n/**\n * @external {SyntaxError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/SyntaxError\n */\n\n/**\n * @external {TypeError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/TypeError\n */\n\n/**\n * @external {URIError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/URIError\n */\n\n/ Numbers and dates\n/**\n * @external {Number} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number\n */\n/**\n * @external {number} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number\n */\n\n/**\n * @external {Date} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Date\n */\n\n/ Text processing\n/**\n * @external {String} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String\n */\n/**\n * @external {string} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String\n */\n\n/**\n * @external {RegExp} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RegExp\n */\n\n/ Indexed collections\n/**\n * @external {Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array\n */\n\n/**\n * @external {Int8Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int8Array\n */\n/**\n * @external {Uint8Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint8Array\n */\n\n/**\n * @external {Uint8ClampedArray} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint8ClampedArray\n */\n\n/**\n * @external {Int16Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int16Array\n */\n\n/**\n * @external {Uint16Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint16Array\n */\n\n/**\n * @external {Int32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int32Array\n */\n\n/**\n * @external {Uint32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint32Array\n */\n\n/**\n * @external {Float32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Float32Array\n */\n\n/**\n * @external {Float64Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Float64Array\n */\n\n/ Keyed collections\n/**\n * @external {Map} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Map\n */\n\n/**\n * @external {Set} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Set\n */\n\n/**\n * @external {WeakMap} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakMap\n */\n\n/**\n * @external {WeakSet} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakSet\n */\n\n/ Structured data\n/**\n * @external {ArrayBuffer} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ArrayBuffer\n */\n\n/**\n * @external {DataView} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/DataView\n */\n\n/**\n * @external {JSON} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/JSON\n */\n\n/ Control abstraction objects\n/**\n * @external {Promise} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Promise\n */\n\n/**\n * @external {Generator} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Generator\n */\n\n/**\n * @external {GeneratorFunction} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/GeneratorFunction\n */\n\n/ Reflection\n/**\n * @external {Reflect} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Reflect\n */\n\n/**\n * @external {Proxy} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Proxy\n */\n~Boolean",
    "external"
  ],
  [
    "\n/**\n * @external {infinity} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/infinity\n */\n\n/**\n * @external {nan} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/nan\n */\n\n/**\n * @external {undefined} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/undefined\n */\n\n/**\n * @external {null} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/null\n */\n\n/ fundamental objects\n/**\n * @external {object} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/object\n */\n/**\n * @external {object} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/object\n */\n\n/**\n * @external {function} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/function\n */\n/**\n * @external {function} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/function\n */\n\n/**\n * @external {boolean} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/boolean\n */\n/**\n * @external {boolean} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/boolean\n */\n\n/**\n * @external {symbol} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/symbol\n */\n\n/**\n * @external {error} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/error\n */\n\n/**\n * @external {evalerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/evalerror\n */\n\n/**\n * @external {internalerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/internalerror\n */\n\n/**\n * @external {rangeerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/rangeerror\n */\n\n/**\n * @external {referenceerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/referenceerror\n */\n\n/**\n * @external {syntaxerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/syntaxerror\n */\n\n/**\n * @external {typeerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/typeerror\n */\n\n/**\n * @external {urierror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/urierror\n */\n\n/ numbers and dates\n/**\n * @external {number} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/number\n */\n/**\n * @external {number} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/number\n */\n\n/**\n * @external {date} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/date\n */\n\n/ text processing\n/**\n * @external {string} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/string\n */\n/**\n * @external {string} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/string\n */\n\n/**\n * @external {regexp} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/regexp\n */\n\n/ indexed collections\n/**\n * @external {array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/array\n */\n\n/**\n * @external {int8array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int8array\n */\n/**\n * @external {uint8array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint8array\n */\n\n/**\n * @external {uint8clampedarray} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint8clampedarray\n */\n\n/**\n * @external {int16array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int16array\n */\n\n/**\n * @external {uint16array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint16array\n */\n\n/**\n * @external {int32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int32array\n */\n\n/**\n * @external {uint32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint32array\n */\n\n/**\n * @external {float32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/float32array\n */\n\n/**\n * @external {float64array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/float64array\n */\n\n/ keyed collections\n/**\n * @external {map} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/map\n */\n\n/**\n * @external {set} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/set\n */\n\n/**\n * @external {weakmap} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/weakmap\n */\n\n/**\n * @external {weakset} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/weakset\n */\n\n/ structured data\n/**\n * @external {arraybuffer} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/arraybuffer\n */\n\n/**\n * @external {dataview} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/dataview\n */\n\n/**\n * @external {json} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/json\n */\n\n/ control abstraction objects\n/**\n * @external {promise} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/promise\n */\n\n/**\n * @external {generator} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/generator\n */\n\n/**\n * @external {generatorfunction} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/generatorfunction\n */\n\n/ reflection\n/**\n * @external {reflect} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/reflect\n */\n\n/**\n * @external {proxy} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/proxy\n */\n~dataview",
    "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/DataView",
    "\n/**\n * @external {Infinity} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Infinity\n */\n\n/**\n * @external {NaN} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/NaN\n */\n\n/**\n * @external {undefined} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/undefined\n */\n\n/**\n * @external {null} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/null\n */\n\n/ Fundamental objects\n/**\n * @external {Object} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object\n */\n/**\n * @external {object} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object\n */\n\n/**\n * @external {Function} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function\n */\n/**\n * @external {function} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function\n */\n\n/**\n * @external {Boolean} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean\n */\n/**\n * @external {boolean} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean\n */\n\n/**\n * @external {Symbol} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Symbol\n */\n\n/**\n * @external {Error} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Error\n */\n\n/**\n * @external {EvalError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/EvalError\n */\n\n/**\n * @external {InternalError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/InternalError\n */\n\n/**\n * @external {RangeError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RangeError\n */\n\n/**\n * @external {ReferenceError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ReferenceError\n */\n\n/**\n * @external {SyntaxError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/SyntaxError\n */\n\n/**\n * @external {TypeError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/TypeError\n */\n\n/**\n * @external {URIError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/URIError\n */\n\n/ Numbers and dates\n/**\n * @external {Number} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number\n */\n/**\n * @external {number} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number\n */\n\n/**\n * @external {Date} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Date\n */\n\n/ Text processing\n/**\n * @external {String} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String\n */\n/**\n * @external {string} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String\n */\n\n/**\n * @external {RegExp} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RegExp\n */\n\n/ Indexed collections\n/**\n * @external {Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array\n */\n\n/**\n * @external {Int8Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int8Array\n */\n/**\n * @external {Uint8Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint8Array\n */\n\n/**\n * @external {Uint8ClampedArray} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint8ClampedArray\n */\n\n/**\n * @external {Int16Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int16Array\n */\n\n/**\n * @external {Uint16Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint16Array\n */\n\n/**\n * @external {Int32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int32Array\n */\n\n/**\n * @external {Uint32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint32Array\n */\n\n/**\n * @external {Float32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Float32Array\n */\n\n/**\n * @external {Float64Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Float64Array\n */\n\n/ Keyed collections\n/**\n * @external {Map} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Map\n */\n\n/**\n * @external {Set} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Set\n */\n\n/**\n * @external {WeakMap} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakMap\n */\n\n/**\n * @external {WeakSet} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakSet\n */\n\n/ Structured data\n/**\n * @external {ArrayBuffer} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ArrayBuffer\n */\n\n/**\n * @external {DataView} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/DataView\n */\n\n/**\n * @external {JSON} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/JSON\n */\n\n/ Control abstraction objects\n/**\n * @external {Promise} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Promise\n */\n\n/**\n * @external {Generator} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Generator\n */\n\n/**\n * @external {GeneratorFunction} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/GeneratorFunction\n */\n\n/ Reflection\n/**\n * @external {Reflect} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Reflect\n */\n\n/**\n * @external {Proxy} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Proxy\n */\n~DataView",
    "external"
  ],
  [
    "\n/**\n * @external {infinity} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/infinity\n */\n\n/**\n * @external {nan} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/nan\n */\n\n/**\n * @external {undefined} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/undefined\n */\n\n/**\n * @external {null} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/null\n */\n\n/ fundamental objects\n/**\n * @external {object} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/object\n */\n/**\n * @external {object} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/object\n */\n\n/**\n * @external {function} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/function\n */\n/**\n * @external {function} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/function\n */\n\n/**\n * @external {boolean} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/boolean\n */\n/**\n * @external {boolean} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/boolean\n */\n\n/**\n * @external {symbol} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/symbol\n */\n\n/**\n * @external {error} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/error\n */\n\n/**\n * @external {evalerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/evalerror\n */\n\n/**\n * @external {internalerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/internalerror\n */\n\n/**\n * @external {rangeerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/rangeerror\n */\n\n/**\n * @external {referenceerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/referenceerror\n */\n\n/**\n * @external {syntaxerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/syntaxerror\n */\n\n/**\n * @external {typeerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/typeerror\n */\n\n/**\n * @external {urierror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/urierror\n */\n\n/ numbers and dates\n/**\n * @external {number} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/number\n */\n/**\n * @external {number} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/number\n */\n\n/**\n * @external {date} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/date\n */\n\n/ text processing\n/**\n * @external {string} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/string\n */\n/**\n * @external {string} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/string\n */\n\n/**\n * @external {regexp} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/regexp\n */\n\n/ indexed collections\n/**\n * @external {array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/array\n */\n\n/**\n * @external {int8array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int8array\n */\n/**\n * @external {uint8array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint8array\n */\n\n/**\n * @external {uint8clampedarray} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint8clampedarray\n */\n\n/**\n * @external {int16array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int16array\n */\n\n/**\n * @external {uint16array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint16array\n */\n\n/**\n * @external {int32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int32array\n */\n\n/**\n * @external {uint32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint32array\n */\n\n/**\n * @external {float32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/float32array\n */\n\n/**\n * @external {float64array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/float64array\n */\n\n/ keyed collections\n/**\n * @external {map} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/map\n */\n\n/**\n * @external {set} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/set\n */\n\n/**\n * @external {weakmap} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/weakmap\n */\n\n/**\n * @external {weakset} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/weakset\n */\n\n/ structured data\n/**\n * @external {arraybuffer} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/arraybuffer\n */\n\n/**\n * @external {dataview} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/dataview\n */\n\n/**\n * @external {json} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/json\n */\n\n/ control abstraction objects\n/**\n * @external {promise} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/promise\n */\n\n/**\n * @external {generator} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/generator\n */\n\n/**\n * @external {generatorfunction} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/generatorfunction\n */\n\n/ reflection\n/**\n * @external {reflect} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/reflect\n */\n\n/**\n * @external {proxy} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/proxy\n */\n~date",
    "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Date",
    "\n/**\n * @external {Infinity} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Infinity\n */\n\n/**\n * @external {NaN} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/NaN\n */\n\n/**\n * @external {undefined} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/undefined\n */\n\n/**\n * @external {null} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/null\n */\n\n/ Fundamental objects\n/**\n * @external {Object} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object\n */\n/**\n * @external {object} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object\n */\n\n/**\n * @external {Function} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function\n */\n/**\n * @external {function} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function\n */\n\n/**\n * @external {Boolean} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean\n */\n/**\n * @external {boolean} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean\n */\n\n/**\n * @external {Symbol} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Symbol\n */\n\n/**\n * @external {Error} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Error\n */\n\n/**\n * @external {EvalError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/EvalError\n */\n\n/**\n * @external {InternalError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/InternalError\n */\n\n/**\n * @external {RangeError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RangeError\n */\n\n/**\n * @external {ReferenceError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ReferenceError\n */\n\n/**\n * @external {SyntaxError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/SyntaxError\n */\n\n/**\n * @external {TypeError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/TypeError\n */\n\n/**\n * @external {URIError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/URIError\n */\n\n/ Numbers and dates\n/**\n * @external {Number} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number\n */\n/**\n * @external {number} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number\n */\n\n/**\n * @external {Date} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Date\n */\n\n/ Text processing\n/**\n * @external {String} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String\n */\n/**\n * @external {string} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String\n */\n\n/**\n * @external {RegExp} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RegExp\n */\n\n/ Indexed collections\n/**\n * @external {Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array\n */\n\n/**\n * @external {Int8Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int8Array\n */\n/**\n * @external {Uint8Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint8Array\n */\n\n/**\n * @external {Uint8ClampedArray} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint8ClampedArray\n */\n\n/**\n * @external {Int16Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int16Array\n */\n\n/**\n * @external {Uint16Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint16Array\n */\n\n/**\n * @external {Int32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int32Array\n */\n\n/**\n * @external {Uint32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint32Array\n */\n\n/**\n * @external {Float32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Float32Array\n */\n\n/**\n * @external {Float64Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Float64Array\n */\n\n/ Keyed collections\n/**\n * @external {Map} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Map\n */\n\n/**\n * @external {Set} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Set\n */\n\n/**\n * @external {WeakMap} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakMap\n */\n\n/**\n * @external {WeakSet} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakSet\n */\n\n/ Structured data\n/**\n * @external {ArrayBuffer} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ArrayBuffer\n */\n\n/**\n * @external {DataView} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/DataView\n */\n\n/**\n * @external {JSON} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/JSON\n */\n\n/ Control abstraction objects\n/**\n * @external {Promise} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Promise\n */\n\n/**\n * @external {Generator} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Generator\n */\n\n/**\n * @external {GeneratorFunction} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/GeneratorFunction\n */\n\n/ Reflection\n/**\n * @external {Reflect} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Reflect\n */\n\n/**\n * @external {Proxy} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Proxy\n */\n~Date",
    "external"
  ],
  [
    "\n/**\n * @external {infinity} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/infinity\n */\n\n/**\n * @external {nan} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/nan\n */\n\n/**\n * @external {undefined} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/undefined\n */\n\n/**\n * @external {null} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/null\n */\n\n/ fundamental objects\n/**\n * @external {object} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/object\n */\n/**\n * @external {object} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/object\n */\n\n/**\n * @external {function} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/function\n */\n/**\n * @external {function} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/function\n */\n\n/**\n * @external {boolean} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/boolean\n */\n/**\n * @external {boolean} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/boolean\n */\n\n/**\n * @external {symbol} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/symbol\n */\n\n/**\n * @external {error} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/error\n */\n\n/**\n * @external {evalerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/evalerror\n */\n\n/**\n * @external {internalerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/internalerror\n */\n\n/**\n * @external {rangeerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/rangeerror\n */\n\n/**\n * @external {referenceerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/referenceerror\n */\n\n/**\n * @external {syntaxerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/syntaxerror\n */\n\n/**\n * @external {typeerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/typeerror\n */\n\n/**\n * @external {urierror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/urierror\n */\n\n/ numbers and dates\n/**\n * @external {number} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/number\n */\n/**\n * @external {number} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/number\n */\n\n/**\n * @external {date} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/date\n */\n\n/ text processing\n/**\n * @external {string} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/string\n */\n/**\n * @external {string} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/string\n */\n\n/**\n * @external {regexp} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/regexp\n */\n\n/ indexed collections\n/**\n * @external {array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/array\n */\n\n/**\n * @external {int8array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int8array\n */\n/**\n * @external {uint8array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint8array\n */\n\n/**\n * @external {uint8clampedarray} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint8clampedarray\n */\n\n/**\n * @external {int16array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int16array\n */\n\n/**\n * @external {uint16array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint16array\n */\n\n/**\n * @external {int32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int32array\n */\n\n/**\n * @external {uint32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint32array\n */\n\n/**\n * @external {float32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/float32array\n */\n\n/**\n * @external {float64array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/float64array\n */\n\n/ keyed collections\n/**\n * @external {map} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/map\n */\n\n/**\n * @external {set} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/set\n */\n\n/**\n * @external {weakmap} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/weakmap\n */\n\n/**\n * @external {weakset} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/weakset\n */\n\n/ structured data\n/**\n * @external {arraybuffer} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/arraybuffer\n */\n\n/**\n * @external {dataview} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/dataview\n */\n\n/**\n * @external {json} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/json\n */\n\n/ control abstraction objects\n/**\n * @external {promise} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/promise\n */\n\n/**\n * @external {generator} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/generator\n */\n\n/**\n * @external {generatorfunction} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/generatorfunction\n */\n\n/ reflection\n/**\n * @external {reflect} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/reflect\n */\n\n/**\n * @external {proxy} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/proxy\n */\n~error",
    "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Error",
    "\n/**\n * @external {Infinity} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Infinity\n */\n\n/**\n * @external {NaN} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/NaN\n */\n\n/**\n * @external {undefined} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/undefined\n */\n\n/**\n * @external {null} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/null\n */\n\n/ Fundamental objects\n/**\n * @external {Object} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object\n */\n/**\n * @external {object} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object\n */\n\n/**\n * @external {Function} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function\n */\n/**\n * @external {function} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function\n */\n\n/**\n * @external {Boolean} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean\n */\n/**\n * @external {boolean} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean\n */\n\n/**\n * @external {Symbol} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Symbol\n */\n\n/**\n * @external {Error} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Error\n */\n\n/**\n * @external {EvalError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/EvalError\n */\n\n/**\n * @external {InternalError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/InternalError\n */\n\n/**\n * @external {RangeError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RangeError\n */\n\n/**\n * @external {ReferenceError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ReferenceError\n */\n\n/**\n * @external {SyntaxError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/SyntaxError\n */\n\n/**\n * @external {TypeError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/TypeError\n */\n\n/**\n * @external {URIError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/URIError\n */\n\n/ Numbers and dates\n/**\n * @external {Number} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number\n */\n/**\n * @external {number} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number\n */\n\n/**\n * @external {Date} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Date\n */\n\n/ Text processing\n/**\n * @external {String} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String\n */\n/**\n * @external {string} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String\n */\n\n/**\n * @external {RegExp} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RegExp\n */\n\n/ Indexed collections\n/**\n * @external {Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array\n */\n\n/**\n * @external {Int8Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int8Array\n */\n/**\n * @external {Uint8Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint8Array\n */\n\n/**\n * @external {Uint8ClampedArray} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint8ClampedArray\n */\n\n/**\n * @external {Int16Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int16Array\n */\n\n/**\n * @external {Uint16Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint16Array\n */\n\n/**\n * @external {Int32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int32Array\n */\n\n/**\n * @external {Uint32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint32Array\n */\n\n/**\n * @external {Float32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Float32Array\n */\n\n/**\n * @external {Float64Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Float64Array\n */\n\n/ Keyed collections\n/**\n * @external {Map} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Map\n */\n\n/**\n * @external {Set} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Set\n */\n\n/**\n * @external {WeakMap} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakMap\n */\n\n/**\n * @external {WeakSet} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakSet\n */\n\n/ Structured data\n/**\n * @external {ArrayBuffer} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ArrayBuffer\n */\n\n/**\n * @external {DataView} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/DataView\n */\n\n/**\n * @external {JSON} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/JSON\n */\n\n/ Control abstraction objects\n/**\n * @external {Promise} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Promise\n */\n\n/**\n * @external {Generator} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Generator\n */\n\n/**\n * @external {GeneratorFunction} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/GeneratorFunction\n */\n\n/ Reflection\n/**\n * @external {Reflect} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Reflect\n */\n\n/**\n * @external {Proxy} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Proxy\n */\n~Error",
    "external"
  ],
  [
    "\n/**\n * @external {infinity} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/infinity\n */\n\n/**\n * @external {nan} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/nan\n */\n\n/**\n * @external {undefined} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/undefined\n */\n\n/**\n * @external {null} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/null\n */\n\n/ fundamental objects\n/**\n * @external {object} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/object\n */\n/**\n * @external {object} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/object\n */\n\n/**\n * @external {function} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/function\n */\n/**\n * @external {function} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/function\n */\n\n/**\n * @external {boolean} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/boolean\n */\n/**\n * @external {boolean} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/boolean\n */\n\n/**\n * @external {symbol} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/symbol\n */\n\n/**\n * @external {error} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/error\n */\n\n/**\n * @external {evalerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/evalerror\n */\n\n/**\n * @external {internalerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/internalerror\n */\n\n/**\n * @external {rangeerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/rangeerror\n */\n\n/**\n * @external {referenceerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/referenceerror\n */\n\n/**\n * @external {syntaxerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/syntaxerror\n */\n\n/**\n * @external {typeerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/typeerror\n */\n\n/**\n * @external {urierror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/urierror\n */\n\n/ numbers and dates\n/**\n * @external {number} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/number\n */\n/**\n * @external {number} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/number\n */\n\n/**\n * @external {date} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/date\n */\n\n/ text processing\n/**\n * @external {string} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/string\n */\n/**\n * @external {string} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/string\n */\n\n/**\n * @external {regexp} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/regexp\n */\n\n/ indexed collections\n/**\n * @external {array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/array\n */\n\n/**\n * @external {int8array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int8array\n */\n/**\n * @external {uint8array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint8array\n */\n\n/**\n * @external {uint8clampedarray} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint8clampedarray\n */\n\n/**\n * @external {int16array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int16array\n */\n\n/**\n * @external {uint16array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint16array\n */\n\n/**\n * @external {int32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int32array\n */\n\n/**\n * @external {uint32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint32array\n */\n\n/**\n * @external {float32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/float32array\n */\n\n/**\n * @external {float64array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/float64array\n */\n\n/ keyed collections\n/**\n * @external {map} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/map\n */\n\n/**\n * @external {set} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/set\n */\n\n/**\n * @external {weakmap} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/weakmap\n */\n\n/**\n * @external {weakset} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/weakset\n */\n\n/ structured data\n/**\n * @external {arraybuffer} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/arraybuffer\n */\n\n/**\n * @external {dataview} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/dataview\n */\n\n/**\n * @external {json} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/json\n */\n\n/ control abstraction objects\n/**\n * @external {promise} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/promise\n */\n\n/**\n * @external {generator} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/generator\n */\n\n/**\n * @external {generatorfunction} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/generatorfunction\n */\n\n/ reflection\n/**\n * @external {reflect} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/reflect\n */\n\n/**\n * @external {proxy} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/proxy\n */\n~evalerror",
    "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/EvalError",
    "\n/**\n * @external {Infinity} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Infinity\n */\n\n/**\n * @external {NaN} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/NaN\n */\n\n/**\n * @external {undefined} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/undefined\n */\n\n/**\n * @external {null} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/null\n */\n\n/ Fundamental objects\n/**\n * @external {Object} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object\n */\n/**\n * @external {object} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object\n */\n\n/**\n * @external {Function} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function\n */\n/**\n * @external {function} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function\n */\n\n/**\n * @external {Boolean} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean\n */\n/**\n * @external {boolean} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean\n */\n\n/**\n * @external {Symbol} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Symbol\n */\n\n/**\n * @external {Error} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Error\n */\n\n/**\n * @external {EvalError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/EvalError\n */\n\n/**\n * @external {InternalError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/InternalError\n */\n\n/**\n * @external {RangeError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RangeError\n */\n\n/**\n * @external {ReferenceError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ReferenceError\n */\n\n/**\n * @external {SyntaxError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/SyntaxError\n */\n\n/**\n * @external {TypeError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/TypeError\n */\n\n/**\n * @external {URIError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/URIError\n */\n\n/ Numbers and dates\n/**\n * @external {Number} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number\n */\n/**\n * @external {number} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number\n */\n\n/**\n * @external {Date} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Date\n */\n\n/ Text processing\n/**\n * @external {String} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String\n */\n/**\n * @external {string} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String\n */\n\n/**\n * @external {RegExp} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RegExp\n */\n\n/ Indexed collections\n/**\n * @external {Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array\n */\n\n/**\n * @external {Int8Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int8Array\n */\n/**\n * @external {Uint8Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint8Array\n */\n\n/**\n * @external {Uint8ClampedArray} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint8ClampedArray\n */\n\n/**\n * @external {Int16Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int16Array\n */\n\n/**\n * @external {Uint16Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint16Array\n */\n\n/**\n * @external {Int32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int32Array\n */\n\n/**\n * @external {Uint32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint32Array\n */\n\n/**\n * @external {Float32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Float32Array\n */\n\n/**\n * @external {Float64Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Float64Array\n */\n\n/ Keyed collections\n/**\n * @external {Map} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Map\n */\n\n/**\n * @external {Set} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Set\n */\n\n/**\n * @external {WeakMap} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakMap\n */\n\n/**\n * @external {WeakSet} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakSet\n */\n\n/ Structured data\n/**\n * @external {ArrayBuffer} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ArrayBuffer\n */\n\n/**\n * @external {DataView} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/DataView\n */\n\n/**\n * @external {JSON} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/JSON\n */\n\n/ Control abstraction objects\n/**\n * @external {Promise} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Promise\n */\n\n/**\n * @external {Generator} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Generator\n */\n\n/**\n * @external {GeneratorFunction} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/GeneratorFunction\n */\n\n/ Reflection\n/**\n * @external {Reflect} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Reflect\n */\n\n/**\n * @external {Proxy} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Proxy\n */\n~EvalError",
    "external"
  ],
  [
    "\n/**\n * @external {infinity} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/infinity\n */\n\n/**\n * @external {nan} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/nan\n */\n\n/**\n * @external {undefined} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/undefined\n */\n\n/**\n * @external {null} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/null\n */\n\n/ fundamental objects\n/**\n * @external {object} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/object\n */\n/**\n * @external {object} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/object\n */\n\n/**\n * @external {function} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/function\n */\n/**\n * @external {function} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/function\n */\n\n/**\n * @external {boolean} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/boolean\n */\n/**\n * @external {boolean} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/boolean\n */\n\n/**\n * @external {symbol} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/symbol\n */\n\n/**\n * @external {error} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/error\n */\n\n/**\n * @external {evalerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/evalerror\n */\n\n/**\n * @external {internalerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/internalerror\n */\n\n/**\n * @external {rangeerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/rangeerror\n */\n\n/**\n * @external {referenceerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/referenceerror\n */\n\n/**\n * @external {syntaxerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/syntaxerror\n */\n\n/**\n * @external {typeerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/typeerror\n */\n\n/**\n * @external {urierror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/urierror\n */\n\n/ numbers and dates\n/**\n * @external {number} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/number\n */\n/**\n * @external {number} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/number\n */\n\n/**\n * @external {date} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/date\n */\n\n/ text processing\n/**\n * @external {string} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/string\n */\n/**\n * @external {string} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/string\n */\n\n/**\n * @external {regexp} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/regexp\n */\n\n/ indexed collections\n/**\n * @external {array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/array\n */\n\n/**\n * @external {int8array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int8array\n */\n/**\n * @external {uint8array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint8array\n */\n\n/**\n * @external {uint8clampedarray} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint8clampedarray\n */\n\n/**\n * @external {int16array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int16array\n */\n\n/**\n * @external {uint16array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint16array\n */\n\n/**\n * @external {int32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int32array\n */\n\n/**\n * @external {uint32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint32array\n */\n\n/**\n * @external {float32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/float32array\n */\n\n/**\n * @external {float64array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/float64array\n */\n\n/ keyed collections\n/**\n * @external {map} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/map\n */\n\n/**\n * @external {set} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/set\n */\n\n/**\n * @external {weakmap} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/weakmap\n */\n\n/**\n * @external {weakset} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/weakset\n */\n\n/ structured data\n/**\n * @external {arraybuffer} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/arraybuffer\n */\n\n/**\n * @external {dataview} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/dataview\n */\n\n/**\n * @external {json} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/json\n */\n\n/ control abstraction objects\n/**\n * @external {promise} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/promise\n */\n\n/**\n * @external {generator} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/generator\n */\n\n/**\n * @external {generatorfunction} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/generatorfunction\n */\n\n/ reflection\n/**\n * @external {reflect} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/reflect\n */\n\n/**\n * @external {proxy} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/proxy\n */\n~float32array",
    "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Float32Array",
    "\n/**\n * @external {Infinity} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Infinity\n */\n\n/**\n * @external {NaN} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/NaN\n */\n\n/**\n * @external {undefined} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/undefined\n */\n\n/**\n * @external {null} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/null\n */\n\n/ Fundamental objects\n/**\n * @external {Object} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object\n */\n/**\n * @external {object} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object\n */\n\n/**\n * @external {Function} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function\n */\n/**\n * @external {function} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function\n */\n\n/**\n * @external {Boolean} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean\n */\n/**\n * @external {boolean} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean\n */\n\n/**\n * @external {Symbol} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Symbol\n */\n\n/**\n * @external {Error} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Error\n */\n\n/**\n * @external {EvalError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/EvalError\n */\n\n/**\n * @external {InternalError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/InternalError\n */\n\n/**\n * @external {RangeError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RangeError\n */\n\n/**\n * @external {ReferenceError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ReferenceError\n */\n\n/**\n * @external {SyntaxError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/SyntaxError\n */\n\n/**\n * @external {TypeError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/TypeError\n */\n\n/**\n * @external {URIError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/URIError\n */\n\n/ Numbers and dates\n/**\n * @external {Number} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number\n */\n/**\n * @external {number} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number\n */\n\n/**\n * @external {Date} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Date\n */\n\n/ Text processing\n/**\n * @external {String} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String\n */\n/**\n * @external {string} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String\n */\n\n/**\n * @external {RegExp} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RegExp\n */\n\n/ Indexed collections\n/**\n * @external {Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array\n */\n\n/**\n * @external {Int8Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int8Array\n */\n/**\n * @external {Uint8Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint8Array\n */\n\n/**\n * @external {Uint8ClampedArray} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint8ClampedArray\n */\n\n/**\n * @external {Int16Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int16Array\n */\n\n/**\n * @external {Uint16Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint16Array\n */\n\n/**\n * @external {Int32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int32Array\n */\n\n/**\n * @external {Uint32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint32Array\n */\n\n/**\n * @external {Float32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Float32Array\n */\n\n/**\n * @external {Float64Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Float64Array\n */\n\n/ Keyed collections\n/**\n * @external {Map} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Map\n */\n\n/**\n * @external {Set} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Set\n */\n\n/**\n * @external {WeakMap} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakMap\n */\n\n/**\n * @external {WeakSet} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakSet\n */\n\n/ Structured data\n/**\n * @external {ArrayBuffer} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ArrayBuffer\n */\n\n/**\n * @external {DataView} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/DataView\n */\n\n/**\n * @external {JSON} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/JSON\n */\n\n/ Control abstraction objects\n/**\n * @external {Promise} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Promise\n */\n\n/**\n * @external {Generator} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Generator\n */\n\n/**\n * @external {GeneratorFunction} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/GeneratorFunction\n */\n\n/ Reflection\n/**\n * @external {Reflect} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Reflect\n */\n\n/**\n * @external {Proxy} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Proxy\n */\n~Float32Array",
    "external"
  ],
  [
    "\n/**\n * @external {infinity} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/infinity\n */\n\n/**\n * @external {nan} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/nan\n */\n\n/**\n * @external {undefined} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/undefined\n */\n\n/**\n * @external {null} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/null\n */\n\n/ fundamental objects\n/**\n * @external {object} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/object\n */\n/**\n * @external {object} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/object\n */\n\n/**\n * @external {function} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/function\n */\n/**\n * @external {function} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/function\n */\n\n/**\n * @external {boolean} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/boolean\n */\n/**\n * @external {boolean} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/boolean\n */\n\n/**\n * @external {symbol} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/symbol\n */\n\n/**\n * @external {error} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/error\n */\n\n/**\n * @external {evalerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/evalerror\n */\n\n/**\n * @external {internalerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/internalerror\n */\n\n/**\n * @external {rangeerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/rangeerror\n */\n\n/**\n * @external {referenceerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/referenceerror\n */\n\n/**\n * @external {syntaxerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/syntaxerror\n */\n\n/**\n * @external {typeerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/typeerror\n */\n\n/**\n * @external {urierror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/urierror\n */\n\n/ numbers and dates\n/**\n * @external {number} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/number\n */\n/**\n * @external {number} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/number\n */\n\n/**\n * @external {date} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/date\n */\n\n/ text processing\n/**\n * @external {string} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/string\n */\n/**\n * @external {string} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/string\n */\n\n/**\n * @external {regexp} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/regexp\n */\n\n/ indexed collections\n/**\n * @external {array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/array\n */\n\n/**\n * @external {int8array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int8array\n */\n/**\n * @external {uint8array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint8array\n */\n\n/**\n * @external {uint8clampedarray} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint8clampedarray\n */\n\n/**\n * @external {int16array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int16array\n */\n\n/**\n * @external {uint16array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint16array\n */\n\n/**\n * @external {int32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int32array\n */\n\n/**\n * @external {uint32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint32array\n */\n\n/**\n * @external {float32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/float32array\n */\n\n/**\n * @external {float64array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/float64array\n */\n\n/ keyed collections\n/**\n * @external {map} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/map\n */\n\n/**\n * @external {set} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/set\n */\n\n/**\n * @external {weakmap} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/weakmap\n */\n\n/**\n * @external {weakset} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/weakset\n */\n\n/ structured data\n/**\n * @external {arraybuffer} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/arraybuffer\n */\n\n/**\n * @external {dataview} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/dataview\n */\n\n/**\n * @external {json} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/json\n */\n\n/ control abstraction objects\n/**\n * @external {promise} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/promise\n */\n\n/**\n * @external {generator} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/generator\n */\n\n/**\n * @external {generatorfunction} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/generatorfunction\n */\n\n/ reflection\n/**\n * @external {reflect} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/reflect\n */\n\n/**\n * @external {proxy} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/proxy\n */\n~float64array",
    "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Float64Array",
    "\n/**\n * @external {Infinity} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Infinity\n */\n\n/**\n * @external {NaN} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/NaN\n */\n\n/**\n * @external {undefined} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/undefined\n */\n\n/**\n * @external {null} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/null\n */\n\n/ Fundamental objects\n/**\n * @external {Object} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object\n */\n/**\n * @external {object} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object\n */\n\n/**\n * @external {Function} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function\n */\n/**\n * @external {function} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function\n */\n\n/**\n * @external {Boolean} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean\n */\n/**\n * @external {boolean} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean\n */\n\n/**\n * @external {Symbol} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Symbol\n */\n\n/**\n * @external {Error} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Error\n */\n\n/**\n * @external {EvalError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/EvalError\n */\n\n/**\n * @external {InternalError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/InternalError\n */\n\n/**\n * @external {RangeError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RangeError\n */\n\n/**\n * @external {ReferenceError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ReferenceError\n */\n\n/**\n * @external {SyntaxError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/SyntaxError\n */\n\n/**\n * @external {TypeError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/TypeError\n */\n\n/**\n * @external {URIError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/URIError\n */\n\n/ Numbers and dates\n/**\n * @external {Number} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number\n */\n/**\n * @external {number} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number\n */\n\n/**\n * @external {Date} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Date\n */\n\n/ Text processing\n/**\n * @external {String} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String\n */\n/**\n * @external {string} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String\n */\n\n/**\n * @external {RegExp} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RegExp\n */\n\n/ Indexed collections\n/**\n * @external {Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array\n */\n\n/**\n * @external {Int8Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int8Array\n */\n/**\n * @external {Uint8Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint8Array\n */\n\n/**\n * @external {Uint8ClampedArray} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint8ClampedArray\n */\n\n/**\n * @external {Int16Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int16Array\n */\n\n/**\n * @external {Uint16Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint16Array\n */\n\n/**\n * @external {Int32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int32Array\n */\n\n/**\n * @external {Uint32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint32Array\n */\n\n/**\n * @external {Float32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Float32Array\n */\n\n/**\n * @external {Float64Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Float64Array\n */\n\n/ Keyed collections\n/**\n * @external {Map} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Map\n */\n\n/**\n * @external {Set} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Set\n */\n\n/**\n * @external {WeakMap} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakMap\n */\n\n/**\n * @external {WeakSet} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakSet\n */\n\n/ Structured data\n/**\n * @external {ArrayBuffer} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ArrayBuffer\n */\n\n/**\n * @external {DataView} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/DataView\n */\n\n/**\n * @external {JSON} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/JSON\n */\n\n/ Control abstraction objects\n/**\n * @external {Promise} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Promise\n */\n\n/**\n * @external {Generator} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Generator\n */\n\n/**\n * @external {GeneratorFunction} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/GeneratorFunction\n */\n\n/ Reflection\n/**\n * @external {Reflect} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Reflect\n */\n\n/**\n * @external {Proxy} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Proxy\n */\n~Float64Array",
    "external"
  ],
  [
    "\n/**\n * @external {infinity} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/infinity\n */\n\n/**\n * @external {nan} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/nan\n */\n\n/**\n * @external {undefined} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/undefined\n */\n\n/**\n * @external {null} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/null\n */\n\n/ fundamental objects\n/**\n * @external {object} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/object\n */\n/**\n * @external {object} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/object\n */\n\n/**\n * @external {function} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/function\n */\n/**\n * @external {function} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/function\n */\n\n/**\n * @external {boolean} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/boolean\n */\n/**\n * @external {boolean} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/boolean\n */\n\n/**\n * @external {symbol} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/symbol\n */\n\n/**\n * @external {error} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/error\n */\n\n/**\n * @external {evalerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/evalerror\n */\n\n/**\n * @external {internalerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/internalerror\n */\n\n/**\n * @external {rangeerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/rangeerror\n */\n\n/**\n * @external {referenceerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/referenceerror\n */\n\n/**\n * @external {syntaxerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/syntaxerror\n */\n\n/**\n * @external {typeerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/typeerror\n */\n\n/**\n * @external {urierror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/urierror\n */\n\n/ numbers and dates\n/**\n * @external {number} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/number\n */\n/**\n * @external {number} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/number\n */\n\n/**\n * @external {date} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/date\n */\n\n/ text processing\n/**\n * @external {string} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/string\n */\n/**\n * @external {string} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/string\n */\n\n/**\n * @external {regexp} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/regexp\n */\n\n/ indexed collections\n/**\n * @external {array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/array\n */\n\n/**\n * @external {int8array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int8array\n */\n/**\n * @external {uint8array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint8array\n */\n\n/**\n * @external {uint8clampedarray} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint8clampedarray\n */\n\n/**\n * @external {int16array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int16array\n */\n\n/**\n * @external {uint16array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint16array\n */\n\n/**\n * @external {int32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int32array\n */\n\n/**\n * @external {uint32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint32array\n */\n\n/**\n * @external {float32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/float32array\n */\n\n/**\n * @external {float64array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/float64array\n */\n\n/ keyed collections\n/**\n * @external {map} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/map\n */\n\n/**\n * @external {set} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/set\n */\n\n/**\n * @external {weakmap} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/weakmap\n */\n\n/**\n * @external {weakset} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/weakset\n */\n\n/ structured data\n/**\n * @external {arraybuffer} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/arraybuffer\n */\n\n/**\n * @external {dataview} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/dataview\n */\n\n/**\n * @external {json} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/json\n */\n\n/ control abstraction objects\n/**\n * @external {promise} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/promise\n */\n\n/**\n * @external {generator} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/generator\n */\n\n/**\n * @external {generatorfunction} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/generatorfunction\n */\n\n/ reflection\n/**\n * @external {reflect} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/reflect\n */\n\n/**\n * @external {proxy} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/proxy\n */\n~function",
    "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function",
    "\n/**\n * @external {Infinity} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Infinity\n */\n\n/**\n * @external {NaN} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/NaN\n */\n\n/**\n * @external {undefined} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/undefined\n */\n\n/**\n * @external {null} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/null\n */\n\n/ Fundamental objects\n/**\n * @external {Object} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object\n */\n/**\n * @external {object} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object\n */\n\n/**\n * @external {Function} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function\n */\n/**\n * @external {function} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function\n */\n\n/**\n * @external {Boolean} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean\n */\n/**\n * @external {boolean} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean\n */\n\n/**\n * @external {Symbol} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Symbol\n */\n\n/**\n * @external {Error} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Error\n */\n\n/**\n * @external {EvalError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/EvalError\n */\n\n/**\n * @external {InternalError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/InternalError\n */\n\n/**\n * @external {RangeError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RangeError\n */\n\n/**\n * @external {ReferenceError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ReferenceError\n */\n\n/**\n * @external {SyntaxError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/SyntaxError\n */\n\n/**\n * @external {TypeError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/TypeError\n */\n\n/**\n * @external {URIError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/URIError\n */\n\n/ Numbers and dates\n/**\n * @external {Number} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number\n */\n/**\n * @external {number} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number\n */\n\n/**\n * @external {Date} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Date\n */\n\n/ Text processing\n/**\n * @external {String} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String\n */\n/**\n * @external {string} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String\n */\n\n/**\n * @external {RegExp} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RegExp\n */\n\n/ Indexed collections\n/**\n * @external {Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array\n */\n\n/**\n * @external {Int8Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int8Array\n */\n/**\n * @external {Uint8Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint8Array\n */\n\n/**\n * @external {Uint8ClampedArray} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint8ClampedArray\n */\n\n/**\n * @external {Int16Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int16Array\n */\n\n/**\n * @external {Uint16Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint16Array\n */\n\n/**\n * @external {Int32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int32Array\n */\n\n/**\n * @external {Uint32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint32Array\n */\n\n/**\n * @external {Float32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Float32Array\n */\n\n/**\n * @external {Float64Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Float64Array\n */\n\n/ Keyed collections\n/**\n * @external {Map} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Map\n */\n\n/**\n * @external {Set} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Set\n */\n\n/**\n * @external {WeakMap} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakMap\n */\n\n/**\n * @external {WeakSet} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakSet\n */\n\n/ Structured data\n/**\n * @external {ArrayBuffer} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ArrayBuffer\n */\n\n/**\n * @external {DataView} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/DataView\n */\n\n/**\n * @external {JSON} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/JSON\n */\n\n/ Control abstraction objects\n/**\n * @external {Promise} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Promise\n */\n\n/**\n * @external {Generator} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Generator\n */\n\n/**\n * @external {GeneratorFunction} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/GeneratorFunction\n */\n\n/ Reflection\n/**\n * @external {Reflect} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Reflect\n */\n\n/**\n * @external {Proxy} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Proxy\n */\n~Function",
    "external"
  ],
  [
    "\n/**\n * @external {infinity} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/infinity\n */\n\n/**\n * @external {nan} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/nan\n */\n\n/**\n * @external {undefined} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/undefined\n */\n\n/**\n * @external {null} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/null\n */\n\n/ fundamental objects\n/**\n * @external {object} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/object\n */\n/**\n * @external {object} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/object\n */\n\n/**\n * @external {function} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/function\n */\n/**\n * @external {function} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/function\n */\n\n/**\n * @external {boolean} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/boolean\n */\n/**\n * @external {boolean} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/boolean\n */\n\n/**\n * @external {symbol} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/symbol\n */\n\n/**\n * @external {error} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/error\n */\n\n/**\n * @external {evalerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/evalerror\n */\n\n/**\n * @external {internalerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/internalerror\n */\n\n/**\n * @external {rangeerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/rangeerror\n */\n\n/**\n * @external {referenceerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/referenceerror\n */\n\n/**\n * @external {syntaxerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/syntaxerror\n */\n\n/**\n * @external {typeerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/typeerror\n */\n\n/**\n * @external {urierror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/urierror\n */\n\n/ numbers and dates\n/**\n * @external {number} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/number\n */\n/**\n * @external {number} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/number\n */\n\n/**\n * @external {date} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/date\n */\n\n/ text processing\n/**\n * @external {string} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/string\n */\n/**\n * @external {string} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/string\n */\n\n/**\n * @external {regexp} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/regexp\n */\n\n/ indexed collections\n/**\n * @external {array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/array\n */\n\n/**\n * @external {int8array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int8array\n */\n/**\n * @external {uint8array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint8array\n */\n\n/**\n * @external {uint8clampedarray} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint8clampedarray\n */\n\n/**\n * @external {int16array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int16array\n */\n\n/**\n * @external {uint16array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint16array\n */\n\n/**\n * @external {int32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int32array\n */\n\n/**\n * @external {uint32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint32array\n */\n\n/**\n * @external {float32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/float32array\n */\n\n/**\n * @external {float64array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/float64array\n */\n\n/ keyed collections\n/**\n * @external {map} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/map\n */\n\n/**\n * @external {set} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/set\n */\n\n/**\n * @external {weakmap} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/weakmap\n */\n\n/**\n * @external {weakset} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/weakset\n */\n\n/ structured data\n/**\n * @external {arraybuffer} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/arraybuffer\n */\n\n/**\n * @external {dataview} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/dataview\n */\n\n/**\n * @external {json} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/json\n */\n\n/ control abstraction objects\n/**\n * @external {promise} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/promise\n */\n\n/**\n * @external {generator} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/generator\n */\n\n/**\n * @external {generatorfunction} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/generatorfunction\n */\n\n/ reflection\n/**\n * @external {reflect} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/reflect\n */\n\n/**\n * @external {proxy} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/proxy\n */\n~generator",
    "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Generator",
    "\n/**\n * @external {Infinity} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Infinity\n */\n\n/**\n * @external {NaN} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/NaN\n */\n\n/**\n * @external {undefined} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/undefined\n */\n\n/**\n * @external {null} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/null\n */\n\n/ Fundamental objects\n/**\n * @external {Object} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object\n */\n/**\n * @external {object} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object\n */\n\n/**\n * @external {Function} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function\n */\n/**\n * @external {function} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function\n */\n\n/**\n * @external {Boolean} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean\n */\n/**\n * @external {boolean} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean\n */\n\n/**\n * @external {Symbol} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Symbol\n */\n\n/**\n * @external {Error} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Error\n */\n\n/**\n * @external {EvalError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/EvalError\n */\n\n/**\n * @external {InternalError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/InternalError\n */\n\n/**\n * @external {RangeError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RangeError\n */\n\n/**\n * @external {ReferenceError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ReferenceError\n */\n\n/**\n * @external {SyntaxError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/SyntaxError\n */\n\n/**\n * @external {TypeError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/TypeError\n */\n\n/**\n * @external {URIError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/URIError\n */\n\n/ Numbers and dates\n/**\n * @external {Number} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number\n */\n/**\n * @external {number} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number\n */\n\n/**\n * @external {Date} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Date\n */\n\n/ Text processing\n/**\n * @external {String} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String\n */\n/**\n * @external {string} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String\n */\n\n/**\n * @external {RegExp} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RegExp\n */\n\n/ Indexed collections\n/**\n * @external {Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array\n */\n\n/**\n * @external {Int8Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int8Array\n */\n/**\n * @external {Uint8Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint8Array\n */\n\n/**\n * @external {Uint8ClampedArray} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint8ClampedArray\n */\n\n/**\n * @external {Int16Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int16Array\n */\n\n/**\n * @external {Uint16Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint16Array\n */\n\n/**\n * @external {Int32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int32Array\n */\n\n/**\n * @external {Uint32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint32Array\n */\n\n/**\n * @external {Float32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Float32Array\n */\n\n/**\n * @external {Float64Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Float64Array\n */\n\n/ Keyed collections\n/**\n * @external {Map} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Map\n */\n\n/**\n * @external {Set} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Set\n */\n\n/**\n * @external {WeakMap} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakMap\n */\n\n/**\n * @external {WeakSet} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakSet\n */\n\n/ Structured data\n/**\n * @external {ArrayBuffer} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ArrayBuffer\n */\n\n/**\n * @external {DataView} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/DataView\n */\n\n/**\n * @external {JSON} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/JSON\n */\n\n/ Control abstraction objects\n/**\n * @external {Promise} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Promise\n */\n\n/**\n * @external {Generator} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Generator\n */\n\n/**\n * @external {GeneratorFunction} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/GeneratorFunction\n */\n\n/ Reflection\n/**\n * @external {Reflect} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Reflect\n */\n\n/**\n * @external {Proxy} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Proxy\n */\n~Generator",
    "external"
  ],
  [
    "\n/**\n * @external {infinity} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/infinity\n */\n\n/**\n * @external {nan} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/nan\n */\n\n/**\n * @external {undefined} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/undefined\n */\n\n/**\n * @external {null} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/null\n */\n\n/ fundamental objects\n/**\n * @external {object} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/object\n */\n/**\n * @external {object} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/object\n */\n\n/**\n * @external {function} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/function\n */\n/**\n * @external {function} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/function\n */\n\n/**\n * @external {boolean} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/boolean\n */\n/**\n * @external {boolean} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/boolean\n */\n\n/**\n * @external {symbol} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/symbol\n */\n\n/**\n * @external {error} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/error\n */\n\n/**\n * @external {evalerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/evalerror\n */\n\n/**\n * @external {internalerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/internalerror\n */\n\n/**\n * @external {rangeerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/rangeerror\n */\n\n/**\n * @external {referenceerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/referenceerror\n */\n\n/**\n * @external {syntaxerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/syntaxerror\n */\n\n/**\n * @external {typeerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/typeerror\n */\n\n/**\n * @external {urierror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/urierror\n */\n\n/ numbers and dates\n/**\n * @external {number} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/number\n */\n/**\n * @external {number} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/number\n */\n\n/**\n * @external {date} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/date\n */\n\n/ text processing\n/**\n * @external {string} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/string\n */\n/**\n * @external {string} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/string\n */\n\n/**\n * @external {regexp} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/regexp\n */\n\n/ indexed collections\n/**\n * @external {array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/array\n */\n\n/**\n * @external {int8array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int8array\n */\n/**\n * @external {uint8array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint8array\n */\n\n/**\n * @external {uint8clampedarray} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint8clampedarray\n */\n\n/**\n * @external {int16array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int16array\n */\n\n/**\n * @external {uint16array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint16array\n */\n\n/**\n * @external {int32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int32array\n */\n\n/**\n * @external {uint32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint32array\n */\n\n/**\n * @external {float32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/float32array\n */\n\n/**\n * @external {float64array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/float64array\n */\n\n/ keyed collections\n/**\n * @external {map} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/map\n */\n\n/**\n * @external {set} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/set\n */\n\n/**\n * @external {weakmap} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/weakmap\n */\n\n/**\n * @external {weakset} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/weakset\n */\n\n/ structured data\n/**\n * @external {arraybuffer} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/arraybuffer\n */\n\n/**\n * @external {dataview} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/dataview\n */\n\n/**\n * @external {json} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/json\n */\n\n/ control abstraction objects\n/**\n * @external {promise} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/promise\n */\n\n/**\n * @external {generator} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/generator\n */\n\n/**\n * @external {generatorfunction} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/generatorfunction\n */\n\n/ reflection\n/**\n * @external {reflect} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/reflect\n */\n\n/**\n * @external {proxy} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/proxy\n */\n~generatorfunction",
    "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/GeneratorFunction",
    "\n/**\n * @external {Infinity} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Infinity\n */\n\n/**\n * @external {NaN} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/NaN\n */\n\n/**\n * @external {undefined} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/undefined\n */\n\n/**\n * @external {null} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/null\n */\n\n/ Fundamental objects\n/**\n * @external {Object} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object\n */\n/**\n * @external {object} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object\n */\n\n/**\n * @external {Function} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function\n */\n/**\n * @external {function} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function\n */\n\n/**\n * @external {Boolean} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean\n */\n/**\n * @external {boolean} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean\n */\n\n/**\n * @external {Symbol} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Symbol\n */\n\n/**\n * @external {Error} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Error\n */\n\n/**\n * @external {EvalError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/EvalError\n */\n\n/**\n * @external {InternalError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/InternalError\n */\n\n/**\n * @external {RangeError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RangeError\n */\n\n/**\n * @external {ReferenceError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ReferenceError\n */\n\n/**\n * @external {SyntaxError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/SyntaxError\n */\n\n/**\n * @external {TypeError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/TypeError\n */\n\n/**\n * @external {URIError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/URIError\n */\n\n/ Numbers and dates\n/**\n * @external {Number} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number\n */\n/**\n * @external {number} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number\n */\n\n/**\n * @external {Date} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Date\n */\n\n/ Text processing\n/**\n * @external {String} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String\n */\n/**\n * @external {string} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String\n */\n\n/**\n * @external {RegExp} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RegExp\n */\n\n/ Indexed collections\n/**\n * @external {Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array\n */\n\n/**\n * @external {Int8Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int8Array\n */\n/**\n * @external {Uint8Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint8Array\n */\n\n/**\n * @external {Uint8ClampedArray} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint8ClampedArray\n */\n\n/**\n * @external {Int16Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int16Array\n */\n\n/**\n * @external {Uint16Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint16Array\n */\n\n/**\n * @external {Int32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int32Array\n */\n\n/**\n * @external {Uint32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint32Array\n */\n\n/**\n * @external {Float32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Float32Array\n */\n\n/**\n * @external {Float64Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Float64Array\n */\n\n/ Keyed collections\n/**\n * @external {Map} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Map\n */\n\n/**\n * @external {Set} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Set\n */\n\n/**\n * @external {WeakMap} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakMap\n */\n\n/**\n * @external {WeakSet} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakSet\n */\n\n/ Structured data\n/**\n * @external {ArrayBuffer} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ArrayBuffer\n */\n\n/**\n * @external {DataView} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/DataView\n */\n\n/**\n * @external {JSON} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/JSON\n */\n\n/ Control abstraction objects\n/**\n * @external {Promise} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Promise\n */\n\n/**\n * @external {Generator} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Generator\n */\n\n/**\n * @external {GeneratorFunction} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/GeneratorFunction\n */\n\n/ Reflection\n/**\n * @external {Reflect} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Reflect\n */\n\n/**\n * @external {Proxy} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Proxy\n */\n~GeneratorFunction",
    "external"
  ],
  [
    "\n/**\n * @external {infinity} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/infinity\n */\n\n/**\n * @external {nan} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/nan\n */\n\n/**\n * @external {undefined} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/undefined\n */\n\n/**\n * @external {null} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/null\n */\n\n/ fundamental objects\n/**\n * @external {object} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/object\n */\n/**\n * @external {object} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/object\n */\n\n/**\n * @external {function} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/function\n */\n/**\n * @external {function} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/function\n */\n\n/**\n * @external {boolean} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/boolean\n */\n/**\n * @external {boolean} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/boolean\n */\n\n/**\n * @external {symbol} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/symbol\n */\n\n/**\n * @external {error} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/error\n */\n\n/**\n * @external {evalerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/evalerror\n */\n\n/**\n * @external {internalerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/internalerror\n */\n\n/**\n * @external {rangeerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/rangeerror\n */\n\n/**\n * @external {referenceerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/referenceerror\n */\n\n/**\n * @external {syntaxerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/syntaxerror\n */\n\n/**\n * @external {typeerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/typeerror\n */\n\n/**\n * @external {urierror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/urierror\n */\n\n/ numbers and dates\n/**\n * @external {number} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/number\n */\n/**\n * @external {number} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/number\n */\n\n/**\n * @external {date} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/date\n */\n\n/ text processing\n/**\n * @external {string} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/string\n */\n/**\n * @external {string} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/string\n */\n\n/**\n * @external {regexp} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/regexp\n */\n\n/ indexed collections\n/**\n * @external {array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/array\n */\n\n/**\n * @external {int8array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int8array\n */\n/**\n * @external {uint8array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint8array\n */\n\n/**\n * @external {uint8clampedarray} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint8clampedarray\n */\n\n/**\n * @external {int16array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int16array\n */\n\n/**\n * @external {uint16array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint16array\n */\n\n/**\n * @external {int32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int32array\n */\n\n/**\n * @external {uint32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint32array\n */\n\n/**\n * @external {float32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/float32array\n */\n\n/**\n * @external {float64array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/float64array\n */\n\n/ keyed collections\n/**\n * @external {map} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/map\n */\n\n/**\n * @external {set} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/set\n */\n\n/**\n * @external {weakmap} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/weakmap\n */\n\n/**\n * @external {weakset} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/weakset\n */\n\n/ structured data\n/**\n * @external {arraybuffer} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/arraybuffer\n */\n\n/**\n * @external {dataview} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/dataview\n */\n\n/**\n * @external {json} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/json\n */\n\n/ control abstraction objects\n/**\n * @external {promise} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/promise\n */\n\n/**\n * @external {generator} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/generator\n */\n\n/**\n * @external {generatorfunction} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/generatorfunction\n */\n\n/ reflection\n/**\n * @external {reflect} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/reflect\n */\n\n/**\n * @external {proxy} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/proxy\n */\n~infinity",
    "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Infinity",
    "\n/**\n * @external {Infinity} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Infinity\n */\n\n/**\n * @external {NaN} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/NaN\n */\n\n/**\n * @external {undefined} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/undefined\n */\n\n/**\n * @external {null} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/null\n */\n\n/ Fundamental objects\n/**\n * @external {Object} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object\n */\n/**\n * @external {object} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object\n */\n\n/**\n * @external {Function} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function\n */\n/**\n * @external {function} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function\n */\n\n/**\n * @external {Boolean} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean\n */\n/**\n * @external {boolean} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean\n */\n\n/**\n * @external {Symbol} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Symbol\n */\n\n/**\n * @external {Error} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Error\n */\n\n/**\n * @external {EvalError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/EvalError\n */\n\n/**\n * @external {InternalError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/InternalError\n */\n\n/**\n * @external {RangeError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RangeError\n */\n\n/**\n * @external {ReferenceError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ReferenceError\n */\n\n/**\n * @external {SyntaxError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/SyntaxError\n */\n\n/**\n * @external {TypeError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/TypeError\n */\n\n/**\n * @external {URIError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/URIError\n */\n\n/ Numbers and dates\n/**\n * @external {Number} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number\n */\n/**\n * @external {number} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number\n */\n\n/**\n * @external {Date} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Date\n */\n\n/ Text processing\n/**\n * @external {String} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String\n */\n/**\n * @external {string} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String\n */\n\n/**\n * @external {RegExp} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RegExp\n */\n\n/ Indexed collections\n/**\n * @external {Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array\n */\n\n/**\n * @external {Int8Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int8Array\n */\n/**\n * @external {Uint8Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint8Array\n */\n\n/**\n * @external {Uint8ClampedArray} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint8ClampedArray\n */\n\n/**\n * @external {Int16Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int16Array\n */\n\n/**\n * @external {Uint16Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint16Array\n */\n\n/**\n * @external {Int32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int32Array\n */\n\n/**\n * @external {Uint32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint32Array\n */\n\n/**\n * @external {Float32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Float32Array\n */\n\n/**\n * @external {Float64Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Float64Array\n */\n\n/ Keyed collections\n/**\n * @external {Map} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Map\n */\n\n/**\n * @external {Set} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Set\n */\n\n/**\n * @external {WeakMap} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakMap\n */\n\n/**\n * @external {WeakSet} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakSet\n */\n\n/ Structured data\n/**\n * @external {ArrayBuffer} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ArrayBuffer\n */\n\n/**\n * @external {DataView} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/DataView\n */\n\n/**\n * @external {JSON} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/JSON\n */\n\n/ Control abstraction objects\n/**\n * @external {Promise} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Promise\n */\n\n/**\n * @external {Generator} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Generator\n */\n\n/**\n * @external {GeneratorFunction} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/GeneratorFunction\n */\n\n/ Reflection\n/**\n * @external {Reflect} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Reflect\n */\n\n/**\n * @external {Proxy} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Proxy\n */\n~Infinity",
    "external"
  ],
  [
    "\n/**\n * @external {infinity} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/infinity\n */\n\n/**\n * @external {nan} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/nan\n */\n\n/**\n * @external {undefined} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/undefined\n */\n\n/**\n * @external {null} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/null\n */\n\n/ fundamental objects\n/**\n * @external {object} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/object\n */\n/**\n * @external {object} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/object\n */\n\n/**\n * @external {function} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/function\n */\n/**\n * @external {function} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/function\n */\n\n/**\n * @external {boolean} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/boolean\n */\n/**\n * @external {boolean} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/boolean\n */\n\n/**\n * @external {symbol} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/symbol\n */\n\n/**\n * @external {error} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/error\n */\n\n/**\n * @external {evalerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/evalerror\n */\n\n/**\n * @external {internalerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/internalerror\n */\n\n/**\n * @external {rangeerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/rangeerror\n */\n\n/**\n * @external {referenceerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/referenceerror\n */\n\n/**\n * @external {syntaxerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/syntaxerror\n */\n\n/**\n * @external {typeerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/typeerror\n */\n\n/**\n * @external {urierror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/urierror\n */\n\n/ numbers and dates\n/**\n * @external {number} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/number\n */\n/**\n * @external {number} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/number\n */\n\n/**\n * @external {date} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/date\n */\n\n/ text processing\n/**\n * @external {string} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/string\n */\n/**\n * @external {string} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/string\n */\n\n/**\n * @external {regexp} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/regexp\n */\n\n/ indexed collections\n/**\n * @external {array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/array\n */\n\n/**\n * @external {int8array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int8array\n */\n/**\n * @external {uint8array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint8array\n */\n\n/**\n * @external {uint8clampedarray} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint8clampedarray\n */\n\n/**\n * @external {int16array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int16array\n */\n\n/**\n * @external {uint16array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint16array\n */\n\n/**\n * @external {int32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int32array\n */\n\n/**\n * @external {uint32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint32array\n */\n\n/**\n * @external {float32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/float32array\n */\n\n/**\n * @external {float64array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/float64array\n */\n\n/ keyed collections\n/**\n * @external {map} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/map\n */\n\n/**\n * @external {set} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/set\n */\n\n/**\n * @external {weakmap} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/weakmap\n */\n\n/**\n * @external {weakset} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/weakset\n */\n\n/ structured data\n/**\n * @external {arraybuffer} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/arraybuffer\n */\n\n/**\n * @external {dataview} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/dataview\n */\n\n/**\n * @external {json} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/json\n */\n\n/ control abstraction objects\n/**\n * @external {promise} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/promise\n */\n\n/**\n * @external {generator} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/generator\n */\n\n/**\n * @external {generatorfunction} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/generatorfunction\n */\n\n/ reflection\n/**\n * @external {reflect} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/reflect\n */\n\n/**\n * @external {proxy} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/proxy\n */\n~int16array",
    "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int16Array",
    "\n/**\n * @external {Infinity} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Infinity\n */\n\n/**\n * @external {NaN} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/NaN\n */\n\n/**\n * @external {undefined} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/undefined\n */\n\n/**\n * @external {null} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/null\n */\n\n/ Fundamental objects\n/**\n * @external {Object} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object\n */\n/**\n * @external {object} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object\n */\n\n/**\n * @external {Function} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function\n */\n/**\n * @external {function} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function\n */\n\n/**\n * @external {Boolean} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean\n */\n/**\n * @external {boolean} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean\n */\n\n/**\n * @external {Symbol} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Symbol\n */\n\n/**\n * @external {Error} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Error\n */\n\n/**\n * @external {EvalError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/EvalError\n */\n\n/**\n * @external {InternalError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/InternalError\n */\n\n/**\n * @external {RangeError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RangeError\n */\n\n/**\n * @external {ReferenceError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ReferenceError\n */\n\n/**\n * @external {SyntaxError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/SyntaxError\n */\n\n/**\n * @external {TypeError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/TypeError\n */\n\n/**\n * @external {URIError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/URIError\n */\n\n/ Numbers and dates\n/**\n * @external {Number} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number\n */\n/**\n * @external {number} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number\n */\n\n/**\n * @external {Date} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Date\n */\n\n/ Text processing\n/**\n * @external {String} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String\n */\n/**\n * @external {string} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String\n */\n\n/**\n * @external {RegExp} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RegExp\n */\n\n/ Indexed collections\n/**\n * @external {Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array\n */\n\n/**\n * @external {Int8Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int8Array\n */\n/**\n * @external {Uint8Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint8Array\n */\n\n/**\n * @external {Uint8ClampedArray} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint8ClampedArray\n */\n\n/**\n * @external {Int16Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int16Array\n */\n\n/**\n * @external {Uint16Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint16Array\n */\n\n/**\n * @external {Int32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int32Array\n */\n\n/**\n * @external {Uint32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint32Array\n */\n\n/**\n * @external {Float32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Float32Array\n */\n\n/**\n * @external {Float64Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Float64Array\n */\n\n/ Keyed collections\n/**\n * @external {Map} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Map\n */\n\n/**\n * @external {Set} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Set\n */\n\n/**\n * @external {WeakMap} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakMap\n */\n\n/**\n * @external {WeakSet} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakSet\n */\n\n/ Structured data\n/**\n * @external {ArrayBuffer} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ArrayBuffer\n */\n\n/**\n * @external {DataView} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/DataView\n */\n\n/**\n * @external {JSON} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/JSON\n */\n\n/ Control abstraction objects\n/**\n * @external {Promise} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Promise\n */\n\n/**\n * @external {Generator} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Generator\n */\n\n/**\n * @external {GeneratorFunction} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/GeneratorFunction\n */\n\n/ Reflection\n/**\n * @external {Reflect} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Reflect\n */\n\n/**\n * @external {Proxy} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Proxy\n */\n~Int16Array",
    "external"
  ],
  [
    "\n/**\n * @external {infinity} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/infinity\n */\n\n/**\n * @external {nan} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/nan\n */\n\n/**\n * @external {undefined} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/undefined\n */\n\n/**\n * @external {null} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/null\n */\n\n/ fundamental objects\n/**\n * @external {object} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/object\n */\n/**\n * @external {object} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/object\n */\n\n/**\n * @external {function} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/function\n */\n/**\n * @external {function} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/function\n */\n\n/**\n * @external {boolean} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/boolean\n */\n/**\n * @external {boolean} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/boolean\n */\n\n/**\n * @external {symbol} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/symbol\n */\n\n/**\n * @external {error} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/error\n */\n\n/**\n * @external {evalerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/evalerror\n */\n\n/**\n * @external {internalerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/internalerror\n */\n\n/**\n * @external {rangeerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/rangeerror\n */\n\n/**\n * @external {referenceerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/referenceerror\n */\n\n/**\n * @external {syntaxerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/syntaxerror\n */\n\n/**\n * @external {typeerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/typeerror\n */\n\n/**\n * @external {urierror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/urierror\n */\n\n/ numbers and dates\n/**\n * @external {number} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/number\n */\n/**\n * @external {number} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/number\n */\n\n/**\n * @external {date} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/date\n */\n\n/ text processing\n/**\n * @external {string} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/string\n */\n/**\n * @external {string} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/string\n */\n\n/**\n * @external {regexp} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/regexp\n */\n\n/ indexed collections\n/**\n * @external {array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/array\n */\n\n/**\n * @external {int8array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int8array\n */\n/**\n * @external {uint8array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint8array\n */\n\n/**\n * @external {uint8clampedarray} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint8clampedarray\n */\n\n/**\n * @external {int16array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int16array\n */\n\n/**\n * @external {uint16array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint16array\n */\n\n/**\n * @external {int32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int32array\n */\n\n/**\n * @external {uint32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint32array\n */\n\n/**\n * @external {float32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/float32array\n */\n\n/**\n * @external {float64array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/float64array\n */\n\n/ keyed collections\n/**\n * @external {map} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/map\n */\n\n/**\n * @external {set} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/set\n */\n\n/**\n * @external {weakmap} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/weakmap\n */\n\n/**\n * @external {weakset} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/weakset\n */\n\n/ structured data\n/**\n * @external {arraybuffer} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/arraybuffer\n */\n\n/**\n * @external {dataview} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/dataview\n */\n\n/**\n * @external {json} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/json\n */\n\n/ control abstraction objects\n/**\n * @external {promise} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/promise\n */\n\n/**\n * @external {generator} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/generator\n */\n\n/**\n * @external {generatorfunction} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/generatorfunction\n */\n\n/ reflection\n/**\n * @external {reflect} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/reflect\n */\n\n/**\n * @external {proxy} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/proxy\n */\n~int32array",
    "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int32Array",
    "\n/**\n * @external {Infinity} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Infinity\n */\n\n/**\n * @external {NaN} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/NaN\n */\n\n/**\n * @external {undefined} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/undefined\n */\n\n/**\n * @external {null} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/null\n */\n\n/ Fundamental objects\n/**\n * @external {Object} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object\n */\n/**\n * @external {object} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object\n */\n\n/**\n * @external {Function} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function\n */\n/**\n * @external {function} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function\n */\n\n/**\n * @external {Boolean} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean\n */\n/**\n * @external {boolean} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean\n */\n\n/**\n * @external {Symbol} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Symbol\n */\n\n/**\n * @external {Error} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Error\n */\n\n/**\n * @external {EvalError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/EvalError\n */\n\n/**\n * @external {InternalError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/InternalError\n */\n\n/**\n * @external {RangeError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RangeError\n */\n\n/**\n * @external {ReferenceError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ReferenceError\n */\n\n/**\n * @external {SyntaxError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/SyntaxError\n */\n\n/**\n * @external {TypeError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/TypeError\n */\n\n/**\n * @external {URIError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/URIError\n */\n\n/ Numbers and dates\n/**\n * @external {Number} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number\n */\n/**\n * @external {number} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number\n */\n\n/**\n * @external {Date} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Date\n */\n\n/ Text processing\n/**\n * @external {String} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String\n */\n/**\n * @external {string} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String\n */\n\n/**\n * @external {RegExp} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RegExp\n */\n\n/ Indexed collections\n/**\n * @external {Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array\n */\n\n/**\n * @external {Int8Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int8Array\n */\n/**\n * @external {Uint8Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint8Array\n */\n\n/**\n * @external {Uint8ClampedArray} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint8ClampedArray\n */\n\n/**\n * @external {Int16Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int16Array\n */\n\n/**\n * @external {Uint16Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint16Array\n */\n\n/**\n * @external {Int32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int32Array\n */\n\n/**\n * @external {Uint32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint32Array\n */\n\n/**\n * @external {Float32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Float32Array\n */\n\n/**\n * @external {Float64Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Float64Array\n */\n\n/ Keyed collections\n/**\n * @external {Map} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Map\n */\n\n/**\n * @external {Set} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Set\n */\n\n/**\n * @external {WeakMap} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakMap\n */\n\n/**\n * @external {WeakSet} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakSet\n */\n\n/ Structured data\n/**\n * @external {ArrayBuffer} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ArrayBuffer\n */\n\n/**\n * @external {DataView} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/DataView\n */\n\n/**\n * @external {JSON} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/JSON\n */\n\n/ Control abstraction objects\n/**\n * @external {Promise} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Promise\n */\n\n/**\n * @external {Generator} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Generator\n */\n\n/**\n * @external {GeneratorFunction} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/GeneratorFunction\n */\n\n/ Reflection\n/**\n * @external {Reflect} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Reflect\n */\n\n/**\n * @external {Proxy} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Proxy\n */\n~Int32Array",
    "external"
  ],
  [
    "\n/**\n * @external {infinity} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/infinity\n */\n\n/**\n * @external {nan} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/nan\n */\n\n/**\n * @external {undefined} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/undefined\n */\n\n/**\n * @external {null} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/null\n */\n\n/ fundamental objects\n/**\n * @external {object} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/object\n */\n/**\n * @external {object} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/object\n */\n\n/**\n * @external {function} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/function\n */\n/**\n * @external {function} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/function\n */\n\n/**\n * @external {boolean} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/boolean\n */\n/**\n * @external {boolean} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/boolean\n */\n\n/**\n * @external {symbol} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/symbol\n */\n\n/**\n * @external {error} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/error\n */\n\n/**\n * @external {evalerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/evalerror\n */\n\n/**\n * @external {internalerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/internalerror\n */\n\n/**\n * @external {rangeerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/rangeerror\n */\n\n/**\n * @external {referenceerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/referenceerror\n */\n\n/**\n * @external {syntaxerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/syntaxerror\n */\n\n/**\n * @external {typeerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/typeerror\n */\n\n/**\n * @external {urierror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/urierror\n */\n\n/ numbers and dates\n/**\n * @external {number} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/number\n */\n/**\n * @external {number} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/number\n */\n\n/**\n * @external {date} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/date\n */\n\n/ text processing\n/**\n * @external {string} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/string\n */\n/**\n * @external {string} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/string\n */\n\n/**\n * @external {regexp} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/regexp\n */\n\n/ indexed collections\n/**\n * @external {array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/array\n */\n\n/**\n * @external {int8array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int8array\n */\n/**\n * @external {uint8array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint8array\n */\n\n/**\n * @external {uint8clampedarray} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint8clampedarray\n */\n\n/**\n * @external {int16array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int16array\n */\n\n/**\n * @external {uint16array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint16array\n */\n\n/**\n * @external {int32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int32array\n */\n\n/**\n * @external {uint32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint32array\n */\n\n/**\n * @external {float32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/float32array\n */\n\n/**\n * @external {float64array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/float64array\n */\n\n/ keyed collections\n/**\n * @external {map} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/map\n */\n\n/**\n * @external {set} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/set\n */\n\n/**\n * @external {weakmap} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/weakmap\n */\n\n/**\n * @external {weakset} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/weakset\n */\n\n/ structured data\n/**\n * @external {arraybuffer} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/arraybuffer\n */\n\n/**\n * @external {dataview} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/dataview\n */\n\n/**\n * @external {json} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/json\n */\n\n/ control abstraction objects\n/**\n * @external {promise} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/promise\n */\n\n/**\n * @external {generator} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/generator\n */\n\n/**\n * @external {generatorfunction} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/generatorfunction\n */\n\n/ reflection\n/**\n * @external {reflect} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/reflect\n */\n\n/**\n * @external {proxy} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/proxy\n */\n~int8array",
    "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int8Array",
    "\n/**\n * @external {Infinity} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Infinity\n */\n\n/**\n * @external {NaN} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/NaN\n */\n\n/**\n * @external {undefined} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/undefined\n */\n\n/**\n * @external {null} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/null\n */\n\n/ Fundamental objects\n/**\n * @external {Object} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object\n */\n/**\n * @external {object} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object\n */\n\n/**\n * @external {Function} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function\n */\n/**\n * @external {function} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function\n */\n\n/**\n * @external {Boolean} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean\n */\n/**\n * @external {boolean} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean\n */\n\n/**\n * @external {Symbol} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Symbol\n */\n\n/**\n * @external {Error} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Error\n */\n\n/**\n * @external {EvalError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/EvalError\n */\n\n/**\n * @external {InternalError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/InternalError\n */\n\n/**\n * @external {RangeError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RangeError\n */\n\n/**\n * @external {ReferenceError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ReferenceError\n */\n\n/**\n * @external {SyntaxError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/SyntaxError\n */\n\n/**\n * @external {TypeError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/TypeError\n */\n\n/**\n * @external {URIError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/URIError\n */\n\n/ Numbers and dates\n/**\n * @external {Number} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number\n */\n/**\n * @external {number} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number\n */\n\n/**\n * @external {Date} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Date\n */\n\n/ Text processing\n/**\n * @external {String} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String\n */\n/**\n * @external {string} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String\n */\n\n/**\n * @external {RegExp} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RegExp\n */\n\n/ Indexed collections\n/**\n * @external {Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array\n */\n\n/**\n * @external {Int8Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int8Array\n */\n/**\n * @external {Uint8Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint8Array\n */\n\n/**\n * @external {Uint8ClampedArray} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint8ClampedArray\n */\n\n/**\n * @external {Int16Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int16Array\n */\n\n/**\n * @external {Uint16Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint16Array\n */\n\n/**\n * @external {Int32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int32Array\n */\n\n/**\n * @external {Uint32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint32Array\n */\n\n/**\n * @external {Float32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Float32Array\n */\n\n/**\n * @external {Float64Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Float64Array\n */\n\n/ Keyed collections\n/**\n * @external {Map} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Map\n */\n\n/**\n * @external {Set} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Set\n */\n\n/**\n * @external {WeakMap} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakMap\n */\n\n/**\n * @external {WeakSet} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakSet\n */\n\n/ Structured data\n/**\n * @external {ArrayBuffer} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ArrayBuffer\n */\n\n/**\n * @external {DataView} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/DataView\n */\n\n/**\n * @external {JSON} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/JSON\n */\n\n/ Control abstraction objects\n/**\n * @external {Promise} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Promise\n */\n\n/**\n * @external {Generator} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Generator\n */\n\n/**\n * @external {GeneratorFunction} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/GeneratorFunction\n */\n\n/ Reflection\n/**\n * @external {Reflect} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Reflect\n */\n\n/**\n * @external {Proxy} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Proxy\n */\n~Int8Array",
    "external"
  ],
  [
    "\n/**\n * @external {infinity} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/infinity\n */\n\n/**\n * @external {nan} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/nan\n */\n\n/**\n * @external {undefined} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/undefined\n */\n\n/**\n * @external {null} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/null\n */\n\n/ fundamental objects\n/**\n * @external {object} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/object\n */\n/**\n * @external {object} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/object\n */\n\n/**\n * @external {function} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/function\n */\n/**\n * @external {function} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/function\n */\n\n/**\n * @external {boolean} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/boolean\n */\n/**\n * @external {boolean} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/boolean\n */\n\n/**\n * @external {symbol} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/symbol\n */\n\n/**\n * @external {error} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/error\n */\n\n/**\n * @external {evalerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/evalerror\n */\n\n/**\n * @external {internalerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/internalerror\n */\n\n/**\n * @external {rangeerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/rangeerror\n */\n\n/**\n * @external {referenceerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/referenceerror\n */\n\n/**\n * @external {syntaxerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/syntaxerror\n */\n\n/**\n * @external {typeerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/typeerror\n */\n\n/**\n * @external {urierror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/urierror\n */\n\n/ numbers and dates\n/**\n * @external {number} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/number\n */\n/**\n * @external {number} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/number\n */\n\n/**\n * @external {date} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/date\n */\n\n/ text processing\n/**\n * @external {string} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/string\n */\n/**\n * @external {string} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/string\n */\n\n/**\n * @external {regexp} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/regexp\n */\n\n/ indexed collections\n/**\n * @external {array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/array\n */\n\n/**\n * @external {int8array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int8array\n */\n/**\n * @external {uint8array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint8array\n */\n\n/**\n * @external {uint8clampedarray} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint8clampedarray\n */\n\n/**\n * @external {int16array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int16array\n */\n\n/**\n * @external {uint16array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint16array\n */\n\n/**\n * @external {int32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int32array\n */\n\n/**\n * @external {uint32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint32array\n */\n\n/**\n * @external {float32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/float32array\n */\n\n/**\n * @external {float64array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/float64array\n */\n\n/ keyed collections\n/**\n * @external {map} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/map\n */\n\n/**\n * @external {set} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/set\n */\n\n/**\n * @external {weakmap} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/weakmap\n */\n\n/**\n * @external {weakset} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/weakset\n */\n\n/ structured data\n/**\n * @external {arraybuffer} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/arraybuffer\n */\n\n/**\n * @external {dataview} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/dataview\n */\n\n/**\n * @external {json} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/json\n */\n\n/ control abstraction objects\n/**\n * @external {promise} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/promise\n */\n\n/**\n * @external {generator} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/generator\n */\n\n/**\n * @external {generatorfunction} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/generatorfunction\n */\n\n/ reflection\n/**\n * @external {reflect} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/reflect\n */\n\n/**\n * @external {proxy} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/proxy\n */\n~internalerror",
    "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/InternalError",
    "\n/**\n * @external {Infinity} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Infinity\n */\n\n/**\n * @external {NaN} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/NaN\n */\n\n/**\n * @external {undefined} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/undefined\n */\n\n/**\n * @external {null} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/null\n */\n\n/ Fundamental objects\n/**\n * @external {Object} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object\n */\n/**\n * @external {object} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object\n */\n\n/**\n * @external {Function} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function\n */\n/**\n * @external {function} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function\n */\n\n/**\n * @external {Boolean} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean\n */\n/**\n * @external {boolean} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean\n */\n\n/**\n * @external {Symbol} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Symbol\n */\n\n/**\n * @external {Error} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Error\n */\n\n/**\n * @external {EvalError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/EvalError\n */\n\n/**\n * @external {InternalError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/InternalError\n */\n\n/**\n * @external {RangeError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RangeError\n */\n\n/**\n * @external {ReferenceError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ReferenceError\n */\n\n/**\n * @external {SyntaxError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/SyntaxError\n */\n\n/**\n * @external {TypeError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/TypeError\n */\n\n/**\n * @external {URIError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/URIError\n */\n\n/ Numbers and dates\n/**\n * @external {Number} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number\n */\n/**\n * @external {number} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number\n */\n\n/**\n * @external {Date} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Date\n */\n\n/ Text processing\n/**\n * @external {String} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String\n */\n/**\n * @external {string} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String\n */\n\n/**\n * @external {RegExp} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RegExp\n */\n\n/ Indexed collections\n/**\n * @external {Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array\n */\n\n/**\n * @external {Int8Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int8Array\n */\n/**\n * @external {Uint8Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint8Array\n */\n\n/**\n * @external {Uint8ClampedArray} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint8ClampedArray\n */\n\n/**\n * @external {Int16Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int16Array\n */\n\n/**\n * @external {Uint16Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint16Array\n */\n\n/**\n * @external {Int32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int32Array\n */\n\n/**\n * @external {Uint32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint32Array\n */\n\n/**\n * @external {Float32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Float32Array\n */\n\n/**\n * @external {Float64Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Float64Array\n */\n\n/ Keyed collections\n/**\n * @external {Map} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Map\n */\n\n/**\n * @external {Set} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Set\n */\n\n/**\n * @external {WeakMap} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakMap\n */\n\n/**\n * @external {WeakSet} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakSet\n */\n\n/ Structured data\n/**\n * @external {ArrayBuffer} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ArrayBuffer\n */\n\n/**\n * @external {DataView} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/DataView\n */\n\n/**\n * @external {JSON} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/JSON\n */\n\n/ Control abstraction objects\n/**\n * @external {Promise} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Promise\n */\n\n/**\n * @external {Generator} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Generator\n */\n\n/**\n * @external {GeneratorFunction} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/GeneratorFunction\n */\n\n/ Reflection\n/**\n * @external {Reflect} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Reflect\n */\n\n/**\n * @external {Proxy} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Proxy\n */\n~InternalError",
    "external"
  ],
  [
    "\n/**\n * @external {infinity} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/infinity\n */\n\n/**\n * @external {nan} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/nan\n */\n\n/**\n * @external {undefined} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/undefined\n */\n\n/**\n * @external {null} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/null\n */\n\n/ fundamental objects\n/**\n * @external {object} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/object\n */\n/**\n * @external {object} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/object\n */\n\n/**\n * @external {function} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/function\n */\n/**\n * @external {function} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/function\n */\n\n/**\n * @external {boolean} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/boolean\n */\n/**\n * @external {boolean} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/boolean\n */\n\n/**\n * @external {symbol} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/symbol\n */\n\n/**\n * @external {error} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/error\n */\n\n/**\n * @external {evalerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/evalerror\n */\n\n/**\n * @external {internalerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/internalerror\n */\n\n/**\n * @external {rangeerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/rangeerror\n */\n\n/**\n * @external {referenceerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/referenceerror\n */\n\n/**\n * @external {syntaxerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/syntaxerror\n */\n\n/**\n * @external {typeerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/typeerror\n */\n\n/**\n * @external {urierror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/urierror\n */\n\n/ numbers and dates\n/**\n * @external {number} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/number\n */\n/**\n * @external {number} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/number\n */\n\n/**\n * @external {date} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/date\n */\n\n/ text processing\n/**\n * @external {string} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/string\n */\n/**\n * @external {string} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/string\n */\n\n/**\n * @external {regexp} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/regexp\n */\n\n/ indexed collections\n/**\n * @external {array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/array\n */\n\n/**\n * @external {int8array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int8array\n */\n/**\n * @external {uint8array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint8array\n */\n\n/**\n * @external {uint8clampedarray} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint8clampedarray\n */\n\n/**\n * @external {int16array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int16array\n */\n\n/**\n * @external {uint16array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint16array\n */\n\n/**\n * @external {int32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int32array\n */\n\n/**\n * @external {uint32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint32array\n */\n\n/**\n * @external {float32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/float32array\n */\n\n/**\n * @external {float64array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/float64array\n */\n\n/ keyed collections\n/**\n * @external {map} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/map\n */\n\n/**\n * @external {set} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/set\n */\n\n/**\n * @external {weakmap} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/weakmap\n */\n\n/**\n * @external {weakset} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/weakset\n */\n\n/ structured data\n/**\n * @external {arraybuffer} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/arraybuffer\n */\n\n/**\n * @external {dataview} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/dataview\n */\n\n/**\n * @external {json} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/json\n */\n\n/ control abstraction objects\n/**\n * @external {promise} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/promise\n */\n\n/**\n * @external {generator} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/generator\n */\n\n/**\n * @external {generatorfunction} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/generatorfunction\n */\n\n/ reflection\n/**\n * @external {reflect} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/reflect\n */\n\n/**\n * @external {proxy} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/proxy\n */\n~json",
    "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/JSON",
    "\n/**\n * @external {Infinity} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Infinity\n */\n\n/**\n * @external {NaN} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/NaN\n */\n\n/**\n * @external {undefined} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/undefined\n */\n\n/**\n * @external {null} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/null\n */\n\n/ Fundamental objects\n/**\n * @external {Object} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object\n */\n/**\n * @external {object} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object\n */\n\n/**\n * @external {Function} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function\n */\n/**\n * @external {function} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function\n */\n\n/**\n * @external {Boolean} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean\n */\n/**\n * @external {boolean} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean\n */\n\n/**\n * @external {Symbol} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Symbol\n */\n\n/**\n * @external {Error} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Error\n */\n\n/**\n * @external {EvalError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/EvalError\n */\n\n/**\n * @external {InternalError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/InternalError\n */\n\n/**\n * @external {RangeError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RangeError\n */\n\n/**\n * @external {ReferenceError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ReferenceError\n */\n\n/**\n * @external {SyntaxError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/SyntaxError\n */\n\n/**\n * @external {TypeError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/TypeError\n */\n\n/**\n * @external {URIError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/URIError\n */\n\n/ Numbers and dates\n/**\n * @external {Number} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number\n */\n/**\n * @external {number} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number\n */\n\n/**\n * @external {Date} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Date\n */\n\n/ Text processing\n/**\n * @external {String} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String\n */\n/**\n * @external {string} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String\n */\n\n/**\n * @external {RegExp} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RegExp\n */\n\n/ Indexed collections\n/**\n * @external {Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array\n */\n\n/**\n * @external {Int8Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int8Array\n */\n/**\n * @external {Uint8Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint8Array\n */\n\n/**\n * @external {Uint8ClampedArray} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint8ClampedArray\n */\n\n/**\n * @external {Int16Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int16Array\n */\n\n/**\n * @external {Uint16Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint16Array\n */\n\n/**\n * @external {Int32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int32Array\n */\n\n/**\n * @external {Uint32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint32Array\n */\n\n/**\n * @external {Float32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Float32Array\n */\n\n/**\n * @external {Float64Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Float64Array\n */\n\n/ Keyed collections\n/**\n * @external {Map} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Map\n */\n\n/**\n * @external {Set} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Set\n */\n\n/**\n * @external {WeakMap} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakMap\n */\n\n/**\n * @external {WeakSet} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakSet\n */\n\n/ Structured data\n/**\n * @external {ArrayBuffer} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ArrayBuffer\n */\n\n/**\n * @external {DataView} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/DataView\n */\n\n/**\n * @external {JSON} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/JSON\n */\n\n/ Control abstraction objects\n/**\n * @external {Promise} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Promise\n */\n\n/**\n * @external {Generator} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Generator\n */\n\n/**\n * @external {GeneratorFunction} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/GeneratorFunction\n */\n\n/ Reflection\n/**\n * @external {Reflect} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Reflect\n */\n\n/**\n * @external {Proxy} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Proxy\n */\n~JSON",
    "external"
  ],
  [
    "\n/**\n * @external {infinity} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/infinity\n */\n\n/**\n * @external {nan} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/nan\n */\n\n/**\n * @external {undefined} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/undefined\n */\n\n/**\n * @external {null} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/null\n */\n\n/ fundamental objects\n/**\n * @external {object} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/object\n */\n/**\n * @external {object} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/object\n */\n\n/**\n * @external {function} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/function\n */\n/**\n * @external {function} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/function\n */\n\n/**\n * @external {boolean} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/boolean\n */\n/**\n * @external {boolean} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/boolean\n */\n\n/**\n * @external {symbol} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/symbol\n */\n\n/**\n * @external {error} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/error\n */\n\n/**\n * @external {evalerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/evalerror\n */\n\n/**\n * @external {internalerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/internalerror\n */\n\n/**\n * @external {rangeerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/rangeerror\n */\n\n/**\n * @external {referenceerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/referenceerror\n */\n\n/**\n * @external {syntaxerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/syntaxerror\n */\n\n/**\n * @external {typeerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/typeerror\n */\n\n/**\n * @external {urierror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/urierror\n */\n\n/ numbers and dates\n/**\n * @external {number} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/number\n */\n/**\n * @external {number} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/number\n */\n\n/**\n * @external {date} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/date\n */\n\n/ text processing\n/**\n * @external {string} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/string\n */\n/**\n * @external {string} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/string\n */\n\n/**\n * @external {regexp} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/regexp\n */\n\n/ indexed collections\n/**\n * @external {array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/array\n */\n\n/**\n * @external {int8array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int8array\n */\n/**\n * @external {uint8array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint8array\n */\n\n/**\n * @external {uint8clampedarray} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint8clampedarray\n */\n\n/**\n * @external {int16array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int16array\n */\n\n/**\n * @external {uint16array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint16array\n */\n\n/**\n * @external {int32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int32array\n */\n\n/**\n * @external {uint32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint32array\n */\n\n/**\n * @external {float32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/float32array\n */\n\n/**\n * @external {float64array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/float64array\n */\n\n/ keyed collections\n/**\n * @external {map} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/map\n */\n\n/**\n * @external {set} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/set\n */\n\n/**\n * @external {weakmap} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/weakmap\n */\n\n/**\n * @external {weakset} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/weakset\n */\n\n/ structured data\n/**\n * @external {arraybuffer} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/arraybuffer\n */\n\n/**\n * @external {dataview} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/dataview\n */\n\n/**\n * @external {json} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/json\n */\n\n/ control abstraction objects\n/**\n * @external {promise} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/promise\n */\n\n/**\n * @external {generator} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/generator\n */\n\n/**\n * @external {generatorfunction} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/generatorfunction\n */\n\n/ reflection\n/**\n * @external {reflect} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/reflect\n */\n\n/**\n * @external {proxy} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/proxy\n */\n~map",
    "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Map",
    "\n/**\n * @external {Infinity} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Infinity\n */\n\n/**\n * @external {NaN} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/NaN\n */\n\n/**\n * @external {undefined} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/undefined\n */\n\n/**\n * @external {null} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/null\n */\n\n/ Fundamental objects\n/**\n * @external {Object} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object\n */\n/**\n * @external {object} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object\n */\n\n/**\n * @external {Function} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function\n */\n/**\n * @external {function} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function\n */\n\n/**\n * @external {Boolean} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean\n */\n/**\n * @external {boolean} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean\n */\n\n/**\n * @external {Symbol} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Symbol\n */\n\n/**\n * @external {Error} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Error\n */\n\n/**\n * @external {EvalError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/EvalError\n */\n\n/**\n * @external {InternalError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/InternalError\n */\n\n/**\n * @external {RangeError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RangeError\n */\n\n/**\n * @external {ReferenceError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ReferenceError\n */\n\n/**\n * @external {SyntaxError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/SyntaxError\n */\n\n/**\n * @external {TypeError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/TypeError\n */\n\n/**\n * @external {URIError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/URIError\n */\n\n/ Numbers and dates\n/**\n * @external {Number} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number\n */\n/**\n * @external {number} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number\n */\n\n/**\n * @external {Date} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Date\n */\n\n/ Text processing\n/**\n * @external {String} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String\n */\n/**\n * @external {string} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String\n */\n\n/**\n * @external {RegExp} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RegExp\n */\n\n/ Indexed collections\n/**\n * @external {Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array\n */\n\n/**\n * @external {Int8Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int8Array\n */\n/**\n * @external {Uint8Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint8Array\n */\n\n/**\n * @external {Uint8ClampedArray} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint8ClampedArray\n */\n\n/**\n * @external {Int16Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int16Array\n */\n\n/**\n * @external {Uint16Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint16Array\n */\n\n/**\n * @external {Int32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int32Array\n */\n\n/**\n * @external {Uint32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint32Array\n */\n\n/**\n * @external {Float32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Float32Array\n */\n\n/**\n * @external {Float64Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Float64Array\n */\n\n/ Keyed collections\n/**\n * @external {Map} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Map\n */\n\n/**\n * @external {Set} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Set\n */\n\n/**\n * @external {WeakMap} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakMap\n */\n\n/**\n * @external {WeakSet} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakSet\n */\n\n/ Structured data\n/**\n * @external {ArrayBuffer} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ArrayBuffer\n */\n\n/**\n * @external {DataView} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/DataView\n */\n\n/**\n * @external {JSON} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/JSON\n */\n\n/ Control abstraction objects\n/**\n * @external {Promise} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Promise\n */\n\n/**\n * @external {Generator} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Generator\n */\n\n/**\n * @external {GeneratorFunction} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/GeneratorFunction\n */\n\n/ Reflection\n/**\n * @external {Reflect} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Reflect\n */\n\n/**\n * @external {Proxy} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Proxy\n */\n~Map",
    "external"
  ],
  [
    "\n/**\n * @external {infinity} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/infinity\n */\n\n/**\n * @external {nan} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/nan\n */\n\n/**\n * @external {undefined} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/undefined\n */\n\n/**\n * @external {null} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/null\n */\n\n/ fundamental objects\n/**\n * @external {object} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/object\n */\n/**\n * @external {object} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/object\n */\n\n/**\n * @external {function} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/function\n */\n/**\n * @external {function} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/function\n */\n\n/**\n * @external {boolean} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/boolean\n */\n/**\n * @external {boolean} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/boolean\n */\n\n/**\n * @external {symbol} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/symbol\n */\n\n/**\n * @external {error} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/error\n */\n\n/**\n * @external {evalerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/evalerror\n */\n\n/**\n * @external {internalerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/internalerror\n */\n\n/**\n * @external {rangeerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/rangeerror\n */\n\n/**\n * @external {referenceerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/referenceerror\n */\n\n/**\n * @external {syntaxerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/syntaxerror\n */\n\n/**\n * @external {typeerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/typeerror\n */\n\n/**\n * @external {urierror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/urierror\n */\n\n/ numbers and dates\n/**\n * @external {number} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/number\n */\n/**\n * @external {number} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/number\n */\n\n/**\n * @external {date} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/date\n */\n\n/ text processing\n/**\n * @external {string} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/string\n */\n/**\n * @external {string} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/string\n */\n\n/**\n * @external {regexp} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/regexp\n */\n\n/ indexed collections\n/**\n * @external {array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/array\n */\n\n/**\n * @external {int8array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int8array\n */\n/**\n * @external {uint8array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint8array\n */\n\n/**\n * @external {uint8clampedarray} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint8clampedarray\n */\n\n/**\n * @external {int16array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int16array\n */\n\n/**\n * @external {uint16array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint16array\n */\n\n/**\n * @external {int32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int32array\n */\n\n/**\n * @external {uint32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint32array\n */\n\n/**\n * @external {float32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/float32array\n */\n\n/**\n * @external {float64array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/float64array\n */\n\n/ keyed collections\n/**\n * @external {map} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/map\n */\n\n/**\n * @external {set} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/set\n */\n\n/**\n * @external {weakmap} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/weakmap\n */\n\n/**\n * @external {weakset} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/weakset\n */\n\n/ structured data\n/**\n * @external {arraybuffer} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/arraybuffer\n */\n\n/**\n * @external {dataview} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/dataview\n */\n\n/**\n * @external {json} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/json\n */\n\n/ control abstraction objects\n/**\n * @external {promise} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/promise\n */\n\n/**\n * @external {generator} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/generator\n */\n\n/**\n * @external {generatorfunction} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/generatorfunction\n */\n\n/ reflection\n/**\n * @external {reflect} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/reflect\n */\n\n/**\n * @external {proxy} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/proxy\n */\n~nan",
    "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/NaN",
    "\n/**\n * @external {Infinity} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Infinity\n */\n\n/**\n * @external {NaN} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/NaN\n */\n\n/**\n * @external {undefined} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/undefined\n */\n\n/**\n * @external {null} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/null\n */\n\n/ Fundamental objects\n/**\n * @external {Object} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object\n */\n/**\n * @external {object} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object\n */\n\n/**\n * @external {Function} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function\n */\n/**\n * @external {function} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function\n */\n\n/**\n * @external {Boolean} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean\n */\n/**\n * @external {boolean} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean\n */\n\n/**\n * @external {Symbol} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Symbol\n */\n\n/**\n * @external {Error} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Error\n */\n\n/**\n * @external {EvalError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/EvalError\n */\n\n/**\n * @external {InternalError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/InternalError\n */\n\n/**\n * @external {RangeError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RangeError\n */\n\n/**\n * @external {ReferenceError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ReferenceError\n */\n\n/**\n * @external {SyntaxError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/SyntaxError\n */\n\n/**\n * @external {TypeError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/TypeError\n */\n\n/**\n * @external {URIError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/URIError\n */\n\n/ Numbers and dates\n/**\n * @external {Number} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number\n */\n/**\n * @external {number} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number\n */\n\n/**\n * @external {Date} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Date\n */\n\n/ Text processing\n/**\n * @external {String} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String\n */\n/**\n * @external {string} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String\n */\n\n/**\n * @external {RegExp} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RegExp\n */\n\n/ Indexed collections\n/**\n * @external {Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array\n */\n\n/**\n * @external {Int8Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int8Array\n */\n/**\n * @external {Uint8Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint8Array\n */\n\n/**\n * @external {Uint8ClampedArray} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint8ClampedArray\n */\n\n/**\n * @external {Int16Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int16Array\n */\n\n/**\n * @external {Uint16Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint16Array\n */\n\n/**\n * @external {Int32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int32Array\n */\n\n/**\n * @external {Uint32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint32Array\n */\n\n/**\n * @external {Float32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Float32Array\n */\n\n/**\n * @external {Float64Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Float64Array\n */\n\n/ Keyed collections\n/**\n * @external {Map} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Map\n */\n\n/**\n * @external {Set} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Set\n */\n\n/**\n * @external {WeakMap} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakMap\n */\n\n/**\n * @external {WeakSet} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakSet\n */\n\n/ Structured data\n/**\n * @external {ArrayBuffer} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ArrayBuffer\n */\n\n/**\n * @external {DataView} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/DataView\n */\n\n/**\n * @external {JSON} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/JSON\n */\n\n/ Control abstraction objects\n/**\n * @external {Promise} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Promise\n */\n\n/**\n * @external {Generator} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Generator\n */\n\n/**\n * @external {GeneratorFunction} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/GeneratorFunction\n */\n\n/ Reflection\n/**\n * @external {Reflect} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Reflect\n */\n\n/**\n * @external {Proxy} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Proxy\n */\n~NaN",
    "external"
  ],
  [
    "\n/**\n * @external {infinity} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/infinity\n */\n\n/**\n * @external {nan} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/nan\n */\n\n/**\n * @external {undefined} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/undefined\n */\n\n/**\n * @external {null} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/null\n */\n\n/ fundamental objects\n/**\n * @external {object} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/object\n */\n/**\n * @external {object} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/object\n */\n\n/**\n * @external {function} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/function\n */\n/**\n * @external {function} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/function\n */\n\n/**\n * @external {boolean} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/boolean\n */\n/**\n * @external {boolean} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/boolean\n */\n\n/**\n * @external {symbol} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/symbol\n */\n\n/**\n * @external {error} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/error\n */\n\n/**\n * @external {evalerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/evalerror\n */\n\n/**\n * @external {internalerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/internalerror\n */\n\n/**\n * @external {rangeerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/rangeerror\n */\n\n/**\n * @external {referenceerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/referenceerror\n */\n\n/**\n * @external {syntaxerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/syntaxerror\n */\n\n/**\n * @external {typeerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/typeerror\n */\n\n/**\n * @external {urierror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/urierror\n */\n\n/ numbers and dates\n/**\n * @external {number} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/number\n */\n/**\n * @external {number} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/number\n */\n\n/**\n * @external {date} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/date\n */\n\n/ text processing\n/**\n * @external {string} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/string\n */\n/**\n * @external {string} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/string\n */\n\n/**\n * @external {regexp} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/regexp\n */\n\n/ indexed collections\n/**\n * @external {array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/array\n */\n\n/**\n * @external {int8array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int8array\n */\n/**\n * @external {uint8array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint8array\n */\n\n/**\n * @external {uint8clampedarray} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint8clampedarray\n */\n\n/**\n * @external {int16array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int16array\n */\n\n/**\n * @external {uint16array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint16array\n */\n\n/**\n * @external {int32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int32array\n */\n\n/**\n * @external {uint32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint32array\n */\n\n/**\n * @external {float32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/float32array\n */\n\n/**\n * @external {float64array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/float64array\n */\n\n/ keyed collections\n/**\n * @external {map} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/map\n */\n\n/**\n * @external {set} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/set\n */\n\n/**\n * @external {weakmap} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/weakmap\n */\n\n/**\n * @external {weakset} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/weakset\n */\n\n/ structured data\n/**\n * @external {arraybuffer} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/arraybuffer\n */\n\n/**\n * @external {dataview} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/dataview\n */\n\n/**\n * @external {json} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/json\n */\n\n/ control abstraction objects\n/**\n * @external {promise} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/promise\n */\n\n/**\n * @external {generator} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/generator\n */\n\n/**\n * @external {generatorfunction} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/generatorfunction\n */\n\n/ reflection\n/**\n * @external {reflect} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/reflect\n */\n\n/**\n * @external {proxy} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/proxy\n */\n~number",
    "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number",
    "\n/**\n * @external {Infinity} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Infinity\n */\n\n/**\n * @external {NaN} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/NaN\n */\n\n/**\n * @external {undefined} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/undefined\n */\n\n/**\n * @external {null} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/null\n */\n\n/ Fundamental objects\n/**\n * @external {Object} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object\n */\n/**\n * @external {object} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object\n */\n\n/**\n * @external {Function} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function\n */\n/**\n * @external {function} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function\n */\n\n/**\n * @external {Boolean} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean\n */\n/**\n * @external {boolean} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean\n */\n\n/**\n * @external {Symbol} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Symbol\n */\n\n/**\n * @external {Error} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Error\n */\n\n/**\n * @external {EvalError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/EvalError\n */\n\n/**\n * @external {InternalError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/InternalError\n */\n\n/**\n * @external {RangeError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RangeError\n */\n\n/**\n * @external {ReferenceError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ReferenceError\n */\n\n/**\n * @external {SyntaxError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/SyntaxError\n */\n\n/**\n * @external {TypeError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/TypeError\n */\n\n/**\n * @external {URIError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/URIError\n */\n\n/ Numbers and dates\n/**\n * @external {Number} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number\n */\n/**\n * @external {number} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number\n */\n\n/**\n * @external {Date} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Date\n */\n\n/ Text processing\n/**\n * @external {String} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String\n */\n/**\n * @external {string} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String\n */\n\n/**\n * @external {RegExp} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RegExp\n */\n\n/ Indexed collections\n/**\n * @external {Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array\n */\n\n/**\n * @external {Int8Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int8Array\n */\n/**\n * @external {Uint8Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint8Array\n */\n\n/**\n * @external {Uint8ClampedArray} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint8ClampedArray\n */\n\n/**\n * @external {Int16Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int16Array\n */\n\n/**\n * @external {Uint16Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint16Array\n */\n\n/**\n * @external {Int32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int32Array\n */\n\n/**\n * @external {Uint32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint32Array\n */\n\n/**\n * @external {Float32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Float32Array\n */\n\n/**\n * @external {Float64Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Float64Array\n */\n\n/ Keyed collections\n/**\n * @external {Map} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Map\n */\n\n/**\n * @external {Set} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Set\n */\n\n/**\n * @external {WeakMap} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakMap\n */\n\n/**\n * @external {WeakSet} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakSet\n */\n\n/ Structured data\n/**\n * @external {ArrayBuffer} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ArrayBuffer\n */\n\n/**\n * @external {DataView} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/DataView\n */\n\n/**\n * @external {JSON} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/JSON\n */\n\n/ Control abstraction objects\n/**\n * @external {Promise} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Promise\n */\n\n/**\n * @external {Generator} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Generator\n */\n\n/**\n * @external {GeneratorFunction} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/GeneratorFunction\n */\n\n/ Reflection\n/**\n * @external {Reflect} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Reflect\n */\n\n/**\n * @external {Proxy} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Proxy\n */\n~Number",
    "external"
  ],
  [
    "\n/**\n * @external {infinity} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/infinity\n */\n\n/**\n * @external {nan} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/nan\n */\n\n/**\n * @external {undefined} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/undefined\n */\n\n/**\n * @external {null} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/null\n */\n\n/ fundamental objects\n/**\n * @external {object} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/object\n */\n/**\n * @external {object} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/object\n */\n\n/**\n * @external {function} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/function\n */\n/**\n * @external {function} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/function\n */\n\n/**\n * @external {boolean} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/boolean\n */\n/**\n * @external {boolean} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/boolean\n */\n\n/**\n * @external {symbol} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/symbol\n */\n\n/**\n * @external {error} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/error\n */\n\n/**\n * @external {evalerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/evalerror\n */\n\n/**\n * @external {internalerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/internalerror\n */\n\n/**\n * @external {rangeerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/rangeerror\n */\n\n/**\n * @external {referenceerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/referenceerror\n */\n\n/**\n * @external {syntaxerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/syntaxerror\n */\n\n/**\n * @external {typeerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/typeerror\n */\n\n/**\n * @external {urierror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/urierror\n */\n\n/ numbers and dates\n/**\n * @external {number} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/number\n */\n/**\n * @external {number} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/number\n */\n\n/**\n * @external {date} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/date\n */\n\n/ text processing\n/**\n * @external {string} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/string\n */\n/**\n * @external {string} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/string\n */\n\n/**\n * @external {regexp} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/regexp\n */\n\n/ indexed collections\n/**\n * @external {array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/array\n */\n\n/**\n * @external {int8array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int8array\n */\n/**\n * @external {uint8array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint8array\n */\n\n/**\n * @external {uint8clampedarray} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint8clampedarray\n */\n\n/**\n * @external {int16array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int16array\n */\n\n/**\n * @external {uint16array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint16array\n */\n\n/**\n * @external {int32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int32array\n */\n\n/**\n * @external {uint32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint32array\n */\n\n/**\n * @external {float32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/float32array\n */\n\n/**\n * @external {float64array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/float64array\n */\n\n/ keyed collections\n/**\n * @external {map} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/map\n */\n\n/**\n * @external {set} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/set\n */\n\n/**\n * @external {weakmap} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/weakmap\n */\n\n/**\n * @external {weakset} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/weakset\n */\n\n/ structured data\n/**\n * @external {arraybuffer} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/arraybuffer\n */\n\n/**\n * @external {dataview} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/dataview\n */\n\n/**\n * @external {json} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/json\n */\n\n/ control abstraction objects\n/**\n * @external {promise} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/promise\n */\n\n/**\n * @external {generator} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/generator\n */\n\n/**\n * @external {generatorfunction} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/generatorfunction\n */\n\n/ reflection\n/**\n * @external {reflect} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/reflect\n */\n\n/**\n * @external {proxy} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/proxy\n */\n~object",
    "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object",
    "\n/**\n * @external {Infinity} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Infinity\n */\n\n/**\n * @external {NaN} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/NaN\n */\n\n/**\n * @external {undefined} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/undefined\n */\n\n/**\n * @external {null} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/null\n */\n\n/ Fundamental objects\n/**\n * @external {Object} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object\n */\n/**\n * @external {object} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object\n */\n\n/**\n * @external {Function} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function\n */\n/**\n * @external {function} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function\n */\n\n/**\n * @external {Boolean} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean\n */\n/**\n * @external {boolean} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean\n */\n\n/**\n * @external {Symbol} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Symbol\n */\n\n/**\n * @external {Error} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Error\n */\n\n/**\n * @external {EvalError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/EvalError\n */\n\n/**\n * @external {InternalError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/InternalError\n */\n\n/**\n * @external {RangeError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RangeError\n */\n\n/**\n * @external {ReferenceError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ReferenceError\n */\n\n/**\n * @external {SyntaxError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/SyntaxError\n */\n\n/**\n * @external {TypeError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/TypeError\n */\n\n/**\n * @external {URIError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/URIError\n */\n\n/ Numbers and dates\n/**\n * @external {Number} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number\n */\n/**\n * @external {number} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number\n */\n\n/**\n * @external {Date} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Date\n */\n\n/ Text processing\n/**\n * @external {String} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String\n */\n/**\n * @external {string} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String\n */\n\n/**\n * @external {RegExp} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RegExp\n */\n\n/ Indexed collections\n/**\n * @external {Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array\n */\n\n/**\n * @external {Int8Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int8Array\n */\n/**\n * @external {Uint8Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint8Array\n */\n\n/**\n * @external {Uint8ClampedArray} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint8ClampedArray\n */\n\n/**\n * @external {Int16Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int16Array\n */\n\n/**\n * @external {Uint16Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint16Array\n */\n\n/**\n * @external {Int32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int32Array\n */\n\n/**\n * @external {Uint32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint32Array\n */\n\n/**\n * @external {Float32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Float32Array\n */\n\n/**\n * @external {Float64Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Float64Array\n */\n\n/ Keyed collections\n/**\n * @external {Map} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Map\n */\n\n/**\n * @external {Set} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Set\n */\n\n/**\n * @external {WeakMap} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakMap\n */\n\n/**\n * @external {WeakSet} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakSet\n */\n\n/ Structured data\n/**\n * @external {ArrayBuffer} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ArrayBuffer\n */\n\n/**\n * @external {DataView} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/DataView\n */\n\n/**\n * @external {JSON} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/JSON\n */\n\n/ Control abstraction objects\n/**\n * @external {Promise} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Promise\n */\n\n/**\n * @external {Generator} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Generator\n */\n\n/**\n * @external {GeneratorFunction} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/GeneratorFunction\n */\n\n/ Reflection\n/**\n * @external {Reflect} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Reflect\n */\n\n/**\n * @external {Proxy} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Proxy\n */\n~Object",
    "external"
  ],
  [
    "\n/**\n * @external {infinity} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/infinity\n */\n\n/**\n * @external {nan} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/nan\n */\n\n/**\n * @external {undefined} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/undefined\n */\n\n/**\n * @external {null} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/null\n */\n\n/ fundamental objects\n/**\n * @external {object} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/object\n */\n/**\n * @external {object} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/object\n */\n\n/**\n * @external {function} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/function\n */\n/**\n * @external {function} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/function\n */\n\n/**\n * @external {boolean} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/boolean\n */\n/**\n * @external {boolean} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/boolean\n */\n\n/**\n * @external {symbol} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/symbol\n */\n\n/**\n * @external {error} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/error\n */\n\n/**\n * @external {evalerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/evalerror\n */\n\n/**\n * @external {internalerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/internalerror\n */\n\n/**\n * @external {rangeerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/rangeerror\n */\n\n/**\n * @external {referenceerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/referenceerror\n */\n\n/**\n * @external {syntaxerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/syntaxerror\n */\n\n/**\n * @external {typeerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/typeerror\n */\n\n/**\n * @external {urierror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/urierror\n */\n\n/ numbers and dates\n/**\n * @external {number} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/number\n */\n/**\n * @external {number} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/number\n */\n\n/**\n * @external {date} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/date\n */\n\n/ text processing\n/**\n * @external {string} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/string\n */\n/**\n * @external {string} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/string\n */\n\n/**\n * @external {regexp} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/regexp\n */\n\n/ indexed collections\n/**\n * @external {array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/array\n */\n\n/**\n * @external {int8array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int8array\n */\n/**\n * @external {uint8array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint8array\n */\n\n/**\n * @external {uint8clampedarray} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint8clampedarray\n */\n\n/**\n * @external {int16array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int16array\n */\n\n/**\n * @external {uint16array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint16array\n */\n\n/**\n * @external {int32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int32array\n */\n\n/**\n * @external {uint32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint32array\n */\n\n/**\n * @external {float32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/float32array\n */\n\n/**\n * @external {float64array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/float64array\n */\n\n/ keyed collections\n/**\n * @external {map} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/map\n */\n\n/**\n * @external {set} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/set\n */\n\n/**\n * @external {weakmap} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/weakmap\n */\n\n/**\n * @external {weakset} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/weakset\n */\n\n/ structured data\n/**\n * @external {arraybuffer} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/arraybuffer\n */\n\n/**\n * @external {dataview} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/dataview\n */\n\n/**\n * @external {json} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/json\n */\n\n/ control abstraction objects\n/**\n * @external {promise} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/promise\n */\n\n/**\n * @external {generator} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/generator\n */\n\n/**\n * @external {generatorfunction} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/generatorfunction\n */\n\n/ reflection\n/**\n * @external {reflect} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/reflect\n */\n\n/**\n * @external {proxy} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/proxy\n */\n~promise",
    "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Promise",
    "\n/**\n * @external {Infinity} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Infinity\n */\n\n/**\n * @external {NaN} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/NaN\n */\n\n/**\n * @external {undefined} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/undefined\n */\n\n/**\n * @external {null} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/null\n */\n\n/ Fundamental objects\n/**\n * @external {Object} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object\n */\n/**\n * @external {object} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object\n */\n\n/**\n * @external {Function} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function\n */\n/**\n * @external {function} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function\n */\n\n/**\n * @external {Boolean} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean\n */\n/**\n * @external {boolean} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean\n */\n\n/**\n * @external {Symbol} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Symbol\n */\n\n/**\n * @external {Error} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Error\n */\n\n/**\n * @external {EvalError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/EvalError\n */\n\n/**\n * @external {InternalError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/InternalError\n */\n\n/**\n * @external {RangeError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RangeError\n */\n\n/**\n * @external {ReferenceError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ReferenceError\n */\n\n/**\n * @external {SyntaxError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/SyntaxError\n */\n\n/**\n * @external {TypeError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/TypeError\n */\n\n/**\n * @external {URIError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/URIError\n */\n\n/ Numbers and dates\n/**\n * @external {Number} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number\n */\n/**\n * @external {number} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number\n */\n\n/**\n * @external {Date} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Date\n */\n\n/ Text processing\n/**\n * @external {String} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String\n */\n/**\n * @external {string} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String\n */\n\n/**\n * @external {RegExp} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RegExp\n */\n\n/ Indexed collections\n/**\n * @external {Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array\n */\n\n/**\n * @external {Int8Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int8Array\n */\n/**\n * @external {Uint8Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint8Array\n */\n\n/**\n * @external {Uint8ClampedArray} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint8ClampedArray\n */\n\n/**\n * @external {Int16Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int16Array\n */\n\n/**\n * @external {Uint16Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint16Array\n */\n\n/**\n * @external {Int32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int32Array\n */\n\n/**\n * @external {Uint32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint32Array\n */\n\n/**\n * @external {Float32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Float32Array\n */\n\n/**\n * @external {Float64Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Float64Array\n */\n\n/ Keyed collections\n/**\n * @external {Map} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Map\n */\n\n/**\n * @external {Set} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Set\n */\n\n/**\n * @external {WeakMap} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakMap\n */\n\n/**\n * @external {WeakSet} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakSet\n */\n\n/ Structured data\n/**\n * @external {ArrayBuffer} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ArrayBuffer\n */\n\n/**\n * @external {DataView} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/DataView\n */\n\n/**\n * @external {JSON} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/JSON\n */\n\n/ Control abstraction objects\n/**\n * @external {Promise} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Promise\n */\n\n/**\n * @external {Generator} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Generator\n */\n\n/**\n * @external {GeneratorFunction} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/GeneratorFunction\n */\n\n/ Reflection\n/**\n * @external {Reflect} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Reflect\n */\n\n/**\n * @external {Proxy} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Proxy\n */\n~Promise",
    "external"
  ],
  [
    "\n/**\n * @external {infinity} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/infinity\n */\n\n/**\n * @external {nan} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/nan\n */\n\n/**\n * @external {undefined} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/undefined\n */\n\n/**\n * @external {null} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/null\n */\n\n/ fundamental objects\n/**\n * @external {object} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/object\n */\n/**\n * @external {object} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/object\n */\n\n/**\n * @external {function} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/function\n */\n/**\n * @external {function} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/function\n */\n\n/**\n * @external {boolean} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/boolean\n */\n/**\n * @external {boolean} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/boolean\n */\n\n/**\n * @external {symbol} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/symbol\n */\n\n/**\n * @external {error} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/error\n */\n\n/**\n * @external {evalerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/evalerror\n */\n\n/**\n * @external {internalerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/internalerror\n */\n\n/**\n * @external {rangeerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/rangeerror\n */\n\n/**\n * @external {referenceerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/referenceerror\n */\n\n/**\n * @external {syntaxerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/syntaxerror\n */\n\n/**\n * @external {typeerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/typeerror\n */\n\n/**\n * @external {urierror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/urierror\n */\n\n/ numbers and dates\n/**\n * @external {number} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/number\n */\n/**\n * @external {number} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/number\n */\n\n/**\n * @external {date} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/date\n */\n\n/ text processing\n/**\n * @external {string} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/string\n */\n/**\n * @external {string} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/string\n */\n\n/**\n * @external {regexp} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/regexp\n */\n\n/ indexed collections\n/**\n * @external {array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/array\n */\n\n/**\n * @external {int8array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int8array\n */\n/**\n * @external {uint8array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint8array\n */\n\n/**\n * @external {uint8clampedarray} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint8clampedarray\n */\n\n/**\n * @external {int16array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int16array\n */\n\n/**\n * @external {uint16array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint16array\n */\n\n/**\n * @external {int32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int32array\n */\n\n/**\n * @external {uint32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint32array\n */\n\n/**\n * @external {float32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/float32array\n */\n\n/**\n * @external {float64array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/float64array\n */\n\n/ keyed collections\n/**\n * @external {map} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/map\n */\n\n/**\n * @external {set} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/set\n */\n\n/**\n * @external {weakmap} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/weakmap\n */\n\n/**\n * @external {weakset} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/weakset\n */\n\n/ structured data\n/**\n * @external {arraybuffer} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/arraybuffer\n */\n\n/**\n * @external {dataview} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/dataview\n */\n\n/**\n * @external {json} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/json\n */\n\n/ control abstraction objects\n/**\n * @external {promise} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/promise\n */\n\n/**\n * @external {generator} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/generator\n */\n\n/**\n * @external {generatorfunction} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/generatorfunction\n */\n\n/ reflection\n/**\n * @external {reflect} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/reflect\n */\n\n/**\n * @external {proxy} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/proxy\n */\n~proxy",
    "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Proxy",
    "\n/**\n * @external {Infinity} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Infinity\n */\n\n/**\n * @external {NaN} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/NaN\n */\n\n/**\n * @external {undefined} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/undefined\n */\n\n/**\n * @external {null} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/null\n */\n\n/ Fundamental objects\n/**\n * @external {Object} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object\n */\n/**\n * @external {object} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object\n */\n\n/**\n * @external {Function} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function\n */\n/**\n * @external {function} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function\n */\n\n/**\n * @external {Boolean} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean\n */\n/**\n * @external {boolean} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean\n */\n\n/**\n * @external {Symbol} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Symbol\n */\n\n/**\n * @external {Error} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Error\n */\n\n/**\n * @external {EvalError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/EvalError\n */\n\n/**\n * @external {InternalError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/InternalError\n */\n\n/**\n * @external {RangeError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RangeError\n */\n\n/**\n * @external {ReferenceError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ReferenceError\n */\n\n/**\n * @external {SyntaxError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/SyntaxError\n */\n\n/**\n * @external {TypeError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/TypeError\n */\n\n/**\n * @external {URIError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/URIError\n */\n\n/ Numbers and dates\n/**\n * @external {Number} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number\n */\n/**\n * @external {number} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number\n */\n\n/**\n * @external {Date} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Date\n */\n\n/ Text processing\n/**\n * @external {String} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String\n */\n/**\n * @external {string} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String\n */\n\n/**\n * @external {RegExp} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RegExp\n */\n\n/ Indexed collections\n/**\n * @external {Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array\n */\n\n/**\n * @external {Int8Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int8Array\n */\n/**\n * @external {Uint8Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint8Array\n */\n\n/**\n * @external {Uint8ClampedArray} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint8ClampedArray\n */\n\n/**\n * @external {Int16Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int16Array\n */\n\n/**\n * @external {Uint16Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint16Array\n */\n\n/**\n * @external {Int32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int32Array\n */\n\n/**\n * @external {Uint32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint32Array\n */\n\n/**\n * @external {Float32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Float32Array\n */\n\n/**\n * @external {Float64Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Float64Array\n */\n\n/ Keyed collections\n/**\n * @external {Map} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Map\n */\n\n/**\n * @external {Set} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Set\n */\n\n/**\n * @external {WeakMap} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakMap\n */\n\n/**\n * @external {WeakSet} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakSet\n */\n\n/ Structured data\n/**\n * @external {ArrayBuffer} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ArrayBuffer\n */\n\n/**\n * @external {DataView} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/DataView\n */\n\n/**\n * @external {JSON} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/JSON\n */\n\n/ Control abstraction objects\n/**\n * @external {Promise} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Promise\n */\n\n/**\n * @external {Generator} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Generator\n */\n\n/**\n * @external {GeneratorFunction} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/GeneratorFunction\n */\n\n/ Reflection\n/**\n * @external {Reflect} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Reflect\n */\n\n/**\n * @external {Proxy} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Proxy\n */\n~Proxy",
    "external"
  ],
  [
    "\n/**\n * @external {infinity} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/infinity\n */\n\n/**\n * @external {nan} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/nan\n */\n\n/**\n * @external {undefined} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/undefined\n */\n\n/**\n * @external {null} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/null\n */\n\n/ fundamental objects\n/**\n * @external {object} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/object\n */\n/**\n * @external {object} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/object\n */\n\n/**\n * @external {function} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/function\n */\n/**\n * @external {function} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/function\n */\n\n/**\n * @external {boolean} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/boolean\n */\n/**\n * @external {boolean} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/boolean\n */\n\n/**\n * @external {symbol} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/symbol\n */\n\n/**\n * @external {error} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/error\n */\n\n/**\n * @external {evalerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/evalerror\n */\n\n/**\n * @external {internalerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/internalerror\n */\n\n/**\n * @external {rangeerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/rangeerror\n */\n\n/**\n * @external {referenceerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/referenceerror\n */\n\n/**\n * @external {syntaxerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/syntaxerror\n */\n\n/**\n * @external {typeerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/typeerror\n */\n\n/**\n * @external {urierror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/urierror\n */\n\n/ numbers and dates\n/**\n * @external {number} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/number\n */\n/**\n * @external {number} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/number\n */\n\n/**\n * @external {date} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/date\n */\n\n/ text processing\n/**\n * @external {string} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/string\n */\n/**\n * @external {string} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/string\n */\n\n/**\n * @external {regexp} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/regexp\n */\n\n/ indexed collections\n/**\n * @external {array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/array\n */\n\n/**\n * @external {int8array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int8array\n */\n/**\n * @external {uint8array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint8array\n */\n\n/**\n * @external {uint8clampedarray} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint8clampedarray\n */\n\n/**\n * @external {int16array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int16array\n */\n\n/**\n * @external {uint16array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint16array\n */\n\n/**\n * @external {int32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int32array\n */\n\n/**\n * @external {uint32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint32array\n */\n\n/**\n * @external {float32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/float32array\n */\n\n/**\n * @external {float64array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/float64array\n */\n\n/ keyed collections\n/**\n * @external {map} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/map\n */\n\n/**\n * @external {set} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/set\n */\n\n/**\n * @external {weakmap} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/weakmap\n */\n\n/**\n * @external {weakset} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/weakset\n */\n\n/ structured data\n/**\n * @external {arraybuffer} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/arraybuffer\n */\n\n/**\n * @external {dataview} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/dataview\n */\n\n/**\n * @external {json} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/json\n */\n\n/ control abstraction objects\n/**\n * @external {promise} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/promise\n */\n\n/**\n * @external {generator} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/generator\n */\n\n/**\n * @external {generatorfunction} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/generatorfunction\n */\n\n/ reflection\n/**\n * @external {reflect} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/reflect\n */\n\n/**\n * @external {proxy} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/proxy\n */\n~rangeerror",
    "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RangeError",
    "\n/**\n * @external {Infinity} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Infinity\n */\n\n/**\n * @external {NaN} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/NaN\n */\n\n/**\n * @external {undefined} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/undefined\n */\n\n/**\n * @external {null} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/null\n */\n\n/ Fundamental objects\n/**\n * @external {Object} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object\n */\n/**\n * @external {object} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object\n */\n\n/**\n * @external {Function} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function\n */\n/**\n * @external {function} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function\n */\n\n/**\n * @external {Boolean} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean\n */\n/**\n * @external {boolean} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean\n */\n\n/**\n * @external {Symbol} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Symbol\n */\n\n/**\n * @external {Error} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Error\n */\n\n/**\n * @external {EvalError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/EvalError\n */\n\n/**\n * @external {InternalError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/InternalError\n */\n\n/**\n * @external {RangeError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RangeError\n */\n\n/**\n * @external {ReferenceError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ReferenceError\n */\n\n/**\n * @external {SyntaxError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/SyntaxError\n */\n\n/**\n * @external {TypeError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/TypeError\n */\n\n/**\n * @external {URIError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/URIError\n */\n\n/ Numbers and dates\n/**\n * @external {Number} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number\n */\n/**\n * @external {number} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number\n */\n\n/**\n * @external {Date} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Date\n */\n\n/ Text processing\n/**\n * @external {String} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String\n */\n/**\n * @external {string} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String\n */\n\n/**\n * @external {RegExp} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RegExp\n */\n\n/ Indexed collections\n/**\n * @external {Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array\n */\n\n/**\n * @external {Int8Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int8Array\n */\n/**\n * @external {Uint8Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint8Array\n */\n\n/**\n * @external {Uint8ClampedArray} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint8ClampedArray\n */\n\n/**\n * @external {Int16Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int16Array\n */\n\n/**\n * @external {Uint16Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint16Array\n */\n\n/**\n * @external {Int32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int32Array\n */\n\n/**\n * @external {Uint32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint32Array\n */\n\n/**\n * @external {Float32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Float32Array\n */\n\n/**\n * @external {Float64Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Float64Array\n */\n\n/ Keyed collections\n/**\n * @external {Map} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Map\n */\n\n/**\n * @external {Set} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Set\n */\n\n/**\n * @external {WeakMap} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakMap\n */\n\n/**\n * @external {WeakSet} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakSet\n */\n\n/ Structured data\n/**\n * @external {ArrayBuffer} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ArrayBuffer\n */\n\n/**\n * @external {DataView} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/DataView\n */\n\n/**\n * @external {JSON} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/JSON\n */\n\n/ Control abstraction objects\n/**\n * @external {Promise} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Promise\n */\n\n/**\n * @external {Generator} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Generator\n */\n\n/**\n * @external {GeneratorFunction} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/GeneratorFunction\n */\n\n/ Reflection\n/**\n * @external {Reflect} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Reflect\n */\n\n/**\n * @external {Proxy} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Proxy\n */\n~RangeError",
    "external"
  ],
  [
    "\n/**\n * @external {infinity} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/infinity\n */\n\n/**\n * @external {nan} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/nan\n */\n\n/**\n * @external {undefined} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/undefined\n */\n\n/**\n * @external {null} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/null\n */\n\n/ fundamental objects\n/**\n * @external {object} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/object\n */\n/**\n * @external {object} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/object\n */\n\n/**\n * @external {function} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/function\n */\n/**\n * @external {function} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/function\n */\n\n/**\n * @external {boolean} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/boolean\n */\n/**\n * @external {boolean} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/boolean\n */\n\n/**\n * @external {symbol} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/symbol\n */\n\n/**\n * @external {error} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/error\n */\n\n/**\n * @external {evalerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/evalerror\n */\n\n/**\n * @external {internalerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/internalerror\n */\n\n/**\n * @external {rangeerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/rangeerror\n */\n\n/**\n * @external {referenceerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/referenceerror\n */\n\n/**\n * @external {syntaxerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/syntaxerror\n */\n\n/**\n * @external {typeerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/typeerror\n */\n\n/**\n * @external {urierror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/urierror\n */\n\n/ numbers and dates\n/**\n * @external {number} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/number\n */\n/**\n * @external {number} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/number\n */\n\n/**\n * @external {date} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/date\n */\n\n/ text processing\n/**\n * @external {string} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/string\n */\n/**\n * @external {string} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/string\n */\n\n/**\n * @external {regexp} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/regexp\n */\n\n/ indexed collections\n/**\n * @external {array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/array\n */\n\n/**\n * @external {int8array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int8array\n */\n/**\n * @external {uint8array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint8array\n */\n\n/**\n * @external {uint8clampedarray} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint8clampedarray\n */\n\n/**\n * @external {int16array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int16array\n */\n\n/**\n * @external {uint16array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint16array\n */\n\n/**\n * @external {int32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int32array\n */\n\n/**\n * @external {uint32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint32array\n */\n\n/**\n * @external {float32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/float32array\n */\n\n/**\n * @external {float64array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/float64array\n */\n\n/ keyed collections\n/**\n * @external {map} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/map\n */\n\n/**\n * @external {set} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/set\n */\n\n/**\n * @external {weakmap} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/weakmap\n */\n\n/**\n * @external {weakset} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/weakset\n */\n\n/ structured data\n/**\n * @external {arraybuffer} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/arraybuffer\n */\n\n/**\n * @external {dataview} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/dataview\n */\n\n/**\n * @external {json} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/json\n */\n\n/ control abstraction objects\n/**\n * @external {promise} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/promise\n */\n\n/**\n * @external {generator} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/generator\n */\n\n/**\n * @external {generatorfunction} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/generatorfunction\n */\n\n/ reflection\n/**\n * @external {reflect} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/reflect\n */\n\n/**\n * @external {proxy} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/proxy\n */\n~referenceerror",
    "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ReferenceError",
    "\n/**\n * @external {Infinity} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Infinity\n */\n\n/**\n * @external {NaN} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/NaN\n */\n\n/**\n * @external {undefined} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/undefined\n */\n\n/**\n * @external {null} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/null\n */\n\n/ Fundamental objects\n/**\n * @external {Object} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object\n */\n/**\n * @external {object} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object\n */\n\n/**\n * @external {Function} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function\n */\n/**\n * @external {function} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function\n */\n\n/**\n * @external {Boolean} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean\n */\n/**\n * @external {boolean} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean\n */\n\n/**\n * @external {Symbol} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Symbol\n */\n\n/**\n * @external {Error} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Error\n */\n\n/**\n * @external {EvalError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/EvalError\n */\n\n/**\n * @external {InternalError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/InternalError\n */\n\n/**\n * @external {RangeError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RangeError\n */\n\n/**\n * @external {ReferenceError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ReferenceError\n */\n\n/**\n * @external {SyntaxError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/SyntaxError\n */\n\n/**\n * @external {TypeError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/TypeError\n */\n\n/**\n * @external {URIError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/URIError\n */\n\n/ Numbers and dates\n/**\n * @external {Number} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number\n */\n/**\n * @external {number} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number\n */\n\n/**\n * @external {Date} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Date\n */\n\n/ Text processing\n/**\n * @external {String} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String\n */\n/**\n * @external {string} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String\n */\n\n/**\n * @external {RegExp} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RegExp\n */\n\n/ Indexed collections\n/**\n * @external {Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array\n */\n\n/**\n * @external {Int8Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int8Array\n */\n/**\n * @external {Uint8Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint8Array\n */\n\n/**\n * @external {Uint8ClampedArray} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint8ClampedArray\n */\n\n/**\n * @external {Int16Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int16Array\n */\n\n/**\n * @external {Uint16Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint16Array\n */\n\n/**\n * @external {Int32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int32Array\n */\n\n/**\n * @external {Uint32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint32Array\n */\n\n/**\n * @external {Float32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Float32Array\n */\n\n/**\n * @external {Float64Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Float64Array\n */\n\n/ Keyed collections\n/**\n * @external {Map} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Map\n */\n\n/**\n * @external {Set} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Set\n */\n\n/**\n * @external {WeakMap} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakMap\n */\n\n/**\n * @external {WeakSet} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakSet\n */\n\n/ Structured data\n/**\n * @external {ArrayBuffer} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ArrayBuffer\n */\n\n/**\n * @external {DataView} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/DataView\n */\n\n/**\n * @external {JSON} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/JSON\n */\n\n/ Control abstraction objects\n/**\n * @external {Promise} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Promise\n */\n\n/**\n * @external {Generator} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Generator\n */\n\n/**\n * @external {GeneratorFunction} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/GeneratorFunction\n */\n\n/ Reflection\n/**\n * @external {Reflect} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Reflect\n */\n\n/**\n * @external {Proxy} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Proxy\n */\n~ReferenceError",
    "external"
  ],
  [
    "\n/**\n * @external {infinity} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/infinity\n */\n\n/**\n * @external {nan} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/nan\n */\n\n/**\n * @external {undefined} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/undefined\n */\n\n/**\n * @external {null} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/null\n */\n\n/ fundamental objects\n/**\n * @external {object} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/object\n */\n/**\n * @external {object} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/object\n */\n\n/**\n * @external {function} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/function\n */\n/**\n * @external {function} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/function\n */\n\n/**\n * @external {boolean} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/boolean\n */\n/**\n * @external {boolean} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/boolean\n */\n\n/**\n * @external {symbol} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/symbol\n */\n\n/**\n * @external {error} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/error\n */\n\n/**\n * @external {evalerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/evalerror\n */\n\n/**\n * @external {internalerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/internalerror\n */\n\n/**\n * @external {rangeerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/rangeerror\n */\n\n/**\n * @external {referenceerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/referenceerror\n */\n\n/**\n * @external {syntaxerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/syntaxerror\n */\n\n/**\n * @external {typeerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/typeerror\n */\n\n/**\n * @external {urierror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/urierror\n */\n\n/ numbers and dates\n/**\n * @external {number} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/number\n */\n/**\n * @external {number} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/number\n */\n\n/**\n * @external {date} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/date\n */\n\n/ text processing\n/**\n * @external {string} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/string\n */\n/**\n * @external {string} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/string\n */\n\n/**\n * @external {regexp} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/regexp\n */\n\n/ indexed collections\n/**\n * @external {array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/array\n */\n\n/**\n * @external {int8array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int8array\n */\n/**\n * @external {uint8array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint8array\n */\n\n/**\n * @external {uint8clampedarray} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint8clampedarray\n */\n\n/**\n * @external {int16array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int16array\n */\n\n/**\n * @external {uint16array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint16array\n */\n\n/**\n * @external {int32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int32array\n */\n\n/**\n * @external {uint32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint32array\n */\n\n/**\n * @external {float32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/float32array\n */\n\n/**\n * @external {float64array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/float64array\n */\n\n/ keyed collections\n/**\n * @external {map} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/map\n */\n\n/**\n * @external {set} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/set\n */\n\n/**\n * @external {weakmap} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/weakmap\n */\n\n/**\n * @external {weakset} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/weakset\n */\n\n/ structured data\n/**\n * @external {arraybuffer} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/arraybuffer\n */\n\n/**\n * @external {dataview} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/dataview\n */\n\n/**\n * @external {json} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/json\n */\n\n/ control abstraction objects\n/**\n * @external {promise} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/promise\n */\n\n/**\n * @external {generator} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/generator\n */\n\n/**\n * @external {generatorfunction} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/generatorfunction\n */\n\n/ reflection\n/**\n * @external {reflect} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/reflect\n */\n\n/**\n * @external {proxy} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/proxy\n */\n~reflect",
    "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Reflect",
    "\n/**\n * @external {Infinity} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Infinity\n */\n\n/**\n * @external {NaN} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/NaN\n */\n\n/**\n * @external {undefined} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/undefined\n */\n\n/**\n * @external {null} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/null\n */\n\n/ Fundamental objects\n/**\n * @external {Object} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object\n */\n/**\n * @external {object} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object\n */\n\n/**\n * @external {Function} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function\n */\n/**\n * @external {function} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function\n */\n\n/**\n * @external {Boolean} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean\n */\n/**\n * @external {boolean} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean\n */\n\n/**\n * @external {Symbol} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Symbol\n */\n\n/**\n * @external {Error} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Error\n */\n\n/**\n * @external {EvalError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/EvalError\n */\n\n/**\n * @external {InternalError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/InternalError\n */\n\n/**\n * @external {RangeError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RangeError\n */\n\n/**\n * @external {ReferenceError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ReferenceError\n */\n\n/**\n * @external {SyntaxError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/SyntaxError\n */\n\n/**\n * @external {TypeError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/TypeError\n */\n\n/**\n * @external {URIError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/URIError\n */\n\n/ Numbers and dates\n/**\n * @external {Number} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number\n */\n/**\n * @external {number} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number\n */\n\n/**\n * @external {Date} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Date\n */\n\n/ Text processing\n/**\n * @external {String} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String\n */\n/**\n * @external {string} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String\n */\n\n/**\n * @external {RegExp} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RegExp\n */\n\n/ Indexed collections\n/**\n * @external {Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array\n */\n\n/**\n * @external {Int8Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int8Array\n */\n/**\n * @external {Uint8Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint8Array\n */\n\n/**\n * @external {Uint8ClampedArray} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint8ClampedArray\n */\n\n/**\n * @external {Int16Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int16Array\n */\n\n/**\n * @external {Uint16Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint16Array\n */\n\n/**\n * @external {Int32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int32Array\n */\n\n/**\n * @external {Uint32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint32Array\n */\n\n/**\n * @external {Float32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Float32Array\n */\n\n/**\n * @external {Float64Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Float64Array\n */\n\n/ Keyed collections\n/**\n * @external {Map} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Map\n */\n\n/**\n * @external {Set} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Set\n */\n\n/**\n * @external {WeakMap} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakMap\n */\n\n/**\n * @external {WeakSet} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakSet\n */\n\n/ Structured data\n/**\n * @external {ArrayBuffer} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ArrayBuffer\n */\n\n/**\n * @external {DataView} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/DataView\n */\n\n/**\n * @external {JSON} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/JSON\n */\n\n/ Control abstraction objects\n/**\n * @external {Promise} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Promise\n */\n\n/**\n * @external {Generator} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Generator\n */\n\n/**\n * @external {GeneratorFunction} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/GeneratorFunction\n */\n\n/ Reflection\n/**\n * @external {Reflect} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Reflect\n */\n\n/**\n * @external {Proxy} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Proxy\n */\n~Reflect",
    "external"
  ],
  [
    "\n/**\n * @external {infinity} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/infinity\n */\n\n/**\n * @external {nan} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/nan\n */\n\n/**\n * @external {undefined} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/undefined\n */\n\n/**\n * @external {null} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/null\n */\n\n/ fundamental objects\n/**\n * @external {object} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/object\n */\n/**\n * @external {object} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/object\n */\n\n/**\n * @external {function} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/function\n */\n/**\n * @external {function} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/function\n */\n\n/**\n * @external {boolean} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/boolean\n */\n/**\n * @external {boolean} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/boolean\n */\n\n/**\n * @external {symbol} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/symbol\n */\n\n/**\n * @external {error} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/error\n */\n\n/**\n * @external {evalerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/evalerror\n */\n\n/**\n * @external {internalerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/internalerror\n */\n\n/**\n * @external {rangeerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/rangeerror\n */\n\n/**\n * @external {referenceerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/referenceerror\n */\n\n/**\n * @external {syntaxerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/syntaxerror\n */\n\n/**\n * @external {typeerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/typeerror\n */\n\n/**\n * @external {urierror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/urierror\n */\n\n/ numbers and dates\n/**\n * @external {number} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/number\n */\n/**\n * @external {number} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/number\n */\n\n/**\n * @external {date} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/date\n */\n\n/ text processing\n/**\n * @external {string} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/string\n */\n/**\n * @external {string} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/string\n */\n\n/**\n * @external {regexp} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/regexp\n */\n\n/ indexed collections\n/**\n * @external {array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/array\n */\n\n/**\n * @external {int8array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int8array\n */\n/**\n * @external {uint8array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint8array\n */\n\n/**\n * @external {uint8clampedarray} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint8clampedarray\n */\n\n/**\n * @external {int16array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int16array\n */\n\n/**\n * @external {uint16array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint16array\n */\n\n/**\n * @external {int32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int32array\n */\n\n/**\n * @external {uint32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint32array\n */\n\n/**\n * @external {float32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/float32array\n */\n\n/**\n * @external {float64array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/float64array\n */\n\n/ keyed collections\n/**\n * @external {map} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/map\n */\n\n/**\n * @external {set} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/set\n */\n\n/**\n * @external {weakmap} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/weakmap\n */\n\n/**\n * @external {weakset} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/weakset\n */\n\n/ structured data\n/**\n * @external {arraybuffer} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/arraybuffer\n */\n\n/**\n * @external {dataview} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/dataview\n */\n\n/**\n * @external {json} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/json\n */\n\n/ control abstraction objects\n/**\n * @external {promise} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/promise\n */\n\n/**\n * @external {generator} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/generator\n */\n\n/**\n * @external {generatorfunction} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/generatorfunction\n */\n\n/ reflection\n/**\n * @external {reflect} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/reflect\n */\n\n/**\n * @external {proxy} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/proxy\n */\n~regexp",
    "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RegExp",
    "\n/**\n * @external {Infinity} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Infinity\n */\n\n/**\n * @external {NaN} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/NaN\n */\n\n/**\n * @external {undefined} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/undefined\n */\n\n/**\n * @external {null} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/null\n */\n\n/ Fundamental objects\n/**\n * @external {Object} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object\n */\n/**\n * @external {object} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object\n */\n\n/**\n * @external {Function} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function\n */\n/**\n * @external {function} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function\n */\n\n/**\n * @external {Boolean} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean\n */\n/**\n * @external {boolean} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean\n */\n\n/**\n * @external {Symbol} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Symbol\n */\n\n/**\n * @external {Error} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Error\n */\n\n/**\n * @external {EvalError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/EvalError\n */\n\n/**\n * @external {InternalError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/InternalError\n */\n\n/**\n * @external {RangeError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RangeError\n */\n\n/**\n * @external {ReferenceError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ReferenceError\n */\n\n/**\n * @external {SyntaxError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/SyntaxError\n */\n\n/**\n * @external {TypeError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/TypeError\n */\n\n/**\n * @external {URIError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/URIError\n */\n\n/ Numbers and dates\n/**\n * @external {Number} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number\n */\n/**\n * @external {number} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number\n */\n\n/**\n * @external {Date} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Date\n */\n\n/ Text processing\n/**\n * @external {String} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String\n */\n/**\n * @external {string} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String\n */\n\n/**\n * @external {RegExp} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RegExp\n */\n\n/ Indexed collections\n/**\n * @external {Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array\n */\n\n/**\n * @external {Int8Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int8Array\n */\n/**\n * @external {Uint8Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint8Array\n */\n\n/**\n * @external {Uint8ClampedArray} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint8ClampedArray\n */\n\n/**\n * @external {Int16Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int16Array\n */\n\n/**\n * @external {Uint16Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint16Array\n */\n\n/**\n * @external {Int32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int32Array\n */\n\n/**\n * @external {Uint32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint32Array\n */\n\n/**\n * @external {Float32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Float32Array\n */\n\n/**\n * @external {Float64Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Float64Array\n */\n\n/ Keyed collections\n/**\n * @external {Map} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Map\n */\n\n/**\n * @external {Set} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Set\n */\n\n/**\n * @external {WeakMap} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakMap\n */\n\n/**\n * @external {WeakSet} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakSet\n */\n\n/ Structured data\n/**\n * @external {ArrayBuffer} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ArrayBuffer\n */\n\n/**\n * @external {DataView} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/DataView\n */\n\n/**\n * @external {JSON} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/JSON\n */\n\n/ Control abstraction objects\n/**\n * @external {Promise} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Promise\n */\n\n/**\n * @external {Generator} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Generator\n */\n\n/**\n * @external {GeneratorFunction} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/GeneratorFunction\n */\n\n/ Reflection\n/**\n * @external {Reflect} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Reflect\n */\n\n/**\n * @external {Proxy} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Proxy\n */\n~RegExp",
    "external"
  ],
  [
    "\n/**\n * @external {infinity} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/infinity\n */\n\n/**\n * @external {nan} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/nan\n */\n\n/**\n * @external {undefined} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/undefined\n */\n\n/**\n * @external {null} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/null\n */\n\n/ fundamental objects\n/**\n * @external {object} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/object\n */\n/**\n * @external {object} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/object\n */\n\n/**\n * @external {function} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/function\n */\n/**\n * @external {function} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/function\n */\n\n/**\n * @external {boolean} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/boolean\n */\n/**\n * @external {boolean} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/boolean\n */\n\n/**\n * @external {symbol} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/symbol\n */\n\n/**\n * @external {error} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/error\n */\n\n/**\n * @external {evalerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/evalerror\n */\n\n/**\n * @external {internalerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/internalerror\n */\n\n/**\n * @external {rangeerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/rangeerror\n */\n\n/**\n * @external {referenceerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/referenceerror\n */\n\n/**\n * @external {syntaxerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/syntaxerror\n */\n\n/**\n * @external {typeerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/typeerror\n */\n\n/**\n * @external {urierror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/urierror\n */\n\n/ numbers and dates\n/**\n * @external {number} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/number\n */\n/**\n * @external {number} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/number\n */\n\n/**\n * @external {date} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/date\n */\n\n/ text processing\n/**\n * @external {string} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/string\n */\n/**\n * @external {string} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/string\n */\n\n/**\n * @external {regexp} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/regexp\n */\n\n/ indexed collections\n/**\n * @external {array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/array\n */\n\n/**\n * @external {int8array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int8array\n */\n/**\n * @external {uint8array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint8array\n */\n\n/**\n * @external {uint8clampedarray} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint8clampedarray\n */\n\n/**\n * @external {int16array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int16array\n */\n\n/**\n * @external {uint16array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint16array\n */\n\n/**\n * @external {int32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int32array\n */\n\n/**\n * @external {uint32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint32array\n */\n\n/**\n * @external {float32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/float32array\n */\n\n/**\n * @external {float64array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/float64array\n */\n\n/ keyed collections\n/**\n * @external {map} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/map\n */\n\n/**\n * @external {set} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/set\n */\n\n/**\n * @external {weakmap} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/weakmap\n */\n\n/**\n * @external {weakset} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/weakset\n */\n\n/ structured data\n/**\n * @external {arraybuffer} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/arraybuffer\n */\n\n/**\n * @external {dataview} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/dataview\n */\n\n/**\n * @external {json} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/json\n */\n\n/ control abstraction objects\n/**\n * @external {promise} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/promise\n */\n\n/**\n * @external {generator} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/generator\n */\n\n/**\n * @external {generatorfunction} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/generatorfunction\n */\n\n/ reflection\n/**\n * @external {reflect} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/reflect\n */\n\n/**\n * @external {proxy} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/proxy\n */\n~set",
    "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Set",
    "\n/**\n * @external {Infinity} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Infinity\n */\n\n/**\n * @external {NaN} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/NaN\n */\n\n/**\n * @external {undefined} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/undefined\n */\n\n/**\n * @external {null} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/null\n */\n\n/ Fundamental objects\n/**\n * @external {Object} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object\n */\n/**\n * @external {object} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object\n */\n\n/**\n * @external {Function} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function\n */\n/**\n * @external {function} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function\n */\n\n/**\n * @external {Boolean} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean\n */\n/**\n * @external {boolean} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean\n */\n\n/**\n * @external {Symbol} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Symbol\n */\n\n/**\n * @external {Error} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Error\n */\n\n/**\n * @external {EvalError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/EvalError\n */\n\n/**\n * @external {InternalError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/InternalError\n */\n\n/**\n * @external {RangeError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RangeError\n */\n\n/**\n * @external {ReferenceError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ReferenceError\n */\n\n/**\n * @external {SyntaxError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/SyntaxError\n */\n\n/**\n * @external {TypeError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/TypeError\n */\n\n/**\n * @external {URIError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/URIError\n */\n\n/ Numbers and dates\n/**\n * @external {Number} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number\n */\n/**\n * @external {number} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number\n */\n\n/**\n * @external {Date} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Date\n */\n\n/ Text processing\n/**\n * @external {String} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String\n */\n/**\n * @external {string} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String\n */\n\n/**\n * @external {RegExp} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RegExp\n */\n\n/ Indexed collections\n/**\n * @external {Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array\n */\n\n/**\n * @external {Int8Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int8Array\n */\n/**\n * @external {Uint8Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint8Array\n */\n\n/**\n * @external {Uint8ClampedArray} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint8ClampedArray\n */\n\n/**\n * @external {Int16Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int16Array\n */\n\n/**\n * @external {Uint16Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint16Array\n */\n\n/**\n * @external {Int32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int32Array\n */\n\n/**\n * @external {Uint32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint32Array\n */\n\n/**\n * @external {Float32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Float32Array\n */\n\n/**\n * @external {Float64Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Float64Array\n */\n\n/ Keyed collections\n/**\n * @external {Map} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Map\n */\n\n/**\n * @external {Set} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Set\n */\n\n/**\n * @external {WeakMap} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakMap\n */\n\n/**\n * @external {WeakSet} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakSet\n */\n\n/ Structured data\n/**\n * @external {ArrayBuffer} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ArrayBuffer\n */\n\n/**\n * @external {DataView} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/DataView\n */\n\n/**\n * @external {JSON} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/JSON\n */\n\n/ Control abstraction objects\n/**\n * @external {Promise} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Promise\n */\n\n/**\n * @external {Generator} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Generator\n */\n\n/**\n * @external {GeneratorFunction} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/GeneratorFunction\n */\n\n/ Reflection\n/**\n * @external {Reflect} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Reflect\n */\n\n/**\n * @external {Proxy} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Proxy\n */\n~Set",
    "external"
  ],
  [
    "\n/**\n * @external {infinity} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/infinity\n */\n\n/**\n * @external {nan} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/nan\n */\n\n/**\n * @external {undefined} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/undefined\n */\n\n/**\n * @external {null} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/null\n */\n\n/ fundamental objects\n/**\n * @external {object} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/object\n */\n/**\n * @external {object} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/object\n */\n\n/**\n * @external {function} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/function\n */\n/**\n * @external {function} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/function\n */\n\n/**\n * @external {boolean} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/boolean\n */\n/**\n * @external {boolean} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/boolean\n */\n\n/**\n * @external {symbol} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/symbol\n */\n\n/**\n * @external {error} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/error\n */\n\n/**\n * @external {evalerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/evalerror\n */\n\n/**\n * @external {internalerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/internalerror\n */\n\n/**\n * @external {rangeerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/rangeerror\n */\n\n/**\n * @external {referenceerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/referenceerror\n */\n\n/**\n * @external {syntaxerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/syntaxerror\n */\n\n/**\n * @external {typeerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/typeerror\n */\n\n/**\n * @external {urierror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/urierror\n */\n\n/ numbers and dates\n/**\n * @external {number} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/number\n */\n/**\n * @external {number} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/number\n */\n\n/**\n * @external {date} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/date\n */\n\n/ text processing\n/**\n * @external {string} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/string\n */\n/**\n * @external {string} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/string\n */\n\n/**\n * @external {regexp} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/regexp\n */\n\n/ indexed collections\n/**\n * @external {array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/array\n */\n\n/**\n * @external {int8array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int8array\n */\n/**\n * @external {uint8array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint8array\n */\n\n/**\n * @external {uint8clampedarray} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint8clampedarray\n */\n\n/**\n * @external {int16array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int16array\n */\n\n/**\n * @external {uint16array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint16array\n */\n\n/**\n * @external {int32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int32array\n */\n\n/**\n * @external {uint32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint32array\n */\n\n/**\n * @external {float32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/float32array\n */\n\n/**\n * @external {float64array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/float64array\n */\n\n/ keyed collections\n/**\n * @external {map} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/map\n */\n\n/**\n * @external {set} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/set\n */\n\n/**\n * @external {weakmap} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/weakmap\n */\n\n/**\n * @external {weakset} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/weakset\n */\n\n/ structured data\n/**\n * @external {arraybuffer} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/arraybuffer\n */\n\n/**\n * @external {dataview} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/dataview\n */\n\n/**\n * @external {json} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/json\n */\n\n/ control abstraction objects\n/**\n * @external {promise} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/promise\n */\n\n/**\n * @external {generator} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/generator\n */\n\n/**\n * @external {generatorfunction} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/generatorfunction\n */\n\n/ reflection\n/**\n * @external {reflect} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/reflect\n */\n\n/**\n * @external {proxy} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/proxy\n */\n~string",
    "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String",
    "\n/**\n * @external {Infinity} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Infinity\n */\n\n/**\n * @external {NaN} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/NaN\n */\n\n/**\n * @external {undefined} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/undefined\n */\n\n/**\n * @external {null} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/null\n */\n\n/ Fundamental objects\n/**\n * @external {Object} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object\n */\n/**\n * @external {object} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object\n */\n\n/**\n * @external {Function} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function\n */\n/**\n * @external {function} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function\n */\n\n/**\n * @external {Boolean} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean\n */\n/**\n * @external {boolean} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean\n */\n\n/**\n * @external {Symbol} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Symbol\n */\n\n/**\n * @external {Error} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Error\n */\n\n/**\n * @external {EvalError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/EvalError\n */\n\n/**\n * @external {InternalError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/InternalError\n */\n\n/**\n * @external {RangeError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RangeError\n */\n\n/**\n * @external {ReferenceError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ReferenceError\n */\n\n/**\n * @external {SyntaxError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/SyntaxError\n */\n\n/**\n * @external {TypeError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/TypeError\n */\n\n/**\n * @external {URIError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/URIError\n */\n\n/ Numbers and dates\n/**\n * @external {Number} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number\n */\n/**\n * @external {number} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number\n */\n\n/**\n * @external {Date} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Date\n */\n\n/ Text processing\n/**\n * @external {String} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String\n */\n/**\n * @external {string} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String\n */\n\n/**\n * @external {RegExp} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RegExp\n */\n\n/ Indexed collections\n/**\n * @external {Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array\n */\n\n/**\n * @external {Int8Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int8Array\n */\n/**\n * @external {Uint8Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint8Array\n */\n\n/**\n * @external {Uint8ClampedArray} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint8ClampedArray\n */\n\n/**\n * @external {Int16Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int16Array\n */\n\n/**\n * @external {Uint16Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint16Array\n */\n\n/**\n * @external {Int32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int32Array\n */\n\n/**\n * @external {Uint32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint32Array\n */\n\n/**\n * @external {Float32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Float32Array\n */\n\n/**\n * @external {Float64Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Float64Array\n */\n\n/ Keyed collections\n/**\n * @external {Map} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Map\n */\n\n/**\n * @external {Set} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Set\n */\n\n/**\n * @external {WeakMap} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakMap\n */\n\n/**\n * @external {WeakSet} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakSet\n */\n\n/ Structured data\n/**\n * @external {ArrayBuffer} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ArrayBuffer\n */\n\n/**\n * @external {DataView} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/DataView\n */\n\n/**\n * @external {JSON} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/JSON\n */\n\n/ Control abstraction objects\n/**\n * @external {Promise} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Promise\n */\n\n/**\n * @external {Generator} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Generator\n */\n\n/**\n * @external {GeneratorFunction} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/GeneratorFunction\n */\n\n/ Reflection\n/**\n * @external {Reflect} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Reflect\n */\n\n/**\n * @external {Proxy} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Proxy\n */\n~String",
    "external"
  ],
  [
    "\n/**\n * @external {infinity} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/infinity\n */\n\n/**\n * @external {nan} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/nan\n */\n\n/**\n * @external {undefined} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/undefined\n */\n\n/**\n * @external {null} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/null\n */\n\n/ fundamental objects\n/**\n * @external {object} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/object\n */\n/**\n * @external {object} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/object\n */\n\n/**\n * @external {function} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/function\n */\n/**\n * @external {function} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/function\n */\n\n/**\n * @external {boolean} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/boolean\n */\n/**\n * @external {boolean} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/boolean\n */\n\n/**\n * @external {symbol} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/symbol\n */\n\n/**\n * @external {error} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/error\n */\n\n/**\n * @external {evalerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/evalerror\n */\n\n/**\n * @external {internalerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/internalerror\n */\n\n/**\n * @external {rangeerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/rangeerror\n */\n\n/**\n * @external {referenceerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/referenceerror\n */\n\n/**\n * @external {syntaxerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/syntaxerror\n */\n\n/**\n * @external {typeerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/typeerror\n */\n\n/**\n * @external {urierror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/urierror\n */\n\n/ numbers and dates\n/**\n * @external {number} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/number\n */\n/**\n * @external {number} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/number\n */\n\n/**\n * @external {date} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/date\n */\n\n/ text processing\n/**\n * @external {string} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/string\n */\n/**\n * @external {string} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/string\n */\n\n/**\n * @external {regexp} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/regexp\n */\n\n/ indexed collections\n/**\n * @external {array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/array\n */\n\n/**\n * @external {int8array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int8array\n */\n/**\n * @external {uint8array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint8array\n */\n\n/**\n * @external {uint8clampedarray} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint8clampedarray\n */\n\n/**\n * @external {int16array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int16array\n */\n\n/**\n * @external {uint16array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint16array\n */\n\n/**\n * @external {int32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int32array\n */\n\n/**\n * @external {uint32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint32array\n */\n\n/**\n * @external {float32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/float32array\n */\n\n/**\n * @external {float64array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/float64array\n */\n\n/ keyed collections\n/**\n * @external {map} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/map\n */\n\n/**\n * @external {set} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/set\n */\n\n/**\n * @external {weakmap} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/weakmap\n */\n\n/**\n * @external {weakset} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/weakset\n */\n\n/ structured data\n/**\n * @external {arraybuffer} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/arraybuffer\n */\n\n/**\n * @external {dataview} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/dataview\n */\n\n/**\n * @external {json} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/json\n */\n\n/ control abstraction objects\n/**\n * @external {promise} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/promise\n */\n\n/**\n * @external {generator} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/generator\n */\n\n/**\n * @external {generatorfunction} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/generatorfunction\n */\n\n/ reflection\n/**\n * @external {reflect} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/reflect\n */\n\n/**\n * @external {proxy} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/proxy\n */\n~symbol",
    "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Symbol",
    "\n/**\n * @external {Infinity} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Infinity\n */\n\n/**\n * @external {NaN} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/NaN\n */\n\n/**\n * @external {undefined} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/undefined\n */\n\n/**\n * @external {null} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/null\n */\n\n/ Fundamental objects\n/**\n * @external {Object} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object\n */\n/**\n * @external {object} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object\n */\n\n/**\n * @external {Function} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function\n */\n/**\n * @external {function} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function\n */\n\n/**\n * @external {Boolean} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean\n */\n/**\n * @external {boolean} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean\n */\n\n/**\n * @external {Symbol} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Symbol\n */\n\n/**\n * @external {Error} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Error\n */\n\n/**\n * @external {EvalError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/EvalError\n */\n\n/**\n * @external {InternalError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/InternalError\n */\n\n/**\n * @external {RangeError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RangeError\n */\n\n/**\n * @external {ReferenceError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ReferenceError\n */\n\n/**\n * @external {SyntaxError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/SyntaxError\n */\n\n/**\n * @external {TypeError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/TypeError\n */\n\n/**\n * @external {URIError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/URIError\n */\n\n/ Numbers and dates\n/**\n * @external {Number} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number\n */\n/**\n * @external {number} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number\n */\n\n/**\n * @external {Date} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Date\n */\n\n/ Text processing\n/**\n * @external {String} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String\n */\n/**\n * @external {string} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String\n */\n\n/**\n * @external {RegExp} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RegExp\n */\n\n/ Indexed collections\n/**\n * @external {Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array\n */\n\n/**\n * @external {Int8Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int8Array\n */\n/**\n * @external {Uint8Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint8Array\n */\n\n/**\n * @external {Uint8ClampedArray} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint8ClampedArray\n */\n\n/**\n * @external {Int16Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int16Array\n */\n\n/**\n * @external {Uint16Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint16Array\n */\n\n/**\n * @external {Int32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int32Array\n */\n\n/**\n * @external {Uint32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint32Array\n */\n\n/**\n * @external {Float32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Float32Array\n */\n\n/**\n * @external {Float64Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Float64Array\n */\n\n/ Keyed collections\n/**\n * @external {Map} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Map\n */\n\n/**\n * @external {Set} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Set\n */\n\n/**\n * @external {WeakMap} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakMap\n */\n\n/**\n * @external {WeakSet} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakSet\n */\n\n/ Structured data\n/**\n * @external {ArrayBuffer} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ArrayBuffer\n */\n\n/**\n * @external {DataView} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/DataView\n */\n\n/**\n * @external {JSON} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/JSON\n */\n\n/ Control abstraction objects\n/**\n * @external {Promise} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Promise\n */\n\n/**\n * @external {Generator} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Generator\n */\n\n/**\n * @external {GeneratorFunction} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/GeneratorFunction\n */\n\n/ Reflection\n/**\n * @external {Reflect} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Reflect\n */\n\n/**\n * @external {Proxy} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Proxy\n */\n~Symbol",
    "external"
  ],
  [
    "\n/**\n * @external {infinity} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/infinity\n */\n\n/**\n * @external {nan} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/nan\n */\n\n/**\n * @external {undefined} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/undefined\n */\n\n/**\n * @external {null} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/null\n */\n\n/ fundamental objects\n/**\n * @external {object} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/object\n */\n/**\n * @external {object} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/object\n */\n\n/**\n * @external {function} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/function\n */\n/**\n * @external {function} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/function\n */\n\n/**\n * @external {boolean} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/boolean\n */\n/**\n * @external {boolean} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/boolean\n */\n\n/**\n * @external {symbol} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/symbol\n */\n\n/**\n * @external {error} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/error\n */\n\n/**\n * @external {evalerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/evalerror\n */\n\n/**\n * @external {internalerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/internalerror\n */\n\n/**\n * @external {rangeerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/rangeerror\n */\n\n/**\n * @external {referenceerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/referenceerror\n */\n\n/**\n * @external {syntaxerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/syntaxerror\n */\n\n/**\n * @external {typeerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/typeerror\n */\n\n/**\n * @external {urierror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/urierror\n */\n\n/ numbers and dates\n/**\n * @external {number} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/number\n */\n/**\n * @external {number} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/number\n */\n\n/**\n * @external {date} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/date\n */\n\n/ text processing\n/**\n * @external {string} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/string\n */\n/**\n * @external {string} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/string\n */\n\n/**\n * @external {regexp} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/regexp\n */\n\n/ indexed collections\n/**\n * @external {array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/array\n */\n\n/**\n * @external {int8array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int8array\n */\n/**\n * @external {uint8array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint8array\n */\n\n/**\n * @external {uint8clampedarray} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint8clampedarray\n */\n\n/**\n * @external {int16array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int16array\n */\n\n/**\n * @external {uint16array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint16array\n */\n\n/**\n * @external {int32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int32array\n */\n\n/**\n * @external {uint32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint32array\n */\n\n/**\n * @external {float32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/float32array\n */\n\n/**\n * @external {float64array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/float64array\n */\n\n/ keyed collections\n/**\n * @external {map} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/map\n */\n\n/**\n * @external {set} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/set\n */\n\n/**\n * @external {weakmap} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/weakmap\n */\n\n/**\n * @external {weakset} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/weakset\n */\n\n/ structured data\n/**\n * @external {arraybuffer} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/arraybuffer\n */\n\n/**\n * @external {dataview} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/dataview\n */\n\n/**\n * @external {json} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/json\n */\n\n/ control abstraction objects\n/**\n * @external {promise} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/promise\n */\n\n/**\n * @external {generator} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/generator\n */\n\n/**\n * @external {generatorfunction} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/generatorfunction\n */\n\n/ reflection\n/**\n * @external {reflect} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/reflect\n */\n\n/**\n * @external {proxy} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/proxy\n */\n~syntaxerror",
    "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/SyntaxError",
    "\n/**\n * @external {Infinity} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Infinity\n */\n\n/**\n * @external {NaN} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/NaN\n */\n\n/**\n * @external {undefined} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/undefined\n */\n\n/**\n * @external {null} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/null\n */\n\n/ Fundamental objects\n/**\n * @external {Object} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object\n */\n/**\n * @external {object} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object\n */\n\n/**\n * @external {Function} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function\n */\n/**\n * @external {function} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function\n */\n\n/**\n * @external {Boolean} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean\n */\n/**\n * @external {boolean} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean\n */\n\n/**\n * @external {Symbol} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Symbol\n */\n\n/**\n * @external {Error} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Error\n */\n\n/**\n * @external {EvalError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/EvalError\n */\n\n/**\n * @external {InternalError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/InternalError\n */\n\n/**\n * @external {RangeError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RangeError\n */\n\n/**\n * @external {ReferenceError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ReferenceError\n */\n\n/**\n * @external {SyntaxError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/SyntaxError\n */\n\n/**\n * @external {TypeError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/TypeError\n */\n\n/**\n * @external {URIError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/URIError\n */\n\n/ Numbers and dates\n/**\n * @external {Number} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number\n */\n/**\n * @external {number} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number\n */\n\n/**\n * @external {Date} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Date\n */\n\n/ Text processing\n/**\n * @external {String} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String\n */\n/**\n * @external {string} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String\n */\n\n/**\n * @external {RegExp} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RegExp\n */\n\n/ Indexed collections\n/**\n * @external {Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array\n */\n\n/**\n * @external {Int8Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int8Array\n */\n/**\n * @external {Uint8Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint8Array\n */\n\n/**\n * @external {Uint8ClampedArray} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint8ClampedArray\n */\n\n/**\n * @external {Int16Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int16Array\n */\n\n/**\n * @external {Uint16Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint16Array\n */\n\n/**\n * @external {Int32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int32Array\n */\n\n/**\n * @external {Uint32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint32Array\n */\n\n/**\n * @external {Float32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Float32Array\n */\n\n/**\n * @external {Float64Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Float64Array\n */\n\n/ Keyed collections\n/**\n * @external {Map} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Map\n */\n\n/**\n * @external {Set} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Set\n */\n\n/**\n * @external {WeakMap} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakMap\n */\n\n/**\n * @external {WeakSet} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakSet\n */\n\n/ Structured data\n/**\n * @external {ArrayBuffer} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ArrayBuffer\n */\n\n/**\n * @external {DataView} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/DataView\n */\n\n/**\n * @external {JSON} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/JSON\n */\n\n/ Control abstraction objects\n/**\n * @external {Promise} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Promise\n */\n\n/**\n * @external {Generator} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Generator\n */\n\n/**\n * @external {GeneratorFunction} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/GeneratorFunction\n */\n\n/ Reflection\n/**\n * @external {Reflect} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Reflect\n */\n\n/**\n * @external {Proxy} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Proxy\n */\n~SyntaxError",
    "external"
  ],
  [
    "\n/**\n * @external {infinity} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/infinity\n */\n\n/**\n * @external {nan} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/nan\n */\n\n/**\n * @external {undefined} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/undefined\n */\n\n/**\n * @external {null} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/null\n */\n\n/ fundamental objects\n/**\n * @external {object} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/object\n */\n/**\n * @external {object} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/object\n */\n\n/**\n * @external {function} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/function\n */\n/**\n * @external {function} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/function\n */\n\n/**\n * @external {boolean} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/boolean\n */\n/**\n * @external {boolean} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/boolean\n */\n\n/**\n * @external {symbol} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/symbol\n */\n\n/**\n * @external {error} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/error\n */\n\n/**\n * @external {evalerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/evalerror\n */\n\n/**\n * @external {internalerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/internalerror\n */\n\n/**\n * @external {rangeerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/rangeerror\n */\n\n/**\n * @external {referenceerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/referenceerror\n */\n\n/**\n * @external {syntaxerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/syntaxerror\n */\n\n/**\n * @external {typeerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/typeerror\n */\n\n/**\n * @external {urierror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/urierror\n */\n\n/ numbers and dates\n/**\n * @external {number} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/number\n */\n/**\n * @external {number} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/number\n */\n\n/**\n * @external {date} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/date\n */\n\n/ text processing\n/**\n * @external {string} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/string\n */\n/**\n * @external {string} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/string\n */\n\n/**\n * @external {regexp} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/regexp\n */\n\n/ indexed collections\n/**\n * @external {array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/array\n */\n\n/**\n * @external {int8array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int8array\n */\n/**\n * @external {uint8array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint8array\n */\n\n/**\n * @external {uint8clampedarray} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint8clampedarray\n */\n\n/**\n * @external {int16array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int16array\n */\n\n/**\n * @external {uint16array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint16array\n */\n\n/**\n * @external {int32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int32array\n */\n\n/**\n * @external {uint32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint32array\n */\n\n/**\n * @external {float32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/float32array\n */\n\n/**\n * @external {float64array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/float64array\n */\n\n/ keyed collections\n/**\n * @external {map} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/map\n */\n\n/**\n * @external {set} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/set\n */\n\n/**\n * @external {weakmap} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/weakmap\n */\n\n/**\n * @external {weakset} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/weakset\n */\n\n/ structured data\n/**\n * @external {arraybuffer} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/arraybuffer\n */\n\n/**\n * @external {dataview} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/dataview\n */\n\n/**\n * @external {json} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/json\n */\n\n/ control abstraction objects\n/**\n * @external {promise} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/promise\n */\n\n/**\n * @external {generator} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/generator\n */\n\n/**\n * @external {generatorfunction} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/generatorfunction\n */\n\n/ reflection\n/**\n * @external {reflect} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/reflect\n */\n\n/**\n * @external {proxy} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/proxy\n */\n~typeerror",
    "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/TypeError",
    "\n/**\n * @external {Infinity} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Infinity\n */\n\n/**\n * @external {NaN} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/NaN\n */\n\n/**\n * @external {undefined} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/undefined\n */\n\n/**\n * @external {null} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/null\n */\n\n/ Fundamental objects\n/**\n * @external {Object} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object\n */\n/**\n * @external {object} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object\n */\n\n/**\n * @external {Function} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function\n */\n/**\n * @external {function} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function\n */\n\n/**\n * @external {Boolean} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean\n */\n/**\n * @external {boolean} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean\n */\n\n/**\n * @external {Symbol} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Symbol\n */\n\n/**\n * @external {Error} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Error\n */\n\n/**\n * @external {EvalError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/EvalError\n */\n\n/**\n * @external {InternalError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/InternalError\n */\n\n/**\n * @external {RangeError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RangeError\n */\n\n/**\n * @external {ReferenceError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ReferenceError\n */\n\n/**\n * @external {SyntaxError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/SyntaxError\n */\n\n/**\n * @external {TypeError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/TypeError\n */\n\n/**\n * @external {URIError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/URIError\n */\n\n/ Numbers and dates\n/**\n * @external {Number} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number\n */\n/**\n * @external {number} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number\n */\n\n/**\n * @external {Date} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Date\n */\n\n/ Text processing\n/**\n * @external {String} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String\n */\n/**\n * @external {string} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String\n */\n\n/**\n * @external {RegExp} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RegExp\n */\n\n/ Indexed collections\n/**\n * @external {Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array\n */\n\n/**\n * @external {Int8Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int8Array\n */\n/**\n * @external {Uint8Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint8Array\n */\n\n/**\n * @external {Uint8ClampedArray} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint8ClampedArray\n */\n\n/**\n * @external {Int16Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int16Array\n */\n\n/**\n * @external {Uint16Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint16Array\n */\n\n/**\n * @external {Int32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int32Array\n */\n\n/**\n * @external {Uint32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint32Array\n */\n\n/**\n * @external {Float32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Float32Array\n */\n\n/**\n * @external {Float64Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Float64Array\n */\n\n/ Keyed collections\n/**\n * @external {Map} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Map\n */\n\n/**\n * @external {Set} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Set\n */\n\n/**\n * @external {WeakMap} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakMap\n */\n\n/**\n * @external {WeakSet} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakSet\n */\n\n/ Structured data\n/**\n * @external {ArrayBuffer} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ArrayBuffer\n */\n\n/**\n * @external {DataView} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/DataView\n */\n\n/**\n * @external {JSON} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/JSON\n */\n\n/ Control abstraction objects\n/**\n * @external {Promise} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Promise\n */\n\n/**\n * @external {Generator} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Generator\n */\n\n/**\n * @external {GeneratorFunction} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/GeneratorFunction\n */\n\n/ Reflection\n/**\n * @external {Reflect} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Reflect\n */\n\n/**\n * @external {Proxy} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Proxy\n */\n~TypeError",
    "external"
  ],
  [
    "\n/**\n * @external {infinity} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/infinity\n */\n\n/**\n * @external {nan} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/nan\n */\n\n/**\n * @external {undefined} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/undefined\n */\n\n/**\n * @external {null} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/null\n */\n\n/ fundamental objects\n/**\n * @external {object} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/object\n */\n/**\n * @external {object} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/object\n */\n\n/**\n * @external {function} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/function\n */\n/**\n * @external {function} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/function\n */\n\n/**\n * @external {boolean} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/boolean\n */\n/**\n * @external {boolean} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/boolean\n */\n\n/**\n * @external {symbol} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/symbol\n */\n\n/**\n * @external {error} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/error\n */\n\n/**\n * @external {evalerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/evalerror\n */\n\n/**\n * @external {internalerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/internalerror\n */\n\n/**\n * @external {rangeerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/rangeerror\n */\n\n/**\n * @external {referenceerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/referenceerror\n */\n\n/**\n * @external {syntaxerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/syntaxerror\n */\n\n/**\n * @external {typeerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/typeerror\n */\n\n/**\n * @external {urierror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/urierror\n */\n\n/ numbers and dates\n/**\n * @external {number} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/number\n */\n/**\n * @external {number} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/number\n */\n\n/**\n * @external {date} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/date\n */\n\n/ text processing\n/**\n * @external {string} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/string\n */\n/**\n * @external {string} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/string\n */\n\n/**\n * @external {regexp} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/regexp\n */\n\n/ indexed collections\n/**\n * @external {array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/array\n */\n\n/**\n * @external {int8array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int8array\n */\n/**\n * @external {uint8array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint8array\n */\n\n/**\n * @external {uint8clampedarray} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint8clampedarray\n */\n\n/**\n * @external {int16array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int16array\n */\n\n/**\n * @external {uint16array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint16array\n */\n\n/**\n * @external {int32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int32array\n */\n\n/**\n * @external {uint32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint32array\n */\n\n/**\n * @external {float32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/float32array\n */\n\n/**\n * @external {float64array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/float64array\n */\n\n/ keyed collections\n/**\n * @external {map} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/map\n */\n\n/**\n * @external {set} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/set\n */\n\n/**\n * @external {weakmap} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/weakmap\n */\n\n/**\n * @external {weakset} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/weakset\n */\n\n/ structured data\n/**\n * @external {arraybuffer} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/arraybuffer\n */\n\n/**\n * @external {dataview} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/dataview\n */\n\n/**\n * @external {json} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/json\n */\n\n/ control abstraction objects\n/**\n * @external {promise} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/promise\n */\n\n/**\n * @external {generator} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/generator\n */\n\n/**\n * @external {generatorfunction} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/generatorfunction\n */\n\n/ reflection\n/**\n * @external {reflect} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/reflect\n */\n\n/**\n * @external {proxy} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/proxy\n */\n~urierror",
    "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/URIError",
    "\n/**\n * @external {Infinity} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Infinity\n */\n\n/**\n * @external {NaN} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/NaN\n */\n\n/**\n * @external {undefined} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/undefined\n */\n\n/**\n * @external {null} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/null\n */\n\n/ Fundamental objects\n/**\n * @external {Object} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object\n */\n/**\n * @external {object} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object\n */\n\n/**\n * @external {Function} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function\n */\n/**\n * @external {function} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function\n */\n\n/**\n * @external {Boolean} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean\n */\n/**\n * @external {boolean} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean\n */\n\n/**\n * @external {Symbol} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Symbol\n */\n\n/**\n * @external {Error} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Error\n */\n\n/**\n * @external {EvalError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/EvalError\n */\n\n/**\n * @external {InternalError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/InternalError\n */\n\n/**\n * @external {RangeError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RangeError\n */\n\n/**\n * @external {ReferenceError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ReferenceError\n */\n\n/**\n * @external {SyntaxError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/SyntaxError\n */\n\n/**\n * @external {TypeError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/TypeError\n */\n\n/**\n * @external {URIError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/URIError\n */\n\n/ Numbers and dates\n/**\n * @external {Number} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number\n */\n/**\n * @external {number} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number\n */\n\n/**\n * @external {Date} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Date\n */\n\n/ Text processing\n/**\n * @external {String} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String\n */\n/**\n * @external {string} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String\n */\n\n/**\n * @external {RegExp} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RegExp\n */\n\n/ Indexed collections\n/**\n * @external {Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array\n */\n\n/**\n * @external {Int8Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int8Array\n */\n/**\n * @external {Uint8Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint8Array\n */\n\n/**\n * @external {Uint8ClampedArray} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint8ClampedArray\n */\n\n/**\n * @external {Int16Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int16Array\n */\n\n/**\n * @external {Uint16Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint16Array\n */\n\n/**\n * @external {Int32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int32Array\n */\n\n/**\n * @external {Uint32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint32Array\n */\n\n/**\n * @external {Float32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Float32Array\n */\n\n/**\n * @external {Float64Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Float64Array\n */\n\n/ Keyed collections\n/**\n * @external {Map} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Map\n */\n\n/**\n * @external {Set} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Set\n */\n\n/**\n * @external {WeakMap} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakMap\n */\n\n/**\n * @external {WeakSet} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakSet\n */\n\n/ Structured data\n/**\n * @external {ArrayBuffer} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ArrayBuffer\n */\n\n/**\n * @external {DataView} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/DataView\n */\n\n/**\n * @external {JSON} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/JSON\n */\n\n/ Control abstraction objects\n/**\n * @external {Promise} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Promise\n */\n\n/**\n * @external {Generator} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Generator\n */\n\n/**\n * @external {GeneratorFunction} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/GeneratorFunction\n */\n\n/ Reflection\n/**\n * @external {Reflect} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Reflect\n */\n\n/**\n * @external {Proxy} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Proxy\n */\n~URIError",
    "external"
  ],
  [
    "\n/**\n * @external {infinity} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/infinity\n */\n\n/**\n * @external {nan} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/nan\n */\n\n/**\n * @external {undefined} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/undefined\n */\n\n/**\n * @external {null} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/null\n */\n\n/ fundamental objects\n/**\n * @external {object} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/object\n */\n/**\n * @external {object} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/object\n */\n\n/**\n * @external {function} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/function\n */\n/**\n * @external {function} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/function\n */\n\n/**\n * @external {boolean} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/boolean\n */\n/**\n * @external {boolean} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/boolean\n */\n\n/**\n * @external {symbol} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/symbol\n */\n\n/**\n * @external {error} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/error\n */\n\n/**\n * @external {evalerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/evalerror\n */\n\n/**\n * @external {internalerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/internalerror\n */\n\n/**\n * @external {rangeerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/rangeerror\n */\n\n/**\n * @external {referenceerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/referenceerror\n */\n\n/**\n * @external {syntaxerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/syntaxerror\n */\n\n/**\n * @external {typeerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/typeerror\n */\n\n/**\n * @external {urierror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/urierror\n */\n\n/ numbers and dates\n/**\n * @external {number} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/number\n */\n/**\n * @external {number} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/number\n */\n\n/**\n * @external {date} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/date\n */\n\n/ text processing\n/**\n * @external {string} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/string\n */\n/**\n * @external {string} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/string\n */\n\n/**\n * @external {regexp} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/regexp\n */\n\n/ indexed collections\n/**\n * @external {array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/array\n */\n\n/**\n * @external {int8array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int8array\n */\n/**\n * @external {uint8array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint8array\n */\n\n/**\n * @external {uint8clampedarray} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint8clampedarray\n */\n\n/**\n * @external {int16array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int16array\n */\n\n/**\n * @external {uint16array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint16array\n */\n\n/**\n * @external {int32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int32array\n */\n\n/**\n * @external {uint32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint32array\n */\n\n/**\n * @external {float32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/float32array\n */\n\n/**\n * @external {float64array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/float64array\n */\n\n/ keyed collections\n/**\n * @external {map} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/map\n */\n\n/**\n * @external {set} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/set\n */\n\n/**\n * @external {weakmap} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/weakmap\n */\n\n/**\n * @external {weakset} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/weakset\n */\n\n/ structured data\n/**\n * @external {arraybuffer} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/arraybuffer\n */\n\n/**\n * @external {dataview} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/dataview\n */\n\n/**\n * @external {json} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/json\n */\n\n/ control abstraction objects\n/**\n * @external {promise} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/promise\n */\n\n/**\n * @external {generator} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/generator\n */\n\n/**\n * @external {generatorfunction} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/generatorfunction\n */\n\n/ reflection\n/**\n * @external {reflect} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/reflect\n */\n\n/**\n * @external {proxy} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/proxy\n */\n~uint16array",
    "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint16Array",
    "\n/**\n * @external {Infinity} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Infinity\n */\n\n/**\n * @external {NaN} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/NaN\n */\n\n/**\n * @external {undefined} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/undefined\n */\n\n/**\n * @external {null} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/null\n */\n\n/ Fundamental objects\n/**\n * @external {Object} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object\n */\n/**\n * @external {object} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object\n */\n\n/**\n * @external {Function} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function\n */\n/**\n * @external {function} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function\n */\n\n/**\n * @external {Boolean} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean\n */\n/**\n * @external {boolean} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean\n */\n\n/**\n * @external {Symbol} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Symbol\n */\n\n/**\n * @external {Error} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Error\n */\n\n/**\n * @external {EvalError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/EvalError\n */\n\n/**\n * @external {InternalError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/InternalError\n */\n\n/**\n * @external {RangeError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RangeError\n */\n\n/**\n * @external {ReferenceError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ReferenceError\n */\n\n/**\n * @external {SyntaxError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/SyntaxError\n */\n\n/**\n * @external {TypeError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/TypeError\n */\n\n/**\n * @external {URIError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/URIError\n */\n\n/ Numbers and dates\n/**\n * @external {Number} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number\n */\n/**\n * @external {number} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number\n */\n\n/**\n * @external {Date} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Date\n */\n\n/ Text processing\n/**\n * @external {String} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String\n */\n/**\n * @external {string} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String\n */\n\n/**\n * @external {RegExp} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RegExp\n */\n\n/ Indexed collections\n/**\n * @external {Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array\n */\n\n/**\n * @external {Int8Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int8Array\n */\n/**\n * @external {Uint8Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint8Array\n */\n\n/**\n * @external {Uint8ClampedArray} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint8ClampedArray\n */\n\n/**\n * @external {Int16Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int16Array\n */\n\n/**\n * @external {Uint16Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint16Array\n */\n\n/**\n * @external {Int32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int32Array\n */\n\n/**\n * @external {Uint32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint32Array\n */\n\n/**\n * @external {Float32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Float32Array\n */\n\n/**\n * @external {Float64Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Float64Array\n */\n\n/ Keyed collections\n/**\n * @external {Map} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Map\n */\n\n/**\n * @external {Set} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Set\n */\n\n/**\n * @external {WeakMap} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakMap\n */\n\n/**\n * @external {WeakSet} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakSet\n */\n\n/ Structured data\n/**\n * @external {ArrayBuffer} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ArrayBuffer\n */\n\n/**\n * @external {DataView} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/DataView\n */\n\n/**\n * @external {JSON} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/JSON\n */\n\n/ Control abstraction objects\n/**\n * @external {Promise} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Promise\n */\n\n/**\n * @external {Generator} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Generator\n */\n\n/**\n * @external {GeneratorFunction} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/GeneratorFunction\n */\n\n/ Reflection\n/**\n * @external {Reflect} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Reflect\n */\n\n/**\n * @external {Proxy} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Proxy\n */\n~Uint16Array",
    "external"
  ],
  [
    "\n/**\n * @external {infinity} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/infinity\n */\n\n/**\n * @external {nan} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/nan\n */\n\n/**\n * @external {undefined} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/undefined\n */\n\n/**\n * @external {null} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/null\n */\n\n/ fundamental objects\n/**\n * @external {object} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/object\n */\n/**\n * @external {object} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/object\n */\n\n/**\n * @external {function} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/function\n */\n/**\n * @external {function} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/function\n */\n\n/**\n * @external {boolean} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/boolean\n */\n/**\n * @external {boolean} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/boolean\n */\n\n/**\n * @external {symbol} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/symbol\n */\n\n/**\n * @external {error} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/error\n */\n\n/**\n * @external {evalerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/evalerror\n */\n\n/**\n * @external {internalerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/internalerror\n */\n\n/**\n * @external {rangeerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/rangeerror\n */\n\n/**\n * @external {referenceerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/referenceerror\n */\n\n/**\n * @external {syntaxerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/syntaxerror\n */\n\n/**\n * @external {typeerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/typeerror\n */\n\n/**\n * @external {urierror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/urierror\n */\n\n/ numbers and dates\n/**\n * @external {number} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/number\n */\n/**\n * @external {number} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/number\n */\n\n/**\n * @external {date} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/date\n */\n\n/ text processing\n/**\n * @external {string} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/string\n */\n/**\n * @external {string} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/string\n */\n\n/**\n * @external {regexp} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/regexp\n */\n\n/ indexed collections\n/**\n * @external {array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/array\n */\n\n/**\n * @external {int8array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int8array\n */\n/**\n * @external {uint8array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint8array\n */\n\n/**\n * @external {uint8clampedarray} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint8clampedarray\n */\n\n/**\n * @external {int16array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int16array\n */\n\n/**\n * @external {uint16array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint16array\n */\n\n/**\n * @external {int32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int32array\n */\n\n/**\n * @external {uint32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint32array\n */\n\n/**\n * @external {float32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/float32array\n */\n\n/**\n * @external {float64array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/float64array\n */\n\n/ keyed collections\n/**\n * @external {map} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/map\n */\n\n/**\n * @external {set} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/set\n */\n\n/**\n * @external {weakmap} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/weakmap\n */\n\n/**\n * @external {weakset} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/weakset\n */\n\n/ structured data\n/**\n * @external {arraybuffer} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/arraybuffer\n */\n\n/**\n * @external {dataview} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/dataview\n */\n\n/**\n * @external {json} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/json\n */\n\n/ control abstraction objects\n/**\n * @external {promise} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/promise\n */\n\n/**\n * @external {generator} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/generator\n */\n\n/**\n * @external {generatorfunction} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/generatorfunction\n */\n\n/ reflection\n/**\n * @external {reflect} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/reflect\n */\n\n/**\n * @external {proxy} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/proxy\n */\n~uint32array",
    "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint32Array",
    "\n/**\n * @external {Infinity} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Infinity\n */\n\n/**\n * @external {NaN} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/NaN\n */\n\n/**\n * @external {undefined} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/undefined\n */\n\n/**\n * @external {null} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/null\n */\n\n/ Fundamental objects\n/**\n * @external {Object} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object\n */\n/**\n * @external {object} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object\n */\n\n/**\n * @external {Function} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function\n */\n/**\n * @external {function} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function\n */\n\n/**\n * @external {Boolean} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean\n */\n/**\n * @external {boolean} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean\n */\n\n/**\n * @external {Symbol} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Symbol\n */\n\n/**\n * @external {Error} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Error\n */\n\n/**\n * @external {EvalError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/EvalError\n */\n\n/**\n * @external {InternalError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/InternalError\n */\n\n/**\n * @external {RangeError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RangeError\n */\n\n/**\n * @external {ReferenceError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ReferenceError\n */\n\n/**\n * @external {SyntaxError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/SyntaxError\n */\n\n/**\n * @external {TypeError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/TypeError\n */\n\n/**\n * @external {URIError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/URIError\n */\n\n/ Numbers and dates\n/**\n * @external {Number} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number\n */\n/**\n * @external {number} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number\n */\n\n/**\n * @external {Date} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Date\n */\n\n/ Text processing\n/**\n * @external {String} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String\n */\n/**\n * @external {string} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String\n */\n\n/**\n * @external {RegExp} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RegExp\n */\n\n/ Indexed collections\n/**\n * @external {Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array\n */\n\n/**\n * @external {Int8Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int8Array\n */\n/**\n * @external {Uint8Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint8Array\n */\n\n/**\n * @external {Uint8ClampedArray} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint8ClampedArray\n */\n\n/**\n * @external {Int16Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int16Array\n */\n\n/**\n * @external {Uint16Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint16Array\n */\n\n/**\n * @external {Int32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int32Array\n */\n\n/**\n * @external {Uint32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint32Array\n */\n\n/**\n * @external {Float32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Float32Array\n */\n\n/**\n * @external {Float64Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Float64Array\n */\n\n/ Keyed collections\n/**\n * @external {Map} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Map\n */\n\n/**\n * @external {Set} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Set\n */\n\n/**\n * @external {WeakMap} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakMap\n */\n\n/**\n * @external {WeakSet} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakSet\n */\n\n/ Structured data\n/**\n * @external {ArrayBuffer} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ArrayBuffer\n */\n\n/**\n * @external {DataView} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/DataView\n */\n\n/**\n * @external {JSON} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/JSON\n */\n\n/ Control abstraction objects\n/**\n * @external {Promise} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Promise\n */\n\n/**\n * @external {Generator} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Generator\n */\n\n/**\n * @external {GeneratorFunction} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/GeneratorFunction\n */\n\n/ Reflection\n/**\n * @external {Reflect} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Reflect\n */\n\n/**\n * @external {Proxy} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Proxy\n */\n~Uint32Array",
    "external"
  ],
  [
    "\n/**\n * @external {infinity} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/infinity\n */\n\n/**\n * @external {nan} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/nan\n */\n\n/**\n * @external {undefined} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/undefined\n */\n\n/**\n * @external {null} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/null\n */\n\n/ fundamental objects\n/**\n * @external {object} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/object\n */\n/**\n * @external {object} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/object\n */\n\n/**\n * @external {function} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/function\n */\n/**\n * @external {function} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/function\n */\n\n/**\n * @external {boolean} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/boolean\n */\n/**\n * @external {boolean} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/boolean\n */\n\n/**\n * @external {symbol} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/symbol\n */\n\n/**\n * @external {error} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/error\n */\n\n/**\n * @external {evalerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/evalerror\n */\n\n/**\n * @external {internalerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/internalerror\n */\n\n/**\n * @external {rangeerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/rangeerror\n */\n\n/**\n * @external {referenceerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/referenceerror\n */\n\n/**\n * @external {syntaxerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/syntaxerror\n */\n\n/**\n * @external {typeerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/typeerror\n */\n\n/**\n * @external {urierror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/urierror\n */\n\n/ numbers and dates\n/**\n * @external {number} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/number\n */\n/**\n * @external {number} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/number\n */\n\n/**\n * @external {date} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/date\n */\n\n/ text processing\n/**\n * @external {string} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/string\n */\n/**\n * @external {string} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/string\n */\n\n/**\n * @external {regexp} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/regexp\n */\n\n/ indexed collections\n/**\n * @external {array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/array\n */\n\n/**\n * @external {int8array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int8array\n */\n/**\n * @external {uint8array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint8array\n */\n\n/**\n * @external {uint8clampedarray} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint8clampedarray\n */\n\n/**\n * @external {int16array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int16array\n */\n\n/**\n * @external {uint16array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint16array\n */\n\n/**\n * @external {int32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int32array\n */\n\n/**\n * @external {uint32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint32array\n */\n\n/**\n * @external {float32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/float32array\n */\n\n/**\n * @external {float64array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/float64array\n */\n\n/ keyed collections\n/**\n * @external {map} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/map\n */\n\n/**\n * @external {set} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/set\n */\n\n/**\n * @external {weakmap} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/weakmap\n */\n\n/**\n * @external {weakset} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/weakset\n */\n\n/ structured data\n/**\n * @external {arraybuffer} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/arraybuffer\n */\n\n/**\n * @external {dataview} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/dataview\n */\n\n/**\n * @external {json} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/json\n */\n\n/ control abstraction objects\n/**\n * @external {promise} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/promise\n */\n\n/**\n * @external {generator} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/generator\n */\n\n/**\n * @external {generatorfunction} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/generatorfunction\n */\n\n/ reflection\n/**\n * @external {reflect} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/reflect\n */\n\n/**\n * @external {proxy} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/proxy\n */\n~uint8array",
    "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint8Array",
    "\n/**\n * @external {Infinity} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Infinity\n */\n\n/**\n * @external {NaN} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/NaN\n */\n\n/**\n * @external {undefined} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/undefined\n */\n\n/**\n * @external {null} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/null\n */\n\n/ Fundamental objects\n/**\n * @external {Object} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object\n */\n/**\n * @external {object} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object\n */\n\n/**\n * @external {Function} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function\n */\n/**\n * @external {function} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function\n */\n\n/**\n * @external {Boolean} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean\n */\n/**\n * @external {boolean} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean\n */\n\n/**\n * @external {Symbol} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Symbol\n */\n\n/**\n * @external {Error} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Error\n */\n\n/**\n * @external {EvalError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/EvalError\n */\n\n/**\n * @external {InternalError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/InternalError\n */\n\n/**\n * @external {RangeError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RangeError\n */\n\n/**\n * @external {ReferenceError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ReferenceError\n */\n\n/**\n * @external {SyntaxError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/SyntaxError\n */\n\n/**\n * @external {TypeError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/TypeError\n */\n\n/**\n * @external {URIError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/URIError\n */\n\n/ Numbers and dates\n/**\n * @external {Number} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number\n */\n/**\n * @external {number} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number\n */\n\n/**\n * @external {Date} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Date\n */\n\n/ Text processing\n/**\n * @external {String} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String\n */\n/**\n * @external {string} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String\n */\n\n/**\n * @external {RegExp} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RegExp\n */\n\n/ Indexed collections\n/**\n * @external {Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array\n */\n\n/**\n * @external {Int8Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int8Array\n */\n/**\n * @external {Uint8Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint8Array\n */\n\n/**\n * @external {Uint8ClampedArray} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint8ClampedArray\n */\n\n/**\n * @external {Int16Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int16Array\n */\n\n/**\n * @external {Uint16Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint16Array\n */\n\n/**\n * @external {Int32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int32Array\n */\n\n/**\n * @external {Uint32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint32Array\n */\n\n/**\n * @external {Float32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Float32Array\n */\n\n/**\n * @external {Float64Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Float64Array\n */\n\n/ Keyed collections\n/**\n * @external {Map} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Map\n */\n\n/**\n * @external {Set} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Set\n */\n\n/**\n * @external {WeakMap} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakMap\n */\n\n/**\n * @external {WeakSet} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakSet\n */\n\n/ Structured data\n/**\n * @external {ArrayBuffer} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ArrayBuffer\n */\n\n/**\n * @external {DataView} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/DataView\n */\n\n/**\n * @external {JSON} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/JSON\n */\n\n/ Control abstraction objects\n/**\n * @external {Promise} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Promise\n */\n\n/**\n * @external {Generator} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Generator\n */\n\n/**\n * @external {GeneratorFunction} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/GeneratorFunction\n */\n\n/ Reflection\n/**\n * @external {Reflect} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Reflect\n */\n\n/**\n * @external {Proxy} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Proxy\n */\n~Uint8Array",
    "external"
  ],
  [
    "\n/**\n * @external {infinity} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/infinity\n */\n\n/**\n * @external {nan} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/nan\n */\n\n/**\n * @external {undefined} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/undefined\n */\n\n/**\n * @external {null} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/null\n */\n\n/ fundamental objects\n/**\n * @external {object} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/object\n */\n/**\n * @external {object} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/object\n */\n\n/**\n * @external {function} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/function\n */\n/**\n * @external {function} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/function\n */\n\n/**\n * @external {boolean} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/boolean\n */\n/**\n * @external {boolean} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/boolean\n */\n\n/**\n * @external {symbol} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/symbol\n */\n\n/**\n * @external {error} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/error\n */\n\n/**\n * @external {evalerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/evalerror\n */\n\n/**\n * @external {internalerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/internalerror\n */\n\n/**\n * @external {rangeerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/rangeerror\n */\n\n/**\n * @external {referenceerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/referenceerror\n */\n\n/**\n * @external {syntaxerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/syntaxerror\n */\n\n/**\n * @external {typeerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/typeerror\n */\n\n/**\n * @external {urierror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/urierror\n */\n\n/ numbers and dates\n/**\n * @external {number} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/number\n */\n/**\n * @external {number} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/number\n */\n\n/**\n * @external {date} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/date\n */\n\n/ text processing\n/**\n * @external {string} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/string\n */\n/**\n * @external {string} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/string\n */\n\n/**\n * @external {regexp} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/regexp\n */\n\n/ indexed collections\n/**\n * @external {array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/array\n */\n\n/**\n * @external {int8array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int8array\n */\n/**\n * @external {uint8array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint8array\n */\n\n/**\n * @external {uint8clampedarray} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint8clampedarray\n */\n\n/**\n * @external {int16array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int16array\n */\n\n/**\n * @external {uint16array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint16array\n */\n\n/**\n * @external {int32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int32array\n */\n\n/**\n * @external {uint32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint32array\n */\n\n/**\n * @external {float32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/float32array\n */\n\n/**\n * @external {float64array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/float64array\n */\n\n/ keyed collections\n/**\n * @external {map} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/map\n */\n\n/**\n * @external {set} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/set\n */\n\n/**\n * @external {weakmap} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/weakmap\n */\n\n/**\n * @external {weakset} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/weakset\n */\n\n/ structured data\n/**\n * @external {arraybuffer} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/arraybuffer\n */\n\n/**\n * @external {dataview} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/dataview\n */\n\n/**\n * @external {json} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/json\n */\n\n/ control abstraction objects\n/**\n * @external {promise} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/promise\n */\n\n/**\n * @external {generator} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/generator\n */\n\n/**\n * @external {generatorfunction} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/generatorfunction\n */\n\n/ reflection\n/**\n * @external {reflect} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/reflect\n */\n\n/**\n * @external {proxy} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/proxy\n */\n~uint8clampedarray",
    "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint8ClampedArray",
    "\n/**\n * @external {Infinity} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Infinity\n */\n\n/**\n * @external {NaN} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/NaN\n */\n\n/**\n * @external {undefined} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/undefined\n */\n\n/**\n * @external {null} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/null\n */\n\n/ Fundamental objects\n/**\n * @external {Object} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object\n */\n/**\n * @external {object} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object\n */\n\n/**\n * @external {Function} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function\n */\n/**\n * @external {function} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function\n */\n\n/**\n * @external {Boolean} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean\n */\n/**\n * @external {boolean} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean\n */\n\n/**\n * @external {Symbol} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Symbol\n */\n\n/**\n * @external {Error} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Error\n */\n\n/**\n * @external {EvalError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/EvalError\n */\n\n/**\n * @external {InternalError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/InternalError\n */\n\n/**\n * @external {RangeError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RangeError\n */\n\n/**\n * @external {ReferenceError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ReferenceError\n */\n\n/**\n * @external {SyntaxError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/SyntaxError\n */\n\n/**\n * @external {TypeError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/TypeError\n */\n\n/**\n * @external {URIError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/URIError\n */\n\n/ Numbers and dates\n/**\n * @external {Number} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number\n */\n/**\n * @external {number} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number\n */\n\n/**\n * @external {Date} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Date\n */\n\n/ Text processing\n/**\n * @external {String} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String\n */\n/**\n * @external {string} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String\n */\n\n/**\n * @external {RegExp} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RegExp\n */\n\n/ Indexed collections\n/**\n * @external {Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array\n */\n\n/**\n * @external {Int8Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int8Array\n */\n/**\n * @external {Uint8Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint8Array\n */\n\n/**\n * @external {Uint8ClampedArray} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint8ClampedArray\n */\n\n/**\n * @external {Int16Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int16Array\n */\n\n/**\n * @external {Uint16Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint16Array\n */\n\n/**\n * @external {Int32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int32Array\n */\n\n/**\n * @external {Uint32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint32Array\n */\n\n/**\n * @external {Float32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Float32Array\n */\n\n/**\n * @external {Float64Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Float64Array\n */\n\n/ Keyed collections\n/**\n * @external {Map} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Map\n */\n\n/**\n * @external {Set} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Set\n */\n\n/**\n * @external {WeakMap} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakMap\n */\n\n/**\n * @external {WeakSet} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakSet\n */\n\n/ Structured data\n/**\n * @external {ArrayBuffer} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ArrayBuffer\n */\n\n/**\n * @external {DataView} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/DataView\n */\n\n/**\n * @external {JSON} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/JSON\n */\n\n/ Control abstraction objects\n/**\n * @external {Promise} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Promise\n */\n\n/**\n * @external {Generator} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Generator\n */\n\n/**\n * @external {GeneratorFunction} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/GeneratorFunction\n */\n\n/ Reflection\n/**\n * @external {Reflect} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Reflect\n */\n\n/**\n * @external {Proxy} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Proxy\n */\n~Uint8ClampedArray",
    "external"
  ],
  [
    "\n/**\n * @external {infinity} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/infinity\n */\n\n/**\n * @external {nan} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/nan\n */\n\n/**\n * @external {undefined} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/undefined\n */\n\n/**\n * @external {null} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/null\n */\n\n/ fundamental objects\n/**\n * @external {object} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/object\n */\n/**\n * @external {object} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/object\n */\n\n/**\n * @external {function} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/function\n */\n/**\n * @external {function} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/function\n */\n\n/**\n * @external {boolean} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/boolean\n */\n/**\n * @external {boolean} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/boolean\n */\n\n/**\n * @external {symbol} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/symbol\n */\n\n/**\n * @external {error} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/error\n */\n\n/**\n * @external {evalerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/evalerror\n */\n\n/**\n * @external {internalerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/internalerror\n */\n\n/**\n * @external {rangeerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/rangeerror\n */\n\n/**\n * @external {referenceerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/referenceerror\n */\n\n/**\n * @external {syntaxerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/syntaxerror\n */\n\n/**\n * @external {typeerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/typeerror\n */\n\n/**\n * @external {urierror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/urierror\n */\n\n/ numbers and dates\n/**\n * @external {number} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/number\n */\n/**\n * @external {number} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/number\n */\n\n/**\n * @external {date} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/date\n */\n\n/ text processing\n/**\n * @external {string} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/string\n */\n/**\n * @external {string} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/string\n */\n\n/**\n * @external {regexp} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/regexp\n */\n\n/ indexed collections\n/**\n * @external {array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/array\n */\n\n/**\n * @external {int8array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int8array\n */\n/**\n * @external {uint8array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint8array\n */\n\n/**\n * @external {uint8clampedarray} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint8clampedarray\n */\n\n/**\n * @external {int16array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int16array\n */\n\n/**\n * @external {uint16array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint16array\n */\n\n/**\n * @external {int32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int32array\n */\n\n/**\n * @external {uint32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint32array\n */\n\n/**\n * @external {float32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/float32array\n */\n\n/**\n * @external {float64array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/float64array\n */\n\n/ keyed collections\n/**\n * @external {map} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/map\n */\n\n/**\n * @external {set} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/set\n */\n\n/**\n * @external {weakmap} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/weakmap\n */\n\n/**\n * @external {weakset} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/weakset\n */\n\n/ structured data\n/**\n * @external {arraybuffer} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/arraybuffer\n */\n\n/**\n * @external {dataview} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/dataview\n */\n\n/**\n * @external {json} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/json\n */\n\n/ control abstraction objects\n/**\n * @external {promise} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/promise\n */\n\n/**\n * @external {generator} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/generator\n */\n\n/**\n * @external {generatorfunction} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/generatorfunction\n */\n\n/ reflection\n/**\n * @external {reflect} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/reflect\n */\n\n/**\n * @external {proxy} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/proxy\n */\n~weakmap",
    "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakMap",
    "\n/**\n * @external {Infinity} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Infinity\n */\n\n/**\n * @external {NaN} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/NaN\n */\n\n/**\n * @external {undefined} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/undefined\n */\n\n/**\n * @external {null} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/null\n */\n\n/ Fundamental objects\n/**\n * @external {Object} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object\n */\n/**\n * @external {object} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object\n */\n\n/**\n * @external {Function} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function\n */\n/**\n * @external {function} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function\n */\n\n/**\n * @external {Boolean} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean\n */\n/**\n * @external {boolean} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean\n */\n\n/**\n * @external {Symbol} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Symbol\n */\n\n/**\n * @external {Error} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Error\n */\n\n/**\n * @external {EvalError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/EvalError\n */\n\n/**\n * @external {InternalError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/InternalError\n */\n\n/**\n * @external {RangeError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RangeError\n */\n\n/**\n * @external {ReferenceError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ReferenceError\n */\n\n/**\n * @external {SyntaxError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/SyntaxError\n */\n\n/**\n * @external {TypeError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/TypeError\n */\n\n/**\n * @external {URIError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/URIError\n */\n\n/ Numbers and dates\n/**\n * @external {Number} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number\n */\n/**\n * @external {number} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number\n */\n\n/**\n * @external {Date} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Date\n */\n\n/ Text processing\n/**\n * @external {String} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String\n */\n/**\n * @external {string} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String\n */\n\n/**\n * @external {RegExp} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RegExp\n */\n\n/ Indexed collections\n/**\n * @external {Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array\n */\n\n/**\n * @external {Int8Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int8Array\n */\n/**\n * @external {Uint8Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint8Array\n */\n\n/**\n * @external {Uint8ClampedArray} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint8ClampedArray\n */\n\n/**\n * @external {Int16Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int16Array\n */\n\n/**\n * @external {Uint16Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint16Array\n */\n\n/**\n * @external {Int32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int32Array\n */\n\n/**\n * @external {Uint32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint32Array\n */\n\n/**\n * @external {Float32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Float32Array\n */\n\n/**\n * @external {Float64Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Float64Array\n */\n\n/ Keyed collections\n/**\n * @external {Map} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Map\n */\n\n/**\n * @external {Set} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Set\n */\n\n/**\n * @external {WeakMap} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakMap\n */\n\n/**\n * @external {WeakSet} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakSet\n */\n\n/ Structured data\n/**\n * @external {ArrayBuffer} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ArrayBuffer\n */\n\n/**\n * @external {DataView} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/DataView\n */\n\n/**\n * @external {JSON} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/JSON\n */\n\n/ Control abstraction objects\n/**\n * @external {Promise} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Promise\n */\n\n/**\n * @external {Generator} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Generator\n */\n\n/**\n * @external {GeneratorFunction} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/GeneratorFunction\n */\n\n/ Reflection\n/**\n * @external {Reflect} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Reflect\n */\n\n/**\n * @external {Proxy} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Proxy\n */\n~WeakMap",
    "external"
  ],
  [
    "\n/**\n * @external {infinity} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/infinity\n */\n\n/**\n * @external {nan} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/nan\n */\n\n/**\n * @external {undefined} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/undefined\n */\n\n/**\n * @external {null} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/null\n */\n\n/ fundamental objects\n/**\n * @external {object} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/object\n */\n/**\n * @external {object} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/object\n */\n\n/**\n * @external {function} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/function\n */\n/**\n * @external {function} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/function\n */\n\n/**\n * @external {boolean} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/boolean\n */\n/**\n * @external {boolean} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/boolean\n */\n\n/**\n * @external {symbol} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/symbol\n */\n\n/**\n * @external {error} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/error\n */\n\n/**\n * @external {evalerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/evalerror\n */\n\n/**\n * @external {internalerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/internalerror\n */\n\n/**\n * @external {rangeerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/rangeerror\n */\n\n/**\n * @external {referenceerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/referenceerror\n */\n\n/**\n * @external {syntaxerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/syntaxerror\n */\n\n/**\n * @external {typeerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/typeerror\n */\n\n/**\n * @external {urierror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/urierror\n */\n\n/ numbers and dates\n/**\n * @external {number} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/number\n */\n/**\n * @external {number} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/number\n */\n\n/**\n * @external {date} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/date\n */\n\n/ text processing\n/**\n * @external {string} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/string\n */\n/**\n * @external {string} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/string\n */\n\n/**\n * @external {regexp} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/regexp\n */\n\n/ indexed collections\n/**\n * @external {array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/array\n */\n\n/**\n * @external {int8array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int8array\n */\n/**\n * @external {uint8array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint8array\n */\n\n/**\n * @external {uint8clampedarray} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint8clampedarray\n */\n\n/**\n * @external {int16array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int16array\n */\n\n/**\n * @external {uint16array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint16array\n */\n\n/**\n * @external {int32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int32array\n */\n\n/**\n * @external {uint32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint32array\n */\n\n/**\n * @external {float32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/float32array\n */\n\n/**\n * @external {float64array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/float64array\n */\n\n/ keyed collections\n/**\n * @external {map} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/map\n */\n\n/**\n * @external {set} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/set\n */\n\n/**\n * @external {weakmap} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/weakmap\n */\n\n/**\n * @external {weakset} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/weakset\n */\n\n/ structured data\n/**\n * @external {arraybuffer} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/arraybuffer\n */\n\n/**\n * @external {dataview} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/dataview\n */\n\n/**\n * @external {json} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/json\n */\n\n/ control abstraction objects\n/**\n * @external {promise} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/promise\n */\n\n/**\n * @external {generator} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/generator\n */\n\n/**\n * @external {generatorfunction} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/generatorfunction\n */\n\n/ reflection\n/**\n * @external {reflect} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/reflect\n */\n\n/**\n * @external {proxy} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/proxy\n */\n~weakset",
    "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakSet",
    "\n/**\n * @external {Infinity} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Infinity\n */\n\n/**\n * @external {NaN} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/NaN\n */\n\n/**\n * @external {undefined} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/undefined\n */\n\n/**\n * @external {null} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/null\n */\n\n/ Fundamental objects\n/**\n * @external {Object} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object\n */\n/**\n * @external {object} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object\n */\n\n/**\n * @external {Function} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function\n */\n/**\n * @external {function} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function\n */\n\n/**\n * @external {Boolean} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean\n */\n/**\n * @external {boolean} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean\n */\n\n/**\n * @external {Symbol} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Symbol\n */\n\n/**\n * @external {Error} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Error\n */\n\n/**\n * @external {EvalError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/EvalError\n */\n\n/**\n * @external {InternalError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/InternalError\n */\n\n/**\n * @external {RangeError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RangeError\n */\n\n/**\n * @external {ReferenceError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ReferenceError\n */\n\n/**\n * @external {SyntaxError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/SyntaxError\n */\n\n/**\n * @external {TypeError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/TypeError\n */\n\n/**\n * @external {URIError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/URIError\n */\n\n/ Numbers and dates\n/**\n * @external {Number} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number\n */\n/**\n * @external {number} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number\n */\n\n/**\n * @external {Date} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Date\n */\n\n/ Text processing\n/**\n * @external {String} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String\n */\n/**\n * @external {string} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String\n */\n\n/**\n * @external {RegExp} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RegExp\n */\n\n/ Indexed collections\n/**\n * @external {Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array\n */\n\n/**\n * @external {Int8Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int8Array\n */\n/**\n * @external {Uint8Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint8Array\n */\n\n/**\n * @external {Uint8ClampedArray} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint8ClampedArray\n */\n\n/**\n * @external {Int16Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int16Array\n */\n\n/**\n * @external {Uint16Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint16Array\n */\n\n/**\n * @external {Int32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int32Array\n */\n\n/**\n * @external {Uint32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint32Array\n */\n\n/**\n * @external {Float32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Float32Array\n */\n\n/**\n * @external {Float64Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Float64Array\n */\n\n/ Keyed collections\n/**\n * @external {Map} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Map\n */\n\n/**\n * @external {Set} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Set\n */\n\n/**\n * @external {WeakMap} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakMap\n */\n\n/**\n * @external {WeakSet} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakSet\n */\n\n/ Structured data\n/**\n * @external {ArrayBuffer} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ArrayBuffer\n */\n\n/**\n * @external {DataView} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/DataView\n */\n\n/**\n * @external {JSON} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/JSON\n */\n\n/ Control abstraction objects\n/**\n * @external {Promise} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Promise\n */\n\n/**\n * @external {Generator} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Generator\n */\n\n/**\n * @external {GeneratorFunction} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/GeneratorFunction\n */\n\n/ Reflection\n/**\n * @external {Reflect} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Reflect\n */\n\n/**\n * @external {Proxy} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Proxy\n */\n~WeakSet",
    "external"
  ],
  [
    "\n/**\n * @external {infinity} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/infinity\n */\n\n/**\n * @external {nan} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/nan\n */\n\n/**\n * @external {undefined} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/undefined\n */\n\n/**\n * @external {null} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/null\n */\n\n/ fundamental objects\n/**\n * @external {object} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/object\n */\n/**\n * @external {object} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/object\n */\n\n/**\n * @external {function} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/function\n */\n/**\n * @external {function} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/function\n */\n\n/**\n * @external {boolean} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/boolean\n */\n/**\n * @external {boolean} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/boolean\n */\n\n/**\n * @external {symbol} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/symbol\n */\n\n/**\n * @external {error} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/error\n */\n\n/**\n * @external {evalerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/evalerror\n */\n\n/**\n * @external {internalerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/internalerror\n */\n\n/**\n * @external {rangeerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/rangeerror\n */\n\n/**\n * @external {referenceerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/referenceerror\n */\n\n/**\n * @external {syntaxerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/syntaxerror\n */\n\n/**\n * @external {typeerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/typeerror\n */\n\n/**\n * @external {urierror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/urierror\n */\n\n/ numbers and dates\n/**\n * @external {number} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/number\n */\n/**\n * @external {number} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/number\n */\n\n/**\n * @external {date} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/date\n */\n\n/ text processing\n/**\n * @external {string} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/string\n */\n/**\n * @external {string} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/string\n */\n\n/**\n * @external {regexp} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/regexp\n */\n\n/ indexed collections\n/**\n * @external {array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/array\n */\n\n/**\n * @external {int8array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int8array\n */\n/**\n * @external {uint8array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint8array\n */\n\n/**\n * @external {uint8clampedarray} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint8clampedarray\n */\n\n/**\n * @external {int16array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int16array\n */\n\n/**\n * @external {uint16array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint16array\n */\n\n/**\n * @external {int32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int32array\n */\n\n/**\n * @external {uint32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint32array\n */\n\n/**\n * @external {float32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/float32array\n */\n\n/**\n * @external {float64array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/float64array\n */\n\n/ keyed collections\n/**\n * @external {map} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/map\n */\n\n/**\n * @external {set} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/set\n */\n\n/**\n * @external {weakmap} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/weakmap\n */\n\n/**\n * @external {weakset} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/weakset\n */\n\n/ structured data\n/**\n * @external {arraybuffer} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/arraybuffer\n */\n\n/**\n * @external {dataview} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/dataview\n */\n\n/**\n * @external {json} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/json\n */\n\n/ control abstraction objects\n/**\n * @external {promise} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/promise\n */\n\n/**\n * @external {generator} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/generator\n */\n\n/**\n * @external {generatorfunction} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/generatorfunction\n */\n\n/ reflection\n/**\n * @external {reflect} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/reflect\n */\n\n/**\n * @external {proxy} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/proxy\n */\n~boolean",
    "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean",
    "\n/**\n * @external {Infinity} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Infinity\n */\n\n/**\n * @external {NaN} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/NaN\n */\n\n/**\n * @external {undefined} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/undefined\n */\n\n/**\n * @external {null} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/null\n */\n\n/ Fundamental objects\n/**\n * @external {Object} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object\n */\n/**\n * @external {object} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object\n */\n\n/**\n * @external {Function} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function\n */\n/**\n * @external {function} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function\n */\n\n/**\n * @external {Boolean} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean\n */\n/**\n * @external {boolean} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean\n */\n\n/**\n * @external {Symbol} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Symbol\n */\n\n/**\n * @external {Error} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Error\n */\n\n/**\n * @external {EvalError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/EvalError\n */\n\n/**\n * @external {InternalError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/InternalError\n */\n\n/**\n * @external {RangeError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RangeError\n */\n\n/**\n * @external {ReferenceError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ReferenceError\n */\n\n/**\n * @external {SyntaxError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/SyntaxError\n */\n\n/**\n * @external {TypeError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/TypeError\n */\n\n/**\n * @external {URIError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/URIError\n */\n\n/ Numbers and dates\n/**\n * @external {Number} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number\n */\n/**\n * @external {number} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number\n */\n\n/**\n * @external {Date} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Date\n */\n\n/ Text processing\n/**\n * @external {String} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String\n */\n/**\n * @external {string} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String\n */\n\n/**\n * @external {RegExp} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RegExp\n */\n\n/ Indexed collections\n/**\n * @external {Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array\n */\n\n/**\n * @external {Int8Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int8Array\n */\n/**\n * @external {Uint8Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint8Array\n */\n\n/**\n * @external {Uint8ClampedArray} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint8ClampedArray\n */\n\n/**\n * @external {Int16Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int16Array\n */\n\n/**\n * @external {Uint16Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint16Array\n */\n\n/**\n * @external {Int32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int32Array\n */\n\n/**\n * @external {Uint32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint32Array\n */\n\n/**\n * @external {Float32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Float32Array\n */\n\n/**\n * @external {Float64Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Float64Array\n */\n\n/ Keyed collections\n/**\n * @external {Map} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Map\n */\n\n/**\n * @external {Set} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Set\n */\n\n/**\n * @external {WeakMap} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakMap\n */\n\n/**\n * @external {WeakSet} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakSet\n */\n\n/ Structured data\n/**\n * @external {ArrayBuffer} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ArrayBuffer\n */\n\n/**\n * @external {DataView} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/DataView\n */\n\n/**\n * @external {JSON} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/JSON\n */\n\n/ Control abstraction objects\n/**\n * @external {Promise} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Promise\n */\n\n/**\n * @external {Generator} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Generator\n */\n\n/**\n * @external {GeneratorFunction} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/GeneratorFunction\n */\n\n/ Reflection\n/**\n * @external {Reflect} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Reflect\n */\n\n/**\n * @external {Proxy} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Proxy\n */\n~boolean",
    "external"
  ],
  [
    "\n/**\n * @external {infinity} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/infinity\n */\n\n/**\n * @external {nan} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/nan\n */\n\n/**\n * @external {undefined} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/undefined\n */\n\n/**\n * @external {null} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/null\n */\n\n/ fundamental objects\n/**\n * @external {object} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/object\n */\n/**\n * @external {object} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/object\n */\n\n/**\n * @external {function} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/function\n */\n/**\n * @external {function} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/function\n */\n\n/**\n * @external {boolean} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/boolean\n */\n/**\n * @external {boolean} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/boolean\n */\n\n/**\n * @external {symbol} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/symbol\n */\n\n/**\n * @external {error} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/error\n */\n\n/**\n * @external {evalerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/evalerror\n */\n\n/**\n * @external {internalerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/internalerror\n */\n\n/**\n * @external {rangeerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/rangeerror\n */\n\n/**\n * @external {referenceerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/referenceerror\n */\n\n/**\n * @external {syntaxerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/syntaxerror\n */\n\n/**\n * @external {typeerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/typeerror\n */\n\n/**\n * @external {urierror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/urierror\n */\n\n/ numbers and dates\n/**\n * @external {number} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/number\n */\n/**\n * @external {number} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/number\n */\n\n/**\n * @external {date} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/date\n */\n\n/ text processing\n/**\n * @external {string} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/string\n */\n/**\n * @external {string} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/string\n */\n\n/**\n * @external {regexp} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/regexp\n */\n\n/ indexed collections\n/**\n * @external {array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/array\n */\n\n/**\n * @external {int8array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int8array\n */\n/**\n * @external {uint8array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint8array\n */\n\n/**\n * @external {uint8clampedarray} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint8clampedarray\n */\n\n/**\n * @external {int16array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int16array\n */\n\n/**\n * @external {uint16array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint16array\n */\n\n/**\n * @external {int32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int32array\n */\n\n/**\n * @external {uint32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint32array\n */\n\n/**\n * @external {float32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/float32array\n */\n\n/**\n * @external {float64array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/float64array\n */\n\n/ keyed collections\n/**\n * @external {map} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/map\n */\n\n/**\n * @external {set} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/set\n */\n\n/**\n * @external {weakmap} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/weakmap\n */\n\n/**\n * @external {weakset} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/weakset\n */\n\n/ structured data\n/**\n * @external {arraybuffer} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/arraybuffer\n */\n\n/**\n * @external {dataview} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/dataview\n */\n\n/**\n * @external {json} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/json\n */\n\n/ control abstraction objects\n/**\n * @external {promise} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/promise\n */\n\n/**\n * @external {generator} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/generator\n */\n\n/**\n * @external {generatorfunction} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/generatorfunction\n */\n\n/ reflection\n/**\n * @external {reflect} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/reflect\n */\n\n/**\n * @external {proxy} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/proxy\n */\n~function",
    "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function",
    "\n/**\n * @external {Infinity} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Infinity\n */\n\n/**\n * @external {NaN} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/NaN\n */\n\n/**\n * @external {undefined} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/undefined\n */\n\n/**\n * @external {null} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/null\n */\n\n/ Fundamental objects\n/**\n * @external {Object} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object\n */\n/**\n * @external {object} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object\n */\n\n/**\n * @external {Function} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function\n */\n/**\n * @external {function} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function\n */\n\n/**\n * @external {Boolean} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean\n */\n/**\n * @external {boolean} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean\n */\n\n/**\n * @external {Symbol} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Symbol\n */\n\n/**\n * @external {Error} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Error\n */\n\n/**\n * @external {EvalError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/EvalError\n */\n\n/**\n * @external {InternalError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/InternalError\n */\n\n/**\n * @external {RangeError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RangeError\n */\n\n/**\n * @external {ReferenceError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ReferenceError\n */\n\n/**\n * @external {SyntaxError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/SyntaxError\n */\n\n/**\n * @external {TypeError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/TypeError\n */\n\n/**\n * @external {URIError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/URIError\n */\n\n/ Numbers and dates\n/**\n * @external {Number} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number\n */\n/**\n * @external {number} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number\n */\n\n/**\n * @external {Date} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Date\n */\n\n/ Text processing\n/**\n * @external {String} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String\n */\n/**\n * @external {string} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String\n */\n\n/**\n * @external {RegExp} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RegExp\n */\n\n/ Indexed collections\n/**\n * @external {Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array\n */\n\n/**\n * @external {Int8Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int8Array\n */\n/**\n * @external {Uint8Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint8Array\n */\n\n/**\n * @external {Uint8ClampedArray} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint8ClampedArray\n */\n\n/**\n * @external {Int16Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int16Array\n */\n\n/**\n * @external {Uint16Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint16Array\n */\n\n/**\n * @external {Int32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int32Array\n */\n\n/**\n * @external {Uint32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint32Array\n */\n\n/**\n * @external {Float32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Float32Array\n */\n\n/**\n * @external {Float64Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Float64Array\n */\n\n/ Keyed collections\n/**\n * @external {Map} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Map\n */\n\n/**\n * @external {Set} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Set\n */\n\n/**\n * @external {WeakMap} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakMap\n */\n\n/**\n * @external {WeakSet} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakSet\n */\n\n/ Structured data\n/**\n * @external {ArrayBuffer} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ArrayBuffer\n */\n\n/**\n * @external {DataView} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/DataView\n */\n\n/**\n * @external {JSON} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/JSON\n */\n\n/ Control abstraction objects\n/**\n * @external {Promise} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Promise\n */\n\n/**\n * @external {Generator} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Generator\n */\n\n/**\n * @external {GeneratorFunction} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/GeneratorFunction\n */\n\n/ Reflection\n/**\n * @external {Reflect} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Reflect\n */\n\n/**\n * @external {Proxy} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Proxy\n */\n~function",
    "external"
  ],
  [
    "\n/**\n * @external {infinity} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/infinity\n */\n\n/**\n * @external {nan} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/nan\n */\n\n/**\n * @external {undefined} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/undefined\n */\n\n/**\n * @external {null} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/null\n */\n\n/ fundamental objects\n/**\n * @external {object} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/object\n */\n/**\n * @external {object} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/object\n */\n\n/**\n * @external {function} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/function\n */\n/**\n * @external {function} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/function\n */\n\n/**\n * @external {boolean} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/boolean\n */\n/**\n * @external {boolean} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/boolean\n */\n\n/**\n * @external {symbol} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/symbol\n */\n\n/**\n * @external {error} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/error\n */\n\n/**\n * @external {evalerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/evalerror\n */\n\n/**\n * @external {internalerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/internalerror\n */\n\n/**\n * @external {rangeerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/rangeerror\n */\n\n/**\n * @external {referenceerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/referenceerror\n */\n\n/**\n * @external {syntaxerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/syntaxerror\n */\n\n/**\n * @external {typeerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/typeerror\n */\n\n/**\n * @external {urierror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/urierror\n */\n\n/ numbers and dates\n/**\n * @external {number} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/number\n */\n/**\n * @external {number} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/number\n */\n\n/**\n * @external {date} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/date\n */\n\n/ text processing\n/**\n * @external {string} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/string\n */\n/**\n * @external {string} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/string\n */\n\n/**\n * @external {regexp} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/regexp\n */\n\n/ indexed collections\n/**\n * @external {array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/array\n */\n\n/**\n * @external {int8array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int8array\n */\n/**\n * @external {uint8array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint8array\n */\n\n/**\n * @external {uint8clampedarray} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint8clampedarray\n */\n\n/**\n * @external {int16array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int16array\n */\n\n/**\n * @external {uint16array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint16array\n */\n\n/**\n * @external {int32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int32array\n */\n\n/**\n * @external {uint32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint32array\n */\n\n/**\n * @external {float32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/float32array\n */\n\n/**\n * @external {float64array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/float64array\n */\n\n/ keyed collections\n/**\n * @external {map} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/map\n */\n\n/**\n * @external {set} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/set\n */\n\n/**\n * @external {weakmap} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/weakmap\n */\n\n/**\n * @external {weakset} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/weakset\n */\n\n/ structured data\n/**\n * @external {arraybuffer} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/arraybuffer\n */\n\n/**\n * @external {dataview} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/dataview\n */\n\n/**\n * @external {json} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/json\n */\n\n/ control abstraction objects\n/**\n * @external {promise} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/promise\n */\n\n/**\n * @external {generator} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/generator\n */\n\n/**\n * @external {generatorfunction} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/generatorfunction\n */\n\n/ reflection\n/**\n * @external {reflect} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/reflect\n */\n\n/**\n * @external {proxy} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/proxy\n */\n~null",
    "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/null",
    "\n/**\n * @external {Infinity} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Infinity\n */\n\n/**\n * @external {NaN} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/NaN\n */\n\n/**\n * @external {undefined} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/undefined\n */\n\n/**\n * @external {null} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/null\n */\n\n/ Fundamental objects\n/**\n * @external {Object} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object\n */\n/**\n * @external {object} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object\n */\n\n/**\n * @external {Function} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function\n */\n/**\n * @external {function} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function\n */\n\n/**\n * @external {Boolean} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean\n */\n/**\n * @external {boolean} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean\n */\n\n/**\n * @external {Symbol} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Symbol\n */\n\n/**\n * @external {Error} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Error\n */\n\n/**\n * @external {EvalError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/EvalError\n */\n\n/**\n * @external {InternalError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/InternalError\n */\n\n/**\n * @external {RangeError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RangeError\n */\n\n/**\n * @external {ReferenceError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ReferenceError\n */\n\n/**\n * @external {SyntaxError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/SyntaxError\n */\n\n/**\n * @external {TypeError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/TypeError\n */\n\n/**\n * @external {URIError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/URIError\n */\n\n/ Numbers and dates\n/**\n * @external {Number} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number\n */\n/**\n * @external {number} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number\n */\n\n/**\n * @external {Date} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Date\n */\n\n/ Text processing\n/**\n * @external {String} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String\n */\n/**\n * @external {string} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String\n */\n\n/**\n * @external {RegExp} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RegExp\n */\n\n/ Indexed collections\n/**\n * @external {Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array\n */\n\n/**\n * @external {Int8Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int8Array\n */\n/**\n * @external {Uint8Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint8Array\n */\n\n/**\n * @external {Uint8ClampedArray} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint8ClampedArray\n */\n\n/**\n * @external {Int16Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int16Array\n */\n\n/**\n * @external {Uint16Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint16Array\n */\n\n/**\n * @external {Int32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int32Array\n */\n\n/**\n * @external {Uint32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint32Array\n */\n\n/**\n * @external {Float32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Float32Array\n */\n\n/**\n * @external {Float64Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Float64Array\n */\n\n/ Keyed collections\n/**\n * @external {Map} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Map\n */\n\n/**\n * @external {Set} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Set\n */\n\n/**\n * @external {WeakMap} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakMap\n */\n\n/**\n * @external {WeakSet} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakSet\n */\n\n/ Structured data\n/**\n * @external {ArrayBuffer} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ArrayBuffer\n */\n\n/**\n * @external {DataView} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/DataView\n */\n\n/**\n * @external {JSON} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/JSON\n */\n\n/ Control abstraction objects\n/**\n * @external {Promise} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Promise\n */\n\n/**\n * @external {Generator} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Generator\n */\n\n/**\n * @external {GeneratorFunction} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/GeneratorFunction\n */\n\n/ Reflection\n/**\n * @external {Reflect} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Reflect\n */\n\n/**\n * @external {Proxy} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Proxy\n */\n~null",
    "external"
  ],
  [
    "\n/**\n * @external {infinity} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/infinity\n */\n\n/**\n * @external {nan} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/nan\n */\n\n/**\n * @external {undefined} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/undefined\n */\n\n/**\n * @external {null} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/null\n */\n\n/ fundamental objects\n/**\n * @external {object} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/object\n */\n/**\n * @external {object} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/object\n */\n\n/**\n * @external {function} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/function\n */\n/**\n * @external {function} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/function\n */\n\n/**\n * @external {boolean} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/boolean\n */\n/**\n * @external {boolean} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/boolean\n */\n\n/**\n * @external {symbol} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/symbol\n */\n\n/**\n * @external {error} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/error\n */\n\n/**\n * @external {evalerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/evalerror\n */\n\n/**\n * @external {internalerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/internalerror\n */\n\n/**\n * @external {rangeerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/rangeerror\n */\n\n/**\n * @external {referenceerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/referenceerror\n */\n\n/**\n * @external {syntaxerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/syntaxerror\n */\n\n/**\n * @external {typeerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/typeerror\n */\n\n/**\n * @external {urierror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/urierror\n */\n\n/ numbers and dates\n/**\n * @external {number} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/number\n */\n/**\n * @external {number} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/number\n */\n\n/**\n * @external {date} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/date\n */\n\n/ text processing\n/**\n * @external {string} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/string\n */\n/**\n * @external {string} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/string\n */\n\n/**\n * @external {regexp} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/regexp\n */\n\n/ indexed collections\n/**\n * @external {array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/array\n */\n\n/**\n * @external {int8array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int8array\n */\n/**\n * @external {uint8array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint8array\n */\n\n/**\n * @external {uint8clampedarray} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint8clampedarray\n */\n\n/**\n * @external {int16array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int16array\n */\n\n/**\n * @external {uint16array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint16array\n */\n\n/**\n * @external {int32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int32array\n */\n\n/**\n * @external {uint32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint32array\n */\n\n/**\n * @external {float32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/float32array\n */\n\n/**\n * @external {float64array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/float64array\n */\n\n/ keyed collections\n/**\n * @external {map} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/map\n */\n\n/**\n * @external {set} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/set\n */\n\n/**\n * @external {weakmap} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/weakmap\n */\n\n/**\n * @external {weakset} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/weakset\n */\n\n/ structured data\n/**\n * @external {arraybuffer} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/arraybuffer\n */\n\n/**\n * @external {dataview} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/dataview\n */\n\n/**\n * @external {json} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/json\n */\n\n/ control abstraction objects\n/**\n * @external {promise} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/promise\n */\n\n/**\n * @external {generator} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/generator\n */\n\n/**\n * @external {generatorfunction} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/generatorfunction\n */\n\n/ reflection\n/**\n * @external {reflect} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/reflect\n */\n\n/**\n * @external {proxy} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/proxy\n */\n~number",
    "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number",
    "\n/**\n * @external {Infinity} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Infinity\n */\n\n/**\n * @external {NaN} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/NaN\n */\n\n/**\n * @external {undefined} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/undefined\n */\n\n/**\n * @external {null} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/null\n */\n\n/ Fundamental objects\n/**\n * @external {Object} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object\n */\n/**\n * @external {object} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object\n */\n\n/**\n * @external {Function} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function\n */\n/**\n * @external {function} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function\n */\n\n/**\n * @external {Boolean} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean\n */\n/**\n * @external {boolean} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean\n */\n\n/**\n * @external {Symbol} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Symbol\n */\n\n/**\n * @external {Error} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Error\n */\n\n/**\n * @external {EvalError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/EvalError\n */\n\n/**\n * @external {InternalError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/InternalError\n */\n\n/**\n * @external {RangeError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RangeError\n */\n\n/**\n * @external {ReferenceError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ReferenceError\n */\n\n/**\n * @external {SyntaxError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/SyntaxError\n */\n\n/**\n * @external {TypeError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/TypeError\n */\n\n/**\n * @external {URIError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/URIError\n */\n\n/ Numbers and dates\n/**\n * @external {Number} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number\n */\n/**\n * @external {number} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number\n */\n\n/**\n * @external {Date} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Date\n */\n\n/ Text processing\n/**\n * @external {String} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String\n */\n/**\n * @external {string} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String\n */\n\n/**\n * @external {RegExp} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RegExp\n */\n\n/ Indexed collections\n/**\n * @external {Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array\n */\n\n/**\n * @external {Int8Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int8Array\n */\n/**\n * @external {Uint8Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint8Array\n */\n\n/**\n * @external {Uint8ClampedArray} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint8ClampedArray\n */\n\n/**\n * @external {Int16Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int16Array\n */\n\n/**\n * @external {Uint16Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint16Array\n */\n\n/**\n * @external {Int32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int32Array\n */\n\n/**\n * @external {Uint32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint32Array\n */\n\n/**\n * @external {Float32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Float32Array\n */\n\n/**\n * @external {Float64Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Float64Array\n */\n\n/ Keyed collections\n/**\n * @external {Map} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Map\n */\n\n/**\n * @external {Set} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Set\n */\n\n/**\n * @external {WeakMap} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakMap\n */\n\n/**\n * @external {WeakSet} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakSet\n */\n\n/ Structured data\n/**\n * @external {ArrayBuffer} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ArrayBuffer\n */\n\n/**\n * @external {DataView} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/DataView\n */\n\n/**\n * @external {JSON} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/JSON\n */\n\n/ Control abstraction objects\n/**\n * @external {Promise} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Promise\n */\n\n/**\n * @external {Generator} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Generator\n */\n\n/**\n * @external {GeneratorFunction} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/GeneratorFunction\n */\n\n/ Reflection\n/**\n * @external {Reflect} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Reflect\n */\n\n/**\n * @external {Proxy} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Proxy\n */\n~number",
    "external"
  ],
  [
    "\n/**\n * @external {infinity} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/infinity\n */\n\n/**\n * @external {nan} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/nan\n */\n\n/**\n * @external {undefined} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/undefined\n */\n\n/**\n * @external {null} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/null\n */\n\n/ fundamental objects\n/**\n * @external {object} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/object\n */\n/**\n * @external {object} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/object\n */\n\n/**\n * @external {function} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/function\n */\n/**\n * @external {function} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/function\n */\n\n/**\n * @external {boolean} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/boolean\n */\n/**\n * @external {boolean} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/boolean\n */\n\n/**\n * @external {symbol} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/symbol\n */\n\n/**\n * @external {error} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/error\n */\n\n/**\n * @external {evalerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/evalerror\n */\n\n/**\n * @external {internalerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/internalerror\n */\n\n/**\n * @external {rangeerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/rangeerror\n */\n\n/**\n * @external {referenceerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/referenceerror\n */\n\n/**\n * @external {syntaxerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/syntaxerror\n */\n\n/**\n * @external {typeerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/typeerror\n */\n\n/**\n * @external {urierror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/urierror\n */\n\n/ numbers and dates\n/**\n * @external {number} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/number\n */\n/**\n * @external {number} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/number\n */\n\n/**\n * @external {date} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/date\n */\n\n/ text processing\n/**\n * @external {string} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/string\n */\n/**\n * @external {string} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/string\n */\n\n/**\n * @external {regexp} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/regexp\n */\n\n/ indexed collections\n/**\n * @external {array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/array\n */\n\n/**\n * @external {int8array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int8array\n */\n/**\n * @external {uint8array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint8array\n */\n\n/**\n * @external {uint8clampedarray} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint8clampedarray\n */\n\n/**\n * @external {int16array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int16array\n */\n\n/**\n * @external {uint16array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint16array\n */\n\n/**\n * @external {int32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int32array\n */\n\n/**\n * @external {uint32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint32array\n */\n\n/**\n * @external {float32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/float32array\n */\n\n/**\n * @external {float64array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/float64array\n */\n\n/ keyed collections\n/**\n * @external {map} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/map\n */\n\n/**\n * @external {set} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/set\n */\n\n/**\n * @external {weakmap} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/weakmap\n */\n\n/**\n * @external {weakset} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/weakset\n */\n\n/ structured data\n/**\n * @external {arraybuffer} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/arraybuffer\n */\n\n/**\n * @external {dataview} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/dataview\n */\n\n/**\n * @external {json} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/json\n */\n\n/ control abstraction objects\n/**\n * @external {promise} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/promise\n */\n\n/**\n * @external {generator} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/generator\n */\n\n/**\n * @external {generatorfunction} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/generatorfunction\n */\n\n/ reflection\n/**\n * @external {reflect} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/reflect\n */\n\n/**\n * @external {proxy} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/proxy\n */\n~object",
    "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object",
    "\n/**\n * @external {Infinity} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Infinity\n */\n\n/**\n * @external {NaN} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/NaN\n */\n\n/**\n * @external {undefined} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/undefined\n */\n\n/**\n * @external {null} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/null\n */\n\n/ Fundamental objects\n/**\n * @external {Object} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object\n */\n/**\n * @external {object} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object\n */\n\n/**\n * @external {Function} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function\n */\n/**\n * @external {function} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function\n */\n\n/**\n * @external {Boolean} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean\n */\n/**\n * @external {boolean} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean\n */\n\n/**\n * @external {Symbol} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Symbol\n */\n\n/**\n * @external {Error} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Error\n */\n\n/**\n * @external {EvalError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/EvalError\n */\n\n/**\n * @external {InternalError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/InternalError\n */\n\n/**\n * @external {RangeError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RangeError\n */\n\n/**\n * @external {ReferenceError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ReferenceError\n */\n\n/**\n * @external {SyntaxError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/SyntaxError\n */\n\n/**\n * @external {TypeError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/TypeError\n */\n\n/**\n * @external {URIError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/URIError\n */\n\n/ Numbers and dates\n/**\n * @external {Number} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number\n */\n/**\n * @external {number} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number\n */\n\n/**\n * @external {Date} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Date\n */\n\n/ Text processing\n/**\n * @external {String} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String\n */\n/**\n * @external {string} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String\n */\n\n/**\n * @external {RegExp} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RegExp\n */\n\n/ Indexed collections\n/**\n * @external {Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array\n */\n\n/**\n * @external {Int8Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int8Array\n */\n/**\n * @external {Uint8Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint8Array\n */\n\n/**\n * @external {Uint8ClampedArray} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint8ClampedArray\n */\n\n/**\n * @external {Int16Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int16Array\n */\n\n/**\n * @external {Uint16Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint16Array\n */\n\n/**\n * @external {Int32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int32Array\n */\n\n/**\n * @external {Uint32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint32Array\n */\n\n/**\n * @external {Float32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Float32Array\n */\n\n/**\n * @external {Float64Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Float64Array\n */\n\n/ Keyed collections\n/**\n * @external {Map} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Map\n */\n\n/**\n * @external {Set} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Set\n */\n\n/**\n * @external {WeakMap} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakMap\n */\n\n/**\n * @external {WeakSet} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakSet\n */\n\n/ Structured data\n/**\n * @external {ArrayBuffer} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ArrayBuffer\n */\n\n/**\n * @external {DataView} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/DataView\n */\n\n/**\n * @external {JSON} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/JSON\n */\n\n/ Control abstraction objects\n/**\n * @external {Promise} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Promise\n */\n\n/**\n * @external {Generator} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Generator\n */\n\n/**\n * @external {GeneratorFunction} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/GeneratorFunction\n */\n\n/ Reflection\n/**\n * @external {Reflect} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Reflect\n */\n\n/**\n * @external {Proxy} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Proxy\n */\n~object",
    "external"
  ],
  [
    "\n/**\n * @external {infinity} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/infinity\n */\n\n/**\n * @external {nan} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/nan\n */\n\n/**\n * @external {undefined} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/undefined\n */\n\n/**\n * @external {null} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/null\n */\n\n/ fundamental objects\n/**\n * @external {object} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/object\n */\n/**\n * @external {object} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/object\n */\n\n/**\n * @external {function} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/function\n */\n/**\n * @external {function} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/function\n */\n\n/**\n * @external {boolean} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/boolean\n */\n/**\n * @external {boolean} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/boolean\n */\n\n/**\n * @external {symbol} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/symbol\n */\n\n/**\n * @external {error} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/error\n */\n\n/**\n * @external {evalerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/evalerror\n */\n\n/**\n * @external {internalerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/internalerror\n */\n\n/**\n * @external {rangeerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/rangeerror\n */\n\n/**\n * @external {referenceerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/referenceerror\n */\n\n/**\n * @external {syntaxerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/syntaxerror\n */\n\n/**\n * @external {typeerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/typeerror\n */\n\n/**\n * @external {urierror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/urierror\n */\n\n/ numbers and dates\n/**\n * @external {number} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/number\n */\n/**\n * @external {number} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/number\n */\n\n/**\n * @external {date} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/date\n */\n\n/ text processing\n/**\n * @external {string} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/string\n */\n/**\n * @external {string} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/string\n */\n\n/**\n * @external {regexp} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/regexp\n */\n\n/ indexed collections\n/**\n * @external {array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/array\n */\n\n/**\n * @external {int8array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int8array\n */\n/**\n * @external {uint8array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint8array\n */\n\n/**\n * @external {uint8clampedarray} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint8clampedarray\n */\n\n/**\n * @external {int16array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int16array\n */\n\n/**\n * @external {uint16array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint16array\n */\n\n/**\n * @external {int32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int32array\n */\n\n/**\n * @external {uint32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint32array\n */\n\n/**\n * @external {float32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/float32array\n */\n\n/**\n * @external {float64array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/float64array\n */\n\n/ keyed collections\n/**\n * @external {map} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/map\n */\n\n/**\n * @external {set} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/set\n */\n\n/**\n * @external {weakmap} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/weakmap\n */\n\n/**\n * @external {weakset} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/weakset\n */\n\n/ structured data\n/**\n * @external {arraybuffer} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/arraybuffer\n */\n\n/**\n * @external {dataview} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/dataview\n */\n\n/**\n * @external {json} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/json\n */\n\n/ control abstraction objects\n/**\n * @external {promise} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/promise\n */\n\n/**\n * @external {generator} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/generator\n */\n\n/**\n * @external {generatorfunction} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/generatorfunction\n */\n\n/ reflection\n/**\n * @external {reflect} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/reflect\n */\n\n/**\n * @external {proxy} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/proxy\n */\n~string",
    "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String",
    "\n/**\n * @external {Infinity} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Infinity\n */\n\n/**\n * @external {NaN} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/NaN\n */\n\n/**\n * @external {undefined} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/undefined\n */\n\n/**\n * @external {null} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/null\n */\n\n/ Fundamental objects\n/**\n * @external {Object} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object\n */\n/**\n * @external {object} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object\n */\n\n/**\n * @external {Function} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function\n */\n/**\n * @external {function} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function\n */\n\n/**\n * @external {Boolean} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean\n */\n/**\n * @external {boolean} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean\n */\n\n/**\n * @external {Symbol} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Symbol\n */\n\n/**\n * @external {Error} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Error\n */\n\n/**\n * @external {EvalError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/EvalError\n */\n\n/**\n * @external {InternalError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/InternalError\n */\n\n/**\n * @external {RangeError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RangeError\n */\n\n/**\n * @external {ReferenceError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ReferenceError\n */\n\n/**\n * @external {SyntaxError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/SyntaxError\n */\n\n/**\n * @external {TypeError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/TypeError\n */\n\n/**\n * @external {URIError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/URIError\n */\n\n/ Numbers and dates\n/**\n * @external {Number} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number\n */\n/**\n * @external {number} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number\n */\n\n/**\n * @external {Date} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Date\n */\n\n/ Text processing\n/**\n * @external {String} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String\n */\n/**\n * @external {string} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String\n */\n\n/**\n * @external {RegExp} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RegExp\n */\n\n/ Indexed collections\n/**\n * @external {Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array\n */\n\n/**\n * @external {Int8Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int8Array\n */\n/**\n * @external {Uint8Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint8Array\n */\n\n/**\n * @external {Uint8ClampedArray} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint8ClampedArray\n */\n\n/**\n * @external {Int16Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int16Array\n */\n\n/**\n * @external {Uint16Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint16Array\n */\n\n/**\n * @external {Int32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int32Array\n */\n\n/**\n * @external {Uint32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint32Array\n */\n\n/**\n * @external {Float32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Float32Array\n */\n\n/**\n * @external {Float64Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Float64Array\n */\n\n/ Keyed collections\n/**\n * @external {Map} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Map\n */\n\n/**\n * @external {Set} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Set\n */\n\n/**\n * @external {WeakMap} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakMap\n */\n\n/**\n * @external {WeakSet} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakSet\n */\n\n/ Structured data\n/**\n * @external {ArrayBuffer} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ArrayBuffer\n */\n\n/**\n * @external {DataView} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/DataView\n */\n\n/**\n * @external {JSON} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/JSON\n */\n\n/ Control abstraction objects\n/**\n * @external {Promise} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Promise\n */\n\n/**\n * @external {Generator} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Generator\n */\n\n/**\n * @external {GeneratorFunction} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/GeneratorFunction\n */\n\n/ Reflection\n/**\n * @external {Reflect} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Reflect\n */\n\n/**\n * @external {Proxy} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Proxy\n */\n~string",
    "external"
  ],
  [
    "\n/**\n * @external {infinity} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/infinity\n */\n\n/**\n * @external {nan} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/nan\n */\n\n/**\n * @external {undefined} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/undefined\n */\n\n/**\n * @external {null} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/null\n */\n\n/ fundamental objects\n/**\n * @external {object} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/object\n */\n/**\n * @external {object} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/object\n */\n\n/**\n * @external {function} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/function\n */\n/**\n * @external {function} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/function\n */\n\n/**\n * @external {boolean} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/boolean\n */\n/**\n * @external {boolean} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/boolean\n */\n\n/**\n * @external {symbol} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/symbol\n */\n\n/**\n * @external {error} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/error\n */\n\n/**\n * @external {evalerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/evalerror\n */\n\n/**\n * @external {internalerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/internalerror\n */\n\n/**\n * @external {rangeerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/rangeerror\n */\n\n/**\n * @external {referenceerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/referenceerror\n */\n\n/**\n * @external {syntaxerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/syntaxerror\n */\n\n/**\n * @external {typeerror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/typeerror\n */\n\n/**\n * @external {urierror} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/urierror\n */\n\n/ numbers and dates\n/**\n * @external {number} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/number\n */\n/**\n * @external {number} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/number\n */\n\n/**\n * @external {date} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/date\n */\n\n/ text processing\n/**\n * @external {string} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/string\n */\n/**\n * @external {string} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/string\n */\n\n/**\n * @external {regexp} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/regexp\n */\n\n/ indexed collections\n/**\n * @external {array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/array\n */\n\n/**\n * @external {int8array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int8array\n */\n/**\n * @external {uint8array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint8array\n */\n\n/**\n * @external {uint8clampedarray} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint8clampedarray\n */\n\n/**\n * @external {int16array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int16array\n */\n\n/**\n * @external {uint16array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint16array\n */\n\n/**\n * @external {int32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/int32array\n */\n\n/**\n * @external {uint32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/uint32array\n */\n\n/**\n * @external {float32array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/float32array\n */\n\n/**\n * @external {float64array} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/float64array\n */\n\n/ keyed collections\n/**\n * @external {map} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/map\n */\n\n/**\n * @external {set} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/set\n */\n\n/**\n * @external {weakmap} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/weakmap\n */\n\n/**\n * @external {weakset} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/weakset\n */\n\n/ structured data\n/**\n * @external {arraybuffer} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/arraybuffer\n */\n\n/**\n * @external {dataview} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/dataview\n */\n\n/**\n * @external {json} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/json\n */\n\n/ control abstraction objects\n/**\n * @external {promise} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/promise\n */\n\n/**\n * @external {generator} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/generator\n */\n\n/**\n * @external {generatorfunction} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/generatorfunction\n */\n\n/ reflection\n/**\n * @external {reflect} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/reflect\n */\n\n/**\n * @external {proxy} https:/developer.mozilla.org/en-us/docs/web/javascript/reference/global_objects/proxy\n */\n~undefined",
    "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/undefined",
    "\n/**\n * @external {Infinity} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Infinity\n */\n\n/**\n * @external {NaN} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/NaN\n */\n\n/**\n * @external {undefined} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/undefined\n */\n\n/**\n * @external {null} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/null\n */\n\n/ Fundamental objects\n/**\n * @external {Object} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object\n */\n/**\n * @external {object} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object\n */\n\n/**\n * @external {Function} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function\n */\n/**\n * @external {function} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function\n */\n\n/**\n * @external {Boolean} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean\n */\n/**\n * @external {boolean} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean\n */\n\n/**\n * @external {Symbol} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Symbol\n */\n\n/**\n * @external {Error} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Error\n */\n\n/**\n * @external {EvalError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/EvalError\n */\n\n/**\n * @external {InternalError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/InternalError\n */\n\n/**\n * @external {RangeError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RangeError\n */\n\n/**\n * @external {ReferenceError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ReferenceError\n */\n\n/**\n * @external {SyntaxError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/SyntaxError\n */\n\n/**\n * @external {TypeError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/TypeError\n */\n\n/**\n * @external {URIError} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/URIError\n */\n\n/ Numbers and dates\n/**\n * @external {Number} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number\n */\n/**\n * @external {number} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number\n */\n\n/**\n * @external {Date} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Date\n */\n\n/ Text processing\n/**\n * @external {String} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String\n */\n/**\n * @external {string} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String\n */\n\n/**\n * @external {RegExp} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RegExp\n */\n\n/ Indexed collections\n/**\n * @external {Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array\n */\n\n/**\n * @external {Int8Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int8Array\n */\n/**\n * @external {Uint8Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint8Array\n */\n\n/**\n * @external {Uint8ClampedArray} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint8ClampedArray\n */\n\n/**\n * @external {Int16Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int16Array\n */\n\n/**\n * @external {Uint16Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint16Array\n */\n\n/**\n * @external {Int32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int32Array\n */\n\n/**\n * @external {Uint32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint32Array\n */\n\n/**\n * @external {Float32Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Float32Array\n */\n\n/**\n * @external {Float64Array} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Float64Array\n */\n\n/ Keyed collections\n/**\n * @external {Map} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Map\n */\n\n/**\n * @external {Set} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Set\n */\n\n/**\n * @external {WeakMap} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakMap\n */\n\n/**\n * @external {WeakSet} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakSet\n */\n\n/ Structured data\n/**\n * @external {ArrayBuffer} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ArrayBuffer\n */\n\n/**\n * @external {DataView} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/DataView\n */\n\n/**\n * @external {JSON} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/JSON\n */\n\n/ Control abstraction objects\n/**\n * @external {Promise} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Promise\n */\n\n/**\n * @external {Generator} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Generator\n */\n\n/**\n * @external {GeneratorFunction} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/GeneratorFunction\n */\n\n/ Reflection\n/**\n * @external {Reflect} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Reflect\n */\n\n/**\n * @external {Proxy} https:/developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Proxy\n */\n~undefined",
    "external"
  ],
  [
    "\n/**\n * @external {pluginconfig} https:/docs.typhonjs.io/typhonjs-node-plugin/typhonjs-plugin-manager/typedef/index.html#static-typedef-pluginconfig\n */\n\n/**\n * @external {pluginevent} https:/docs.typhonjs.io/typhonjs-node-plugin/typhonjs-plugin-manager/class/src/pluginevent.js~pluginevent.html\n */\n\n/**\n * @external {pluginmanageroptions} https:/docs.typhonjs.io/typhonjs-node-plugin/typhonjs-plugin-manager/typedef/index.html#static-typedef-manageroptions\n */\n.pluginconfig",
    "https://docs.typhonjs.io/typhonjs-node-plugin/typhonjs-plugin-manager/typedef/index.html#static-typedef-PluginConfig",
    "\n/**\n * @external {PluginConfig} https:/docs.typhonjs.io/typhonjs-node-plugin/typhonjs-plugin-manager/typedef/index.html#static-typedef-PluginConfig\n */\n\n/**\n * @external {PluginEvent} https:/docs.typhonjs.io/typhonjs-node-plugin/typhonjs-plugin-manager/class/src/PluginEvent.js~PluginEvent.html\n */\n\n/**\n * @external {PluginManagerOptions} https:/docs.typhonjs.io/typhonjs-node-plugin/typhonjs-plugin-manager/typedef/index.html#static-typedef-ManagerOptions\n */\n.PluginConfig",
    "external"
  ],
  [
    "\n/**\n * @external {pluginconfig} https:/docs.typhonjs.io/typhonjs-node-plugin/typhonjs-plugin-manager/typedef/index.html#static-typedef-pluginconfig\n */\n\n/**\n * @external {pluginevent} https:/docs.typhonjs.io/typhonjs-node-plugin/typhonjs-plugin-manager/class/src/pluginevent.js~pluginevent.html\n */\n\n/**\n * @external {pluginmanageroptions} https:/docs.typhonjs.io/typhonjs-node-plugin/typhonjs-plugin-manager/typedef/index.html#static-typedef-manageroptions\n */\n.pluginevent",
    "https://docs.typhonjs.io/typhonjs-node-plugin/typhonjs-plugin-manager/class/src/PluginEvent.js~PluginEvent.html",
    "\n/**\n * @external {PluginConfig} https:/docs.typhonjs.io/typhonjs-node-plugin/typhonjs-plugin-manager/typedef/index.html#static-typedef-PluginConfig\n */\n\n/**\n * @external {PluginEvent} https:/docs.typhonjs.io/typhonjs-node-plugin/typhonjs-plugin-manager/class/src/PluginEvent.js~PluginEvent.html\n */\n\n/**\n * @external {PluginManagerOptions} https:/docs.typhonjs.io/typhonjs-node-plugin/typhonjs-plugin-manager/typedef/index.html#static-typedef-ManagerOptions\n */\n.PluginEvent",
    "external"
  ],
  [
    "\n/**\n * @external {pluginconfig} https:/docs.typhonjs.io/typhonjs-node-plugin/typhonjs-plugin-manager/typedef/index.html#static-typedef-pluginconfig\n */\n\n/**\n * @external {pluginevent} https:/docs.typhonjs.io/typhonjs-node-plugin/typhonjs-plugin-manager/class/src/pluginevent.js~pluginevent.html\n */\n\n/**\n * @external {pluginmanageroptions} https:/docs.typhonjs.io/typhonjs-node-plugin/typhonjs-plugin-manager/typedef/index.html#static-typedef-manageroptions\n */\n.pluginmanageroptions",
    "https://docs.typhonjs.io/typhonjs-node-plugin/typhonjs-plugin-manager/typedef/index.html#static-typedef-ManagerOptions",
    "\n/**\n * @external {PluginConfig} https:/docs.typhonjs.io/typhonjs-node-plugin/typhonjs-plugin-manager/typedef/index.html#static-typedef-PluginConfig\n */\n\n/**\n * @external {PluginEvent} https:/docs.typhonjs.io/typhonjs-node-plugin/typhonjs-plugin-manager/class/src/PluginEvent.js~PluginEvent.html\n */\n\n/**\n * @external {PluginManagerOptions} https:/docs.typhonjs.io/typhonjs-node-plugin/typhonjs-plugin-manager/typedef/index.html#static-typedef-ManagerOptions\n */\n.PluginManagerOptions",
    "external"
  ],
  [
    "esdoc/src/publisher/builder/astdocbuilder.js~astdocbuilder",
    "class/src/Publisher/Builder/ASTDocBuilder.js~ASTDocBuilder.html",
    "<span>ASTDocBuilder</span> <span class=\"search-result-import-path\">esdoc/src/Publisher/Builder/ASTDocBuilder.js</span>",
    "class"
  ],
  [
    "esdoc/src/common/utils/astnodecontainer.js~astnodecontainer",
    "class/src/common/utils/ASTNodeContainer.js~ASTNodeContainer.html",
    "<span>ASTNodeContainer</span> <span class=\"search-result-import-path\">esdoc/src/common/utils/ASTNodeContainer.js</span>",
    "class"
  ],
  [
    "esdoc/src/doc/abstractdoc.js~abstractdoc",
    "class/src/Doc/AbstractDoc.js~AbstractDoc.html",
    "<span>AbstractDoc</span> <span class=\"search-result-import-path\">esdoc/src/Doc/AbstractDoc.js</span>",
    "class"
  ],
  [
    "esdoc/src/common/doc/abstractdoc.js~abstractdoc",
    "class/src/common/doc/AbstractDoc.js~AbstractDoc.html",
    "<span>AbstractDoc</span> <span class=\"search-result-import-path\">esdoc/src/common/doc/AbstractDoc.js</span>",
    "class"
  ],
  [
    "esdoc/src/doc/assignmentdoc.js~assignmentdoc",
    "class/src/Doc/AssignmentDoc.js~AssignmentDoc.html",
    "<span>AssignmentDoc</span> <span class=\"search-result-import-path\">esdoc/src/Doc/AssignmentDoc.js</span>",
    "class"
  ],
  [
    "esdoc/src/babylon/utils/babylonastutil.js~babylonastutil",
    "class/src/babylon/utils/BabylonASTUtil.js~BabylonASTUtil.html",
    "<span>BabylonASTUtil</span> <span class=\"search-result-import-path\">esdoc/src/babylon/utils/BabylonASTUtil.js</span>",
    "class"
  ],
  [
    "esdoc/src/babylon/parser/babylonparser.js~babylonparser",
    "class/src/babylon/parser/BabylonParser.js~BabylonParser.html",
    "<span>BabylonParser</span> <span class=\"search-result-import-path\">esdoc/src/babylon/parser/BabylonParser.js</span>",
    "class"
  ],
  [
    "esdoc/src/doc/classdoc.js~classdoc",
    "class/src/Doc/ClassDoc.js~ClassDoc.html",
    "<span>ClassDoc</span> <span class=\"search-result-import-path\">esdoc/src/Doc/ClassDoc.js</span>",
    "class"
  ],
  [
    "esdoc/src/publisher/builder/classdocbuilder.js~classdocbuilder",
    "class/src/Publisher/Builder/ClassDocBuilder.js~ClassDocBuilder.html",
    "<span>ClassDocBuilder</span> <span class=\"search-result-import-path\">esdoc/src/Publisher/Builder/ClassDocBuilder.js</span>",
    "class"
  ],
  [
    "esdoc/src/doc/classpropertydoc.js~classpropertydoc",
    "class/src/Doc/ClassPropertyDoc.js~ClassPropertyDoc.html",
    "<span>ClassPropertyDoc</span> <span class=\"search-result-import-path\">esdoc/src/Doc/ClassPropertyDoc.js</span>",
    "class"
  ],
  [
    "esdoc/src/parser/commentparser.js~commentparser",
    "class/src/Parser/CommentParser.js~CommentParser.html",
    "<span>CommentParser</span> <span class=\"search-result-import-path\">esdoc/src/Parser/CommentParser.js</span>",
    "class"
  ],
  [
    "esdoc/src/publisher/builder/coveragebuilder.js~coveragebuilder",
    "class/src/Publisher/Builder/CoverageBuilder.js~CoverageBuilder.html",
    "<span>CoverageBuilder</span> <span class=\"search-result-import-path\">esdoc/src/Publisher/Builder/CoverageBuilder.js</span>",
    "class"
  ],
  [
    "esdoc/src/publisher/builder/docbuilder.js~docbuilder",
    "class/src/Publisher/Builder/DocBuilder.js~DocBuilder.html",
    "<span>DocBuilder</span> <span class=\"search-result-import-path\">esdoc/src/Publisher/Builder/DocBuilder.js</span>",
    "class"
  ],
  [
    "esdoc/src/factory/docfactory.js~docfactory",
    "class/src/Factory/DocFactory.js~DocFactory.html",
    "<span>DocFactory</span> <span class=\"search-result-import-path\">esdoc/src/Factory/DocFactory.js</span>",
    "class"
  ],
  [
    "esdoc/src/publisher/builder/docresolver.js~docresolver",
    "class/src/Publisher/Builder/DocResolver.js~DocResolver.html",
    "<span>DocResolver</span> <span class=\"search-result-import-path\">esdoc/src/Publisher/Builder/DocResolver.js</span>",
    "class"
  ],
  [
    "esdoc/src/esdoc.js~esdoc",
    "class/src/ESDoc.js~ESDoc.html",
    "<span>ESDoc</span> <span class=\"search-result-import-path\">esdoc/src/ESDoc.js</span>",
    "class"
  ],
  [
    "esdoc/src/esdoccli.js~esdoccli",
    "class/src/ESDocCLI.js~ESDocCLI.html",
    "<span>ESDocCLI</span> <span class=\"search-result-import-path\">esdoc/src/ESDocCLI.js</span>",
    "class"
  ],
  [
    "esdoc/src/doc/externaldoc.js~externaldoc",
    "class/src/Doc/ExternalDoc.js~ExternalDoc.html",
    "<span>ExternalDoc</span> <span class=\"search-result-import-path\">esdoc/src/Doc/ExternalDoc.js</span>",
    "class"
  ],
  [
    "esdoc/src/doc/filedoc.js~filedoc",
    "class/src/Doc/FileDoc.js~FileDoc.html",
    "<span>FileDoc</span> <span class=\"search-result-import-path\">esdoc/src/Doc/FileDoc.js</span>",
    "class"
  ],
  [
    "esdoc/src/publisher/builder/filedocbuilder.js~filedocbuilder",
    "class/src/Publisher/Builder/FileDocBuilder.js~FileDocBuilder.html",
    "<span>FileDocBuilder</span> <span class=\"search-result-import-path\">esdoc/src/Publisher/Builder/FileDocBuilder.js</span>",
    "class"
  ],
  [
    "esdoc/src/doc/functiondoc.js~functiondoc",
    "class/src/Doc/FunctionDoc.js~FunctionDoc.html",
    "<span>FunctionDoc</span> <span class=\"search-result-import-path\">esdoc/src/Doc/FunctionDoc.js</span>",
    "class"
  ],
  [
    "esdoc/src/publisher/builder/identifiersdocbuilder.js~identifiersdocbuilder",
    "class/src/Publisher/Builder/IdentifiersDocBuilder.js~IdentifiersDocBuilder.html",
    "<span>IdentifiersDocBuilder</span> <span class=\"search-result-import-path\">esdoc/src/Publisher/Builder/IdentifiersDocBuilder.js</span>",
    "class"
  ],
  [
    "esdoc/src/publisher/builder/indexdocbuilder.js~indexdocbuilder",
    "class/src/Publisher/Builder/IndexDocBuilder.js~IndexDocBuilder.html",
    "<span>IndexDocBuilder</span> <span class=\"search-result-import-path\">esdoc/src/Publisher/Builder/IndexDocBuilder.js</span>",
    "class"
  ],
  [
    "esdoc/src/common/utils/invalidcodelogger.js~invalidcodelogger",
    "class/src/common/utils/InvalidCodeLogger.js~InvalidCodeLogger.html",
    "<span>InvalidCodeLogger</span> <span class=\"search-result-import-path\">esdoc/src/common/utils/InvalidCodeLogger.js</span>",
    "class"
  ],
  [
    "esdoc/src/publisher/builder/lintdocbuilder.js~lintdocbuilder",
    "class/src/Publisher/Builder/LintDocBuilder.js~LintDocBuilder.html",
    "<span>LintDocBuilder</span> <span class=\"search-result-import-path\">esdoc/src/Publisher/Builder/LintDocBuilder.js</span>",
    "class"
  ],
  [
    "esdoc/src/publisher/builder/manualdocbuilder.js~manualdocbuilder",
    "class/src/Publisher/Builder/ManualDocBuilder.js~ManualDocBuilder.html",
    "<span>ManualDocBuilder</span> <span class=\"search-result-import-path\">esdoc/src/Publisher/Builder/ManualDocBuilder.js</span>",
    "class"
  ],
  [
    "esdoc/src/doc/memberdoc.js~memberdoc",
    "class/src/Doc/MemberDoc.js~MemberDoc.html",
    "<span>MemberDoc</span> <span class=\"search-result-import-path\">esdoc/src/Doc/MemberDoc.js</span>",
    "class"
  ],
  [
    "esdoc/src/doc/memorydoc.js~memorydoc",
    "class/src/Doc/MemoryDoc.js~MemoryDoc.html",
    "<span>MemoryDoc</span> <span class=\"search-result-import-path\">esdoc/src/Doc/MemoryDoc.js</span>",
    "class"
  ],
  [
    "esdoc/src/doc/methoddoc.js~methoddoc",
    "class/src/Doc/MethodDoc.js~MethodDoc.html",
    "<span>MethodDoc</span> <span class=\"search-result-import-path\">esdoc/src/Doc/MethodDoc.js</span>",
    "class"
  ],
  [
    "esdoc/src/common/utils/namingutil.js~namingutil",
    "class/src/common/utils/NamingUtil.js~NamingUtil.html",
    "<span>NamingUtil</span> <span class=\"search-result-import-path\">esdoc/src/common/utils/NamingUtil.js</span>",
    "class"
  ],
  [
    "esdoc/src/parser/paramparser.js~paramparser",
    "class/src/Parser/ParamParser.js~ParamParser.html",
    "<span>ParamParser</span> <span class=\"search-result-import-path\">esdoc/src/Parser/ParamParser.js</span>",
    "class"
  ],
  [
    "esdoc/src/common/utils/pathresolver.js~pathresolver",
    "class/src/common/utils/PathResolver.js~PathResolver.html",
    "<span>PathResolver</span> <span class=\"search-result-import-path\">esdoc/src/common/utils/PathResolver.js</span>",
    "class"
  ],
  [
    "esdoc/src/publisher/builder/searchindexbuilder.js~searchindexbuilder",
    "class/src/Publisher/Builder/SearchIndexBuilder.js~SearchIndexBuilder.html",
    "<span>SearchIndexBuilder</span> <span class=\"search-result-import-path\">esdoc/src/Publisher/Builder/SearchIndexBuilder.js</span>",
    "class"
  ],
  [
    "esdoc/src/publisher/builder/singledocbuilder.js~singledocbuilder",
    "class/src/Publisher/Builder/SingleDocBuilder.js~SingleDocBuilder.html",
    "<span>SingleDocBuilder</span> <span class=\"search-result-import-path\">esdoc/src/Publisher/Builder/SingleDocBuilder.js</span>",
    "class"
  ],
  [
    "esdoc/src/publisher/builder/sourcedocbuilder.js~sourcedocbuilder",
    "class/src/Publisher/Builder/SourceDocBuilder.js~SourceDocBuilder.html",
    "<span>SourceDocBuilder</span> <span class=\"search-result-import-path\">esdoc/src/Publisher/Builder/SourceDocBuilder.js</span>",
    "class"
  ],
  [
    "esdoc/src/publisher/builder/staticfilebuilder.js~staticfilebuilder",
    "class/src/Publisher/Builder/StaticFileBuilder.js~StaticFileBuilder.html",
    "<span>StaticFileBuilder</span> <span class=\"search-result-import-path\">esdoc/src/Publisher/Builder/StaticFileBuilder.js</span>",
    "class"
  ],
  [
    "esdoc/src/doc/testdoc.js~testdoc",
    "class/src/Doc/TestDoc.js~TestDoc.html",
    "<span>TestDoc</span> <span class=\"search-result-import-path\">esdoc/src/Doc/TestDoc.js</span>",
    "class"
  ],
  [
    "esdoc/src/publisher/builder/testdocbuilder.js~testdocbuilder",
    "class/src/Publisher/Builder/TestDocBuilder.js~TestDocBuilder.html",
    "<span>TestDocBuilder</span> <span class=\"search-result-import-path\">esdoc/src/Publisher/Builder/TestDocBuilder.js</span>",
    "class"
  ],
  [
    "esdoc/src/factory/testdocfactory.js~testdocfactory",
    "class/src/Factory/TestDocFactory.js~TestDocFactory.html",
    "<span>TestDocFactory</span> <span class=\"search-result-import-path\">esdoc/src/Factory/TestDocFactory.js</span>",
    "class"
  ],
  [
    "esdoc/src/doc/testfiledoc.js~testfiledoc",
    "class/src/Doc/TestFileDoc.js~TestFileDoc.html",
    "<span>TestFileDoc</span> <span class=\"search-result-import-path\">esdoc/src/Doc/TestFileDoc.js</span>",
    "class"
  ],
  [
    "esdoc/src/publisher/builder/testfiledocbuilder.js~testfiledocbuilder",
    "class/src/Publisher/Builder/TestFileDocBuilder.js~TestFileDocBuilder.html",
    "<span>TestFileDocBuilder</span> <span class=\"search-result-import-path\">esdoc/src/Publisher/Builder/TestFileDocBuilder.js</span>",
    "class"
  ],
  [
    "esdoc/src/doc/typedefdoc.js~typedefdoc",
    "class/src/Doc/TypedefDoc.js~TypedefDoc.html",
    "<span>TypedefDoc</span> <span class=\"search-result-import-path\">esdoc/src/Doc/TypedefDoc.js</span>",
    "class"
  ],
  [
    "esdoc/src/doc/variabledoc.js~variabledoc",
    "class/src/Doc/VariableDoc.js~VariableDoc.html",
    "<span>VariableDoc</span> <span class=\"search-result-import-path\">esdoc/src/Doc/VariableDoc.js</span>",
    "class"
  ],
  [
    "esdoc/src/publisher/builder/utils/dateforutc.js~dateforutc",
    "function/index.html#static-function-dateForUTC",
    "<span>dateForUTC</span> <span class=\"search-result-import-path\">esdoc/src/Publisher/Builder/utils/dateForUTC.js</span>",
    "function"
  ],
  [
    "esdoc/src/publisher/builder/utils/markdown.js~markdown",
    "function/index.html#static-function-markdown",
    "<span>markdown</span> <span class=\"search-result-import-path\">esdoc/src/Publisher/Builder/utils/markdown.js</span>",
    "function"
  ],
  [
    "esdoc/src/publisher/builder/utils/parseexample.js~parseexample",
    "function/index.html#static-function-parseExample",
    "<span>parseExample</span> <span class=\"search-result-import-path\">esdoc/src/Publisher/Builder/utils/parseExample.js</span>",
    "function"
  ],
  [
    "esdoc/src/publisher/publish.js~publish",
    "function/index.html#static-function-publish",
    "<span>publish</span> <span class=\"search-result-import-path\">esdoc/src/Publisher/publish.js</span>",
    "function"
  ],
  [
    "esdoc/src/publisher/builder/utils/shorten.js~shorten",
    "function/index.html#static-function-shorten",
    "<span>shorten</span> <span class=\"search-result-import-path\">esdoc/src/Publisher/Builder/utils/shorten.js</span>",
    "function"
  ],
  [
    "babylonparser src/babylon/parser/babylonparser.js~babylonparser,babylonparser",
    "test-file/src/ParserTest/BabylonParserTest.js.html#lineNumber5",
    "BabylonParser",
    "test"
  ],
  [
    "",
    "test-file/src/ParserTest/BabylonParserTest.js.html#lineNumber25",
    "BabylonParser can parse \"async generators\"",
    "test"
  ],
  [
    "",
    "test-file/src/ParserTest/BabylonParserTest.js.html#lineNumber7",
    "BabylonParser can parse \"do expressions\"",
    "test"
  ],
  [
    "",
    "test-file/src/ParserTest/BabylonParserTest.js.html#lineNumber37",
    "BabylonParser can parse \"dynamic import\"",
    "test"
  ],
  [
    "",
    "test-file/src/ParserTest/BabylonParserTest.js.html#lineNumber31",
    "BabylonParser can parse \"export extensions\"",
    "test"
  ],
  [
    "",
    "test-file/src/ParserTest/BabylonParserTest.js.html#lineNumber13",
    "BabylonParser can parse \"function bind\"",
    "test"
  ],
  [
    "",
    "test-file/src/ParserTest/BabylonParserTest.js.html#lineNumber19",
    "BabylonParser can parse \"function sent\"",
    "test"
  ],
  [
    "commentparser src/parser/commentparser.js~commentparser,commentparser",
    "test-file/src/ParserTest/CommentParserTest.js.html#lineNumber5",
    "CommentParser:",
    "test"
  ],
  [
    "commentparser.parse src/parser/commentparser.js~commentparser.parse,commentparser.parse",
    "test-file/src/ParserTest/CommentParserTest.js.html#lineNumber8",
    "CommentParser: can parse doc comment.",
    "test"
  ],
  [
    "commentparser.parse src/parser/commentparser.js~commentparser.parse,commentparser.parse",
    "test-file/src/ParserTest/CommentParserTest.js.html#lineNumber31",
    "CommentParser: can parse doc comments with trailing tabs",
    "test"
  ],
  [
    "commentparser.parse src/parser/commentparser.js~commentparser.parse,commentparser.parse",
    "test-file/src/ParserTest/CommentParserTest.js.html#lineNumber65",
    "CommentParser: return empty with line comment.",
    "test"
  ],
  [
    "commentparser.isesdoc src/parser/commentparser.js~commentparser.isesdoc,commentparser.isesdoc",
    "test-file/src/ParserTest/CommentParserTest.js.html#lineNumber54",
    "CommentParser: return empty with non doc comment.",
    "test"
  ],
  [
    "paramparser src/parser/paramparser.js~paramparser,paramparser",
    "test-file/src/ParserTest/ParamParserTest.js.html#lineNumber5",
    "ParamParser:",
    "test"
  ],
  [
    "",
    "test-file/src/ParserTest/ParamParserTest.js.html#lineNumber123",
    "ParamParser: parse param even if description has {}.",
    "test"
  ],
  [
    "paramparser.parseparamvalue src/parser/paramparser.js~paramparser.parseparamvalue,paramparser.parseparamvalue",
    "test-file/src/ParserTest/ParamParserTest.js.html#lineNumber46",
    "ParamParser: parse param value with complex",
    "test"
  ],
  [
    "paramparser.parseparamvalue src/parser/paramparser.js~paramparser.parseparamvalue,paramparser.parseparamvalue",
    "test-file/src/ParserTest/ParamParserTest.js.html#lineNumber18",
    "ParamParser: parse param value with hyphen prefix.",
    "test"
  ],
  [
    "paramparser.parseparamvalue src/parser/paramparser.js~paramparser.parseparamvalue,paramparser.parseparamvalue",
    "test-file/src/ParserTest/ParamParserTest.js.html#lineNumber37",
    "ParamParser: parse param value without param desc",
    "test"
  ],
  [
    "paramparser.parseparamvalue src/parser/paramparser.js~paramparser.parseparamvalue,paramparser.parseparamvalue",
    "test-file/src/ParserTest/ParamParserTest.js.html#lineNumber28",
    "ParamParser: parse param value without param name",
    "test"
  ],
  [
    "paramparser.parseparamvalue src/parser/paramparser.js~paramparser.parseparamvalue,paramparser.parseparamvalue",
    "test-file/src/ParserTest/ParamParserTest.js.html#lineNumber8",
    "ParamParser: parse param value.",
    "test"
  ],
  [
    "paramparser.parseparam src/parser/paramparser.js~paramparser.parseparam,paramparser.parseparam",
    "test-file/src/ParserTest/ParamParserTest.js.html#lineNumber106",
    "ParamParser: parse param with complex.",
    "test"
  ],
  [
    "paramparser.parseparam src/parser/paramparser.js~paramparser.parseparam,paramparser.parseparam",
    "test-file/src/ParserTest/ParamParserTest.js.html#lineNumber72",
    "ParamParser: parse param with complex.",
    "test"
  ],
  [
    "paramparser.parseparam src/parser/paramparser.js~paramparser.parseparam,paramparser.parseparam",
    "test-file/src/ParserTest/ParamParserTest.js.html#lineNumber88",
    "ParamParser: parse param with object ({}) as default.",
    "test"
  ],
  [
    "paramparser.parseparam src/parser/paramparser.js~paramparser.parseparam,paramparser.parseparam",
    "test-file/src/ParserTest/ParamParserTest.js.html#lineNumber56",
    "ParamParser: parse param.",
    "test"
  ],
  [
    "paramparser.parseparam src/parser/paramparser.js~paramparser.parseparam,paramparser.parseparam",
    "test-file/src/ParserTest/ParamParserTest.js.html#lineNumber139",
    "ParamParser: throws error when empty type.",
    "test"
  ],
  [
    "docbuilder src/publisher/builder/docbuilder.js~docbuilder,docbuilder",
    "test-file/src/HTMLTest/DocumentTest/AbstractTest/DefinitionTest.js.html#lineNumber4",
    "TestAbstractDefinition:",
    "test"
  ],
  [
    "docbuilder#_builddetaildocs src/publisher/builder/docbuilder.js~docbuilder#_builddetaildocs,docbuilder#_builddetaildocs",
    "test-file/src/HTMLTest/DocumentTest/AbstractTest/DefinitionTest.js.html#lineNumber19",
    "TestAbstractDefinition: has abstract method in detail.",
    "test"
  ],
  [
    "docbuilder#_buildsummarydoc src/publisher/builder/docbuilder.js~docbuilder#_buildsummarydoc,docbuilder#_buildsummarydoc",
    "test-file/src/HTMLTest/DocumentTest/AbstractTest/DefinitionTest.js.html#lineNumber9",
    "TestAbstractDefinition: has abstract method in summary.",
    "test"
  ],
  [
    "docbuilder src/publisher/builder/docbuilder.js~docbuilder,docbuilder",
    "test-file/src/HTMLTest/DocumentTest/AbstractTest/OverrideTest.js.html#lineNumber4",
    "TestAbstractOverrideDefinition:",
    "test"
  ],
  [
    "docbuilder#_buildoverridemethod src/publisher/builder/docbuilder.js~docbuilder#_buildoverridemethod,docbuilder#_buildoverridemethod",
    "test-file/src/HTMLTest/DocumentTest/AbstractTest/OverrideTest.js.html#lineNumber9",
    "TestAbstractOverrideDefinition: has override description in summary.",
    "test"
  ],
  [
    "classdocbuilder src/publisher/builder/classdocbuilder.js~classdocbuilder,classdocbuilder",
    "test-file/src/HTMLTest/DocumentTest/AccessTest/ClassTest.js.html#lineNumber4",
    "TestAccessClass:",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/AccessTest/ClassTest.js.html#lineNumber6",
    "TestAccessClass: in header:",
    "test"
  ],
  [
    "classdocbuilder#_buildclassdoc src/publisher/builder/classdocbuilder.js~classdocbuilder#_buildclassdoc,classdocbuilder#_buildclassdoc",
    "test-file/src/HTMLTest/DocumentTest/AccessTest/ClassTest.js.html#lineNumber30",
    "TestAccessClass: in header: has auto private accessor.",
    "test"
  ],
  [
    "classdocbuilder#_buildclassdoc src/publisher/builder/classdocbuilder.js~classdocbuilder#_buildclassdoc,classdocbuilder#_buildclassdoc",
    "test-file/src/HTMLTest/DocumentTest/AccessTest/ClassTest.js.html#lineNumber23",
    "TestAccessClass: in header: has private accessor.",
    "test"
  ],
  [
    "classdocbuilder#_buildclassdoc src/publisher/builder/classdocbuilder.js~classdocbuilder#_buildclassdoc,classdocbuilder#_buildclassdoc",
    "test-file/src/HTMLTest/DocumentTest/AccessTest/ClassTest.js.html#lineNumber16",
    "TestAccessClass: in header: has protected accessor.",
    "test"
  ],
  [
    "classdocbuilder#_buildclassdoc src/publisher/builder/classdocbuilder.js~classdocbuilder#_buildclassdoc,classdocbuilder#_buildclassdoc",
    "test-file/src/HTMLTest/DocumentTest/AccessTest/ClassTest.js.html#lineNumber9",
    "TestAccessClass: in header: has public accessor.",
    "test"
  ],
  [
    "singledocbuilder src/publisher/builder/singledocbuilder.js~singledocbuilder,singledocbuilder",
    "test-file/src/HTMLTest/DocumentTest/AccessTest/FunctionTest.js.html#lineNumber4",
    "TestAccessFunction:",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/AccessTest/FunctionTest.js.html#lineNumber55",
    "TestAccessFunction: in detail: ",
    "test"
  ],
  [
    "singledocbuilder#_buildsingledoc src/publisher/builder/singledocbuilder.js~singledocbuilder#_buildsingledoc,singledocbuilder#_buildsingledoc",
    "test-file/src/HTMLTest/DocumentTest/AccessTest/FunctionTest.js.html#lineNumber79",
    "TestAccessFunction: in detail:  has auto private accessor.",
    "test"
  ],
  [
    "singledocbuilder#_buildsingledoc src/publisher/builder/singledocbuilder.js~singledocbuilder#_buildsingledoc,singledocbuilder#_buildsingledoc",
    "test-file/src/HTMLTest/DocumentTest/AccessTest/FunctionTest.js.html#lineNumber72",
    "TestAccessFunction: in detail:  has private accessor.",
    "test"
  ],
  [
    "singledocbuilder#_buildsingledoc src/publisher/builder/singledocbuilder.js~singledocbuilder#_buildsingledoc,singledocbuilder#_buildsingledoc",
    "test-file/src/HTMLTest/DocumentTest/AccessTest/FunctionTest.js.html#lineNumber65",
    "TestAccessFunction: in detail:  has protected accessor.",
    "test"
  ],
  [
    "singledocbuilder#_buildsingledoc src/publisher/builder/singledocbuilder.js~singledocbuilder#_buildsingledoc,singledocbuilder#_buildsingledoc",
    "test-file/src/HTMLTest/DocumentTest/AccessTest/FunctionTest.js.html#lineNumber58",
    "TestAccessFunction: in detail:  has public accessor.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/AccessTest/FunctionTest.js.html#lineNumber8",
    "TestAccessFunction: in summary: ",
    "test"
  ],
  [
    "singledocbuilder#_buildsingledoc src/publisher/builder/singledocbuilder.js~singledocbuilder#_buildsingledoc,singledocbuilder#_buildsingledoc",
    "test-file/src/HTMLTest/DocumentTest/AccessTest/FunctionTest.js.html#lineNumber44",
    "TestAccessFunction: in summary:  has auto private accessor.",
    "test"
  ],
  [
    "singledocbuilder#_buildsingledoc src/publisher/builder/singledocbuilder.js~singledocbuilder#_buildsingledoc,singledocbuilder#_buildsingledoc",
    "test-file/src/HTMLTest/DocumentTest/AccessTest/FunctionTest.js.html#lineNumber33",
    "TestAccessFunction: in summary:  has private accessor.",
    "test"
  ],
  [
    "singledocbuilder#_buildsingledoc src/publisher/builder/singledocbuilder.js~singledocbuilder#_buildsingledoc,singledocbuilder#_buildsingledoc",
    "test-file/src/HTMLTest/DocumentTest/AccessTest/FunctionTest.js.html#lineNumber22",
    "TestAccessFunction: in summary:  has protected accessor.",
    "test"
  ],
  [
    "singledocbuilder#_buildsingledoc src/publisher/builder/singledocbuilder.js~singledocbuilder#_buildsingledoc,singledocbuilder#_buildsingledoc",
    "test-file/src/HTMLTest/DocumentTest/AccessTest/FunctionTest.js.html#lineNumber11",
    "TestAccessFunction: in summary:  has public accessor.",
    "test"
  ],
  [
    "classdocbuilder#_buildclassdoc src/publisher/builder/classdocbuilder.js~classdocbuilder#_buildclassdoc,classdocbuilder#_buildclassdoc",
    "test-file/src/HTMLTest/DocumentTest/AccessTest/MethodTest.js.html#lineNumber4",
    "TestAccessMethod:",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/AccessTest/MethodTest.js.html#lineNumber55",
    "TestAccessMethod: in detail:",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/AccessTest/MethodTest.js.html#lineNumber72",
    "TestAccessMethod: in detail: has auto private accessor.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/AccessTest/MethodTest.js.html#lineNumber67",
    "TestAccessMethod: in detail: has private accessor.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/AccessTest/MethodTest.js.html#lineNumber62",
    "TestAccessMethod: in detail: has protected accessor.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/AccessTest/MethodTest.js.html#lineNumber57",
    "TestAccessMethod: in detail: has public accessor.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/AccessTest/MethodTest.js.html#lineNumber8",
    "TestAccessMethod: in summary:",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/AccessTest/MethodTest.js.html#lineNumber43",
    "TestAccessMethod: in summary: has auto private accessor.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/AccessTest/MethodTest.js.html#lineNumber32",
    "TestAccessMethod: in summary: has private accessor.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/AccessTest/MethodTest.js.html#lineNumber21",
    "TestAccessMethod: in summary: has protected accessor.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/AccessTest/MethodTest.js.html#lineNumber10",
    "TestAccessMethod: in summary: has public accessor.",
    "test"
  ],
  [
    "classdocbuilder#_buildclassdoc src/publisher/builder/classdocbuilder.js~classdocbuilder#_buildclassdoc,classdocbuilder#_buildclassdoc",
    "test-file/src/HTMLTest/DocumentTest/AccessTest/PropertyTest.js.html#lineNumber4",
    "TestAccessProperty:",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/AccessTest/PropertyTest.js.html#lineNumber55",
    "TestAccessProperty: in detail:",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/AccessTest/PropertyTest.js.html#lineNumber72",
    "TestAccessProperty: in detail: has auto private accessor.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/AccessTest/PropertyTest.js.html#lineNumber67",
    "TestAccessProperty: in detail: has private accessor.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/AccessTest/PropertyTest.js.html#lineNumber62",
    "TestAccessProperty: in detail: has protected accessor.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/AccessTest/PropertyTest.js.html#lineNumber57",
    "TestAccessProperty: in detail: has public accessor.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/AccessTest/PropertyTest.js.html#lineNumber8",
    "TestAccessProperty: in summary:",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/AccessTest/PropertyTest.js.html#lineNumber43",
    "TestAccessProperty: in summary: has auto private accessor.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/AccessTest/PropertyTest.js.html#lineNumber32",
    "TestAccessProperty: in summary: has private accessor.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/AccessTest/PropertyTest.js.html#lineNumber21",
    "TestAccessProperty: in summary: has protected accessor.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/AccessTest/PropertyTest.js.html#lineNumber10",
    "TestAccessProperty: in summary: has public accessor.",
    "test"
  ],
  [
    "singledocbuilder src/publisher/builder/singledocbuilder.js~singledocbuilder,singledocbuilder",
    "test-file/src/HTMLTest/DocumentTest/AccessTest/VariableTest.js.html#lineNumber4",
    "TestAccessVariable:",
    "test"
  ],
  [
    "singledocbuilder#_buildsingledoc src/publisher/builder/singledocbuilder.js~singledocbuilder#_buildsingledoc,singledocbuilder#_buildsingledoc",
    "test-file/src/HTMLTest/DocumentTest/AccessTest/VariableTest.js.html#lineNumber53",
    "TestAccessVariable: in detail: ",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/AccessTest/VariableTest.js.html#lineNumber73",
    "TestAccessVariable: in detail:  has auto private accessor.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/AccessTest/VariableTest.js.html#lineNumber67",
    "TestAccessVariable: in detail:  has private accessor.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/AccessTest/VariableTest.js.html#lineNumber61",
    "TestAccessVariable: in detail:  has protected accessor.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/AccessTest/VariableTest.js.html#lineNumber55",
    "TestAccessVariable: in detail:  has public accessor.",
    "test"
  ],
  [
    "singledocbuilder#_buildsingledoc src/publisher/builder/singledocbuilder.js~singledocbuilder#_buildsingledoc,singledocbuilder#_buildsingledoc",
    "test-file/src/HTMLTest/DocumentTest/AccessTest/VariableTest.js.html#lineNumber9",
    "TestAccessVariable: in summary: ",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/AccessTest/VariableTest.js.html#lineNumber41",
    "TestAccessVariable: in summary:  has auto private accessor.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/AccessTest/VariableTest.js.html#lineNumber31",
    "TestAccessVariable: in summary:  has private accessor.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/AccessTest/VariableTest.js.html#lineNumber21",
    "TestAccessVariable: in summary:  has protected accessor.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/AccessTest/VariableTest.js.html#lineNumber11",
    "TestAccessVariable: in summary:  has public accessor.",
    "test"
  ],
  [
    "methoddoc#_$async methoddoc#_$async,methoddoc#_$async",
    "test-file/src/HTMLTest/DocumentTest/AsyncTest/MethodTest.js.html#lineNumber4",
    "TestAsyncMethod",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/AsyncTest/MethodTest.js.html#lineNumber19",
    "TestAsyncMethod in details",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/AsyncTest/MethodTest.js.html#lineNumber21",
    "TestAsyncMethod in details has async mark.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/AsyncTest/MethodTest.js.html#lineNumber8",
    "TestAsyncMethod in summary",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/AsyncTest/MethodTest.js.html#lineNumber10",
    "TestAsyncMethod in summary has async mark.",
    "test"
  ],
  [
    "classdocbuilder src/publisher/builder/classdocbuilder.js~classdocbuilder,classdocbuilder",
    "test-file/src/HTMLTest/DocumentTest/ClassTest/DefinitionTest.js.html#lineNumber4",
    "TestClassDefinition:",
    "test"
  ],
  [
    "classdocbuilder#_buildclassdoc src/publisher/builder/classdocbuilder.js~classdocbuilder#_buildclassdoc,classdocbuilder#_buildclassdoc",
    "test-file/src/HTMLTest/DocumentTest/ClassTest/DefinitionTest.js.html#lineNumber133",
    "TestClassDefinition: in detail",
    "test"
  ],
  [
    "classdocbuilder#_buildclassdoc src/publisher/builder/classdocbuilder.js~classdocbuilder#_buildclassdoc,classdocbuilder#_buildclassdoc",
    "test-file/src/HTMLTest/DocumentTest/ClassTest/DefinitionTest.js.html#lineNumber34",
    "TestClassDefinition: in detail",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ClassTest/DefinitionTest.js.html#lineNumber183",
    "TestClassDefinition: in detail has constructor detail.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ClassTest/DefinitionTest.js.html#lineNumber159",
    "TestClassDefinition: in detail has member.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ClassTest/DefinitionTest.js.html#lineNumber197",
    "TestClassDefinition: in detail has method detail.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ClassTest/DefinitionTest.js.html#lineNumber36",
    "TestClassDefinition: in detail has self detail.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ClassTest/DefinitionTest.js.html#lineNumber135",
    "TestClassDefinition: in detail has static member.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ClassTest/DefinitionTest.js.html#lineNumber147",
    "TestClassDefinition: in detail has static method.",
    "test"
  ],
  [
    "classdocbuilder#_buildclassdoc src/publisher/builder/classdocbuilder.js~classdocbuilder#_buildclassdoc,classdocbuilder#_buildclassdoc",
    "test-file/src/HTMLTest/DocumentTest/ClassTest/DefinitionTest.js.html#lineNumber18",
    "TestClassDefinition: in header",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ClassTest/DefinitionTest.js.html#lineNumber20",
    "TestClassDefinition: in header has header notice.",
    "test"
  ],
  [
    "classdocbuilder#_buildclassdoc src/publisher/builder/classdocbuilder.js~classdocbuilder#_buildclassdoc,classdocbuilder#_buildclassdoc",
    "test-file/src/HTMLTest/DocumentTest/ClassTest/DefinitionTest.js.html#lineNumber47",
    "TestClassDefinition: in summary",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ClassTest/DefinitionTest.js.html#lineNumber79",
    "TestClassDefinition: in summary has constructor.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ClassTest/DefinitionTest.js.html#lineNumber94",
    "TestClassDefinition: in summary has member.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ClassTest/DefinitionTest.js.html#lineNumber117",
    "TestClassDefinition: in summary has method summary.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ClassTest/DefinitionTest.js.html#lineNumber49",
    "TestClassDefinition: in summary has static member",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ClassTest/DefinitionTest.js.html#lineNumber64",
    "TestClassDefinition: in summary has static method.",
    "test"
  ],
  [
    "docbuilder#_gettitle src/publisher/builder/docbuilder.js~docbuilder#_gettitle,docbuilder#_gettitle",
    "test-file/src/HTMLTest/DocumentTest/ClassTest/DefinitionTest.js.html#lineNumber9",
    "TestClassDefinition: in title:",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ClassTest/DefinitionTest.js.html#lineNumber11",
    "TestClassDefinition: in title: has document title",
    "test"
  ],
  [
    "classdocbuilder src/publisher/builder/classdocbuilder.js~classdocbuilder,classdocbuilder",
    "test-file/src/HTMLTest/DocumentTest/ClassPropertyTest/DefinitionTest.js.html#lineNumber4",
    "TestClassPropertyDefinition:",
    "test"
  ],
  [
    "classdocbuilder#_buildclassdoc src/publisher/builder/classdocbuilder.js~classdocbuilder#_buildclassdoc,classdocbuilder#_buildclassdoc",
    "test-file/src/HTMLTest/DocumentTest/ClassPropertyTest/DefinitionTest.js.html#lineNumber42",
    "TestClassPropertyDefinition: in detail",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ClassPropertyTest/DefinitionTest.js.html#lineNumber56",
    "TestClassPropertyDefinition: in detail has member.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ClassPropertyTest/DefinitionTest.js.html#lineNumber44",
    "TestClassPropertyDefinition: in detail has static member.",
    "test"
  ],
  [
    "classdocbuilder#_buildclassdoc src/publisher/builder/classdocbuilder.js~classdocbuilder#_buildclassdoc,classdocbuilder#_buildclassdoc",
    "test-file/src/HTMLTest/DocumentTest/ClassPropertyTest/DefinitionTest.js.html#lineNumber9",
    "TestClassPropertyDefinition: in summary",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ClassPropertyTest/DefinitionTest.js.html#lineNumber26",
    "TestClassPropertyDefinition: in summary has member.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ClassPropertyTest/DefinitionTest.js.html#lineNumber11",
    "TestClassPropertyDefinition: in summary has static member",
    "test"
  ],
  [
    "* *,*",
    "test-file/src/HTMLTest/DocumentTest/ComputedTest/MethodTest.js.html#lineNumber4",
    "TestComputedMethod:",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ComputedTest/MethodTest.js.html#lineNumber53",
    "TestComputedMethod: in detail:",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ComputedTest/MethodTest.js.html#lineNumber55",
    "TestComputedMethod: in detail: has computed method.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ComputedTest/MethodTest.js.html#lineNumber8",
    "TestComputedMethod: in summary:",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ComputedTest/MethodTest.js.html#lineNumber10",
    "TestComputedMethod: in summary: has computed methods.",
    "test"
  ],
  [
    "* *,*",
    "test-file/src/HTMLTest/DocumentTest/ComputedTest/PropertyTest.js.html#lineNumber4",
    "TestComputedProperty:",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ComputedTest/PropertyTest.js.html#lineNumber54",
    "TestComputedProperty: in detail:",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ComputedTest/PropertyTest.js.html#lineNumber56",
    "TestComputedProperty: in detail: has computed properties.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ComputedTest/PropertyTest.js.html#lineNumber8",
    "TestComputedProperty: in summary:",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ComputedTest/PropertyTest.js.html#lineNumber10",
    "TestComputedProperty: in summary: has computed properties.",
    "test"
  ],
  [
    "classdocbuilder#_buildclassdoc docbuilder#_builddetaildocs src/publisher/builder/classdocbuilder.js~classdocbuilder#_buildclassdoc,classdocbuilder#_buildclassdoc src/publisher/builder/docbuilder.js~docbuilder#_builddetaildocs,docbuilder#_builddetaildocs",
    "test-file/src/HTMLTest/DocumentTest/DecoratorTest/DefinitionTest.js.html#lineNumber7",
    "TestDecoratorDefinition:",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/DecoratorTest/DefinitionTest.js.html#lineNumber11",
    "TestDecoratorDefinition: has decorator at class.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/DecoratorTest/DefinitionTest.js.html#lineNumber27",
    "TestDecoratorDefinition: has decorator at getter.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/DecoratorTest/DefinitionTest.js.html#lineNumber43",
    "TestDecoratorDefinition: has decorator at method.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/DecoratorTest/DefinitionTest.js.html#lineNumber35",
    "TestDecoratorDefinition: has decorator at setter.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/DecoratorTest/DefinitionTest.js.html#lineNumber19",
    "TestDecoratorDefinition: has decorator at static method.",
    "test"
  ],
  [
    "* *,*",
    "test-file/src/HTMLTest/DocumentTest/DeprecatedTest/ClassTest.js.html#lineNumber4",
    "TestDeprecatedClass:",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/DeprecatedTest/ClassTest.js.html#lineNumber38",
    "TestDeprecatedClass: in details:",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/DeprecatedTest/ClassTest.js.html#lineNumber40",
    "TestDeprecatedClass: in details: has deprecated message of member and method.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/DeprecatedTest/ClassTest.js.html#lineNumber8",
    "TestDeprecatedClass: in self detail:",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/DeprecatedTest/ClassTest.js.html#lineNumber10",
    "TestDeprecatedClass: in self detail: has deprecated message of self.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/DeprecatedTest/ClassTest.js.html#lineNumber16",
    "TestDeprecatedClass: in summary:",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/DeprecatedTest/ClassTest.js.html#lineNumber18",
    "TestDeprecatedClass: in summary: has deprecated message of member and method.",
    "test"
  ],
  [
    "* *,*",
    "test-file/src/HTMLTest/DocumentTest/DescTest/ClassTest.js.html#lineNumber4",
    "TestDescClass",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/DescTest/ClassTest.js.html#lineNumber34",
    "TestDescClass in details",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/DescTest/ClassTest.js.html#lineNumber36",
    "TestDescClass in details has desc.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/DescTest/ClassTest.js.html#lineNumber8",
    "TestDescClass in self detail",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/DescTest/ClassTest.js.html#lineNumber10",
    "TestDescClass in self detail has desc.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/DescTest/ClassTest.js.html#lineNumber16",
    "TestDescClass in summary",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/DescTest/ClassTest.js.html#lineNumber18",
    "TestDescClass in summary has desc",
    "test"
  ],
  [
    "* *,*",
    "test-file/src/HTMLTest/DocumentTest/DescTest/MarkdownTest.js.html#lineNumber4",
    "TestDescMarkdown:",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/DescTest/MarkdownTest.js.html#lineNumber8",
    "TestDescMarkdown: in self detail",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/DescTest/MarkdownTest.js.html#lineNumber10",
    "TestDescMarkdown: in self detail has markdown desc.",
    "test"
  ],
  [
    "* *,*",
    "test-file/src/HTMLTest/DocumentTest/DescTest/MultiLineTest.js.html#lineNumber4",
    "TestDescMultiLine:",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/DescTest/MultiLineTest.js.html#lineNumber29",
    "TestDescMultiLine: in details:",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/DescTest/MultiLineTest.js.html#lineNumber31",
    "TestDescMultiLine: in details: has all sentence desc.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/DescTest/MultiLineTest.js.html#lineNumber8",
    "TestDescMultiLine: in summary",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/DescTest/MultiLineTest.js.html#lineNumber10",
    "TestDescMultiLine: in summary has first sentence desc",
    "test"
  ],
  [
    "* *,*",
    "test-file/src/HTMLTest/DocumentTest/DestructuringTest/ArrayTest.js.html#lineNumber4",
    "TestDestructuringArray",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/DestructuringTest/ArrayTest.js.html#lineNumber19",
    "TestDestructuringArray in details",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/DestructuringTest/ArrayTest.js.html#lineNumber21",
    "TestDestructuringArray in details has array destructuring.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/DestructuringTest/ArrayTest.js.html#lineNumber8",
    "TestDestructuringArray in summary",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/DestructuringTest/ArrayTest.js.html#lineNumber10",
    "TestDestructuringArray in summary has array destructuring",
    "test"
  ],
  [
    "* *,*",
    "test-file/src/HTMLTest/DocumentTest/DestructuringTest/ObjectTest.js.html#lineNumber4",
    "TestDestructuringObject",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/DestructuringTest/ObjectTest.js.html#lineNumber19",
    "TestDestructuringObject in details",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/DestructuringTest/ObjectTest.js.html#lineNumber21",
    "TestDestructuringObject in details has object destructuring.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/DestructuringTest/ObjectTest.js.html#lineNumber8",
    "TestDestructuringObject in summary",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/DestructuringTest/ObjectTest.js.html#lineNumber10",
    "TestDestructuringObject in summary has object destructuring",
    "test"
  ],
  [
    "docresolver#_resolveduplication src/publisher/builder/docresolver.js~docresolver#_resolveduplication,docresolver#_resolveduplication",
    "test-file/src/HTMLTest/DocumentTest/DuplicationTest/DefinitionTest.js.html#lineNumber4",
    "TestDuplicationDefinition",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/DuplicationTest/DefinitionTest.js.html#lineNumber29",
    "TestDuplicationDefinition in details",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/DuplicationTest/DefinitionTest.js.html#lineNumber31",
    "TestDuplicationDefinition in details has setter/getter/method.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/DuplicationTest/DefinitionTest.js.html#lineNumber8",
    "TestDuplicationDefinition in summary",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/DuplicationTest/DefinitionTest.js.html#lineNumber10",
    "TestDuplicationDefinition in summary has setter/getter/method.",
    "test"
  ],
  [
    "* *,*",
    "test-file/src/HTMLTest/DocumentTest/EmitsTest/MethodTest.js.html#lineNumber4",
    "TestEmitsMethod",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/EmitsTest/MethodTest.js.html#lineNumber8",
    "TestEmitsMethod in details",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/EmitsTest/MethodTest.js.html#lineNumber10",
    "TestEmitsMethod in details has desc.",
    "test"
  ],
  [
    "* *,*",
    "test-file/src/HTMLTest/DocumentTest/ExamleTest/CaptionTest.js.html#lineNumber4",
    "TestExampleCaption",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ExamleTest/CaptionTest.js.html#lineNumber8",
    "TestExampleCaption in self detail",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ExamleTest/CaptionTest.js.html#lineNumber10",
    "TestExampleCaption in self detail has caption of example.",
    "test"
  ],
  [
    "* *,*",
    "test-file/src/HTMLTest/DocumentTest/ExamleTest/ClassTest.js.html#lineNumber4",
    "TestExampleClass",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ExamleTest/ClassTest.js.html#lineNumber20",
    "TestExampleClass in details",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ExamleTest/ClassTest.js.html#lineNumber22",
    "TestExampleClass in details has example.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ExamleTest/ClassTest.js.html#lineNumber8",
    "TestExampleClass in self detail",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ExamleTest/ClassTest.js.html#lineNumber10",
    "TestExampleClass in self detail has example.",
    "test"
  ],
  [
    "* *,*",
    "test-file/src/HTMLTest/DocumentTest/ExperimentalTest/ClassTest.js.html#lineNumber4",
    "TestExperimentalClass",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ExperimentalTest/ClassTest.js.html#lineNumber33",
    "TestExperimentalClass in details",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ExperimentalTest/ClassTest.js.html#lineNumber35",
    "TestExperimentalClass in details has desc.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ExperimentalTest/ClassTest.js.html#lineNumber8",
    "TestExperimentalClass in self detail",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ExperimentalTest/ClassTest.js.html#lineNumber10",
    "TestExperimentalClass in self detail has desc.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ExperimentalTest/ClassTest.js.html#lineNumber17",
    "TestExperimentalClass in summary",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ExperimentalTest/ClassTest.js.html#lineNumber19",
    "TestExperimentalClass in summary has desc",
    "test"
  ],
  [
    "esparser esparser,esparser",
    "test-file/src/HTMLTest/DocumentTest/ExponentialOperatorTest/DefinitionTest.js.html#lineNumber4",
    "TestExponentiationOperatorDefinition",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ExponentialOperatorTest/DefinitionTest.js.html#lineNumber27",
    "TestExponentiationOperatorDefinition in details",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ExponentialOperatorTest/DefinitionTest.js.html#lineNumber29",
    "TestExponentiationOperatorDefinition in details has desc.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ExponentialOperatorTest/DefinitionTest.js.html#lineNumber8",
    "TestExponentiationOperatorDefinition in self detail",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ExponentialOperatorTest/DefinitionTest.js.html#lineNumber10",
    "TestExponentiationOperatorDefinition in self detail has desc.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ExponentialOperatorTest/DefinitionTest.js.html#lineNumber16",
    "TestExponentiationOperatorDefinition in summary",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ExponentialOperatorTest/DefinitionTest.js.html#lineNumber18",
    "TestExponentiationOperatorDefinition in summary has desc",
    "test"
  ],
  [
    "* *,*",
    "test-file/src/HTMLTest/DocumentTest/ExportTest/AnonymousClassTest.js.html#lineNumber4",
    "TestExportAnonymousClass",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ExportTest/AnonymousClassTest.js.html#lineNumber8",
    "TestExportAnonymousClass in self detail",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ExportTest/AnonymousClassTest.js.html#lineNumber10",
    "TestExportAnonymousClass in self detail is named with anonymous.",
    "test"
  ],
  [
    "* * *,* *,*",
    "test-file/src/HTMLTest/DocumentTest/ExportTest/DefaultTest.js.html#lineNumber7",
    "TestExportDefault",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ExportTest/DefaultTest.js.html#lineNumber10",
    "TestExportDefault has default import path.",
    "test"
  ],
  [
    "docresolver#_resolvenecessary src/publisher/builder/docresolver.js~docresolver#_resolvenecessary,docresolver#_resolvenecessary",
    "test-file/src/HTMLTest/DocumentTest/ExportTest/ExtendTest.js.html#lineNumber4",
    "TestExportExtendsInner",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ExportTest/ExtendTest.js.html#lineNumber6",
    "TestExportExtendsInner is documented.",
    "test"
  ],
  [
    "* * *,* *,*",
    "test-file/src/HTMLTest/DocumentTest/ExportTest/NamedTest.js.html#lineNumber7",
    "TestExportNamed",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ExportTest/NamedTest.js.html#lineNumber9",
    "TestExportNamed has named import path.",
    "test"
  ],
  [
    "* *,*",
    "test-file/src/HTMLTest/DocumentTest/ExtendsTest/BuiltinTest.js.html#lineNumber4",
    "TestExtendsBuiltin",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ExtendsTest/BuiltinTest.js.html#lineNumber8",
    "TestExtendsBuiltin has extends chain.",
    "test"
  ],
  [
    "* *,*",
    "test-file/src/HTMLTest/DocumentTest/ExtendsTest/ExpressionTest.js.html#lineNumber4",
    "TestExtendsExpression",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ExtendsTest/ExpressionTest.js.html#lineNumber8",
    "TestExtendsExpression has expression extends.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ExtendsTest/ExpressionTest.js.html#lineNumber16",
    "TestExtendsExpression has extends chain.",
    "test"
  ],
  [
    "* * *,* *,*",
    "test-file/src/HTMLTest/DocumentTest/ExtendsTest/InnerTest.js.html#lineNumber7",
    "TestExtendsInner",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ExtendsTest/InnerTest.js.html#lineNumber19",
    "TestExtendsInner has direct subclass.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ExtendsTest/InnerTest.js.html#lineNumber9",
    "TestExtendsInner has extends chain.",
    "test"
  ],
  [
    "* docresolver#_resolvenecessary *,* src/publisher/builder/docresolver.js~docresolver#_resolvenecessary,docresolver#_resolvenecessary",
    "test-file/src/HTMLTest/DocumentTest/ExtendsTest/MixinTest.js.html#lineNumber7",
    "TestExtendsMixin",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ExtendsTest/MixinTest.js.html#lineNumber11",
    "TestExtendsMixin has expression extends.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ExtendsTest/MixinTest.js.html#lineNumber20",
    "TestExtendsMixin has extends chain.",
    "test"
  ],
  [
    "* *,*",
    "test-file/src/HTMLTest/DocumentTest/ExtendsTest/OuterTest.js.html#lineNumber4",
    "TestExtendsOuter",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ExtendsTest/OuterTest.js.html#lineNumber8",
    "TestExtendsOuter has extends chain.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ExtendsTest/OuterTest.js.html#lineNumber21",
    "TestExtendsOuter has inherited methods and more",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ExtendsTest/OuterTest.js.html#lineNumber23",
    "TestExtendsOuter has inherited methods and more has super class methods and more.",
    "test"
  ],
  [
    "* *,*",
    "test-file/src/HTMLTest/DocumentTest/ExtendsTest/PropertyTest.js.html#lineNumber4",
    "TestExtendsProperty",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ExtendsTest/PropertyTest.js.html#lineNumber8",
    "TestExtendsProperty has extends chain.",
    "test"
  ],
  [
    "* *,*",
    "test-file/src/HTMLTest/DocumentTest/ExternalTest/DefinitionTest.js.html#lineNumber4",
    "TestExternalDefinition",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ExternalTest/DefinitionTest.js.html#lineNumber8",
    "TestExternalDefinition has external document.",
    "test"
  ],
  [
    "* *,*",
    "test-file/src/HTMLTest/DocumentTest/GeneratorTest/MethodTest.js.html#lineNumber4",
    "TestGeneratorMethod",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/GeneratorTest/MethodTest.js.html#lineNumber19",
    "TestGeneratorMethod in details",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/GeneratorTest/MethodTest.js.html#lineNumber21",
    "TestGeneratorMethod in details has generator mark.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/GeneratorTest/MethodTest.js.html#lineNumber8",
    "TestGeneratorMethod in summary",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/GeneratorTest/MethodTest.js.html#lineNumber10",
    "TestGeneratorMethod in summary has generator mark.",
    "test"
  ],
  [
    "paramparser#guessparam paramparser#guessparam,paramparser#guessparam",
    "test-file/src/HTMLTest/DocumentTest/GuessTest/ParamTest.js.html#lineNumber4",
    "TestGuessParam",
    "test"
  ],
  [
    "paramparser#guessreturn paramparser#guessreturn,paramparser#guessreturn",
    "test-file/src/HTMLTest/DocumentTest/GuessTest/ReturnTest.js.html#lineNumber4",
    "TestGuessParam",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/GuessTest/ParamTest.js.html#lineNumber64",
    "TestGuessParam in details",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/GuessTest/ReturnTest.js.html#lineNumber39",
    "TestGuessParam in details",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/GuessTest/ParamTest.js.html#lineNumber66",
    "TestGuessParam in details has guessed param.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/GuessTest/ReturnTest.js.html#lineNumber41",
    "TestGuessParam in details has guessed param.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/GuessTest/ReturnTest.js.html#lineNumber8",
    "TestGuessParam in summary",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/GuessTest/ParamTest.js.html#lineNumber8",
    "TestGuessParam in summary",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/GuessTest/ParamTest.js.html#lineNumber10",
    "TestGuessParam in summary has guessed param.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/GuessTest/ReturnTest.js.html#lineNumber10",
    "TestGuessParam in summary has guessed return.",
    "test"
  ],
  [
    "paramparser#guessparam paramparser#guessparam,paramparser#guessparam",
    "test-file/src/HTMLTest/DocumentTest/GuessTest/PropertyTest.js.html#lineNumber4",
    "TestGuessProperty",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/GuessTest/PropertyTest.js.html#lineNumber34",
    "TestGuessProperty in details",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/GuessTest/PropertyTest.js.html#lineNumber36",
    "TestGuessProperty in details has guessed member.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/GuessTest/PropertyTest.js.html#lineNumber8",
    "TestGuessProperty in summary",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/GuessTest/PropertyTest.js.html#lineNumber10",
    "TestGuessProperty in summary has guessed member.",
    "test"
  ],
  [
    "* *,*",
    "test-file/src/HTMLTest/DocumentTest/InterfaceTest/DefinitionTest.js.html#lineNumber4",
    "TestInterfaceDefinition",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/InterfaceTest/DefinitionTest.js.html#lineNumber13",
    "TestInterfaceDefinition has direct subclass.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/InterfaceTest/DefinitionTest.js.html#lineNumber8",
    "TestInterfaceDefinition has interface mark.",
    "test"
  ],
  [
    "* *,*",
    "test-file/src/HTMLTest/DocumentTest/InterfaceTest/ImplementsTest.js.html#lineNumber4",
    "TestInterfaceImplements",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/InterfaceTest/ImplementsTest.js.html#lineNumber8",
    "TestInterfaceImplements has implements.",
    "test"
  ],
  [
    "esparser esparser,esparser",
    "test-file/src/HTMLTest/DocumentTest/JSXTest/DefinitionTest.js.html#lineNumber4",
    "TestJSXDefinition",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/JSXTest/DefinitionTest.js.html#lineNumber27",
    "TestJSXDefinition in details",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/JSXTest/DefinitionTest.js.html#lineNumber29",
    "TestJSXDefinition in details has desc.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/JSXTest/DefinitionTest.js.html#lineNumber8",
    "TestJSXDefinition in self detail",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/JSXTest/DefinitionTest.js.html#lineNumber10",
    "TestJSXDefinition in self detail has desc.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/JSXTest/DefinitionTest.js.html#lineNumber16",
    "TestJSXDefinition in summary",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/JSXTest/DefinitionTest.js.html#lineNumber18",
    "TestJSXDefinition in summary has desc",
    "test"
  ],
  [
    "docresolver#_resolvelink src/publisher/builder/docresolver.js~docresolver#_resolvelink,docresolver#_resolvelink",
    "test-file/src/HTMLTest/DocumentTest/LinkTest/ClassTest.js.html#lineNumber4",
    "TestLinkClass",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/LinkTest/ClassTest.js.html#lineNumber8",
    "TestLinkClass has link from class.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/LinkTest/ClassTest.js.html#lineNumber15",
    "TestLinkClass has link from constructor.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/LinkTest/ClassTest.js.html#lineNumber24",
    "TestLinkClass has link from member.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/LinkTest/ClassTest.js.html#lineNumber33",
    "TestLinkClass has link from method.",
    "test"
  ],
  [
    "lintdocbuilder src/publisher/builder/lintdocbuilder.js~lintdocbuilder,lintdocbuilder",
    "test-file/src/DocTest/LintTest.js.html#lineNumber5",
    "TestLintInvalid",
    "test"
  ],
  [
    "",
    "test-file/src/DocTest/LintTest.js.html#lineNumber7",
    "TestLintInvalid has results",
    "test"
  ],
  [
    "* *,*",
    "test-file/src/HTMLTest/DocumentTest/ListensTest/MethodTest.js.html#lineNumber4",
    "TestListensMethod",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ListensTest/MethodTest.js.html#lineNumber8",
    "TestListensMethod has listens.",
    "test"
  ],
  [
    "* *,*",
    "test-file/src/HTMLTest/DocumentTest/ParamTest/MethodTest.js.html#lineNumber4",
    "TestParamMethod",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ParamTest/MethodTest.js.html#lineNumber19",
    "TestParamMethod in details",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ParamTest/MethodTest.js.html#lineNumber21",
    "TestParamMethod in details has desc.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ParamTest/MethodTest.js.html#lineNumber8",
    "TestParamMethod in summary",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ParamTest/MethodTest.js.html#lineNumber10",
    "TestParamMethod in summary has desc",
    "test"
  ],
  [
    "* *,*",
    "test-file/src/HTMLTest/DocumentTest/PropertyTest/ReturnTest.js.html#lineNumber4",
    "TestPropertyReturn",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/PropertyTest/ReturnTest.js.html#lineNumber8",
    "TestPropertyReturn in details",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/PropertyTest/ReturnTest.js.html#lineNumber10",
    "TestPropertyReturn in details has desc.",
    "test"
  ],
  [
    "* *,*",
    "test-file/src/HTMLTest/DocumentTest/ReturnTest/MethodTest.js.html#lineNumber4",
    "TestReturnMethod",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ReturnTest/MethodTest.js.html#lineNumber24",
    "TestReturnMethod in details",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ReturnTest/MethodTest.js.html#lineNumber26",
    "TestReturnMethod in details has desc.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ReturnTest/MethodTest.js.html#lineNumber8",
    "TestReturnMethod in summary",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ReturnTest/MethodTest.js.html#lineNumber10",
    "TestReturnMethod in summary has return",
    "test"
  ],
  [
    "* *,*",
    "test-file/src/HTMLTest/DocumentTest/SeeTest/ClassTest.js.html#lineNumber4",
    "TestSeeClass",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/SeeTest/ClassTest.js.html#lineNumber8",
    "TestSeeClass has see from class.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/SeeTest/ClassTest.js.html#lineNumber17",
    "TestSeeClass has see from constructor.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/SeeTest/ClassTest.js.html#lineNumber25",
    "TestSeeClass has see from member.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/SeeTest/ClassTest.js.html#lineNumber33",
    "TestSeeClass has see from method.",
    "test"
  ],
  [
    "* *,*",
    "test-file/src/HTMLTest/DocumentTest/SinceTest/ClassTest.js.html#lineNumber4",
    "TestSinceClass",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/SinceTest/ClassTest.js.html#lineNumber8",
    "TestSinceClass has since at class.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/SinceTest/ClassTest.js.html#lineNumber40",
    "TestSinceClass in detail",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/SinceTest/ClassTest.js.html#lineNumber42",
    "TestSinceClass in detail has since at constructor.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/SinceTest/ClassTest.js.html#lineNumber50",
    "TestSinceClass in detail has since at member.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/SinceTest/ClassTest.js.html#lineNumber58",
    "TestSinceClass in detail has since at method.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/SinceTest/ClassTest.js.html#lineNumber13",
    "TestSinceClass in summary",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/SinceTest/ClassTest.js.html#lineNumber15",
    "TestSinceClass in summary has since at constructor.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/SinceTest/ClassTest.js.html#lineNumber23",
    "TestSinceClass in summary has since at member.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/SinceTest/ClassTest.js.html#lineNumber31",
    "TestSinceClass in summary has since at method.",
    "test"
  ],
  [
    "* *,*",
    "test-file/src/HTMLTest/DocumentTest/ThrowsTest/MethodTest.js.html#lineNumber4",
    "TestThrowsMethod",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ThrowsTest/MethodTest.js.html#lineNumber8",
    "TestThrowsMethod has throws.",
    "test"
  ],
  [
    "* *,*",
    "test-file/src/HTMLTest/DocumentTest/TodoTest/ClassTest.js.html#lineNumber4",
    "TestTodoClass",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/TodoTest/ClassTest.js.html#lineNumber25",
    "TestTodoClass has see from member.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/TodoTest/ClassTest.js.html#lineNumber33",
    "TestTodoClass has see from method.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/TodoTest/ClassTest.js.html#lineNumber8",
    "TestTodoClass has todo at class.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/TodoTest/ClassTest.js.html#lineNumber17",
    "TestTodoClass has todo at constructor.",
    "test"
  ],
  [
    "esparser esparser,esparser",
    "test-file/src/HTMLTest/DocumentTest/TrailingCommaTest/DefinitionTest.js.html#lineNumber4",
    "TestTrailingCommaDefinition",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/TrailingCommaTest/DefinitionTest.js.html#lineNumber32",
    "TestTrailingCommaDefinition in details",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/TrailingCommaTest/DefinitionTest.js.html#lineNumber34",
    "TestTrailingCommaDefinition in details has desc.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/TrailingCommaTest/DefinitionTest.js.html#lineNumber8",
    "TestTrailingCommaDefinition in self detail",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/TrailingCommaTest/DefinitionTest.js.html#lineNumber10",
    "TestTrailingCommaDefinition in self detail has desc.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/TrailingCommaTest/DefinitionTest.js.html#lineNumber16",
    "TestTrailingCommaDefinition in summary",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/TrailingCommaTest/DefinitionTest.js.html#lineNumber18",
    "TestTrailingCommaDefinition in summary has desc",
    "test"
  ],
  [
    "paramparser#parseparamvalue paramparser#parseparam paramparser#parseparamvalue,paramparser#parseparamvalue paramparser#parseparam,paramparser#parseparam",
    "test-file/src/HTMLTest/DocumentTest/TypeTest/ArrayTest.js.html#lineNumber7",
    "TestTypeArray",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/TypeTest/ArrayTest.js.html#lineNumber11",
    "TestTypeArray has array type.",
    "test"
  ],
  [
    "paramparser#parseparamvalue paramparser#parseparam paramparser#parseparamvalue,paramparser#parseparamvalue paramparser#parseparam,paramparser#parseparam",
    "test-file/src/HTMLTest/DocumentTest/TypeTest/ClassTest.js.html#lineNumber7",
    "TestTypeClass",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/TypeTest/ClassTest.js.html#lineNumber11",
    "TestTypeClass has class type.",
    "test"
  ],
  [
    "paramparser#parseparamvalue paramparser#parseparam paramparser#parseparamvalue,paramparser#parseparamvalue paramparser#parseparam,paramparser#parseparam",
    "test-file/src/HTMLTest/DocumentTest/TypeTest/ComplexTest.js.html#lineNumber7",
    "TestTypeComplex",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/TypeTest/ComplexTest.js.html#lineNumber27",
    "TestTypeComplex has complex generics type.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/TypeTest/ComplexTest.js.html#lineNumber40",
    "TestTypeComplex has complex record type.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/TypeTest/ComplexTest.js.html#lineNumber72",
    "TestTypeComplex has complex union type in generics.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/TypeTest/ComplexTest.js.html#lineNumber86",
    "TestTypeComplex has complex union type with spread.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/TypeTest/ComplexTest.js.html#lineNumber58",
    "TestTypeComplex has complex union type.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/TypeTest/ComplexTest.js.html#lineNumber11",
    "TestTypeComplex has function complex type.",
    "test"
  ],
  [
    "paramparser#parseparamvalue paramparser#parseparam paramparser#parseparamvalue,paramparser#parseparamvalue paramparser#parseparam,paramparser#parseparam",
    "test-file/src/HTMLTest/DocumentTest/TypeTest/DefaultTest.js.html#lineNumber7",
    "TestTypeDefault",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/TypeTest/DefaultTest.js.html#lineNumber20",
    "TestTypeDefault has default value of object.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/TypeTest/DefaultTest.js.html#lineNumber11",
    "TestTypeDefault has default value.",
    "test"
  ],
  [
    "paramparser#parseparamvalue paramparser#parseparam paramparser#parseparamvalue,paramparser#parseparamvalue paramparser#parseparam,paramparser#parseparam",
    "test-file/src/HTMLTest/DocumentTest/TypeTest/ExternalTest.js.html#lineNumber7",
    "TestTypeExternal",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/TypeTest/ExternalTest.js.html#lineNumber11",
    "TestTypeExternal has external type.",
    "test"
  ],
  [
    "paramparser#parseparamvalue paramparser#parseparam paramparser#parseparamvalue,paramparser#parseparamvalue paramparser#parseparam,paramparser#parseparam",
    "test-file/src/HTMLTest/DocumentTest/TypeTest/FunctionTest.js.html#lineNumber7",
    "TestTypeFunction",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/TypeTest/FunctionTest.js.html#lineNumber11",
    "TestTypeFunction has function type.",
    "test"
  ],
  [
    "paramparser#parseparamvalue paramparser#parseparam paramparser#parseparamvalue,paramparser#parseparamvalue paramparser#parseparam,paramparser#parseparam",
    "test-file/src/HTMLTest/DocumentTest/TypeTest/GenericsTest.js.html#lineNumber7",
    "TestTypeGenerics",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/TypeTest/GenericsTest.js.html#lineNumber11",
    "TestTypeGenerics has generics type.",
    "test"
  ],
  [
    "paramparser#parseparamvalue paramparser#parseparam paramparser#parseparamvalue,paramparser#parseparamvalue paramparser#parseparam,paramparser#parseparam",
    "test-file/src/HTMLTest/DocumentTest/TypeTest/LiteralTest.js.html#lineNumber7",
    "TestTypeLiteral",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/TypeTest/LiteralTest.js.html#lineNumber11",
    "TestTypeLiteral has literal type.",
    "test"
  ],
  [
    "paramparser#parseparamvalue paramparser#parseparam paramparser#parseparamvalue,paramparser#parseparamvalue paramparser#parseparam,paramparser#parseparam",
    "test-file/src/HTMLTest/DocumentTest/TypeTest/NullableTest.js.html#lineNumber7",
    "TestTypeNullable",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/TypeTest/NullableTest.js.html#lineNumber11",
    "TestTypeNullable has nullable value.",
    "test"
  ],
  [
    "paramparser#parseparamvalue paramparser#parseparam paramparser#parseparamvalue,paramparser#parseparamvalue paramparser#parseparam,paramparser#parseparam",
    "test-file/src/HTMLTest/DocumentTest/TypeTest/ObjectTest.js.html#lineNumber7",
    "TestTypeObject",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/TypeTest/ObjectTest.js.html#lineNumber22",
    "TestTypeObject has object property.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/TypeTest/ObjectTest.js.html#lineNumber11",
    "TestTypeObject has object type.",
    "test"
  ],
  [
    "paramparser#parseparamvalue paramparser#parseparam paramparser#parseparamvalue,paramparser#parseparamvalue paramparser#parseparam,paramparser#parseparam",
    "test-file/src/HTMLTest/DocumentTest/TypeTest/OptionalTest.js.html#lineNumber7",
    "TestTypeOptional",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/TypeTest/OptionalTest.js.html#lineNumber11",
    "TestTypeOptional has optional attribute.",
    "test"
  ],
  [
    "paramparser#parseparamvalue paramparser#parseparam paramparser#parseparamvalue,paramparser#parseparamvalue paramparser#parseparam,paramparser#parseparam",
    "test-file/src/HTMLTest/DocumentTest/TypeTest/RecordTest.js.html#lineNumber7",
    "TestTypeRecord",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/TypeTest/RecordTest.js.html#lineNumber11",
    "TestTypeRecord has record type.",
    "test"
  ],
  [
    "paramparser#parseparamvalue paramparser#parseparam paramparser#parseparamvalue,paramparser#parseparamvalue paramparser#parseparam,paramparser#parseparam",
    "test-file/src/HTMLTest/DocumentTest/TypeTest/SpreadTest.js.html#lineNumber7",
    "TestTypeSpread",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/TypeTest/SpreadTest.js.html#lineNumber22",
    "TestTypeSpread has object spread type.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/TypeTest/SpreadTest.js.html#lineNumber11",
    "TestTypeSpread has spread type.",
    "test"
  ],
  [
    "paramparser#parseparamvalue paramparser#parseparam paramparser#parseparamvalue,paramparser#parseparamvalue paramparser#parseparam,paramparser#parseparam",
    "test-file/src/HTMLTest/DocumentTest/TypeTest/TypedefTest.js.html#lineNumber7",
    "TestTypeTypedef",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/TypeTest/TypedefTest.js.html#lineNumber11",
    "TestTypeTypedef has typedef type.",
    "test"
  ],
  [
    "paramparser#parseparamvalue paramparser#parseparam paramparser#parseparamvalue,paramparser#parseparamvalue paramparser#parseparam,paramparser#parseparam",
    "test-file/src/HTMLTest/DocumentTest/TypeTest/UnionTest.js.html#lineNumber7",
    "TestTypeUnion",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/TypeTest/UnionTest.js.html#lineNumber11",
    "TestTypeUnion has union type.",
    "test"
  ],
  [
    "typedefdoc src/doc/typedefdoc.js~typedefdoc,typedefdoc",
    "test-file/src/HTMLTest/DocumentTest/TypedefTest/DefinitionTest.js.html#lineNumber4",
    "TestTypedefDefinition",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/TypedefTest/DefinitionTest.js.html#lineNumber20",
    "TestTypedefDefinition in details",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/TypedefTest/DefinitionTest.js.html#lineNumber22",
    "TestTypedefDefinition in details has desc.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/TypedefTest/DefinitionTest.js.html#lineNumber8",
    "TestTypedefDefinition in summary",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/TypedefTest/DefinitionTest.js.html#lineNumber10",
    "TestTypedefDefinition in summary has desc",
    "test"
  ],
  [
    "docfactory#_traversecomments * docresolver#_resolveundocumentidentifier src/factory/docfactory.js~docfactory#_traversecomments,docfactory#_traversecomments *,* src/publisher/builder/docresolver.js~docresolver#_resolveundocumentidentifier,docresolver#_resolveundocumentidentifier",
    "test-file/src/HTMLTest/DocumentTest/UndocumentTest/DefinitionTest.js.html#lineNumber8",
    "TestUndocumentDefinition",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/UndocumentTest/DefinitionTest.js.html#lineNumber12",
    "TestUndocumentDefinition is exist",
    "test"
  ],
  [
    "* *,*",
    "test-file/src/HTMLTest/DocumentTest/VersionTest/ClassTest.js.html#lineNumber4",
    "TestVersionClass",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/VersionTest/ClassTest.js.html#lineNumber34",
    "TestVersionClass in details",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/VersionTest/ClassTest.js.html#lineNumber36",
    "TestVersionClass in details has version",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/VersionTest/ClassTest.js.html#lineNumber8",
    "TestVersionClass in self detail",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/VersionTest/ClassTest.js.html#lineNumber10",
    "TestVersionClass in self detail has version.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/VersionTest/ClassTest.js.html#lineNumber16",
    "TestVersionClass in summary",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/VersionTest/ClassTest.js.html#lineNumber18",
    "TestVersionClass in summary has version",
    "test"
  ],
  [
    "src/configtest/accesstest.js",
    "test-file/src/ConfigTest/AccessTest.js.html",
    "src/ConfigTest/AccessTest.js",
    "testFile"
  ],
  [
    "src/configtest/autoprivatetest.js",
    "test-file/src/ConfigTest/AutoPrivateTest.js.html",
    "src/ConfigTest/AutoPrivateTest.js",
    "testFile"
  ],
  [
    "src/configtest/builtinexternaltest.js",
    "test-file/src/ConfigTest/BuiltinExternalTest.js.html",
    "src/ConfigTest/BuiltinExternalTest.js",
    "testFile"
  ],
  [
    "src/configtest/clitest.js",
    "test-file/src/ConfigTest/CLITest.js.html",
    "src/ConfigTest/CLITest.js",
    "testFile"
  ],
  [
    "src/configtest/coveragetest.js",
    "test-file/src/ConfigTest/CoverageTest.js.html",
    "src/ConfigTest/CoverageTest.js",
    "testFile"
  ],
  [
    "src/configtest/excludestest.js",
    "test-file/src/ConfigTest/ExcludesTest.js.html",
    "src/ConfigTest/ExcludesTest.js",
    "testFile"
  ],
  [
    "src/configtest/findconfigpathtest.js",
    "test-file/src/ConfigTest/FindConfigPathTest.js.html",
    "src/ConfigTest/FindConfigPathTest.js",
    "testFile"
  ],
  [
    "src/configtest/includesourcetest.js",
    "test-file/src/ConfigTest/IncludeSourceTest.js.html",
    "src/ConfigTest/IncludeSourceTest.js",
    "testFile"
  ],
  [
    "src/configtest/linttest.js",
    "test-file/src/ConfigTest/LintTest.js.html",
    "src/ConfigTest/LintTest.js",
    "testFile"
  ],
  [
    "src/configtest/manualtest.js",
    "test-file/src/ConfigTest/ManualTest.js.html",
    "src/ConfigTest/ManualTest.js",
    "testFile"
  ],
  [
    "src/configtest/pluginstest.js",
    "test-file/src/ConfigTest/PluginsTest.js.html",
    "src/ConfigTest/PluginsTest.js",
    "testFile"
  ],
  [
    "src/configtest/scriptstest.js",
    "test-file/src/ConfigTest/ScriptsTest.js.html",
    "src/ConfigTest/ScriptsTest.js",
    "testFile"
  ],
  [
    "src/configtest/stylestest.js",
    "test-file/src/ConfigTest/StylesTest.js.html",
    "src/ConfigTest/StylesTest.js",
    "testFile"
  ],
  [
    "src/configtest/testtest.js",
    "test-file/src/ConfigTest/TestTest.js.html",
    "src/ConfigTest/TestTest.js",
    "testFile"
  ],
  [
    "src/configtest/undocumentidentifiertest.js",
    "test-file/src/ConfigTest/UndocumentIdentifierTest.js.html",
    "src/ConfigTest/UndocumentIdentifierTest.js",
    "testFile"
  ],
  [
    "src/configtest/unexportidentifiertest.js",
    "test-file/src/ConfigTest/UnexportIdentifierTest.js.html",
    "src/ConfigTest/UnexportIdentifierTest.js",
    "testFile"
  ],
  [
    "src/doc/abstractdoc.js",
    "file/src/Doc/AbstractDoc.js.html",
    "src/Doc/AbstractDoc.js",
    "file"
  ],
  [
    "src/doc/abstractdoc.js~abstractdoc#_$abstract",
    "class/src/Doc/AbstractDoc.js~AbstractDoc.html#instance-method-_$abstract",
    "src/Doc/AbstractDoc.js~AbstractDoc#_$abstract",
    "method"
  ],
  [
    "src/doc/abstractdoc.js~abstractdoc#_$access",
    "class/src/Doc/AbstractDoc.js~AbstractDoc.html#instance-method-_$access",
    "src/Doc/AbstractDoc.js~AbstractDoc#_$access",
    "method"
  ],
  [
    "src/doc/abstractdoc.js~abstractdoc#_$async",
    "class/src/Doc/AbstractDoc.js~AbstractDoc.html#instance-method-_$async",
    "src/Doc/AbstractDoc.js~AbstractDoc#_$async",
    "method"
  ],
  [
    "src/doc/abstractdoc.js~abstractdoc#_$content",
    "class/src/Doc/AbstractDoc.js~AbstractDoc.html#instance-method-_$content",
    "src/Doc/AbstractDoc.js~AbstractDoc#_$content",
    "method"
  ],
  [
    "src/doc/abstractdoc.js~abstractdoc#_$decorator",
    "class/src/Doc/AbstractDoc.js~AbstractDoc.html#instance-method-_$decorator",
    "src/Doc/AbstractDoc.js~AbstractDoc#_$decorator",
    "method"
  ],
  [
    "src/doc/abstractdoc.js~abstractdoc#_$deprecated",
    "class/src/Doc/AbstractDoc.js~AbstractDoc.html#instance-method-_$deprecated",
    "src/Doc/AbstractDoc.js~AbstractDoc#_$deprecated",
    "method"
  ],
  [
    "src/doc/abstractdoc.js~abstractdoc#_$desc",
    "class/src/Doc/AbstractDoc.js~AbstractDoc.html#instance-method-_$desc",
    "src/Doc/AbstractDoc.js~AbstractDoc#_$desc",
    "method"
  ],
  [
    "src/doc/abstractdoc.js~abstractdoc#_$emits",
    "class/src/Doc/AbstractDoc.js~AbstractDoc.html#instance-method-_$emits",
    "src/Doc/AbstractDoc.js~AbstractDoc#_$emits",
    "method"
  ],
  [
    "src/doc/abstractdoc.js~abstractdoc#_$example",
    "class/src/Doc/AbstractDoc.js~AbstractDoc.html#instance-method-_$example",
    "src/Doc/AbstractDoc.js~AbstractDoc#_$example",
    "method"
  ],
  [
    "src/doc/abstractdoc.js~abstractdoc#_$experimental",
    "class/src/Doc/AbstractDoc.js~AbstractDoc.html#instance-method-_$experimental",
    "src/Doc/AbstractDoc.js~AbstractDoc#_$experimental",
    "method"
  ],
  [
    "src/doc/abstractdoc.js~abstractdoc#_$export",
    "class/src/Doc/AbstractDoc.js~AbstractDoc.html#instance-method-_$export",
    "src/Doc/AbstractDoc.js~AbstractDoc#_$export",
    "method"
  ],
  [
    "src/doc/abstractdoc.js~abstractdoc#_$generator",
    "class/src/Doc/AbstractDoc.js~AbstractDoc.html#instance-method-_$generator",
    "src/Doc/AbstractDoc.js~AbstractDoc#_$generator",
    "method"
  ],
  [
    "src/doc/abstractdoc.js~abstractdoc#_$ignore",
    "class/src/Doc/AbstractDoc.js~AbstractDoc.html#instance-method-_$ignore",
    "src/Doc/AbstractDoc.js~AbstractDoc#_$ignore",
    "method"
  ],
  [
    "src/doc/abstractdoc.js~abstractdoc#_$importpath",
    "class/src/Doc/AbstractDoc.js~AbstractDoc.html#instance-method-_$importPath",
    "src/Doc/AbstractDoc.js~AbstractDoc#_$importPath",
    "method"
  ],
  [
    "src/doc/abstractdoc.js~abstractdoc#_$importstyle",
    "class/src/Doc/AbstractDoc.js~AbstractDoc.html#instance-method-_$importStyle",
    "src/Doc/AbstractDoc.js~AbstractDoc#_$importStyle",
    "method"
  ],
  [
    "src/doc/abstractdoc.js~abstractdoc#_$kind",
    "class/src/Doc/AbstractDoc.js~AbstractDoc.html#instance-method-_$kind",
    "src/Doc/AbstractDoc.js~AbstractDoc#_$kind",
    "method"
  ],
  [
    "src/doc/abstractdoc.js~abstractdoc#_$linenumber",
    "class/src/Doc/AbstractDoc.js~AbstractDoc.html#instance-method-_$lineNumber",
    "src/Doc/AbstractDoc.js~AbstractDoc#_$lineNumber",
    "method"
  ],
  [
    "src/doc/abstractdoc.js~abstractdoc#_$listens",
    "class/src/Doc/AbstractDoc.js~AbstractDoc.html#instance-method-_$listens",
    "src/Doc/AbstractDoc.js~AbstractDoc#_$listens",
    "method"
  ],
  [
    "src/doc/abstractdoc.js~abstractdoc#_$longname",
    "class/src/Doc/AbstractDoc.js~AbstractDoc.html#instance-method-_$longname",
    "src/Doc/AbstractDoc.js~AbstractDoc#_$longname",
    "method"
  ],
  [
    "src/doc/abstractdoc.js~abstractdoc#_$member",
    "class/src/Doc/AbstractDoc.js~AbstractDoc.html#instance-method-_$member",
    "src/Doc/AbstractDoc.js~AbstractDoc#_$member",
    "method"
  ],
  [
    "src/doc/abstractdoc.js~abstractdoc#_$memberof",
    "class/src/Doc/AbstractDoc.js~AbstractDoc.html#instance-method-_$memberof",
    "src/Doc/AbstractDoc.js~AbstractDoc#_$memberof",
    "method"
  ],
  [
    "src/doc/abstractdoc.js~abstractdoc#_$name",
    "class/src/Doc/AbstractDoc.js~AbstractDoc.html#instance-method-_$name",
    "src/Doc/AbstractDoc.js~AbstractDoc#_$name",
    "method"
  ],
  [
    "src/doc/abstractdoc.js~abstractdoc#_$override",
    "class/src/Doc/AbstractDoc.js~AbstractDoc.html#instance-method-_$override",
    "src/Doc/AbstractDoc.js~AbstractDoc#_$override",
    "method"
  ],
  [
    "src/doc/abstractdoc.js~abstractdoc#_$param",
    "class/src/Doc/AbstractDoc.js~AbstractDoc.html#instance-method-_$param",
    "src/Doc/AbstractDoc.js~AbstractDoc#_$param",
    "method"
  ],
  [
    "src/doc/abstractdoc.js~abstractdoc#_$private",
    "class/src/Doc/AbstractDoc.js~AbstractDoc.html#instance-method-_$private",
    "src/Doc/AbstractDoc.js~AbstractDoc#_$private",
    "method"
  ],
  [
    "src/doc/abstractdoc.js~abstractdoc#_$property",
    "class/src/Doc/AbstractDoc.js~AbstractDoc.html#instance-method-_$property",
    "src/Doc/AbstractDoc.js~AbstractDoc#_$property",
    "method"
  ],
  [
    "src/doc/abstractdoc.js~abstractdoc#_$protected",
    "class/src/Doc/AbstractDoc.js~AbstractDoc.html#instance-method-_$protected",
    "src/Doc/AbstractDoc.js~AbstractDoc#_$protected",
    "method"
  ],
  [
    "src/doc/abstractdoc.js~abstractdoc#_$pseudoexport",
    "class/src/Doc/AbstractDoc.js~AbstractDoc.html#instance-method-_$pseudoExport",
    "src/Doc/AbstractDoc.js~AbstractDoc#_$pseudoExport",
    "method"
  ],
  [
    "src/doc/abstractdoc.js~abstractdoc#_$public",
    "class/src/Doc/AbstractDoc.js~AbstractDoc.html#instance-method-_$public",
    "src/Doc/AbstractDoc.js~AbstractDoc#_$public",
    "method"
  ],
  [
    "src/doc/abstractdoc.js~abstractdoc#_$return",
    "class/src/Doc/AbstractDoc.js~AbstractDoc.html#instance-method-_$return",
    "src/Doc/AbstractDoc.js~AbstractDoc#_$return",
    "method"
  ],
  [
    "src/doc/abstractdoc.js~abstractdoc#_$see",
    "class/src/Doc/AbstractDoc.js~AbstractDoc.html#instance-method-_$see",
    "src/Doc/AbstractDoc.js~AbstractDoc#_$see",
    "method"
  ],
  [
    "src/doc/abstractdoc.js~abstractdoc#_$since",
    "class/src/Doc/AbstractDoc.js~AbstractDoc.html#instance-method-_$since",
    "src/Doc/AbstractDoc.js~AbstractDoc#_$since",
    "method"
  ],
  [
    "src/doc/abstractdoc.js~abstractdoc#_$static",
    "class/src/Doc/AbstractDoc.js~AbstractDoc.html#instance-method-_$static",
    "src/Doc/AbstractDoc.js~AbstractDoc#_$static",
    "method"
  ],
  [
    "src/doc/abstractdoc.js~abstractdoc#_$throws",
    "class/src/Doc/AbstractDoc.js~AbstractDoc.html#instance-method-_$throws",
    "src/Doc/AbstractDoc.js~AbstractDoc#_$throws",
    "method"
  ],
  [
    "src/doc/abstractdoc.js~abstractdoc#_$todo",
    "class/src/Doc/AbstractDoc.js~AbstractDoc.html#instance-method-_$todo",
    "src/Doc/AbstractDoc.js~AbstractDoc#_$todo",
    "method"
  ],
  [
    "src/doc/abstractdoc.js~abstractdoc#_$type",
    "class/src/Doc/AbstractDoc.js~AbstractDoc.html#instance-method-_$type",
    "src/Doc/AbstractDoc.js~AbstractDoc#_$type",
    "method"
  ],
  [
    "src/doc/abstractdoc.js~abstractdoc#_$undocument",
    "class/src/Doc/AbstractDoc.js~AbstractDoc.html#instance-method-_$undocument",
    "src/Doc/AbstractDoc.js~AbstractDoc#_$undocument",
    "method"
  ],
  [
    "src/doc/abstractdoc.js~abstractdoc#_$unknown",
    "class/src/Doc/AbstractDoc.js~AbstractDoc.html#instance-method-_$unknown",
    "src/Doc/AbstractDoc.js~AbstractDoc#_$unknown",
    "method"
  ],
  [
    "src/doc/abstractdoc.js~abstractdoc#_$variation",
    "class/src/Doc/AbstractDoc.js~AbstractDoc.html#instance-method-_$variation",
    "src/Doc/AbstractDoc.js~AbstractDoc#_$variation",
    "method"
  ],
  [
    "src/doc/abstractdoc.js~abstractdoc#_$version",
    "class/src/Doc/AbstractDoc.js~AbstractDoc.html#instance-method-_$version",
    "src/Doc/AbstractDoc.js~AbstractDoc#_$version",
    "method"
  ],
  [
    "src/doc/abstractdoc.js~abstractdoc#_apply",
    "class/src/Doc/AbstractDoc.js~AbstractDoc.html#instance-method-_apply",
    "src/Doc/AbstractDoc.js~AbstractDoc#_apply",
    "method"
  ],
  [
    "src/doc/abstractdoc.js~abstractdoc#_ast",
    "class/src/Doc/AbstractDoc.js~AbstractDoc.html#instance-member-_ast",
    "src/Doc/AbstractDoc.js~AbstractDoc#_ast",
    "member"
  ],
  [
    "src/doc/abstractdoc.js~abstractdoc#_commenttags",
    "class/src/Doc/AbstractDoc.js~AbstractDoc.html#instance-member-_commentTags",
    "src/Doc/AbstractDoc.js~AbstractDoc#_commentTags",
    "member"
  ],
  [
    "src/doc/abstractdoc.js~abstractdoc#_find",
    "class/src/Doc/AbstractDoc.js~AbstractDoc.html#instance-method-_find",
    "src/Doc/AbstractDoc.js~AbstractDoc#_find",
    "method"
  ],
  [
    "src/doc/abstractdoc.js~abstractdoc#_findall",
    "class/src/Doc/AbstractDoc.js~AbstractDoc.html#instance-method-_findAll",
    "src/Doc/AbstractDoc.js~AbstractDoc#_findAll",
    "method"
  ],
  [
    "src/doc/abstractdoc.js~abstractdoc#_findalltagvalues",
    "class/src/Doc/AbstractDoc.js~AbstractDoc.html#instance-method-_findAllTagValues",
    "src/Doc/AbstractDoc.js~AbstractDoc#_findAllTagValues",
    "method"
  ],
  [
    "src/doc/abstractdoc.js~abstractdoc#_findclasslongname",
    "class/src/Doc/AbstractDoc.js~AbstractDoc.html#instance-method-_findClassLongname",
    "src/Doc/AbstractDoc.js~AbstractDoc#_findClassLongname",
    "method"
  ],
  [
    "src/doc/abstractdoc.js~abstractdoc#_findtagvalue",
    "class/src/Doc/AbstractDoc.js~AbstractDoc.html#instance-method-_findTagValue",
    "src/Doc/AbstractDoc.js~AbstractDoc#_findTagValue",
    "method"
  ],
  [
    "src/doc/abstractdoc.js~abstractdoc#_flattenmemberexpression",
    "class/src/Doc/AbstractDoc.js~AbstractDoc.html#instance-method-_flattenMemberExpression",
    "src/Doc/AbstractDoc.js~AbstractDoc#_flattenMemberExpression",
    "method"
  ],
  [
    "src/doc/abstractdoc.js~abstractdoc#_node",
    "class/src/Doc/AbstractDoc.js~AbstractDoc.html#instance-member-_node",
    "src/Doc/AbstractDoc.js~AbstractDoc#_node",
    "member"
  ],
  [
    "src/doc/abstractdoc.js~abstractdoc#_pathresolver",
    "class/src/Doc/AbstractDoc.js~AbstractDoc.html#instance-member-_pathResolver",
    "src/Doc/AbstractDoc.js~AbstractDoc#_pathResolver",
    "member"
  ],
  [
    "src/doc/abstractdoc.js~abstractdoc#_resolvelongname",
    "class/src/Doc/AbstractDoc.js~AbstractDoc.html#instance-method-_resolveLongname",
    "src/Doc/AbstractDoc.js~AbstractDoc#_resolveLongname",
    "method"
  ],
  [
    "src/doc/abstractdoc.js~abstractdoc#_value",
    "class/src/Doc/AbstractDoc.js~AbstractDoc.html#instance-member-_value",
    "src/Doc/AbstractDoc.js~AbstractDoc#_value",
    "member"
  ],
  [
    "src/doc/abstractdoc.js~abstractdoc#constructor",
    "class/src/Doc/AbstractDoc.js~AbstractDoc.html#instance-constructor-constructor",
    "src/Doc/AbstractDoc.js~AbstractDoc#constructor",
    "method"
  ],
  [
    "src/doc/abstractdoc.js~abstractdoc#value",
    "class/src/Doc/AbstractDoc.js~AbstractDoc.html#instance-get-value",
    "src/Doc/AbstractDoc.js~AbstractDoc#value",
    "member"
  ],
  [
    "src/doc/assignmentdoc.js",
    "file/src/Doc/AssignmentDoc.js.html",
    "src/Doc/AssignmentDoc.js",
    "file"
  ],
  [
    "src/doc/assignmentdoc.js~assignmentdoc#_$kind",
    "class/src/Doc/AssignmentDoc.js~AssignmentDoc.html#instance-method-_$kind",
    "src/Doc/AssignmentDoc.js~AssignmentDoc#_$kind",
    "method"
  ],
  [
    "src/doc/assignmentdoc.js~assignmentdoc#_$memberof",
    "class/src/Doc/AssignmentDoc.js~AssignmentDoc.html#instance-method-_$memberof",
    "src/Doc/AssignmentDoc.js~AssignmentDoc#_$memberof",
    "method"
  ],
  [
    "src/doc/assignmentdoc.js~assignmentdoc#_$name",
    "class/src/Doc/AssignmentDoc.js~AssignmentDoc.html#instance-method-_$name",
    "src/Doc/AssignmentDoc.js~AssignmentDoc#_$name",
    "method"
  ],
  [
    "src/doc/classdoc.js",
    "file/src/Doc/ClassDoc.js.html",
    "src/Doc/ClassDoc.js",
    "file"
  ],
  [
    "src/doc/classdoc.js~classdoc#_$extends",
    "class/src/Doc/ClassDoc.js~ClassDoc.html#instance-method-_$extends",
    "src/Doc/ClassDoc.js~ClassDoc#_$extends",
    "method"
  ],
  [
    "src/doc/classdoc.js~classdoc#_$implements",
    "class/src/Doc/ClassDoc.js~ClassDoc.html#instance-method-_$implements",
    "src/Doc/ClassDoc.js~ClassDoc#_$implements",
    "method"
  ],
  [
    "src/doc/classdoc.js~classdoc#_$interface",
    "class/src/Doc/ClassDoc.js~ClassDoc.html#instance-method-_$interface",
    "src/Doc/ClassDoc.js~ClassDoc#_$interface",
    "method"
  ],
  [
    "src/doc/classdoc.js~classdoc#_$kind",
    "class/src/Doc/ClassDoc.js~ClassDoc.html#instance-method-_$kind",
    "src/Doc/ClassDoc.js~ClassDoc#_$kind",
    "method"
  ],
  [
    "src/doc/classdoc.js~classdoc#_$memberof",
    "class/src/Doc/ClassDoc.js~ClassDoc.html#instance-method-_$memberof",
    "src/Doc/ClassDoc.js~ClassDoc#_$memberof",
    "method"
  ],
  [
    "src/doc/classdoc.js~classdoc#_$name",
    "class/src/Doc/ClassDoc.js~ClassDoc.html#instance-method-_$name",
    "src/Doc/ClassDoc.js~ClassDoc#_$name",
    "method"
  ],
  [
    "src/doc/classdoc.js~classdoc#_apply",
    "class/src/Doc/ClassDoc.js~ClassDoc.html#instance-method-_apply",
    "src/Doc/ClassDoc.js~ClassDoc#_apply",
    "method"
  ],
  [
    "src/doc/classdoc.js~classdoc#_readselection",
    "class/src/Doc/ClassDoc.js~ClassDoc.html#instance-method-_readSelection",
    "src/Doc/ClassDoc.js~ClassDoc#_readSelection",
    "method"
  ],
  [
    "src/doc/classpropertydoc.js",
    "file/src/Doc/ClassPropertyDoc.js.html",
    "src/Doc/ClassPropertyDoc.js",
    "file"
  ],
  [
    "src/doc/classpropertydoc.js~classpropertydoc#_$kind",
    "class/src/Doc/ClassPropertyDoc.js~ClassPropertyDoc.html#instance-method-_$kind",
    "src/Doc/ClassPropertyDoc.js~ClassPropertyDoc#_$kind",
    "method"
  ],
  [
    "src/doc/classpropertydoc.js~classpropertydoc#_$memberof",
    "class/src/Doc/ClassPropertyDoc.js~ClassPropertyDoc.html#instance-method-_$memberof",
    "src/Doc/ClassPropertyDoc.js~ClassPropertyDoc#_$memberof",
    "method"
  ],
  [
    "src/doc/classpropertydoc.js~classpropertydoc#_$name",
    "class/src/Doc/ClassPropertyDoc.js~ClassPropertyDoc.html#instance-method-_$name",
    "src/Doc/ClassPropertyDoc.js~ClassPropertyDoc#_$name",
    "method"
  ],
  [
    "src/doc/classpropertydoc.js~classpropertydoc#_$type",
    "class/src/Doc/ClassPropertyDoc.js~ClassPropertyDoc.html#instance-method-_$type",
    "src/Doc/ClassPropertyDoc.js~ClassPropertyDoc#_$type",
    "method"
  ],
  [
    "src/doc/classpropertydoc.js~classpropertydoc#_apply",
    "class/src/Doc/ClassPropertyDoc.js~ClassPropertyDoc.html#instance-method-_apply",
    "src/Doc/ClassPropertyDoc.js~ClassPropertyDoc#_apply",
    "method"
  ],
  [
    "src/doc/externaldoc.js",
    "file/src/Doc/ExternalDoc.js.html",
    "src/Doc/ExternalDoc.js",
    "file"
  ],
  [
    "src/doc/externaldoc.js~externaldoc#_$external",
    "class/src/Doc/ExternalDoc.js~ExternalDoc.html#instance-method-_$external",
    "src/Doc/ExternalDoc.js~ExternalDoc#_$external",
    "method"
  ],
  [
    "src/doc/externaldoc.js~externaldoc#_$kind",
    "class/src/Doc/ExternalDoc.js~ExternalDoc.html#instance-method-_$kind",
    "src/Doc/ExternalDoc.js~ExternalDoc#_$kind",
    "method"
  ],
  [
    "src/doc/externaldoc.js~externaldoc#_$longname",
    "class/src/Doc/ExternalDoc.js~ExternalDoc.html#instance-method-_$longname",
    "src/Doc/ExternalDoc.js~ExternalDoc#_$longname",
    "method"
  ],
  [
    "src/doc/externaldoc.js~externaldoc#_$memberof",
    "class/src/Doc/ExternalDoc.js~ExternalDoc.html#instance-method-_$memberof",
    "src/Doc/ExternalDoc.js~ExternalDoc#_$memberof",
    "method"
  ],
  [
    "src/doc/externaldoc.js~externaldoc#_$name",
    "class/src/Doc/ExternalDoc.js~ExternalDoc.html#instance-method-_$name",
    "src/Doc/ExternalDoc.js~ExternalDoc#_$name",
    "method"
  ],
  [
    "src/doc/externaldoc.js~externaldoc#_apply",
    "class/src/Doc/ExternalDoc.js~ExternalDoc.html#instance-method-_apply",
    "src/Doc/ExternalDoc.js~ExternalDoc#_apply",
    "method"
  ],
  [
    "src/doc/filedoc.js",
    "file/src/Doc/FileDoc.js.html",
    "src/Doc/FileDoc.js",
    "file"
  ],
  [
    "src/doc/filedoc.js~filedoc#_$content",
    "class/src/Doc/FileDoc.js~FileDoc.html#instance-method-_$content",
    "src/Doc/FileDoc.js~FileDoc#_$content",
    "method"
  ],
  [
    "src/doc/filedoc.js~filedoc#_$kind",
    "class/src/Doc/FileDoc.js~FileDoc.html#instance-method-_$kind",
    "src/Doc/FileDoc.js~FileDoc#_$kind",
    "method"
  ],
  [
    "src/doc/filedoc.js~filedoc#_$longname",
    "class/src/Doc/FileDoc.js~FileDoc.html#instance-method-_$longname",
    "src/Doc/FileDoc.js~FileDoc#_$longname",
    "method"
  ],
  [
    "src/doc/filedoc.js~filedoc#_$name",
    "class/src/Doc/FileDoc.js~FileDoc.html#instance-method-_$name",
    "src/Doc/FileDoc.js~FileDoc#_$name",
    "method"
  ],
  [
    "src/doc/filedoc.js~filedoc#_apply",
    "class/src/Doc/FileDoc.js~FileDoc.html#instance-method-_apply",
    "src/Doc/FileDoc.js~FileDoc#_apply",
    "method"
  ],
  [
    "src/doc/functiondoc.js",
    "file/src/Doc/FunctionDoc.js.html",
    "src/Doc/FunctionDoc.js",
    "file"
  ],
  [
    "src/doc/functiondoc.js~functiondoc#_$async",
    "class/src/Doc/FunctionDoc.js~FunctionDoc.html#instance-method-_$async",
    "src/Doc/FunctionDoc.js~FunctionDoc#_$async",
    "method"
  ],
  [
    "src/doc/functiondoc.js~functiondoc#_$generator",
    "class/src/Doc/FunctionDoc.js~FunctionDoc.html#instance-method-_$generator",
    "src/Doc/FunctionDoc.js~FunctionDoc#_$generator",
    "method"
  ],
  [
    "src/doc/functiondoc.js~functiondoc#_$kind",
    "class/src/Doc/FunctionDoc.js~FunctionDoc.html#instance-method-_$kind",
    "src/Doc/FunctionDoc.js~FunctionDoc#_$kind",
    "method"
  ],
  [
    "src/doc/functiondoc.js~functiondoc#_$memberof",
    "class/src/Doc/FunctionDoc.js~FunctionDoc.html#instance-method-_$memberof",
    "src/Doc/FunctionDoc.js~FunctionDoc#_$memberof",
    "method"
  ],
  [
    "src/doc/functiondoc.js~functiondoc#_$name",
    "class/src/Doc/FunctionDoc.js~FunctionDoc.html#instance-method-_$name",
    "src/Doc/FunctionDoc.js~FunctionDoc#_$name",
    "method"
  ],
  [
    "src/doc/functiondoc.js~functiondoc#_$param",
    "class/src/Doc/FunctionDoc.js~FunctionDoc.html#instance-method-_$param",
    "src/Doc/FunctionDoc.js~FunctionDoc#_$param",
    "method"
  ],
  [
    "src/doc/functiondoc.js~functiondoc#_$return",
    "class/src/Doc/FunctionDoc.js~FunctionDoc.html#instance-method-_$return",
    "src/Doc/FunctionDoc.js~FunctionDoc#_$return",
    "method"
  ],
  [
    "src/doc/memberdoc.js",
    "file/src/Doc/MemberDoc.js.html",
    "src/Doc/MemberDoc.js",
    "file"
  ],
  [
    "src/doc/memberdoc.js~memberdoc#_$kind",
    "class/src/Doc/MemberDoc.js~MemberDoc.html#instance-method-_$kind",
    "src/Doc/MemberDoc.js~MemberDoc#_$kind",
    "method"
  ],
  [
    "src/doc/memberdoc.js~memberdoc#_$memberof",
    "class/src/Doc/MemberDoc.js~MemberDoc.html#instance-method-_$memberof",
    "src/Doc/MemberDoc.js~MemberDoc#_$memberof",
    "method"
  ],
  [
    "src/doc/memberdoc.js~memberdoc#_$name",
    "class/src/Doc/MemberDoc.js~MemberDoc.html#instance-method-_$name",
    "src/Doc/MemberDoc.js~MemberDoc#_$name",
    "method"
  ],
  [
    "src/doc/memberdoc.js~memberdoc#_$static",
    "class/src/Doc/MemberDoc.js~MemberDoc.html#instance-method-_$static",
    "src/Doc/MemberDoc.js~MemberDoc#_$static",
    "method"
  ],
  [
    "src/doc/memberdoc.js~memberdoc#_$type",
    "class/src/Doc/MemberDoc.js~MemberDoc.html#instance-method-_$type",
    "src/Doc/MemberDoc.js~MemberDoc#_$type",
    "method"
  ],
  [
    "src/doc/memberdoc.js~memberdoc#_apply",
    "class/src/Doc/MemberDoc.js~MemberDoc.html#instance-method-_apply",
    "src/Doc/MemberDoc.js~MemberDoc#_apply",
    "method"
  ],
  [
    "src/doc/memorydoc.js",
    "file/src/Doc/MemoryDoc.js.html",
    "src/Doc/MemoryDoc.js",
    "file"
  ],
  [
    "src/doc/memorydoc.js~memorydoc#_$content",
    "class/src/Doc/MemoryDoc.js~MemoryDoc.html#instance-method-_$content",
    "src/Doc/MemoryDoc.js~MemoryDoc#_$content",
    "method"
  ],
  [
    "src/doc/memorydoc.js~memorydoc#_$kind",
    "class/src/Doc/MemoryDoc.js~MemoryDoc.html#instance-method-_$kind",
    "src/Doc/MemoryDoc.js~MemoryDoc#_$kind",
    "method"
  ],
  [
    "src/doc/memorydoc.js~memorydoc#_$longname",
    "class/src/Doc/MemoryDoc.js~MemoryDoc.html#instance-method-_$longname",
    "src/Doc/MemoryDoc.js~MemoryDoc#_$longname",
    "method"
  ],
  [
    "src/doc/memorydoc.js~memorydoc#_$name",
    "class/src/Doc/MemoryDoc.js~MemoryDoc.html#instance-method-_$name",
    "src/Doc/MemoryDoc.js~MemoryDoc#_$name",
    "method"
  ],
  [
    "src/doc/memorydoc.js~memorydoc#_apply",
    "class/src/Doc/MemoryDoc.js~MemoryDoc.html#instance-method-_apply",
    "src/Doc/MemoryDoc.js~MemoryDoc#_apply",
    "method"
  ],
  [
    "src/doc/memorydoc.js~memorydoc#_memorycode",
    "class/src/Doc/MemoryDoc.js~MemoryDoc.html#instance-member-_memoryCode",
    "src/Doc/MemoryDoc.js~MemoryDoc#_memoryCode",
    "member"
  ],
  [
    "src/doc/memorydoc.js~memorydoc#constructor",
    "class/src/Doc/MemoryDoc.js~MemoryDoc.html#instance-constructor-constructor",
    "src/Doc/MemoryDoc.js~MemoryDoc#constructor",
    "method"
  ],
  [
    "src/doc/methoddoc.js",
    "file/src/Doc/MethodDoc.js.html",
    "src/Doc/MethodDoc.js",
    "file"
  ],
  [
    "src/doc/methoddoc.js~methoddoc#_$async",
    "class/src/Doc/MethodDoc.js~MethodDoc.html#instance-method-_$async",
    "src/Doc/MethodDoc.js~MethodDoc#_$async",
    "method"
  ],
  [
    "src/doc/methoddoc.js~methoddoc#_$generator",
    "class/src/Doc/MethodDoc.js~MethodDoc.html#instance-method-_$generator",
    "src/Doc/MethodDoc.js~MethodDoc#_$generator",
    "method"
  ],
  [
    "src/doc/methoddoc.js~methoddoc#_$kind",
    "class/src/Doc/MethodDoc.js~MethodDoc.html#instance-method-_$kind",
    "src/Doc/MethodDoc.js~MethodDoc#_$kind",
    "method"
  ],
  [
    "src/doc/methoddoc.js~methoddoc#_$memberof",
    "class/src/Doc/MethodDoc.js~MethodDoc.html#instance-method-_$memberof",
    "src/Doc/MethodDoc.js~MethodDoc#_$memberof",
    "method"
  ],
  [
    "src/doc/methoddoc.js~methoddoc#_$name",
    "class/src/Doc/MethodDoc.js~MethodDoc.html#instance-method-_$name",
    "src/Doc/MethodDoc.js~MethodDoc#_$name",
    "method"
  ],
  [
    "src/doc/methoddoc.js~methoddoc#_$param",
    "class/src/Doc/MethodDoc.js~MethodDoc.html#instance-method-_$param",
    "src/Doc/MethodDoc.js~MethodDoc#_$param",
    "method"
  ],
  [
    "src/doc/methoddoc.js~methoddoc#_$return",
    "class/src/Doc/MethodDoc.js~MethodDoc.html#instance-method-_$return",
    "src/Doc/MethodDoc.js~MethodDoc#_$return",
    "method"
  ],
  [
    "src/doc/methoddoc.js~methoddoc#_$type",
    "class/src/Doc/MethodDoc.js~MethodDoc.html#instance-method-_$type",
    "src/Doc/MethodDoc.js~MethodDoc#_$type",
    "method"
  ],
  [
    "src/doc/methoddoc.js~methoddoc#_apply",
    "class/src/Doc/MethodDoc.js~MethodDoc.html#instance-method-_apply",
    "src/Doc/MethodDoc.js~MethodDoc#_apply",
    "method"
  ],
  [
    "src/doc/testdoc.js",
    "file/src/Doc/TestDoc.js.html",
    "src/Doc/TestDoc.js",
    "file"
  ],
  [
    "src/doc/testdoc.js~testdoc#_$desc",
    "class/src/Doc/TestDoc.js~TestDoc.html#instance-method-_$desc",
    "src/Doc/TestDoc.js~TestDoc#_$desc",
    "method"
  ],
  [
    "src/doc/testdoc.js~testdoc#_$kind",
    "class/src/Doc/TestDoc.js~TestDoc.html#instance-method-_$kind",
    "src/Doc/TestDoc.js~TestDoc#_$kind",
    "method"
  ],
  [
    "src/doc/testdoc.js~testdoc#_$memberof",
    "class/src/Doc/TestDoc.js~TestDoc.html#instance-method-_$memberof",
    "src/Doc/TestDoc.js~TestDoc#_$memberof",
    "method"
  ],
  [
    "src/doc/testdoc.js~testdoc#_$name",
    "class/src/Doc/TestDoc.js~TestDoc.html#instance-method-_$name",
    "src/Doc/TestDoc.js~TestDoc#_$name",
    "method"
  ],
  [
    "src/doc/testdoc.js~testdoc#_$testtarget",
    "class/src/Doc/TestDoc.js~TestDoc.html#instance-method-_$testTarget",
    "src/Doc/TestDoc.js~TestDoc#_$testTarget",
    "method"
  ],
  [
    "src/doc/testdoc.js~testdoc#_apply",
    "class/src/Doc/TestDoc.js~TestDoc.html#instance-method-_apply",
    "src/Doc/TestDoc.js~TestDoc#_apply",
    "method"
  ],
  [
    "src/doc/testfiledoc.js",
    "file/src/Doc/TestFileDoc.js.html",
    "src/Doc/TestFileDoc.js",
    "file"
  ],
  [
    "src/doc/testfiledoc.js~testfiledoc#_$kind",
    "class/src/Doc/TestFileDoc.js~TestFileDoc.html#instance-method-_$kind",
    "src/Doc/TestFileDoc.js~TestFileDoc#_$kind",
    "method"
  ],
  [
    "src/doc/typedefdoc.js",
    "file/src/Doc/TypedefDoc.js.html",
    "src/Doc/TypedefDoc.js",
    "file"
  ],
  [
    "src/doc/typedefdoc.js~typedefdoc#_$kind",
    "class/src/Doc/TypedefDoc.js~TypedefDoc.html#instance-method-_$kind",
    "src/Doc/TypedefDoc.js~TypedefDoc#_$kind",
    "method"
  ],
  [
    "src/doc/typedefdoc.js~typedefdoc#_$memberof",
    "class/src/Doc/TypedefDoc.js~TypedefDoc.html#instance-method-_$memberof",
    "src/Doc/TypedefDoc.js~TypedefDoc#_$memberof",
    "method"
  ],
  [
    "src/doc/typedefdoc.js~typedefdoc#_$name",
    "class/src/Doc/TypedefDoc.js~TypedefDoc.html#instance-method-_$name",
    "src/Doc/TypedefDoc.js~TypedefDoc#_$name",
    "method"
  ],
  [
    "src/doc/typedefdoc.js~typedefdoc#_$typedef",
    "class/src/Doc/TypedefDoc.js~TypedefDoc.html#instance-method-_$typedef",
    "src/Doc/TypedefDoc.js~TypedefDoc#_$typedef",
    "method"
  ],
  [
    "src/doc/typedefdoc.js~typedefdoc#_apply",
    "class/src/Doc/TypedefDoc.js~TypedefDoc.html#instance-method-_apply",
    "src/Doc/TypedefDoc.js~TypedefDoc#_apply",
    "method"
  ],
  [
    "src/doc/variabledoc.js",
    "file/src/Doc/VariableDoc.js.html",
    "src/Doc/VariableDoc.js",
    "file"
  ],
  [
    "src/doc/variabledoc.js~variabledoc#_$kind",
    "class/src/Doc/VariableDoc.js~VariableDoc.html#instance-method-_$kind",
    "src/Doc/VariableDoc.js~VariableDoc#_$kind",
    "method"
  ],
  [
    "src/doc/variabledoc.js~variabledoc#_$memberof",
    "class/src/Doc/VariableDoc.js~VariableDoc.html#instance-method-_$memberof",
    "src/Doc/VariableDoc.js~VariableDoc#_$memberof",
    "method"
  ],
  [
    "src/doc/variabledoc.js~variabledoc#_$name",
    "class/src/Doc/VariableDoc.js~VariableDoc.html#instance-method-_$name",
    "src/Doc/VariableDoc.js~VariableDoc#_$name",
    "method"
  ],
  [
    "src/doc/variabledoc.js~variabledoc#_$type",
    "class/src/Doc/VariableDoc.js~VariableDoc.html#instance-method-_$type",
    "src/Doc/VariableDoc.js~VariableDoc#_$type",
    "method"
  ],
  [
    "src/doctest/linttest.js",
    "test-file/src/DocTest/LintTest.js.html",
    "src/DocTest/LintTest.js",
    "testFile"
  ],
  [
    "src/doctest/searchtest.js",
    "test-file/src/DocTest/SearchTest.js.html",
    "src/DocTest/SearchTest.js",
    "testFile"
  ],
  [
    "src/doctest/undocumenttest.js",
    "test-file/src/DocTest/UndocumentTest.js.html",
    "src/DocTest/UndocumentTest.js",
    "testFile"
  ],
  [
    "src/doctest/unknowntest.js",
    "test-file/src/DocTest/UnknownTest.js.html",
    "src/DocTest/UnknownTest.js",
    "testFile"
  ],
  [
    "src/esdoc.js",
    "file/src/ESDoc.js.html",
    "src/ESDoc.js",
    "file"
  ],
  [
    "src/esdoc.js~esdoc._generatefortest",
    "class/src/ESDoc.js~ESDoc.html#static-method-_generateForTest",
    "src/ESDoc.js~ESDoc._generateForTest",
    "method"
  ],
  [
    "src/esdoc.js~esdoc._setdefaultconfig",
    "class/src/ESDoc.js~ESDoc.html#static-method-_setDefaultConfig",
    "src/ESDoc.js~ESDoc._setDefaultConfig",
    "method"
  ],
  [
    "src/esdoc.js~esdoc._traversecode",
    "class/src/ESDoc.js~ESDoc.html#static-method-_traverseCode",
    "src/ESDoc.js~ESDoc._traverseCode",
    "method"
  ],
  [
    "src/esdoc.js~esdoc._traversefile",
    "class/src/ESDoc.js~ESDoc.html#static-method-_traverseFile",
    "src/ESDoc.js~ESDoc._traverseFile",
    "method"
  ],
  [
    "src/esdoc.js~esdoc._traversefortest",
    "class/src/ESDoc.js~ESDoc.html#static-method-_traverseForTest",
    "src/ESDoc.js~ESDoc._traverseForTest",
    "method"
  ],
  [
    "src/esdoc.js~esdoc._walk",
    "class/src/ESDoc.js~ESDoc.html#static-method-_walk",
    "src/ESDoc.js~ESDoc._walk",
    "method"
  ],
  [
    "src/esdoc.js~esdoc.generate",
    "class/src/ESDoc.js~ESDoc.html#static-method-generate",
    "src/ESDoc.js~ESDoc.generate",
    "method"
  ],
  [
    "src/esdoccli.js",
    "file/src/ESDocCLI.js.html",
    "src/ESDocCLI.js",
    "file"
  ],
  [
    "src/esdoccli.js~esdoccli#_argv",
    "class/src/ESDocCLI.js~ESDocCLI.html#instance-member-_argv",
    "src/ESDocCLI.js~ESDocCLI#_argv",
    "member"
  ],
  [
    "src/esdoccli.js~esdoccli#_createconfigfromjsonfile",
    "class/src/ESDocCLI.js~ESDocCLI.html#instance-method-_createConfigFromJSONFile",
    "src/ESDocCLI.js~ESDocCLI#_createConfigFromJSONFile",
    "method"
  ],
  [
    "src/esdoccli.js~esdoccli#_createconfigfrompackagejson",
    "class/src/ESDocCLI.js~ESDocCLI.html#instance-method-_createConfigFromPackageJSON",
    "src/ESDocCLI.js~ESDocCLI#_createConfigFromPackageJSON",
    "method"
  ],
  [
    "src/esdoccli.js~esdoccli#_findconfigfilepath",
    "class/src/ESDocCLI.js~ESDocCLI.html#instance-method-_findConfigFilePath",
    "src/ESDocCLI.js~ESDocCLI#_findConfigFilePath",
    "method"
  ],
  [
    "src/esdoccli.js~esdoccli#_showhelp",
    "class/src/ESDocCLI.js~ESDocCLI.html#instance-method-_showHelp",
    "src/ESDocCLI.js~ESDocCLI#_showHelp",
    "method"
  ],
  [
    "src/esdoccli.js~esdoccli#_showversion",
    "class/src/ESDocCLI.js~ESDocCLI.html#instance-method-_showVersion",
    "src/ESDocCLI.js~ESDocCLI#_showVersion",
    "method"
  ],
  [
    "src/esdoccli.js~esdoccli#constructor",
    "class/src/ESDocCLI.js~ESDocCLI.html#instance-constructor-constructor",
    "src/ESDocCLI.js~ESDocCLI#constructor",
    "method"
  ],
  [
    "src/esdoccli.js~esdoccli#exec",
    "class/src/ESDocCLI.js~ESDocCLI.html#instance-method-exec",
    "src/ESDocCLI.js~ESDocCLI#exec",
    "method"
  ],
  [
    "src/factory/docfactory.js",
    "file/src/Factory/DocFactory.js.html",
    "src/Factory/DocFactory.js",
    "file"
  ],
  [
    "src/factory/docfactory.js~docfactory#_ast",
    "class/src/Factory/DocFactory.js~DocFactory.html#instance-member-_ast",
    "src/Factory/DocFactory.js~DocFactory#_ast",
    "member"
  ],
  [
    "src/factory/docfactory.js~docfactory#_copy",
    "class/src/Factory/DocFactory.js~DocFactory.html#instance-method-_copy",
    "src/Factory/DocFactory.js~DocFactory#_copy",
    "method"
  ],
  [
    "src/factory/docfactory.js~docfactory#_createdoc",
    "class/src/Factory/DocFactory.js~DocFactory.html#instance-method-_createDoc",
    "src/Factory/DocFactory.js~DocFactory#_createDoc",
    "method"
  ],
  [
    "src/factory/docfactory.js~docfactory#_decidearrowfunctionexpressiontype",
    "class/src/Factory/DocFactory.js~DocFactory.html#instance-method-_decideArrowFunctionExpressionType",
    "src/Factory/DocFactory.js~DocFactory#_decideArrowFunctionExpressionType",
    "method"
  ],
  [
    "src/factory/docfactory.js~docfactory#_decideassignmenttype",
    "class/src/Factory/DocFactory.js~DocFactory.html#instance-method-_decideAssignmentType",
    "src/Factory/DocFactory.js~DocFactory#_decideAssignmentType",
    "method"
  ],
  [
    "src/factory/docfactory.js~docfactory#_decideclassdeclarationtype",
    "class/src/Factory/DocFactory.js~DocFactory.html#instance-method-_decideClassDeclarationType",
    "src/Factory/DocFactory.js~DocFactory#_decideClassDeclarationType",
    "method"
  ],
  [
    "src/factory/docfactory.js~docfactory#_decideclasspropertytype",
    "class/src/Factory/DocFactory.js~DocFactory.html#instance-method-_decideClassPropertyType",
    "src/Factory/DocFactory.js~DocFactory#_decideClassPropertyType",
    "method"
  ],
  [
    "src/factory/docfactory.js~docfactory#_decideexpressionstatementtype",
    "class/src/Factory/DocFactory.js~DocFactory.html#instance-method-_decideExpressionStatementType",
    "src/Factory/DocFactory.js~DocFactory#_decideExpressionStatementType",
    "method"
  ],
  [
    "src/factory/docfactory.js~docfactory#_decidefunctiondeclarationtype",
    "class/src/Factory/DocFactory.js~DocFactory.html#instance-method-_decideFunctionDeclarationType",
    "src/Factory/DocFactory.js~DocFactory#_decideFunctionDeclarationType",
    "method"
  ],
  [
    "src/factory/docfactory.js~docfactory#_decidefunctionexpressiontype",
    "class/src/Factory/DocFactory.js~DocFactory.html#instance-method-_decideFunctionExpressionType",
    "src/Factory/DocFactory.js~DocFactory#_decideFunctionExpressionType",
    "method"
  ],
  [
    "src/factory/docfactory.js~docfactory#_decidemethoddefinitiontype",
    "class/src/Factory/DocFactory.js~DocFactory.html#instance-method-_decideMethodDefinitionType",
    "src/Factory/DocFactory.js~DocFactory#_decideMethodDefinitionType",
    "method"
  ],
  [
    "src/factory/docfactory.js~docfactory#_decidetype",
    "class/src/Factory/DocFactory.js~DocFactory.html#instance-method-_decideType",
    "src/Factory/DocFactory.js~DocFactory#_decideType",
    "method"
  ],
  [
    "src/factory/docfactory.js~docfactory#_decidevariabletype",
    "class/src/Factory/DocFactory.js~DocFactory.html#instance-method-_decideVariableType",
    "src/Factory/DocFactory.js~DocFactory#_decideVariableType",
    "method"
  ],
  [
    "src/factory/docfactory.js~docfactory#_findup",
    "class/src/Factory/DocFactory.js~DocFactory.html#instance-method-_findUp",
    "src/Factory/DocFactory.js~DocFactory#_findUp",
    "method"
  ],
  [
    "src/factory/docfactory.js~docfactory#_inspectexportdefaultdeclaration",
    "class/src/Factory/DocFactory.js~DocFactory.html#instance-method-_inspectExportDefaultDeclaration",
    "src/Factory/DocFactory.js~DocFactory#_inspectExportDefaultDeclaration",
    "method"
  ],
  [
    "src/factory/docfactory.js~docfactory#_inspectexportnameddeclaration",
    "class/src/Factory/DocFactory.js~DocFactory.html#instance-method-_inspectExportNamedDeclaration",
    "src/Factory/DocFactory.js~DocFactory#_inspectExportNamedDeclaration",
    "method"
  ],
  [
    "src/factory/docfactory.js~docfactory#_islastnodeinparent",
    "class/src/Factory/DocFactory.js~DocFactory.html#instance-method-_isLastNodeInParent",
    "src/Factory/DocFactory.js~DocFactory#_isLastNodeInParent",
    "method"
  ],
  [
    "src/factory/docfactory.js~docfactory#_istopdepthinbody",
    "class/src/Factory/DocFactory.js~DocFactory.html#instance-method-_isTopDepthInBody",
    "src/Factory/DocFactory.js~DocFactory#_isTopDepthInBody",
    "method"
  ],
  [
    "src/factory/docfactory.js~docfactory#_pathresolver",
    "class/src/Factory/DocFactory.js~DocFactory.html#instance-member-_pathResolver",
    "src/Factory/DocFactory.js~DocFactory#_pathResolver",
    "member"
  ],
  [
    "src/factory/docfactory.js~docfactory#_processedclassnodes",
    "class/src/Factory/DocFactory.js~DocFactory.html#instance-member-_processedClassNodes",
    "src/Factory/DocFactory.js~DocFactory#_processedClassNodes",
    "member"
  ],
  [
    "src/factory/docfactory.js~docfactory#_results",
    "class/src/Factory/DocFactory.js~DocFactory.html#instance-member-_results",
    "src/Factory/DocFactory.js~DocFactory#_results",
    "member"
  ],
  [
    "src/factory/docfactory.js~docfactory#_traversecomments",
    "class/src/Factory/DocFactory.js~DocFactory.html#instance-method-_traverseComments",
    "src/Factory/DocFactory.js~DocFactory#_traverseComments",
    "method"
  ],
  [
    "src/factory/docfactory.js~docfactory#_unwrapexportdeclaration",
    "class/src/Factory/DocFactory.js~DocFactory.html#instance-method-_unwrapExportDeclaration",
    "src/Factory/DocFactory.js~DocFactory#_unwrapExportDeclaration",
    "method"
  ],
  [
    "src/factory/docfactory.js~docfactory#constructor",
    "class/src/Factory/DocFactory.js~DocFactory.html#instance-constructor-constructor",
    "src/Factory/DocFactory.js~DocFactory#constructor",
    "method"
  ],
  [
    "src/factory/docfactory.js~docfactory#push",
    "class/src/Factory/DocFactory.js~DocFactory.html#instance-method-push",
    "src/Factory/DocFactory.js~DocFactory#push",
    "method"
  ],
  [
    "src/factory/docfactory.js~docfactory#results",
    "class/src/Factory/DocFactory.js~DocFactory.html#instance-get-results",
    "src/Factory/DocFactory.js~DocFactory#results",
    "member"
  ],
  [
    "src/factory/testdocfactory.js",
    "file/src/Factory/TestDocFactory.js.html",
    "src/Factory/TestDocFactory.js",
    "file"
  ],
  [
    "src/factory/testdocfactory.js~testdocfactory#_ast",
    "class/src/Factory/TestDocFactory.js~TestDocFactory.html#instance-member-_ast",
    "src/Factory/TestDocFactory.js~TestDocFactory#_ast",
    "member"
  ],
  [
    "src/factory/testdocfactory.js~testdocfactory#_pathresolver",
    "class/src/Factory/TestDocFactory.js~TestDocFactory.html#instance-member-_pathResolver",
    "src/Factory/TestDocFactory.js~TestDocFactory#_pathResolver",
    "member"
  ],
  [
    "src/factory/testdocfactory.js~testdocfactory#_pushformocha",
    "class/src/Factory/TestDocFactory.js~TestDocFactory.html#instance-method-_pushForMocha",
    "src/Factory/TestDocFactory.js~TestDocFactory#_pushForMocha",
    "method"
  ],
  [
    "src/factory/testdocfactory.js~testdocfactory#_results",
    "class/src/Factory/TestDocFactory.js~TestDocFactory.html#instance-member-_results",
    "src/Factory/TestDocFactory.js~TestDocFactory#_results",
    "member"
  ],
  [
    "src/factory/testdocfactory.js~testdocfactory#_type",
    "class/src/Factory/TestDocFactory.js~TestDocFactory.html#instance-member-_type",
    "src/Factory/TestDocFactory.js~TestDocFactory#_type",
    "member"
  ],
  [
    "src/factory/testdocfactory.js~testdocfactory#constructor",
    "class/src/Factory/TestDocFactory.js~TestDocFactory.html#instance-constructor-constructor",
    "src/Factory/TestDocFactory.js~TestDocFactory#constructor",
    "method"
  ],
  [
    "src/factory/testdocfactory.js~testdocfactory#push",
    "class/src/Factory/TestDocFactory.js~TestDocFactory.html#instance-method-push",
    "src/Factory/TestDocFactory.js~TestDocFactory#push",
    "method"
  ],
  [
    "src/factory/testdocfactory.js~testdocfactory#results",
    "class/src/Factory/TestDocFactory.js~TestDocFactory.html#instance-get-results",
    "src/Factory/TestDocFactory.js~TestDocFactory#results",
    "member"
  ],
  [
    "src/factory/testdocfactory.js~testdocfactory._getuniqueid",
    "class/src/Factory/TestDocFactory.js~TestDocFactory.html#static-method-_getUniqueId",
    "src/Factory/TestDocFactory.js~TestDocFactory._getUniqueId",
    "method"
  ],
  [
    "src/factory/testdocfactory.js~testdocfactory._sequence",
    "class/src/Factory/TestDocFactory.js~TestDocFactory.html#static-member-_sequence",
    "src/Factory/TestDocFactory.js~TestDocFactory._sequence",
    "member"
  ],
  [
    "src/htmltest/coveragetest/coveragetest.js",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html",
    "src/HTMLTest/CoverageTest/CoverageTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/abstracttest/definitiontest.js",
    "test-file/src/HTMLTest/DocumentTest/AbstractTest/DefinitionTest.js.html",
    "src/HTMLTest/DocumentTest/AbstractTest/DefinitionTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/abstracttest/overridetest.js",
    "test-file/src/HTMLTest/DocumentTest/AbstractTest/OverrideTest.js.html",
    "src/HTMLTest/DocumentTest/AbstractTest/OverrideTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/accesstest/classtest.js",
    "test-file/src/HTMLTest/DocumentTest/AccessTest/ClassTest.js.html",
    "src/HTMLTest/DocumentTest/AccessTest/ClassTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/accesstest/functiontest.js",
    "test-file/src/HTMLTest/DocumentTest/AccessTest/FunctionTest.js.html",
    "src/HTMLTest/DocumentTest/AccessTest/FunctionTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/accesstest/methodtest.js",
    "test-file/src/HTMLTest/DocumentTest/AccessTest/MethodTest.js.html",
    "src/HTMLTest/DocumentTest/AccessTest/MethodTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/accesstest/propertytest.js",
    "test-file/src/HTMLTest/DocumentTest/AccessTest/PropertyTest.js.html",
    "src/HTMLTest/DocumentTest/AccessTest/PropertyTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/accesstest/variabletest.js",
    "test-file/src/HTMLTest/DocumentTest/AccessTest/VariableTest.js.html",
    "src/HTMLTest/DocumentTest/AccessTest/VariableTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/asynctest/functiontest.js",
    "test-file/src/HTMLTest/DocumentTest/AsyncTest/FunctionTest.js.html",
    "src/HTMLTest/DocumentTest/AsyncTest/FunctionTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/asynctest/methodtest.js",
    "test-file/src/HTMLTest/DocumentTest/AsyncTest/MethodTest.js.html",
    "src/HTMLTest/DocumentTest/AsyncTest/MethodTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/classpropertytest/definitiontest.js",
    "test-file/src/HTMLTest/DocumentTest/ClassPropertyTest/DefinitionTest.js.html",
    "src/HTMLTest/DocumentTest/ClassPropertyTest/DefinitionTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/classtest/definitiontest.js",
    "test-file/src/HTMLTest/DocumentTest/ClassTest/DefinitionTest.js.html",
    "src/HTMLTest/DocumentTest/ClassTest/DefinitionTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/computedtest/methodtest.js",
    "test-file/src/HTMLTest/DocumentTest/ComputedTest/MethodTest.js.html",
    "src/HTMLTest/DocumentTest/ComputedTest/MethodTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/computedtest/propertytest.js",
    "test-file/src/HTMLTest/DocumentTest/ComputedTest/PropertyTest.js.html",
    "src/HTMLTest/DocumentTest/ComputedTest/PropertyTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/decoratortest/definitiontest.js",
    "test-file/src/HTMLTest/DocumentTest/DecoratorTest/DefinitionTest.js.html",
    "src/HTMLTest/DocumentTest/DecoratorTest/DefinitionTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/deprecatedtest/classtest.js",
    "test-file/src/HTMLTest/DocumentTest/DeprecatedTest/ClassTest.js.html",
    "src/HTMLTest/DocumentTest/DeprecatedTest/ClassTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/deprecatedtest/functiontest.js",
    "test-file/src/HTMLTest/DocumentTest/DeprecatedTest/FunctionTest.js.html",
    "src/HTMLTest/DocumentTest/DeprecatedTest/FunctionTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/deprecatedtest/variabletest.js",
    "test-file/src/HTMLTest/DocumentTest/DeprecatedTest/VariableTest.js.html",
    "src/HTMLTest/DocumentTest/DeprecatedTest/VariableTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/desctest/classtest.js",
    "test-file/src/HTMLTest/DocumentTest/DescTest/ClassTest.js.html",
    "src/HTMLTest/DocumentTest/DescTest/ClassTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/desctest/functiontest.js",
    "test-file/src/HTMLTest/DocumentTest/DescTest/FunctionTest.js.html",
    "src/HTMLTest/DocumentTest/DescTest/FunctionTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/desctest/markdowntest.js",
    "test-file/src/HTMLTest/DocumentTest/DescTest/MarkdownTest.js.html",
    "src/HTMLTest/DocumentTest/DescTest/MarkdownTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/desctest/multilinetest.js",
    "test-file/src/HTMLTest/DocumentTest/DescTest/MultiLineTest.js.html",
    "src/HTMLTest/DocumentTest/DescTest/MultiLineTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/desctest/variabletest.js",
    "test-file/src/HTMLTest/DocumentTest/DescTest/VariableTest.js.html",
    "src/HTMLTest/DocumentTest/DescTest/VariableTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/destructuringtest/arraytest.js",
    "test-file/src/HTMLTest/DocumentTest/DestructuringTest/ArrayTest.js.html",
    "src/HTMLTest/DocumentTest/DestructuringTest/ArrayTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/destructuringtest/objecttest.js",
    "test-file/src/HTMLTest/DocumentTest/DestructuringTest/ObjectTest.js.html",
    "src/HTMLTest/DocumentTest/DestructuringTest/ObjectTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/duplicationtest/definitiontest.js",
    "test-file/src/HTMLTest/DocumentTest/DuplicationTest/DefinitionTest.js.html",
    "src/HTMLTest/DocumentTest/DuplicationTest/DefinitionTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/emitstest/functiontest.js",
    "test-file/src/HTMLTest/DocumentTest/EmitsTest/FunctionTest.js.html",
    "src/HTMLTest/DocumentTest/EmitsTest/FunctionTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/emitstest/methodtest.js",
    "test-file/src/HTMLTest/DocumentTest/EmitsTest/MethodTest.js.html",
    "src/HTMLTest/DocumentTest/EmitsTest/MethodTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/examletest/captiontest.js",
    "test-file/src/HTMLTest/DocumentTest/ExamleTest/CaptionTest.js.html",
    "src/HTMLTest/DocumentTest/ExamleTest/CaptionTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/examletest/classtest.js",
    "test-file/src/HTMLTest/DocumentTest/ExamleTest/ClassTest.js.html",
    "src/HTMLTest/DocumentTest/ExamleTest/ClassTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/examletest/functiontest.js",
    "test-file/src/HTMLTest/DocumentTest/ExamleTest/FunctionTest.js.html",
    "src/HTMLTest/DocumentTest/ExamleTest/FunctionTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/examletest/variabletest.js",
    "test-file/src/HTMLTest/DocumentTest/ExamleTest/VariableTest.js.html",
    "src/HTMLTest/DocumentTest/ExamleTest/VariableTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/experimentaltest/classtest.js",
    "test-file/src/HTMLTest/DocumentTest/ExperimentalTest/ClassTest.js.html",
    "src/HTMLTest/DocumentTest/ExperimentalTest/ClassTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/experimentaltest/functiontest.js",
    "test-file/src/HTMLTest/DocumentTest/ExperimentalTest/FunctionTest.js.html",
    "src/HTMLTest/DocumentTest/ExperimentalTest/FunctionTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/experimentaltest/variabletest.js",
    "test-file/src/HTMLTest/DocumentTest/ExperimentalTest/VariableTest.js.html",
    "src/HTMLTest/DocumentTest/ExperimentalTest/VariableTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/exponentialoperatortest/definitiontest.js",
    "test-file/src/HTMLTest/DocumentTest/ExponentialOperatorTest/DefinitionTest.js.html",
    "src/HTMLTest/DocumentTest/ExponentialOperatorTest/DefinitionTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/exporttest/anonymousclasstest.js",
    "test-file/src/HTMLTest/DocumentTest/ExportTest/AnonymousClassTest.js.html",
    "src/HTMLTest/DocumentTest/ExportTest/AnonymousClassTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/exporttest/anonymousfunctiontest.js",
    "test-file/src/HTMLTest/DocumentTest/ExportTest/AnonymousFunctionTest.js.html",
    "src/HTMLTest/DocumentTest/ExportTest/AnonymousFunctionTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/exporttest/arrowfunctiontest.js",
    "test-file/src/HTMLTest/DocumentTest/ExportTest/ArrowFunctionTest.js.html",
    "src/HTMLTest/DocumentTest/ExportTest/ArrowFunctionTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/exporttest/classindirectdefaulttest.js",
    "test-file/src/HTMLTest/DocumentTest/ExportTest/ClassIndirectDefaultTest.js.html",
    "src/HTMLTest/DocumentTest/ExportTest/ClassIndirectDefaultTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/exporttest/classtest.js",
    "test-file/src/HTMLTest/DocumentTest/ExportTest/ClassTest.js.html",
    "src/HTMLTest/DocumentTest/ExportTest/ClassTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/exporttest/defaulttest.js",
    "test-file/src/HTMLTest/DocumentTest/ExportTest/DefaultTest.js.html",
    "src/HTMLTest/DocumentTest/ExportTest/DefaultTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/exporttest/extendtest.js",
    "test-file/src/HTMLTest/DocumentTest/ExportTest/ExtendTest.js.html",
    "src/HTMLTest/DocumentTest/ExportTest/ExtendTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/exporttest/functionindirectdefaulttest.js",
    "test-file/src/HTMLTest/DocumentTest/ExportTest/FunctionIndirectDefaultTest.js.html",
    "src/HTMLTest/DocumentTest/ExportTest/FunctionIndirectDefaultTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/exporttest/functiontest.js",
    "test-file/src/HTMLTest/DocumentTest/ExportTest/FunctionTest.js.html",
    "src/HTMLTest/DocumentTest/ExportTest/FunctionTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/exporttest/multipletest.js",
    "test-file/src/HTMLTest/DocumentTest/ExportTest/MultipleTest.js.html",
    "src/HTMLTest/DocumentTest/ExportTest/MultipleTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/exporttest/namedtest.js",
    "test-file/src/HTMLTest/DocumentTest/ExportTest/NamedTest.js.html",
    "src/HTMLTest/DocumentTest/ExportTest/NamedTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/exporttest/newexpressionindirecttest.js",
    "test-file/src/HTMLTest/DocumentTest/ExportTest/NewExpressionIndirectTest.js.html",
    "src/HTMLTest/DocumentTest/ExportTest/NewExpressionIndirectTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/exporttest/newexpressionpropertytest.js",
    "test-file/src/HTMLTest/DocumentTest/ExportTest/NewExpressionPropertyTest.js.html",
    "src/HTMLTest/DocumentTest/ExportTest/NewExpressionPropertyTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/exporttest/newexpressiontest.js",
    "test-file/src/HTMLTest/DocumentTest/ExportTest/NewExpressionTest.js.html",
    "src/HTMLTest/DocumentTest/ExportTest/NewExpressionTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/exporttest/variableindirectdefaulttest.js",
    "test-file/src/HTMLTest/DocumentTest/ExportTest/VariableIndirectDefaultTest.js.html",
    "src/HTMLTest/DocumentTest/ExportTest/VariableIndirectDefaultTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/exporttest/variabletest.js",
    "test-file/src/HTMLTest/DocumentTest/ExportTest/VariableTest.js.html",
    "src/HTMLTest/DocumentTest/ExportTest/VariableTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/extendstest/builtintest.js",
    "test-file/src/HTMLTest/DocumentTest/ExtendsTest/BuiltinTest.js.html",
    "src/HTMLTest/DocumentTest/ExtendsTest/BuiltinTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/extendstest/deeptest.js",
    "test-file/src/HTMLTest/DocumentTest/ExtendsTest/DeepTest.js.html",
    "src/HTMLTest/DocumentTest/ExtendsTest/DeepTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/extendstest/expressiontest.js",
    "test-file/src/HTMLTest/DocumentTest/ExtendsTest/ExpressionTest.js.html",
    "src/HTMLTest/DocumentTest/ExtendsTest/ExpressionTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/extendstest/innertest.js",
    "test-file/src/HTMLTest/DocumentTest/ExtendsTest/InnerTest.js.html",
    "src/HTMLTest/DocumentTest/ExtendsTest/InnerTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/extendstest/mixintest.js",
    "test-file/src/HTMLTest/DocumentTest/ExtendsTest/MixinTest.js.html",
    "src/HTMLTest/DocumentTest/ExtendsTest/MixinTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/extendstest/outertest.js",
    "test-file/src/HTMLTest/DocumentTest/ExtendsTest/OuterTest.js.html",
    "src/HTMLTest/DocumentTest/ExtendsTest/OuterTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/extendstest/propertytest.js",
    "test-file/src/HTMLTest/DocumentTest/ExtendsTest/PropertyTest.js.html",
    "src/HTMLTest/DocumentTest/ExtendsTest/PropertyTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/externaltest/definitiontest.js",
    "test-file/src/HTMLTest/DocumentTest/ExternalTest/DefinitionTest.js.html",
    "src/HTMLTest/DocumentTest/ExternalTest/DefinitionTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/generatortest/functiontest.js",
    "test-file/src/HTMLTest/DocumentTest/GeneratorTest/FunctionTest.js.html",
    "src/HTMLTest/DocumentTest/GeneratorTest/FunctionTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/generatortest/methodtest.js",
    "test-file/src/HTMLTest/DocumentTest/GeneratorTest/MethodTest.js.html",
    "src/HTMLTest/DocumentTest/GeneratorTest/MethodTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/guesstest/paramtest.js",
    "test-file/src/HTMLTest/DocumentTest/GuessTest/ParamTest.js.html",
    "src/HTMLTest/DocumentTest/GuessTest/ParamTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/guesstest/propertytest.js",
    "test-file/src/HTMLTest/DocumentTest/GuessTest/PropertyTest.js.html",
    "src/HTMLTest/DocumentTest/GuessTest/PropertyTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/guesstest/returntest.js",
    "test-file/src/HTMLTest/DocumentTest/GuessTest/ReturnTest.js.html",
    "src/HTMLTest/DocumentTest/GuessTest/ReturnTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/guesstest/variabletest.js",
    "test-file/src/HTMLTest/DocumentTest/GuessTest/VariableTest.js.html",
    "src/HTMLTest/DocumentTest/GuessTest/VariableTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/ignoretest/classtest.js",
    "test-file/src/HTMLTest/DocumentTest/IgnoreTest/ClassTest.js.html",
    "src/HTMLTest/DocumentTest/IgnoreTest/ClassTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/ignoretest/functiontest.js",
    "test-file/src/HTMLTest/DocumentTest/IgnoreTest/FunctionTest.js.html",
    "src/HTMLTest/DocumentTest/IgnoreTest/FunctionTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/ignoretest/variabletest.js",
    "test-file/src/HTMLTest/DocumentTest/IgnoreTest/VariableTest.js.html",
    "src/HTMLTest/DocumentTest/IgnoreTest/VariableTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/interfacetest/definitiontest.js",
    "test-file/src/HTMLTest/DocumentTest/InterfaceTest/DefinitionTest.js.html",
    "src/HTMLTest/DocumentTest/InterfaceTest/DefinitionTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/interfacetest/implementstest.js",
    "test-file/src/HTMLTest/DocumentTest/InterfaceTest/ImplementsTest.js.html",
    "src/HTMLTest/DocumentTest/InterfaceTest/ImplementsTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/jsxtest/definitiontest.js",
    "test-file/src/HTMLTest/DocumentTest/JSXTest/DefinitionTest.js.html",
    "src/HTMLTest/DocumentTest/JSXTest/DefinitionTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/linktest/classtest.js",
    "test-file/src/HTMLTest/DocumentTest/LinkTest/ClassTest.js.html",
    "src/HTMLTest/DocumentTest/LinkTest/ClassTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/linktest/functiontest.js",
    "test-file/src/HTMLTest/DocumentTest/LinkTest/FunctionTest.js.html",
    "src/HTMLTest/DocumentTest/LinkTest/FunctionTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/linktest/variabletest.js",
    "test-file/src/HTMLTest/DocumentTest/LinkTest/VariableTest.js.html",
    "src/HTMLTest/DocumentTest/LinkTest/VariableTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/listenstest/functiontest.js",
    "test-file/src/HTMLTest/DocumentTest/ListensTest/FunctionTest.js.html",
    "src/HTMLTest/DocumentTest/ListensTest/FunctionTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/listenstest/methodtest.js",
    "test-file/src/HTMLTest/DocumentTest/ListensTest/MethodTest.js.html",
    "src/HTMLTest/DocumentTest/ListensTest/MethodTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/paramtest/functiontest.js",
    "test-file/src/HTMLTest/DocumentTest/ParamTest/FunctionTest.js.html",
    "src/HTMLTest/DocumentTest/ParamTest/FunctionTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/paramtest/methodtest.js",
    "test-file/src/HTMLTest/DocumentTest/ParamTest/MethodTest.js.html",
    "src/HTMLTest/DocumentTest/ParamTest/MethodTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/propertytest/returntest.js",
    "test-file/src/HTMLTest/DocumentTest/PropertyTest/ReturnTest.js.html",
    "src/HTMLTest/DocumentTest/PropertyTest/ReturnTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/returntest/functiontest.js",
    "test-file/src/HTMLTest/DocumentTest/ReturnTest/FunctionTest.js.html",
    "src/HTMLTest/DocumentTest/ReturnTest/FunctionTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/returntest/methodtest.js",
    "test-file/src/HTMLTest/DocumentTest/ReturnTest/MethodTest.js.html",
    "src/HTMLTest/DocumentTest/ReturnTest/MethodTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/seetest/classtest.js",
    "test-file/src/HTMLTest/DocumentTest/SeeTest/ClassTest.js.html",
    "src/HTMLTest/DocumentTest/SeeTest/ClassTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/seetest/functiontest.js",
    "test-file/src/HTMLTest/DocumentTest/SeeTest/FunctionTest.js.html",
    "src/HTMLTest/DocumentTest/SeeTest/FunctionTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/seetest/variabletest.js",
    "test-file/src/HTMLTest/DocumentTest/SeeTest/VariableTest.js.html",
    "src/HTMLTest/DocumentTest/SeeTest/VariableTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/sincetest/classtest.js",
    "test-file/src/HTMLTest/DocumentTest/SinceTest/ClassTest.js.html",
    "src/HTMLTest/DocumentTest/SinceTest/ClassTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/sincetest/functiontest.js",
    "test-file/src/HTMLTest/DocumentTest/SinceTest/FunctionTest.js.html",
    "src/HTMLTest/DocumentTest/SinceTest/FunctionTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/sincetest/variabletest.js",
    "test-file/src/HTMLTest/DocumentTest/SinceTest/VariableTest.js.html",
    "src/HTMLTest/DocumentTest/SinceTest/VariableTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/throwstest/functiontest.js",
    "test-file/src/HTMLTest/DocumentTest/ThrowsTest/FunctionTest.js.html",
    "src/HTMLTest/DocumentTest/ThrowsTest/FunctionTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/throwstest/methodtest.js",
    "test-file/src/HTMLTest/DocumentTest/ThrowsTest/MethodTest.js.html",
    "src/HTMLTest/DocumentTest/ThrowsTest/MethodTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/todotest/classtest.js",
    "test-file/src/HTMLTest/DocumentTest/TodoTest/ClassTest.js.html",
    "src/HTMLTest/DocumentTest/TodoTest/ClassTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/todotest/functiontest.js",
    "test-file/src/HTMLTest/DocumentTest/TodoTest/FunctionTest.js.html",
    "src/HTMLTest/DocumentTest/TodoTest/FunctionTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/todotest/variabletest.js",
    "test-file/src/HTMLTest/DocumentTest/TodoTest/VariableTest.js.html",
    "src/HTMLTest/DocumentTest/TodoTest/VariableTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/trailingcommatest/definitiontest.js",
    "test-file/src/HTMLTest/DocumentTest/TrailingCommaTest/DefinitionTest.js.html",
    "src/HTMLTest/DocumentTest/TrailingCommaTest/DefinitionTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/typetest/arraytest.js",
    "test-file/src/HTMLTest/DocumentTest/TypeTest/ArrayTest.js.html",
    "src/HTMLTest/DocumentTest/TypeTest/ArrayTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/typetest/classtest.js",
    "test-file/src/HTMLTest/DocumentTest/TypeTest/ClassTest.js.html",
    "src/HTMLTest/DocumentTest/TypeTest/ClassTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/typetest/complextest.js",
    "test-file/src/HTMLTest/DocumentTest/TypeTest/ComplexTest.js.html",
    "src/HTMLTest/DocumentTest/TypeTest/ComplexTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/typetest/defaulttest.js",
    "test-file/src/HTMLTest/DocumentTest/TypeTest/DefaultTest.js.html",
    "src/HTMLTest/DocumentTest/TypeTest/DefaultTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/typetest/externaltest.js",
    "test-file/src/HTMLTest/DocumentTest/TypeTest/ExternalTest.js.html",
    "src/HTMLTest/DocumentTest/TypeTest/ExternalTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/typetest/functiontest.js",
    "test-file/src/HTMLTest/DocumentTest/TypeTest/FunctionTest.js.html",
    "src/HTMLTest/DocumentTest/TypeTest/FunctionTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/typetest/genericstest.js",
    "test-file/src/HTMLTest/DocumentTest/TypeTest/GenericsTest.js.html",
    "src/HTMLTest/DocumentTest/TypeTest/GenericsTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/typetest/literaltest.js",
    "test-file/src/HTMLTest/DocumentTest/TypeTest/LiteralTest.js.html",
    "src/HTMLTest/DocumentTest/TypeTest/LiteralTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/typetest/nullabletest.js",
    "test-file/src/HTMLTest/DocumentTest/TypeTest/NullableTest.js.html",
    "src/HTMLTest/DocumentTest/TypeTest/NullableTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/typetest/objecttest.js",
    "test-file/src/HTMLTest/DocumentTest/TypeTest/ObjectTest.js.html",
    "src/HTMLTest/DocumentTest/TypeTest/ObjectTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/typetest/optionaltest.js",
    "test-file/src/HTMLTest/DocumentTest/TypeTest/OptionalTest.js.html",
    "src/HTMLTest/DocumentTest/TypeTest/OptionalTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/typetest/recordtest.js",
    "test-file/src/HTMLTest/DocumentTest/TypeTest/RecordTest.js.html",
    "src/HTMLTest/DocumentTest/TypeTest/RecordTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/typetest/spreadtest.js",
    "test-file/src/HTMLTest/DocumentTest/TypeTest/SpreadTest.js.html",
    "src/HTMLTest/DocumentTest/TypeTest/SpreadTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/typetest/typedeftest.js",
    "test-file/src/HTMLTest/DocumentTest/TypeTest/TypedefTest.js.html",
    "src/HTMLTest/DocumentTest/TypeTest/TypedefTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/typetest/uniontest.js",
    "test-file/src/HTMLTest/DocumentTest/TypeTest/UnionTest.js.html",
    "src/HTMLTest/DocumentTest/TypeTest/UnionTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/typedeftest/definitiontest.js",
    "test-file/src/HTMLTest/DocumentTest/TypedefTest/DefinitionTest.js.html",
    "src/HTMLTest/DocumentTest/TypedefTest/DefinitionTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/undocumenttest/definitiontest.js",
    "test-file/src/HTMLTest/DocumentTest/UndocumentTest/DefinitionTest.js.html",
    "src/HTMLTest/DocumentTest/UndocumentTest/DefinitionTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/variabletest/arraypattertest.js",
    "test-file/src/HTMLTest/DocumentTest/VariableTest/ArrayPatterTest.js.html",
    "src/HTMLTest/DocumentTest/VariableTest/ArrayPatterTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/variabletest/definitiontest.js",
    "test-file/src/HTMLTest/DocumentTest/VariableTest/DefinitionTest.js.html",
    "src/HTMLTest/DocumentTest/VariableTest/DefinitionTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/variabletest/objectpattertest.js",
    "test-file/src/HTMLTest/DocumentTest/VariableTest/ObjectPatterTest.js.html",
    "src/HTMLTest/DocumentTest/VariableTest/ObjectPatterTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/versiontest/classtest.js",
    "test-file/src/HTMLTest/DocumentTest/VersionTest/ClassTest.js.html",
    "src/HTMLTest/DocumentTest/VersionTest/ClassTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/versiontest/functiontest.js",
    "test-file/src/HTMLTest/DocumentTest/VersionTest/FunctionTest.js.html",
    "src/HTMLTest/DocumentTest/VersionTest/FunctionTest.js",
    "testFile"
  ],
  [
    "src/htmltest/documenttest/versiontest/variabletest.js",
    "test-file/src/HTMLTest/DocumentTest/VersionTest/VariableTest.js.html",
    "src/HTMLTest/DocumentTest/VersionTest/VariableTest.js",
    "testFile"
  ],
  [
    "src/htmltest/filetest/filetest.js",
    "test-file/src/HTMLTest/FileTest/FileTest.js.html",
    "src/HTMLTest/FileTest/FileTest.js",
    "testFile"
  ],
  [
    "src/htmltest/identifierstest/identifierstest.js",
    "test-file/src/HTMLTest/IdentifiersTest/IdentifiersTest.js.html",
    "src/HTMLTest/IdentifiersTest/IdentifiersTest.js",
    "testFile"
  ],
  [
    "src/htmltest/indextest/indextest.js",
    "test-file/src/HTMLTest/IndexTest/IndexTest.js.html",
    "src/HTMLTest/IndexTest/IndexTest.js",
    "testFile"
  ],
  [
    "src/htmltest/manualtest/manualtest.js",
    "test-file/src/HTMLTest/ManualTest/ManualTest.js.html",
    "src/HTMLTest/ManualTest/ManualTest.js",
    "testFile"
  ],
  [
    "src/htmltest/navtest/navtest.js",
    "test-file/src/HTMLTest/NavTest/NavTest.js.html",
    "src/HTMLTest/NavTest/NavTest.js",
    "testFile"
  ],
  [
    "src/htmltest/testtest/testlinktest.js",
    "test-file/src/HTMLTest/TestTest/TestLinkTest.js.html",
    "src/HTMLTest/TestTest/TestLinkTest.js",
    "testFile"
  ],
  [
    "src/htmltest/testtest/testtest.js",
    "test-file/src/HTMLTest/TestTest/TestTest.js.html",
    "src/HTMLTest/TestTest/TestTest.js",
    "testFile"
  ],
  [
    "src/parser/commentparser.js",
    "file/src/Parser/CommentParser.js.html",
    "src/Parser/CommentParser.js",
    "file"
  ],
  [
    "src/parser/commentparser.js~commentparser.isesdoc",
    "class/src/Parser/CommentParser.js~CommentParser.html#static-method-isESDoc",
    "src/Parser/CommentParser.js~CommentParser.isESDoc",
    "method"
  ],
  [
    "src/parser/commentparser.js~commentparser.parse",
    "class/src/Parser/CommentParser.js~CommentParser.html#static-method-parse",
    "src/Parser/CommentParser.js~CommentParser.parse",
    "method"
  ],
  [
    "src/parser/paramparser.js",
    "file/src/Parser/ParamParser.js.html",
    "src/Parser/ParamParser.js",
    "file"
  ],
  [
    "src/parser/paramparser.js~paramparser.guessparams",
    "class/src/Parser/ParamParser.js~ParamParser.html#static-method-guessParams",
    "src/Parser/ParamParser.js~ParamParser.guessParams",
    "method"
  ],
  [
    "src/parser/paramparser.js~paramparser.guessreturnparam",
    "class/src/Parser/ParamParser.js~ParamParser.html#static-method-guessReturnParam",
    "src/Parser/ParamParser.js~ParamParser.guessReturnParam",
    "method"
  ],
  [
    "src/parser/paramparser.js~paramparser.guesstype",
    "class/src/Parser/ParamParser.js~ParamParser.html#static-method-guessType",
    "src/Parser/ParamParser.js~ParamParser.guessType",
    "method"
  ],
  [
    "src/parser/paramparser.js~paramparser.parseparam",
    "class/src/Parser/ParamParser.js~ParamParser.html#static-method-parseParam",
    "src/Parser/ParamParser.js~ParamParser.parseParam",
    "method"
  ],
  [
    "src/parser/paramparser.js~paramparser.parseparamvalue",
    "class/src/Parser/ParamParser.js~ParamParser.html#static-method-parseParamValue",
    "src/Parser/ParamParser.js~ParamParser.parseParamValue",
    "method"
  ],
  [
    "src/parsertest/babylonparsertest.js",
    "test-file/src/ParserTest/BabylonParserTest.js.html",
    "src/ParserTest/BabylonParserTest.js",
    "testFile"
  ],
  [
    "src/parsertest/commentparsertest.js",
    "test-file/src/ParserTest/CommentParserTest.js.html",
    "src/ParserTest/CommentParserTest.js",
    "testFile"
  ],
  [
    "src/parsertest/paramparsertest.js",
    "test-file/src/ParserTest/ParamParserTest.js.html",
    "src/ParserTest/ParamParserTest.js",
    "testFile"
  ],
  [
    "src/publisher/builder/astdocbuilder.js",
    "file/src/Publisher/Builder/ASTDocBuilder.js.html",
    "src/Publisher/Builder/ASTDocBuilder.js",
    "file"
  ],
  [
    "src/publisher/builder/astdocbuilder.js~astdocbuilder#_asts",
    "class/src/Publisher/Builder/ASTDocBuilder.js~ASTDocBuilder.html#instance-member-_asts",
    "src/Publisher/Builder/ASTDocBuilder.js~ASTDocBuilder#_asts",
    "member"
  ],
  [
    "src/publisher/builder/astdocbuilder.js~astdocbuilder#constructor",
    "class/src/Publisher/Builder/ASTDocBuilder.js~ASTDocBuilder.html#instance-constructor-constructor",
    "src/Publisher/Builder/ASTDocBuilder.js~ASTDocBuilder#constructor",
    "method"
  ],
  [
    "src/publisher/builder/astdocbuilder.js~astdocbuilder#exec",
    "class/src/Publisher/Builder/ASTDocBuilder.js~ASTDocBuilder.html#instance-method-exec",
    "src/Publisher/Builder/ASTDocBuilder.js~ASTDocBuilder#exec",
    "method"
  ],
  [
    "src/publisher/builder/classdocbuilder.js",
    "file/src/Publisher/Builder/ClassDocBuilder.js.html",
    "src/Publisher/Builder/ClassDocBuilder.js",
    "file"
  ],
  [
    "src/publisher/builder/classdocbuilder.js~classdocbuilder#_buildclassdoc",
    "class/src/Publisher/Builder/ClassDocBuilder.js~ClassDocBuilder.html#instance-method-_buildClassDoc",
    "src/Publisher/Builder/ClassDocBuilder.js~ClassDocBuilder#_buildClassDoc",
    "method"
  ],
  [
    "src/publisher/builder/classdocbuilder.js~classdocbuilder#_builddirectsubclasshtml",
    "class/src/Publisher/Builder/ClassDocBuilder.js~ClassDocBuilder.html#instance-method-_buildDirectSubclassHTML",
    "src/Publisher/Builder/ClassDocBuilder.js~ClassDocBuilder#_buildDirectSubclassHTML",
    "method"
  ],
  [
    "src/publisher/builder/classdocbuilder.js~classdocbuilder#_buildexpressionextendshtml",
    "class/src/Publisher/Builder/ClassDocBuilder.js~ClassDocBuilder.html#instance-method-_buildExpressionExtendsHTML",
    "src/Publisher/Builder/ClassDocBuilder.js~ClassDocBuilder#_buildExpressionExtendsHTML",
    "method"
  ],
  [
    "src/publisher/builder/classdocbuilder.js~classdocbuilder#_buildextendschainhtml",
    "class/src/Publisher/Builder/ClassDocBuilder.js~ClassDocBuilder.html#instance-method-_buildExtendsChainHTML",
    "src/Publisher/Builder/ClassDocBuilder.js~ClassDocBuilder#_buildExtendsChainHTML",
    "method"
  ],
  [
    "src/publisher/builder/classdocbuilder.js~classdocbuilder#_buildindirectsubclasshtml",
    "class/src/Publisher/Builder/ClassDocBuilder.js~ClassDocBuilder.html#instance-method-_buildIndirectSubclassHTML",
    "src/Publisher/Builder/ClassDocBuilder.js~ClassDocBuilder#_buildIndirectSubclassHTML",
    "method"
  ],
  [
    "src/publisher/builder/classdocbuilder.js~classdocbuilder#_buildinheritedsummaryhtml",
    "class/src/Publisher/Builder/ClassDocBuilder.js~ClassDocBuilder.html#instance-method-_buildInheritedSummaryHTML",
    "src/Publisher/Builder/ClassDocBuilder.js~ClassDocBuilder#_buildInheritedSummaryHTML",
    "method"
  ],
  [
    "src/publisher/builder/classdocbuilder.js~classdocbuilder#_buildmixinclasseshtml",
    "class/src/Publisher/Builder/ClassDocBuilder.js~ClassDocBuilder.html#instance-method-_buildMixinClassesHTML",
    "src/Publisher/Builder/ClassDocBuilder.js~ClassDocBuilder#_buildMixinClassesHTML",
    "method"
  ],
  [
    "src/publisher/builder/classdocbuilder.js~classdocbuilder#_buildvariationhtml",
    "class/src/Publisher/Builder/ClassDocBuilder.js~ClassDocBuilder.html#instance-method-_buildVariationHTML",
    "src/Publisher/Builder/ClassDocBuilder.js~ClassDocBuilder#_buildVariationHTML",
    "method"
  ],
  [
    "src/publisher/builder/classdocbuilder.js~classdocbuilder#exec",
    "class/src/Publisher/Builder/ClassDocBuilder.js~ClassDocBuilder.html#instance-method-exec",
    "src/Publisher/Builder/ClassDocBuilder.js~ClassDocBuilder#exec",
    "method"
  ],
  [
    "src/publisher/builder/coveragebuilder.js",
    "file/src/Publisher/Builder/CoverageBuilder.js.html",
    "src/Publisher/Builder/CoverageBuilder.js",
    "file"
  ],
  [
    "src/publisher/builder/coveragebuilder.js~coveragebuilder#exec",
    "class/src/Publisher/Builder/CoverageBuilder.js~CoverageBuilder.html#instance-method-exec",
    "src/Publisher/Builder/CoverageBuilder.js~CoverageBuilder#exec",
    "method"
  ],
  [
    "src/publisher/builder/docbuilder.js",
    "file/src/Publisher/Builder/DocBuilder.js.html",
    "src/Publisher/Builder/DocBuilder.js",
    "file"
  ],
  [
    "src/publisher/builder/docbuilder.js~docbuilder#_builddecoratorhtml",
    "class/src/Publisher/Builder/DocBuilder.js~DocBuilder.html#instance-method-_buildDecoratorHTML",
    "src/Publisher/Builder/DocBuilder.js~DocBuilder#_buildDecoratorHTML",
    "method"
  ],
  [
    "src/publisher/builder/docbuilder.js~docbuilder#_builddeprecatedhtml",
    "class/src/Publisher/Builder/DocBuilder.js~DocBuilder.html#instance-method-_buildDeprecatedHTML",
    "src/Publisher/Builder/DocBuilder.js~DocBuilder#_buildDeprecatedHTML",
    "method"
  ],
  [
    "src/publisher/builder/docbuilder.js~docbuilder#_builddetaildocs",
    "class/src/Publisher/Builder/DocBuilder.js~DocBuilder.html#instance-method-_buildDetailDocs",
    "src/Publisher/Builder/DocBuilder.js~DocBuilder#_buildDetailDocs",
    "method"
  ],
  [
    "src/publisher/builder/docbuilder.js~docbuilder#_builddetailhtml",
    "class/src/Publisher/Builder/DocBuilder.js~DocBuilder.html#instance-method-_buildDetailHTML",
    "src/Publisher/Builder/DocBuilder.js~DocBuilder#_buildDetailHTML",
    "method"
  ],
  [
    "src/publisher/builder/docbuilder.js~docbuilder#_builddoclinkhtml",
    "class/src/Publisher/Builder/DocBuilder.js~DocBuilder.html#instance-method-_buildDocLinkHTML",
    "src/Publisher/Builder/DocBuilder.js~DocBuilder#_buildDocLinkHTML",
    "method"
  ],
  [
    "src/publisher/builder/docbuilder.js~docbuilder#_builddocslinkhtml",
    "class/src/Publisher/Builder/DocBuilder.js~DocBuilder.html#instance-method-_buildDocsLinkHTML",
    "src/Publisher/Builder/DocBuilder.js~DocBuilder#_buildDocsLinkHTML",
    "method"
  ],
  [
    "src/publisher/builder/docbuilder.js~docbuilder#_buildexperimentalhtml",
    "class/src/Publisher/Builder/DocBuilder.js~DocBuilder.html#instance-method-_buildExperimentalHTML",
    "src/Publisher/Builder/DocBuilder.js~DocBuilder#_buildExperimentalHTML",
    "method"
  ],
  [
    "src/publisher/builder/docbuilder.js~docbuilder#_buildfiledoclinkhtml",
    "class/src/Publisher/Builder/DocBuilder.js~DocBuilder.html#instance-method-_buildFileDocLinkHTML",
    "src/Publisher/Builder/DocBuilder.js~DocBuilder#_buildFileDocLinkHTML",
    "method"
  ],
  [
    "src/publisher/builder/docbuilder.js~docbuilder#_buildlayoutdoc",
    "class/src/Publisher/Builder/DocBuilder.js~DocBuilder.html#instance-method-_buildLayoutDoc",
    "src/Publisher/Builder/DocBuilder.js~DocBuilder#_buildLayoutDoc",
    "method"
  ],
  [
    "src/publisher/builder/docbuilder.js~docbuilder#_buildnavdoc",
    "class/src/Publisher/Builder/DocBuilder.js~DocBuilder.html#instance-method-_buildNavDoc",
    "src/Publisher/Builder/DocBuilder.js~DocBuilder#_buildNavDoc",
    "method"
  ],
  [
    "src/publisher/builder/docbuilder.js~docbuilder#_buildoverridemethod",
    "class/src/Publisher/Builder/DocBuilder.js~DocBuilder.html#instance-method-_buildOverrideMethod",
    "src/Publisher/Builder/DocBuilder.js~DocBuilder#_buildOverrideMethod",
    "method"
  ],
  [
    "src/publisher/builder/docbuilder.js~docbuilder#_buildoverridemethoddescription",
    "class/src/Publisher/Builder/DocBuilder.js~DocBuilder.html#instance-method-_buildOverrideMethodDescription",
    "src/Publisher/Builder/DocBuilder.js~DocBuilder#_buildOverrideMethodDescription",
    "method"
  ],
  [
    "src/publisher/builder/docbuilder.js~docbuilder#_buildproperties",
    "class/src/Publisher/Builder/DocBuilder.js~DocBuilder.html#instance-method-_buildProperties",
    "src/Publisher/Builder/DocBuilder.js~DocBuilder#_buildProperties",
    "method"
  ],
  [
    "src/publisher/builder/docbuilder.js~docbuilder#_buildsignaturehtml",
    "class/src/Publisher/Builder/DocBuilder.js~DocBuilder.html#instance-method-_buildSignatureHTML",
    "src/Publisher/Builder/DocBuilder.js~DocBuilder#_buildSignatureHTML",
    "method"
  ],
  [
    "src/publisher/builder/docbuilder.js~docbuilder#_buildsummarydoc",
    "class/src/Publisher/Builder/DocBuilder.js~DocBuilder.html#instance-method-_buildSummaryDoc",
    "src/Publisher/Builder/DocBuilder.js~DocBuilder#_buildSummaryDoc",
    "method"
  ],
  [
    "src/publisher/builder/docbuilder.js~docbuilder#_buildsummaryhtml",
    "class/src/Publisher/Builder/DocBuilder.js~DocBuilder.html#instance-method-_buildSummaryHTML",
    "src/Publisher/Builder/DocBuilder.js~DocBuilder#_buildSummaryHTML",
    "method"
  ],
  [
    "src/publisher/builder/docbuilder.js~docbuilder#_buildtypedoclinkhtml",
    "class/src/Publisher/Builder/DocBuilder.js~DocBuilder.html#instance-method-_buildTypeDocLinkHTML",
    "src/Publisher/Builder/DocBuilder.js~DocBuilder#_buildTypeDocLinkHTML",
    "method"
  ],
  [
    "src/publisher/builder/docbuilder.js~docbuilder#_config",
    "class/src/Publisher/Builder/DocBuilder.js~DocBuilder.html#instance-member-_config",
    "src/Publisher/Builder/DocBuilder.js~DocBuilder#_config",
    "member"
  ],
  [
    "src/publisher/builder/docbuilder.js~docbuilder#_data",
    "class/src/Publisher/Builder/DocBuilder.js~DocBuilder.html#instance-member-_data",
    "src/Publisher/Builder/DocBuilder.js~DocBuilder#_data",
    "member"
  ],
  [
    "src/publisher/builder/docbuilder.js~docbuilder#_find",
    "class/src/Publisher/Builder/DocBuilder.js~DocBuilder.html#instance-method-_find",
    "src/Publisher/Builder/DocBuilder.js~DocBuilder#_find",
    "method"
  ],
  [
    "src/publisher/builder/docbuilder.js~docbuilder#_findaccessdocs",
    "class/src/Publisher/Builder/DocBuilder.js~DocBuilder.html#instance-method-_findAccessDocs",
    "src/Publisher/Builder/DocBuilder.js~DocBuilder#_findAccessDocs",
    "method"
  ],
  [
    "src/publisher/builder/docbuilder.js~docbuilder#_findallidentifierskindgrouping",
    "class/src/Publisher/Builder/DocBuilder.js~DocBuilder.html#instance-method-_findAllIdentifiersKindGrouping",
    "src/Publisher/Builder/DocBuilder.js~DocBuilder#_findAllIdentifiersKindGrouping",
    "method"
  ],
  [
    "src/publisher/builder/docbuilder.js~docbuilder#_findbyname",
    "class/src/Publisher/Builder/DocBuilder.js~DocBuilder.html#instance-method-_findByName",
    "src/Publisher/Builder/DocBuilder.js~DocBuilder#_findByName",
    "method"
  ],
  [
    "src/publisher/builder/docbuilder.js~docbuilder#_getbaseurl",
    "class/src/Publisher/Builder/DocBuilder.js~DocBuilder.html#instance-method-_getBaseUrl",
    "src/Publisher/Builder/DocBuilder.js~DocBuilder#_getBaseUrl",
    "method"
  ],
  [
    "src/publisher/builder/docbuilder.js~docbuilder#_getinfo",
    "class/src/Publisher/Builder/DocBuilder.js~DocBuilder.html#instance-method-_getInfo",
    "src/Publisher/Builder/DocBuilder.js~DocBuilder#_getInfo",
    "method"
  ],
  [
    "src/publisher/builder/docbuilder.js~docbuilder#_getoutputfilename",
    "class/src/Publisher/Builder/DocBuilder.js~DocBuilder.html#instance-method-_getOutputFileName",
    "src/Publisher/Builder/DocBuilder.js~DocBuilder#_getOutputFileName",
    "method"
  ],
  [
    "src/publisher/builder/docbuilder.js~docbuilder#_gettitle",
    "class/src/Publisher/Builder/DocBuilder.js~DocBuilder.html#instance-method-_getTitle",
    "src/Publisher/Builder/DocBuilder.js~DocBuilder#_getTitle",
    "method"
  ],
  [
    "src/publisher/builder/docbuilder.js~docbuilder#_geturl",
    "class/src/Publisher/Builder/DocBuilder.js~DocBuilder.html#instance-method-_getURL",
    "src/Publisher/Builder/DocBuilder.js~DocBuilder#_getURL",
    "method"
  ],
  [
    "src/publisher/builder/docbuilder.js~docbuilder#_orderedfind",
    "class/src/Publisher/Builder/DocBuilder.js~DocBuilder.html#instance-method-_orderedFind",
    "src/Publisher/Builder/DocBuilder.js~DocBuilder#_orderedFind",
    "method"
  ],
  [
    "src/publisher/builder/docbuilder.js~docbuilder#_readtemplate",
    "class/src/Publisher/Builder/DocBuilder.js~DocBuilder.html#instance-method-_readTemplate",
    "src/Publisher/Builder/DocBuilder.js~DocBuilder#_readTemplate",
    "method"
  ],
  [
    "src/publisher/builder/docbuilder.js~docbuilder#constructor",
    "class/src/Publisher/Builder/DocBuilder.js~DocBuilder.html#instance-constructor-constructor",
    "src/Publisher/Builder/DocBuilder.js~DocBuilder#constructor",
    "method"
  ],
  [
    "src/publisher/builder/docbuilder.js~docbuilder#exec",
    "class/src/Publisher/Builder/DocBuilder.js~DocBuilder.html#instance-method-exec",
    "src/Publisher/Builder/DocBuilder.js~DocBuilder#exec",
    "method"
  ],
  [
    "src/publisher/builder/docresolver.js",
    "file/src/Publisher/Builder/DocResolver.js.html",
    "src/Publisher/Builder/DocResolver.js",
    "file"
  ],
  [
    "src/publisher/builder/docresolver.js~docresolver#_builder",
    "class/src/Publisher/Builder/DocResolver.js~DocResolver.html#instance-member-_builder",
    "src/Publisher/Builder/DocResolver.js~DocResolver#_builder",
    "member"
  ],
  [
    "src/publisher/builder/docresolver.js~docresolver#_data",
    "class/src/Publisher/Builder/DocResolver.js~DocResolver.html#instance-member-_data",
    "src/Publisher/Builder/DocResolver.js~DocResolver#_data",
    "member"
  ],
  [
    "src/publisher/builder/docresolver.js~docresolver#_resolveaccess",
    "class/src/Publisher/Builder/DocResolver.js~DocResolver.html#instance-method-_resolveAccess",
    "src/Publisher/Builder/DocResolver.js~DocResolver#_resolveAccess",
    "method"
  ],
  [
    "src/publisher/builder/docresolver.js~docresolver#_resolveduplication",
    "class/src/Publisher/Builder/DocResolver.js~DocResolver.html#instance-method-_resolveDuplication",
    "src/Publisher/Builder/DocResolver.js~DocResolver#_resolveDuplication",
    "method"
  ],
  [
    "src/publisher/builder/docresolver.js~docresolver#_resolveextendschain",
    "class/src/Publisher/Builder/DocResolver.js~DocResolver.html#instance-method-_resolveExtendsChain",
    "src/Publisher/Builder/DocResolver.js~DocResolver#_resolveExtendsChain",
    "method"
  ],
  [
    "src/publisher/builder/docresolver.js~docresolver#_resolveignore",
    "class/src/Publisher/Builder/DocResolver.js~DocResolver.html#instance-method-_resolveIgnore",
    "src/Publisher/Builder/DocResolver.js~DocResolver#_resolveIgnore",
    "method"
  ],
  [
    "src/publisher/builder/docresolver.js~docresolver#_resolvelink",
    "class/src/Publisher/Builder/DocResolver.js~DocResolver.html#instance-method-_resolveLink",
    "src/Publisher/Builder/DocResolver.js~DocResolver#_resolveLink",
    "method"
  ],
  [
    "src/publisher/builder/docresolver.js~docresolver#_resolvemarkdown",
    "class/src/Publisher/Builder/DocResolver.js~DocResolver.html#instance-method-_resolveMarkdown",
    "src/Publisher/Builder/DocResolver.js~DocResolver#_resolveMarkdown",
    "method"
  ],
  [
    "src/publisher/builder/docresolver.js~docresolver#_resolvenecessary",
    "class/src/Publisher/Builder/DocResolver.js~DocResolver.html#instance-method-_resolveNecessary",
    "src/Publisher/Builder/DocResolver.js~DocResolver#_resolveNecessary",
    "method"
  ],
  [
    "src/publisher/builder/docresolver.js~docresolver#_resolvetestrelation",
    "class/src/Publisher/Builder/DocResolver.js~DocResolver.html#instance-method-_resolveTestRelation",
    "src/Publisher/Builder/DocResolver.js~DocResolver#_resolveTestRelation",
    "method"
  ],
  [
    "src/publisher/builder/docresolver.js~docresolver#_resolveundocumentidentifier",
    "class/src/Publisher/Builder/DocResolver.js~DocResolver.html#instance-method-_resolveUndocumentIdentifier",
    "src/Publisher/Builder/DocResolver.js~DocResolver#_resolveUndocumentIdentifier",
    "method"
  ],
  [
    "src/publisher/builder/docresolver.js~docresolver#_resolveunexportidentifier",
    "class/src/Publisher/Builder/DocResolver.js~DocResolver.html#instance-method-_resolveUnexportIdentifier",
    "src/Publisher/Builder/DocResolver.js~DocResolver#_resolveUnexportIdentifier",
    "method"
  ],
  [
    "src/publisher/builder/docresolver.js~docresolver#constructor",
    "class/src/Publisher/Builder/DocResolver.js~DocResolver.html#instance-constructor-constructor",
    "src/Publisher/Builder/DocResolver.js~DocResolver#constructor",
    "method"
  ],
  [
    "src/publisher/builder/docresolver.js~docresolver#resolve",
    "class/src/Publisher/Builder/DocResolver.js~DocResolver.html#instance-method-resolve",
    "src/Publisher/Builder/DocResolver.js~DocResolver#resolve",
    "method"
  ],
  [
    "src/publisher/builder/filedocbuilder.js",
    "file/src/Publisher/Builder/FileDocBuilder.js.html",
    "src/Publisher/Builder/FileDocBuilder.js",
    "file"
  ],
  [
    "src/publisher/builder/filedocbuilder.js~filedocbuilder#_buildfiledoc",
    "class/src/Publisher/Builder/FileDocBuilder.js~FileDocBuilder.html#instance-method-_buildFileDoc",
    "src/Publisher/Builder/FileDocBuilder.js~FileDocBuilder#_buildFileDoc",
    "method"
  ],
  [
    "src/publisher/builder/filedocbuilder.js~filedocbuilder#exec",
    "class/src/Publisher/Builder/FileDocBuilder.js~FileDocBuilder.html#instance-method-exec",
    "src/Publisher/Builder/FileDocBuilder.js~FileDocBuilder#exec",
    "method"
  ],
  [
    "src/publisher/builder/identifiersdocbuilder.js",
    "file/src/Publisher/Builder/IdentifiersDocBuilder.js.html",
    "src/Publisher/Builder/IdentifiersDocBuilder.js",
    "file"
  ],
  [
    "src/publisher/builder/identifiersdocbuilder.js~identifiersdocbuilder#_buildidentifierdoc",
    "class/src/Publisher/Builder/IdentifiersDocBuilder.js~IdentifiersDocBuilder.html#instance-method-_buildIdentifierDoc",
    "src/Publisher/Builder/IdentifiersDocBuilder.js~IdentifiersDocBuilder#_buildIdentifierDoc",
    "method"
  ],
  [
    "src/publisher/builder/identifiersdocbuilder.js~identifiersdocbuilder#exec",
    "class/src/Publisher/Builder/IdentifiersDocBuilder.js~IdentifiersDocBuilder.html#instance-method-exec",
    "src/Publisher/Builder/IdentifiersDocBuilder.js~IdentifiersDocBuilder#exec",
    "method"
  ],
  [
    "src/publisher/builder/indexdocbuilder.js",
    "file/src/Publisher/Builder/IndexDocBuilder.js.html",
    "src/Publisher/Builder/IndexDocBuilder.js",
    "file"
  ],
  [
    "src/publisher/builder/indexdocbuilder.js~indexdocbuilder#_buildindexdoc",
    "class/src/Publisher/Builder/IndexDocBuilder.js~IndexDocBuilder.html#instance-method-_buildIndexDoc",
    "src/Publisher/Builder/IndexDocBuilder.js~IndexDocBuilder#_buildIndexDoc",
    "method"
  ],
  [
    "src/publisher/builder/indexdocbuilder.js~indexdocbuilder#_coverage",
    "class/src/Publisher/Builder/IndexDocBuilder.js~IndexDocBuilder.html#instance-member-_coverage",
    "src/Publisher/Builder/IndexDocBuilder.js~IndexDocBuilder#_coverage",
    "member"
  ],
  [
    "src/publisher/builder/indexdocbuilder.js~indexdocbuilder#constructor",
    "class/src/Publisher/Builder/IndexDocBuilder.js~IndexDocBuilder.html#instance-constructor-constructor",
    "src/Publisher/Builder/IndexDocBuilder.js~IndexDocBuilder#constructor",
    "method"
  ],
  [
    "src/publisher/builder/indexdocbuilder.js~indexdocbuilder#exec",
    "class/src/Publisher/Builder/IndexDocBuilder.js~IndexDocBuilder.html#instance-method-exec",
    "src/Publisher/Builder/IndexDocBuilder.js~IndexDocBuilder#exec",
    "method"
  ],
  [
    "src/publisher/builder/lintdocbuilder.js",
    "file/src/Publisher/Builder/LintDocBuilder.js.html",
    "src/Publisher/Builder/LintDocBuilder.js",
    "file"
  ],
  [
    "src/publisher/builder/lintdocbuilder.js~lintdocbuilder#_getparamsfromdoc",
    "class/src/Publisher/Builder/LintDocBuilder.js~LintDocBuilder.html#instance-method-_getParamsFromDoc",
    "src/Publisher/Builder/LintDocBuilder.js~LintDocBuilder#_getParamsFromDoc",
    "method"
  ],
  [
    "src/publisher/builder/lintdocbuilder.js~lintdocbuilder#_getparamsfromnode",
    "class/src/Publisher/Builder/LintDocBuilder.js~LintDocBuilder.html#instance-method-_getParamsFromNode",
    "src/Publisher/Builder/LintDocBuilder.js~LintDocBuilder#_getParamsFromNode",
    "method"
  ],
  [
    "src/publisher/builder/lintdocbuilder.js~lintdocbuilder#_match",
    "class/src/Publisher/Builder/LintDocBuilder.js~LintDocBuilder.html#instance-method-_match",
    "src/Publisher/Builder/LintDocBuilder.js~LintDocBuilder#_match",
    "method"
  ],
  [
    "src/publisher/builder/lintdocbuilder.js~lintdocbuilder#_showresult",
    "class/src/Publisher/Builder/LintDocBuilder.js~LintDocBuilder.html#instance-method-_showResult",
    "src/Publisher/Builder/LintDocBuilder.js~LintDocBuilder#_showResult",
    "method"
  ],
  [
    "src/publisher/builder/lintdocbuilder.js~lintdocbuilder#exec",
    "class/src/Publisher/Builder/LintDocBuilder.js~LintDocBuilder.html#instance-method-exec",
    "src/Publisher/Builder/LintDocBuilder.js~LintDocBuilder#exec",
    "method"
  ],
  [
    "src/publisher/builder/manualdocbuilder.js",
    "file/src/Publisher/Builder/ManualDocBuilder.js.html",
    "src/Publisher/Builder/ManualDocBuilder.js",
    "file"
  ],
  [
    "src/publisher/builder/manualdocbuilder.js~manualdocbuilder#_buildmanual",
    "class/src/Publisher/Builder/ManualDocBuilder.js~ManualDocBuilder.html#instance-method-_buildManual",
    "src/Publisher/Builder/ManualDocBuilder.js~ManualDocBuilder#_buildManual",
    "method"
  ],
  [
    "src/publisher/builder/manualdocbuilder.js~manualdocbuilder#_buildmanualcardindex",
    "class/src/Publisher/Builder/ManualDocBuilder.js~ManualDocBuilder.html#instance-method-_buildManualCardIndex",
    "src/Publisher/Builder/ManualDocBuilder.js~ManualDocBuilder#_buildManualCardIndex",
    "method"
  ],
  [
    "src/publisher/builder/manualdocbuilder.js~manualdocbuilder#_buildmanualindex",
    "class/src/Publisher/Builder/ManualDocBuilder.js~ManualDocBuilder.html#instance-method-_buildManualIndex",
    "src/Publisher/Builder/ManualDocBuilder.js~ManualDocBuilder#_buildManualIndex",
    "method"
  ],
  [
    "src/publisher/builder/manualdocbuilder.js~manualdocbuilder#_buildmanualnav",
    "class/src/Publisher/Builder/ManualDocBuilder.js~ManualDocBuilder.html#instance-method-_buildManualNav",
    "src/Publisher/Builder/ManualDocBuilder.js~ManualDocBuilder#_buildManualNav",
    "method"
  ],
  [
    "src/publisher/builder/manualdocbuilder.js~manualdocbuilder#_convertmdtohtml",
    "class/src/Publisher/Builder/ManualDocBuilder.js~ManualDocBuilder.html#instance-method-_convertMDToHTML",
    "src/Publisher/Builder/ManualDocBuilder.js~ManualDocBuilder#_convertMDToHTML",
    "method"
  ],
  [
    "src/publisher/builder/manualdocbuilder.js~manualdocbuilder#_getmanualconfig",
    "class/src/Publisher/Builder/ManualDocBuilder.js~ManualDocBuilder.html#instance-method-_getManualConfig",
    "src/Publisher/Builder/ManualDocBuilder.js~ManualDocBuilder#_getManualConfig",
    "method"
  ],
  [
    "src/publisher/builder/manualdocbuilder.js~manualdocbuilder#_getmanualoutputfilename",
    "class/src/Publisher/Builder/ManualDocBuilder.js~ManualDocBuilder.html#instance-method-_getManualOutputFileName",
    "src/Publisher/Builder/ManualDocBuilder.js~ManualDocBuilder#_getManualOutputFileName",
    "method"
  ],
  [
    "src/publisher/builder/manualdocbuilder.js~manualdocbuilder#exec",
    "class/src/Publisher/Builder/ManualDocBuilder.js~ManualDocBuilder.html#instance-method-exec",
    "src/Publisher/Builder/ManualDocBuilder.js~ManualDocBuilder#exec",
    "method"
  ],
  [
    "src/publisher/builder/searchindexbuilder.js",
    "file/src/Publisher/Builder/SearchIndexBuilder.js.html",
    "src/Publisher/Builder/SearchIndexBuilder.js",
    "file"
  ],
  [
    "src/publisher/builder/searchindexbuilder.js~searchindexbuilder#exec",
    "class/src/Publisher/Builder/SearchIndexBuilder.js~SearchIndexBuilder.html#instance-method-exec",
    "src/Publisher/Builder/SearchIndexBuilder.js~SearchIndexBuilder#exec",
    "method"
  ],
  [
    "src/publisher/builder/singledocbuilder.js",
    "file/src/Publisher/Builder/SingleDocBuilder.js.html",
    "src/Publisher/Builder/SingleDocBuilder.js",
    "file"
  ],
  [
    "src/publisher/builder/singledocbuilder.js~singledocbuilder#_buildsingledoc",
    "class/src/Publisher/Builder/SingleDocBuilder.js~SingleDocBuilder.html#instance-method-_buildSingleDoc",
    "src/Publisher/Builder/SingleDocBuilder.js~SingleDocBuilder#_buildSingleDoc",
    "method"
  ],
  [
    "src/publisher/builder/singledocbuilder.js~singledocbuilder#exec",
    "class/src/Publisher/Builder/SingleDocBuilder.js~SingleDocBuilder.html#instance-method-exec",
    "src/Publisher/Builder/SingleDocBuilder.js~SingleDocBuilder#exec",
    "method"
  ],
  [
    "src/publisher/builder/sourcedocbuilder.js",
    "file/src/Publisher/Builder/SourceDocBuilder.js.html",
    "src/Publisher/Builder/SourceDocBuilder.js",
    "file"
  ],
  [
    "src/publisher/builder/sourcedocbuilder.js~sourcedocbuilder#_buildsourcehtml",
    "class/src/Publisher/Builder/SourceDocBuilder.js~SourceDocBuilder.html#instance-method-_buildSourceHTML",
    "src/Publisher/Builder/SourceDocBuilder.js~SourceDocBuilder#_buildSourceHTML",
    "method"
  ],
  [
    "src/publisher/builder/sourcedocbuilder.js~sourcedocbuilder#_coverage",
    "class/src/Publisher/Builder/SourceDocBuilder.js~SourceDocBuilder.html#instance-member-_coverage",
    "src/Publisher/Builder/SourceDocBuilder.js~SourceDocBuilder#_coverage",
    "member"
  ],
  [
    "src/publisher/builder/sourcedocbuilder.js~sourcedocbuilder#constructor",
    "class/src/Publisher/Builder/SourceDocBuilder.js~SourceDocBuilder.html#instance-constructor-constructor",
    "src/Publisher/Builder/SourceDocBuilder.js~SourceDocBuilder#constructor",
    "method"
  ],
  [
    "src/publisher/builder/sourcedocbuilder.js~sourcedocbuilder#exec",
    "class/src/Publisher/Builder/SourceDocBuilder.js~SourceDocBuilder.html#instance-method-exec",
    "src/Publisher/Builder/SourceDocBuilder.js~SourceDocBuilder#exec",
    "method"
  ],
  [
    "src/publisher/builder/staticfilebuilder.js",
    "file/src/Publisher/Builder/StaticFileBuilder.js.html",
    "src/Publisher/Builder/StaticFileBuilder.js",
    "file"
  ],
  [
    "src/publisher/builder/staticfilebuilder.js~staticfilebuilder#exec",
    "class/src/Publisher/Builder/StaticFileBuilder.js~StaticFileBuilder.html#instance-method-exec",
    "src/Publisher/Builder/StaticFileBuilder.js~StaticFileBuilder#exec",
    "method"
  ],
  [
    "src/publisher/builder/testdocbuilder.js",
    "file/src/Publisher/Builder/TestDocBuilder.js.html",
    "src/Publisher/Builder/TestDocBuilder.js",
    "file"
  ],
  [
    "src/publisher/builder/testdocbuilder.js~testdocbuilder#_buildtestdescribedochtml",
    "class/src/Publisher/Builder/TestDocBuilder.js~TestDocBuilder.html#instance-method-_buildTestDescribeDocHTML",
    "src/Publisher/Builder/TestDocBuilder.js~TestDocBuilder#_buildTestDescribeDocHTML",
    "method"
  ],
  [
    "src/publisher/builder/testdocbuilder.js~testdocbuilder#_buildtestdochtml",
    "class/src/Publisher/Builder/TestDocBuilder.js~TestDocBuilder.html#instance-method-_buildTestDocHTML",
    "src/Publisher/Builder/TestDocBuilder.js~TestDocBuilder#_buildTestDocHTML",
    "method"
  ],
  [
    "src/publisher/builder/testdocbuilder.js~testdocbuilder#exec",
    "class/src/Publisher/Builder/TestDocBuilder.js~TestDocBuilder.html#instance-method-exec",
    "src/Publisher/Builder/TestDocBuilder.js~TestDocBuilder#exec",
    "method"
  ],
  [
    "src/publisher/builder/testfiledocbuilder.js",
    "file/src/Publisher/Builder/TestFileDocBuilder.js.html",
    "src/Publisher/Builder/TestFileDocBuilder.js",
    "file"
  ],
  [
    "src/publisher/builder/testfiledocbuilder.js~testfiledocbuilder#_buildfiledoc",
    "class/src/Publisher/Builder/TestFileDocBuilder.js~TestFileDocBuilder.html#instance-method-_buildFileDoc",
    "src/Publisher/Builder/TestFileDocBuilder.js~TestFileDocBuilder#_buildFileDoc",
    "method"
  ],
  [
    "src/publisher/builder/testfiledocbuilder.js~testfiledocbuilder#exec",
    "class/src/Publisher/Builder/TestFileDocBuilder.js~TestFileDocBuilder.html#instance-method-exec",
    "src/Publisher/Builder/TestFileDocBuilder.js~TestFileDocBuilder#exec",
    "method"
  ],
  [
    "src/publisher/builder/utils/dateforutc.js",
    "file/src/Publisher/Builder/utils/dateForUTC.js.html",
    "src/Publisher/Builder/utils/dateForUTC.js",
    "file"
  ],
  [
    "src/publisher/builder/utils/markdown.js",
    "file/src/Publisher/Builder/utils/markdown.js.html",
    "src/Publisher/Builder/utils/markdown.js",
    "file"
  ],
  [
    "src/publisher/builder/utils/parseexample.js",
    "file/src/Publisher/Builder/utils/parseExample.js.html",
    "src/Publisher/Builder/utils/parseExample.js",
    "file"
  ],
  [
    "src/publisher/builder/utils/shorten.js",
    "file/src/Publisher/Builder/utils/shorten.js.html",
    "src/Publisher/Builder/utils/shorten.js",
    "file"
  ],
  [
    "src/publisher/publish.js",
    "file/src/Publisher/publish.js.html",
    "src/Publisher/publish.js",
    "file"
  ],
  [
    "src/typedef/typedef.js",
    "file/src/Typedef/typedef.js.html",
    "src/Typedef/typedef.js",
    "file"
  ],
  [
    "src/typedef/typedef.js~ast",
    "typedef/index.html#static-typedef-AST",
    "src/Typedef/typedef.js~AST",
    "typedef"
  ],
  [
    "src/typedef/typedef.js~astnode",
    "typedef/index.html#static-typedef-ASTNode",
    "src/Typedef/typedef.js~ASTNode",
    "typedef"
  ],
  [
    "src/typedef/typedef.js~coverageobject",
    "typedef/index.html#static-typedef-CoverageObject",
    "src/Typedef/typedef.js~CoverageObject",
    "typedef"
  ],
  [
    "src/typedef/typedef.js~docobject",
    "typedef/index.html#static-typedef-DocObject",
    "src/Typedef/typedef.js~DocObject",
    "typedef"
  ],
  [
    "src/typedef/typedef.js~doctypedef",
    "typedef/index.html#static-typedef-DocTypedef",
    "src/Typedef/typedef.js~DocTypedef",
    "typedef"
  ],
  [
    "src/typedef/typedef.js~esdoccliargv",
    "typedef/index.html#static-typedef-ESDocCLIArgv",
    "src/Typedef/typedef.js~ESDocCLIArgv",
    "typedef"
  ],
  [
    "src/typedef/typedef.js~esdocconfig",
    "typedef/index.html#static-typedef-ESDocConfig",
    "src/Typedef/typedef.js~ESDocConfig",
    "typedef"
  ],
  [
    "src/typedef/typedef.js~icecap",
    "typedef/index.html#static-typedef-IceCap",
    "src/Typedef/typedef.js~IceCap",
    "typedef"
  ],
  [
    "src/typedef/typedef.js~icecapinstancetypedef",
    "typedef/index.html#static-typedef-IceCapInstanceTypedef",
    "src/Typedef/typedef.js~IceCapInstanceTypedef",
    "typedef"
  ],
  [
    "src/typedef/typedef.js~manualconfigitem",
    "typedef/index.html#static-typedef-ManualConfigItem",
    "src/Typedef/typedef.js~ManualConfigItem",
    "typedef"
  ],
  [
    "src/typedef/typedef.js~npmpackageobject",
    "typedef/index.html#static-typedef-NPMPackageObject",
    "src/Typedef/typedef.js~NPMPackageObject",
    "typedef"
  ],
  [
    "src/typedef/typedef.js~packagetypedef",
    "typedef/index.html#static-typedef-PackageTypedef",
    "src/Typedef/typedef.js~PackageTypedef",
    "typedef"
  ],
  [
    "src/typedef/typedef.js~parsedparam",
    "typedef/index.html#static-typedef-ParsedParam",
    "src/Typedef/typedef.js~ParsedParam",
    "typedef"
  ],
  [
    "src/typedef/typedef.js~taffy",
    "typedef/index.html#static-typedef-Taffy",
    "src/Typedef/typedef.js~Taffy",
    "typedef"
  ],
  [
    "src/typedef/typedef.js~taffycursor",
    "typedef/index.html#static-typedef-TaffyCursor",
    "src/Typedef/typedef.js~TaffyCursor",
    "typedef"
  ],
  [
    "src/typedef/typedef.js~tag",
    "typedef/index.html#static-typedef-Tag",
    "src/Typedef/typedef.js~Tag",
    "typedef"
  ],
  [
    "src/babylon/parser/babylonparser.js",
    "file/src/babylon/parser/BabylonParser.js.html",
    "src/babylon/parser/BabylonParser.js",
    "file"
  ],
  [
    "src/babylon/parser/babylonparser.js~babylonparser.parsecode",
    "class/src/babylon/parser/BabylonParser.js~BabylonParser.html#static-method-parseCode",
    "src/babylon/parser/BabylonParser.js~BabylonParser.parseCode",
    "method"
  ],
  [
    "src/babylon/parser/babylonparser.js~babylonparser.parsefile",
    "class/src/babylon/parser/BabylonParser.js~BabylonParser.html#static-method-parseFile",
    "src/babylon/parser/BabylonParser.js~BabylonParser.parseFile",
    "method"
  ],
  [
    "src/babylon/utils/babylonastutil.js",
    "file/src/babylon/utils/BabylonASTUtil.js.html",
    "src/babylon/utils/BabylonASTUtil.js",
    "file"
  ],
  [
    "src/babylon/utils/babylonastutil.js~babylonastutil.createvariabledeclarationandnewexpressionnode",
    "class/src/babylon/utils/BabylonASTUtil.js~BabylonASTUtil.html#static-method-createVariableDeclarationAndNewExpressionNode",
    "src/babylon/utils/BabylonASTUtil.js~BabylonASTUtil.createVariableDeclarationAndNewExpressionNode",
    "method"
  ],
  [
    "src/babylon/utils/babylonastutil.js~babylonastutil.findclassdeclarationnode",
    "class/src/babylon/utils/BabylonASTUtil.js~BabylonASTUtil.html#static-method-findClassDeclarationNode",
    "src/babylon/utils/BabylonASTUtil.js~BabylonASTUtil.findClassDeclarationNode",
    "method"
  ],
  [
    "src/babylon/utils/babylonastutil.js~babylonastutil.findfunctiondeclarationnode",
    "class/src/babylon/utils/BabylonASTUtil.js~BabylonASTUtil.html#static-method-findFunctionDeclarationNode",
    "src/babylon/utils/BabylonASTUtil.js~BabylonASTUtil.findFunctionDeclarationNode",
    "method"
  ],
  [
    "src/babylon/utils/babylonastutil.js~babylonastutil.findpathinimportdeclaration",
    "class/src/babylon/utils/BabylonASTUtil.js~BabylonASTUtil.html#static-method-findPathInImportDeclaration",
    "src/babylon/utils/BabylonASTUtil.js~BabylonASTUtil.findPathInImportDeclaration",
    "method"
  ],
  [
    "src/babylon/utils/babylonastutil.js~babylonastutil.findvariabledeclarationandnewexpressionnode",
    "class/src/babylon/utils/BabylonASTUtil.js~BabylonASTUtil.html#static-method-findVariableDeclarationAndNewExpressionNode",
    "src/babylon/utils/BabylonASTUtil.js~BabylonASTUtil.findVariableDeclarationAndNewExpressionNode",
    "method"
  ],
  [
    "src/babylon/utils/babylonastutil.js~babylonastutil.findvariabledeclarationnode",
    "class/src/babylon/utils/BabylonASTUtil.js~BabylonASTUtil.html#static-method-findVariableDeclarationNode",
    "src/babylon/utils/BabylonASTUtil.js~BabylonASTUtil.findVariableDeclarationNode",
    "method"
  ],
  [
    "src/babylon/utils/babylonastutil.js~babylonastutil.sanitize",
    "class/src/babylon/utils/BabylonASTUtil.js~BabylonASTUtil.html#static-method-sanitize",
    "src/babylon/utils/BabylonASTUtil.js~BabylonASTUtil.sanitize",
    "method"
  ],
  [
    "src/common/doc/abstractdoc.js",
    "file/src/common/doc/AbstractDoc.js.html",
    "src/common/doc/AbstractDoc.js",
    "file"
  ],
  [
    "src/common/doc/abstractdoc.js~abstractdoc#_$abstract",
    "class/src/common/doc/AbstractDoc.js~AbstractDoc.html#instance-method-_$abstract",
    "src/common/doc/AbstractDoc.js~AbstractDoc#_$abstract",
    "method"
  ],
  [
    "src/common/doc/abstractdoc.js~abstractdoc#_$access",
    "class/src/common/doc/AbstractDoc.js~AbstractDoc.html#instance-method-_$access",
    "src/common/doc/AbstractDoc.js~AbstractDoc#_$access",
    "method"
  ],
  [
    "src/common/doc/abstractdoc.js~abstractdoc#_$async",
    "class/src/common/doc/AbstractDoc.js~AbstractDoc.html#instance-method-_$async",
    "src/common/doc/AbstractDoc.js~AbstractDoc#_$async",
    "method"
  ],
  [
    "src/common/doc/abstractdoc.js~abstractdoc#_$content",
    "class/src/common/doc/AbstractDoc.js~AbstractDoc.html#instance-method-_$content",
    "src/common/doc/AbstractDoc.js~AbstractDoc#_$content",
    "method"
  ],
  [
    "src/common/doc/abstractdoc.js~abstractdoc#_$decorator",
    "class/src/common/doc/AbstractDoc.js~AbstractDoc.html#instance-method-_$decorator",
    "src/common/doc/AbstractDoc.js~AbstractDoc#_$decorator",
    "method"
  ],
  [
    "src/common/doc/abstractdoc.js~abstractdoc#_$deprecated",
    "class/src/common/doc/AbstractDoc.js~AbstractDoc.html#instance-method-_$deprecated",
    "src/common/doc/AbstractDoc.js~AbstractDoc#_$deprecated",
    "method"
  ],
  [
    "src/common/doc/abstractdoc.js~abstractdoc#_$desc",
    "class/src/common/doc/AbstractDoc.js~AbstractDoc.html#instance-method-_$desc",
    "src/common/doc/AbstractDoc.js~AbstractDoc#_$desc",
    "method"
  ],
  [
    "src/common/doc/abstractdoc.js~abstractdoc#_$emits",
    "class/src/common/doc/AbstractDoc.js~AbstractDoc.html#instance-method-_$emits",
    "src/common/doc/AbstractDoc.js~AbstractDoc#_$emits",
    "method"
  ],
  [
    "src/common/doc/abstractdoc.js~abstractdoc#_$example",
    "class/src/common/doc/AbstractDoc.js~AbstractDoc.html#instance-method-_$example",
    "src/common/doc/AbstractDoc.js~AbstractDoc#_$example",
    "method"
  ],
  [
    "src/common/doc/abstractdoc.js~abstractdoc#_$experimental",
    "class/src/common/doc/AbstractDoc.js~AbstractDoc.html#instance-method-_$experimental",
    "src/common/doc/AbstractDoc.js~AbstractDoc#_$experimental",
    "method"
  ],
  [
    "src/common/doc/abstractdoc.js~abstractdoc#_$export",
    "class/src/common/doc/AbstractDoc.js~AbstractDoc.html#instance-method-_$export",
    "src/common/doc/AbstractDoc.js~AbstractDoc#_$export",
    "method"
  ],
  [
    "src/common/doc/abstractdoc.js~abstractdoc#_$generator",
    "class/src/common/doc/AbstractDoc.js~AbstractDoc.html#instance-method-_$generator",
    "src/common/doc/AbstractDoc.js~AbstractDoc#_$generator",
    "method"
  ],
  [
    "src/common/doc/abstractdoc.js~abstractdoc#_$ignore",
    "class/src/common/doc/AbstractDoc.js~AbstractDoc.html#instance-method-_$ignore",
    "src/common/doc/AbstractDoc.js~AbstractDoc#_$ignore",
    "method"
  ],
  [
    "src/common/doc/abstractdoc.js~abstractdoc#_$importpath",
    "class/src/common/doc/AbstractDoc.js~AbstractDoc.html#instance-method-_$importPath",
    "src/common/doc/AbstractDoc.js~AbstractDoc#_$importPath",
    "method"
  ],
  [
    "src/common/doc/abstractdoc.js~abstractdoc#_$importstyle",
    "class/src/common/doc/AbstractDoc.js~AbstractDoc.html#instance-method-_$importStyle",
    "src/common/doc/AbstractDoc.js~AbstractDoc#_$importStyle",
    "method"
  ],
  [
    "src/common/doc/abstractdoc.js~abstractdoc#_$kind",
    "class/src/common/doc/AbstractDoc.js~AbstractDoc.html#instance-method-_$kind",
    "src/common/doc/AbstractDoc.js~AbstractDoc#_$kind",
    "method"
  ],
  [
    "src/common/doc/abstractdoc.js~abstractdoc#_$linenumber",
    "class/src/common/doc/AbstractDoc.js~AbstractDoc.html#instance-method-_$lineNumber",
    "src/common/doc/AbstractDoc.js~AbstractDoc#_$lineNumber",
    "method"
  ],
  [
    "src/common/doc/abstractdoc.js~abstractdoc#_$listens",
    "class/src/common/doc/AbstractDoc.js~AbstractDoc.html#instance-method-_$listens",
    "src/common/doc/AbstractDoc.js~AbstractDoc#_$listens",
    "method"
  ],
  [
    "src/common/doc/abstractdoc.js~abstractdoc#_$longname",
    "class/src/common/doc/AbstractDoc.js~AbstractDoc.html#instance-method-_$longname",
    "src/common/doc/AbstractDoc.js~AbstractDoc#_$longname",
    "method"
  ],
  [
    "src/common/doc/abstractdoc.js~abstractdoc#_$member",
    "class/src/common/doc/AbstractDoc.js~AbstractDoc.html#instance-method-_$member",
    "src/common/doc/AbstractDoc.js~AbstractDoc#_$member",
    "method"
  ],
  [
    "src/common/doc/abstractdoc.js~abstractdoc#_$memberof",
    "class/src/common/doc/AbstractDoc.js~AbstractDoc.html#instance-method-_$memberof",
    "src/common/doc/AbstractDoc.js~AbstractDoc#_$memberof",
    "method"
  ],
  [
    "src/common/doc/abstractdoc.js~abstractdoc#_$name",
    "class/src/common/doc/AbstractDoc.js~AbstractDoc.html#instance-method-_$name",
    "src/common/doc/AbstractDoc.js~AbstractDoc#_$name",
    "method"
  ],
  [
    "src/common/doc/abstractdoc.js~abstractdoc#_$override",
    "class/src/common/doc/AbstractDoc.js~AbstractDoc.html#instance-method-_$override",
    "src/common/doc/AbstractDoc.js~AbstractDoc#_$override",
    "method"
  ],
  [
    "src/common/doc/abstractdoc.js~abstractdoc#_$param",
    "class/src/common/doc/AbstractDoc.js~AbstractDoc.html#instance-method-_$param",
    "src/common/doc/AbstractDoc.js~AbstractDoc#_$param",
    "method"
  ],
  [
    "src/common/doc/abstractdoc.js~abstractdoc#_$private",
    "class/src/common/doc/AbstractDoc.js~AbstractDoc.html#instance-method-_$private",
    "src/common/doc/AbstractDoc.js~AbstractDoc#_$private",
    "method"
  ],
  [
    "src/common/doc/abstractdoc.js~abstractdoc#_$property",
    "class/src/common/doc/AbstractDoc.js~AbstractDoc.html#instance-method-_$property",
    "src/common/doc/AbstractDoc.js~AbstractDoc#_$property",
    "method"
  ],
  [
    "src/common/doc/abstractdoc.js~abstractdoc#_$protected",
    "class/src/common/doc/AbstractDoc.js~AbstractDoc.html#instance-method-_$protected",
    "src/common/doc/AbstractDoc.js~AbstractDoc#_$protected",
    "method"
  ],
  [
    "src/common/doc/abstractdoc.js~abstractdoc#_$pseudoexport",
    "class/src/common/doc/AbstractDoc.js~AbstractDoc.html#instance-method-_$pseudoExport",
    "src/common/doc/AbstractDoc.js~AbstractDoc#_$pseudoExport",
    "method"
  ],
  [
    "src/common/doc/abstractdoc.js~abstractdoc#_$public",
    "class/src/common/doc/AbstractDoc.js~AbstractDoc.html#instance-method-_$public",
    "src/common/doc/AbstractDoc.js~AbstractDoc#_$public",
    "method"
  ],
  [
    "src/common/doc/abstractdoc.js~abstractdoc#_$return",
    "class/src/common/doc/AbstractDoc.js~AbstractDoc.html#instance-method-_$return",
    "src/common/doc/AbstractDoc.js~AbstractDoc#_$return",
    "method"
  ],
  [
    "src/common/doc/abstractdoc.js~abstractdoc#_$see",
    "class/src/common/doc/AbstractDoc.js~AbstractDoc.html#instance-method-_$see",
    "src/common/doc/AbstractDoc.js~AbstractDoc#_$see",
    "method"
  ],
  [
    "src/common/doc/abstractdoc.js~abstractdoc#_$since",
    "class/src/common/doc/AbstractDoc.js~AbstractDoc.html#instance-method-_$since",
    "src/common/doc/AbstractDoc.js~AbstractDoc#_$since",
    "method"
  ],
  [
    "src/common/doc/abstractdoc.js~abstractdoc#_$static",
    "class/src/common/doc/AbstractDoc.js~AbstractDoc.html#instance-method-_$static",
    "src/common/doc/AbstractDoc.js~AbstractDoc#_$static",
    "method"
  ],
  [
    "src/common/doc/abstractdoc.js~abstractdoc#_$throws",
    "class/src/common/doc/AbstractDoc.js~AbstractDoc.html#instance-method-_$throws",
    "src/common/doc/AbstractDoc.js~AbstractDoc#_$throws",
    "method"
  ],
  [
    "src/common/doc/abstractdoc.js~abstractdoc#_$todo",
    "class/src/common/doc/AbstractDoc.js~AbstractDoc.html#instance-method-_$todo",
    "src/common/doc/AbstractDoc.js~AbstractDoc#_$todo",
    "method"
  ],
  [
    "src/common/doc/abstractdoc.js~abstractdoc#_$type",
    "class/src/common/doc/AbstractDoc.js~AbstractDoc.html#instance-method-_$type",
    "src/common/doc/AbstractDoc.js~AbstractDoc#_$type",
    "method"
  ],
  [
    "src/common/doc/abstractdoc.js~abstractdoc#_$undocument",
    "class/src/common/doc/AbstractDoc.js~AbstractDoc.html#instance-method-_$undocument",
    "src/common/doc/AbstractDoc.js~AbstractDoc#_$undocument",
    "method"
  ],
  [
    "src/common/doc/abstractdoc.js~abstractdoc#_$unknown",
    "class/src/common/doc/AbstractDoc.js~AbstractDoc.html#instance-method-_$unknown",
    "src/common/doc/AbstractDoc.js~AbstractDoc#_$unknown",
    "method"
  ],
  [
    "src/common/doc/abstractdoc.js~abstractdoc#_$variation",
    "class/src/common/doc/AbstractDoc.js~AbstractDoc.html#instance-method-_$variation",
    "src/common/doc/AbstractDoc.js~AbstractDoc#_$variation",
    "method"
  ],
  [
    "src/common/doc/abstractdoc.js~abstractdoc#_$version",
    "class/src/common/doc/AbstractDoc.js~AbstractDoc.html#instance-method-_$version",
    "src/common/doc/AbstractDoc.js~AbstractDoc#_$version",
    "method"
  ],
  [
    "src/common/doc/abstractdoc.js~abstractdoc#_apply",
    "class/src/common/doc/AbstractDoc.js~AbstractDoc.html#instance-method-_apply",
    "src/common/doc/AbstractDoc.js~AbstractDoc#_apply",
    "method"
  ],
  [
    "src/common/doc/abstractdoc.js~abstractdoc#_ast",
    "class/src/common/doc/AbstractDoc.js~AbstractDoc.html#instance-member-_ast",
    "src/common/doc/AbstractDoc.js~AbstractDoc#_ast",
    "member"
  ],
  [
    "src/common/doc/abstractdoc.js~abstractdoc#_commenttags",
    "class/src/common/doc/AbstractDoc.js~AbstractDoc.html#instance-member-_commentTags",
    "src/common/doc/AbstractDoc.js~AbstractDoc#_commentTags",
    "member"
  ],
  [
    "src/common/doc/abstractdoc.js~abstractdoc#_find",
    "class/src/common/doc/AbstractDoc.js~AbstractDoc.html#instance-method-_find",
    "src/common/doc/AbstractDoc.js~AbstractDoc#_find",
    "method"
  ],
  [
    "src/common/doc/abstractdoc.js~abstractdoc#_findall",
    "class/src/common/doc/AbstractDoc.js~AbstractDoc.html#instance-method-_findAll",
    "src/common/doc/AbstractDoc.js~AbstractDoc#_findAll",
    "method"
  ],
  [
    "src/common/doc/abstractdoc.js~abstractdoc#_findalltagvalues",
    "class/src/common/doc/AbstractDoc.js~AbstractDoc.html#instance-method-_findAllTagValues",
    "src/common/doc/AbstractDoc.js~AbstractDoc#_findAllTagValues",
    "method"
  ],
  [
    "src/common/doc/abstractdoc.js~abstractdoc#_findclasslongname",
    "class/src/common/doc/AbstractDoc.js~AbstractDoc.html#instance-method-_findClassLongname",
    "src/common/doc/AbstractDoc.js~AbstractDoc#_findClassLongname",
    "method"
  ],
  [
    "src/common/doc/abstractdoc.js~abstractdoc#_findtagvalue",
    "class/src/common/doc/AbstractDoc.js~AbstractDoc.html#instance-method-_findTagValue",
    "src/common/doc/AbstractDoc.js~AbstractDoc#_findTagValue",
    "method"
  ],
  [
    "src/common/doc/abstractdoc.js~abstractdoc#_flattenmemberexpression",
    "class/src/common/doc/AbstractDoc.js~AbstractDoc.html#instance-method-_flattenMemberExpression",
    "src/common/doc/AbstractDoc.js~AbstractDoc#_flattenMemberExpression",
    "method"
  ],
  [
    "src/common/doc/abstractdoc.js~abstractdoc#_node",
    "class/src/common/doc/AbstractDoc.js~AbstractDoc.html#instance-member-_node",
    "src/common/doc/AbstractDoc.js~AbstractDoc#_node",
    "member"
  ],
  [
    "src/common/doc/abstractdoc.js~abstractdoc#_pathresolver",
    "class/src/common/doc/AbstractDoc.js~AbstractDoc.html#instance-member-_pathResolver",
    "src/common/doc/AbstractDoc.js~AbstractDoc#_pathResolver",
    "member"
  ],
  [
    "src/common/doc/abstractdoc.js~abstractdoc#_resolvelongname",
    "class/src/common/doc/AbstractDoc.js~AbstractDoc.html#instance-method-_resolveLongname",
    "src/common/doc/AbstractDoc.js~AbstractDoc#_resolveLongname",
    "method"
  ],
  [
    "src/common/doc/abstractdoc.js~abstractdoc#_value",
    "class/src/common/doc/AbstractDoc.js~AbstractDoc.html#instance-member-_value",
    "src/common/doc/AbstractDoc.js~AbstractDoc#_value",
    "member"
  ],
  [
    "src/common/doc/abstractdoc.js~abstractdoc#constructor",
    "class/src/common/doc/AbstractDoc.js~AbstractDoc.html#instance-constructor-constructor",
    "src/common/doc/AbstractDoc.js~AbstractDoc#constructor",
    "method"
  ],
  [
    "src/common/doc/abstractdoc.js~abstractdoc#value",
    "class/src/common/doc/AbstractDoc.js~AbstractDoc.html#instance-get-value",
    "src/common/doc/AbstractDoc.js~AbstractDoc#value",
    "member"
  ],
  [
    "src/common/utils/astnodecontainer.js",
    "file/src/common/utils/ASTNodeContainer.js.html",
    "src/common/utils/ASTNodeContainer.js",
    "file"
  ],
  [
    "src/common/utils/astnodecontainer.js~astnodecontainer#_docid",
    "class/src/common/utils/ASTNodeContainer.js~ASTNodeContainer.html#instance-member-_docId",
    "src/common/utils/ASTNodeContainer.js~ASTNodeContainer#_docId",
    "member"
  ],
  [
    "src/common/utils/astnodecontainer.js~astnodecontainer#_nodes",
    "class/src/common/utils/ASTNodeContainer.js~ASTNodeContainer.html#instance-member-_nodes",
    "src/common/utils/ASTNodeContainer.js~ASTNodeContainer#_nodes",
    "member"
  ],
  [
    "src/common/utils/astnodecontainer.js~astnodecontainer#add",
    "class/src/common/utils/ASTNodeContainer.js~ASTNodeContainer.html#instance-method-add",
    "src/common/utils/ASTNodeContainer.js~ASTNodeContainer#add",
    "method"
  ],
  [
    "src/common/utils/astnodecontainer.js~astnodecontainer#constructor",
    "class/src/common/utils/ASTNodeContainer.js~ASTNodeContainer.html#instance-constructor-constructor",
    "src/common/utils/ASTNodeContainer.js~ASTNodeContainer#constructor",
    "method"
  ],
  [
    "src/common/utils/astnodecontainer.js~astnodecontainer#get",
    "class/src/common/utils/ASTNodeContainer.js~ASTNodeContainer.html#instance-method-get",
    "src/common/utils/ASTNodeContainer.js~ASTNodeContainer#get",
    "method"
  ],
  [
    "src/common/utils/astutil.js",
    "file/src/common/utils/ASTUtil.js.html",
    "src/common/utils/ASTUtil.js",
    "file"
  ],
  [
    "src/common/utils/invalidcodelogger.js",
    "file/src/common/utils/InvalidCodeLogger.js.html",
    "src/common/utils/InvalidCodeLogger.js",
    "file"
  ],
  [
    "src/common/utils/invalidcodelogger.js~invalidcodelogger#_logs",
    "class/src/common/utils/InvalidCodeLogger.js~InvalidCodeLogger.html#instance-member-_logs",
    "src/common/utils/InvalidCodeLogger.js~InvalidCodeLogger#_logs",
    "member"
  ],
  [
    "src/common/utils/invalidcodelogger.js~invalidcodelogger#constructor",
    "class/src/common/utils/InvalidCodeLogger.js~InvalidCodeLogger.html#instance-constructor-constructor",
    "src/common/utils/InvalidCodeLogger.js~InvalidCodeLogger#constructor",
    "method"
  ],
  [
    "src/common/utils/invalidcodelogger.js~invalidcodelogger#getlogs",
    "class/src/common/utils/InvalidCodeLogger.js~InvalidCodeLogger.html#instance-method-getLogs",
    "src/common/utils/InvalidCodeLogger.js~InvalidCodeLogger#getLogs",
    "method"
  ],
  [
    "src/common/utils/invalidcodelogger.js~invalidcodelogger#show",
    "class/src/common/utils/InvalidCodeLogger.js~InvalidCodeLogger.html#instance-method-show",
    "src/common/utils/InvalidCodeLogger.js~InvalidCodeLogger#show",
    "method"
  ],
  [
    "src/common/utils/invalidcodelogger.js~invalidcodelogger#showerror",
    "class/src/common/utils/InvalidCodeLogger.js~InvalidCodeLogger.html#instance-method-showError",
    "src/common/utils/InvalidCodeLogger.js~InvalidCodeLogger#showError",
    "method"
  ],
  [
    "src/common/utils/invalidcodelogger.js~invalidcodelogger#showfile",
    "class/src/common/utils/InvalidCodeLogger.js~InvalidCodeLogger.html#instance-method-showFile",
    "src/common/utils/InvalidCodeLogger.js~InvalidCodeLogger#showFile",
    "method"
  ],
  [
    "src/common/utils/logger.js",
    "file/src/common/utils/Logger.js.html",
    "src/common/utils/Logger.js",
    "file"
  ],
  [
    "src/common/utils/namingutil.js",
    "file/src/common/utils/NamingUtil.js.html",
    "src/common/utils/NamingUtil.js",
    "file"
  ],
  [
    "src/common/utils/namingutil.js~namingutil.filepathtoname",
    "class/src/common/utils/NamingUtil.js~NamingUtil.html#static-method-filePathToName",
    "src/common/utils/NamingUtil.js~NamingUtil.filePathToName",
    "method"
  ],
  [
    "src/common/utils/pathresolver.js",
    "file/src/common/utils/PathResolver.js.html",
    "src/common/utils/PathResolver.js",
    "file"
  ],
  [
    "src/common/utils/pathresolver.js~pathresolver#_filepath",
    "class/src/common/utils/PathResolver.js~PathResolver.html#instance-member-_filePath",
    "src/common/utils/PathResolver.js~PathResolver#_filePath",
    "member"
  ],
  [
    "src/common/utils/pathresolver.js~pathresolver#_indirpath",
    "class/src/common/utils/PathResolver.js~PathResolver.html#instance-member-_inDirPath",
    "src/common/utils/PathResolver.js~PathResolver#_inDirPath",
    "member"
  ],
  [
    "src/common/utils/pathresolver.js~pathresolver#_mainfilepath",
    "class/src/common/utils/PathResolver.js~PathResolver.html#instance-member-_mainFilePath",
    "src/common/utils/PathResolver.js~PathResolver#_mainFilePath",
    "member"
  ],
  [
    "src/common/utils/pathresolver.js~pathresolver#_packagename",
    "class/src/common/utils/PathResolver.js~PathResolver.html#instance-member-_packageName",
    "src/common/utils/PathResolver.js~PathResolver#_packageName",
    "member"
  ],
  [
    "src/common/utils/pathresolver.js~pathresolver#_slash",
    "class/src/common/utils/PathResolver.js~PathResolver.html#instance-method-_slash",
    "src/common/utils/PathResolver.js~PathResolver#_slash",
    "method"
  ],
  [
    "src/common/utils/pathresolver.js~pathresolver#constructor",
    "class/src/common/utils/PathResolver.js~PathResolver.html#instance-constructor-constructor",
    "src/common/utils/PathResolver.js~PathResolver#constructor",
    "method"
  ],
  [
    "src/common/utils/pathresolver.js~pathresolver#filefullpath",
    "class/src/common/utils/PathResolver.js~PathResolver.html#instance-get-fileFullPath",
    "src/common/utils/PathResolver.js~PathResolver#fileFullPath",
    "member"
  ],
  [
    "src/common/utils/pathresolver.js~pathresolver#filepath",
    "class/src/common/utils/PathResolver.js~PathResolver.html#instance-get-filePath",
    "src/common/utils/PathResolver.js~PathResolver#filePath",
    "member"
  ],
  [
    "src/common/utils/pathresolver.js~pathresolver#importpath",
    "class/src/common/utils/PathResolver.js~PathResolver.html#instance-get-importPath",
    "src/common/utils/PathResolver.js~PathResolver#importPath",
    "member"
  ],
  [
    "src/common/utils/pathresolver.js~pathresolver#resolve",
    "class/src/common/utils/PathResolver.js~PathResolver.html#instance-method-resolve",
    "src/common/utils/PathResolver.js~PathResolver#resolve",
    "method"
  ],
  [
    "esdoccli#exec esdoccli#_createconfigfromjsonfile src/esdoccli.js~esdoccli#exec,esdoccli#exec src/esdoccli.js~esdoccli#_createconfigfromjsonfile,esdoccli#_createconfigfromjsonfile",
    "test-file/src/ConfigTest/CLITest.js.html#lineNumber9",
    "test cli",
    "test"
  ],
  [
    "",
    "test-file/src/ConfigTest/CLITest.js.html#lineNumber14",
    "test cli can execute with config file.",
    "test"
  ],
  [
    "",
    "test-file/src/ConfigTest/CLITest.js.html#lineNumber24",
    "test cli can show help",
    "test"
  ],
  [
    "",
    "test-file/src/ConfigTest/CLITest.js.html#lineNumber34",
    "test cli can show version",
    "test"
  ],
  [
    "docresolver#_resolveaccess src/publisher/builder/docresolver.js~docresolver#_resolveaccess,docresolver#_resolveaccess",
    "test-file/src/ConfigTest/AccessTest.js.html#lineNumber4",
    "test config.access: [\"public\", \"protected\"]",
    "test"
  ],
  [
    "",
    "test-file/src/ConfigTest/AccessTest.js.html#lineNumber20",
    "test config.access: [\"public\", \"protected\"] class",
    "test"
  ],
  [
    "",
    "test-file/src/ConfigTest/AccessTest.js.html#lineNumber42",
    "test config.access: [\"public\", \"protected\"] class does not have auto private class",
    "test"
  ],
  [
    "",
    "test-file/src/ConfigTest/AccessTest.js.html#lineNumber34",
    "test config.access: [\"public\", \"protected\"] class does not have private class",
    "test"
  ],
  [
    "",
    "test-file/src/ConfigTest/AccessTest.js.html#lineNumber28",
    "test config.access: [\"public\", \"protected\"] class have protected class",
    "test"
  ],
  [
    "",
    "test-file/src/ConfigTest/AccessTest.js.html#lineNumber22",
    "test config.access: [\"public\", \"protected\"] class have public class",
    "test"
  ],
  [
    "",
    "test-file/src/ConfigTest/AccessTest.js.html#lineNumber113",
    "test config.access: [\"public\", \"protected\"] function",
    "test"
  ],
  [
    "",
    "test-file/src/ConfigTest/AccessTest.js.html#lineNumber135",
    "test config.access: [\"public\", \"protected\"] function does not have auto private function",
    "test"
  ],
  [
    "",
    "test-file/src/ConfigTest/AccessTest.js.html#lineNumber127",
    "test config.access: [\"public\", \"protected\"] function does not have private function",
    "test"
  ],
  [
    "",
    "test-file/src/ConfigTest/AccessTest.js.html#lineNumber122",
    "test config.access: [\"public\", \"protected\"] function have protected function",
    "test"
  ],
  [
    "",
    "test-file/src/ConfigTest/AccessTest.js.html#lineNumber117",
    "test config.access: [\"public\", \"protected\"] function have public function",
    "test"
  ],
  [
    "",
    "test-file/src/ConfigTest/AccessTest.js.html#lineNumber82",
    "test config.access: [\"public\", \"protected\"] member",
    "test"
  ],
  [
    "",
    "test-file/src/ConfigTest/AccessTest.js.html#lineNumber104",
    "test config.access: [\"public\", \"protected\"] member does not have auto private member",
    "test"
  ],
  [
    "",
    "test-file/src/ConfigTest/AccessTest.js.html#lineNumber96",
    "test config.access: [\"public\", \"protected\"] member does not have private member",
    "test"
  ],
  [
    "",
    "test-file/src/ConfigTest/AccessTest.js.html#lineNumber91",
    "test config.access: [\"public\", \"protected\"] member have protected member",
    "test"
  ],
  [
    "",
    "test-file/src/ConfigTest/AccessTest.js.html#lineNumber86",
    "test config.access: [\"public\", \"protected\"] member have public member",
    "test"
  ],
  [
    "",
    "test-file/src/ConfigTest/AccessTest.js.html#lineNumber51",
    "test config.access: [\"public\", \"protected\"] method",
    "test"
  ],
  [
    "",
    "test-file/src/ConfigTest/AccessTest.js.html#lineNumber73",
    "test config.access: [\"public\", \"protected\"] method does not have auto private method",
    "test"
  ],
  [
    "",
    "test-file/src/ConfigTest/AccessTest.js.html#lineNumber65",
    "test config.access: [\"public\", \"protected\"] method does not have private method",
    "test"
  ],
  [
    "",
    "test-file/src/ConfigTest/AccessTest.js.html#lineNumber60",
    "test config.access: [\"public\", \"protected\"] method have protected method",
    "test"
  ],
  [
    "",
    "test-file/src/ConfigTest/AccessTest.js.html#lineNumber55",
    "test config.access: [\"public\", \"protected\"] method have public method",
    "test"
  ],
  [
    "",
    "test-file/src/ConfigTest/AccessTest.js.html#lineNumber145",
    "test config.access: [\"public\", \"protected\"] variable",
    "test"
  ],
  [
    "",
    "test-file/src/ConfigTest/AccessTest.js.html#lineNumber167",
    "test config.access: [\"public\", \"protected\"] variable does not have auto private variable",
    "test"
  ],
  [
    "",
    "test-file/src/ConfigTest/AccessTest.js.html#lineNumber159",
    "test config.access: [\"public\", \"protected\"] variable does not have private variable",
    "test"
  ],
  [
    "",
    "test-file/src/ConfigTest/AccessTest.js.html#lineNumber154",
    "test config.access: [\"public\", \"protected\"] variable have protected variable",
    "test"
  ],
  [
    "",
    "test-file/src/ConfigTest/AccessTest.js.html#lineNumber149",
    "test config.access: [\"public\", \"protected\"] variable have public variable",
    "test"
  ],
  [
    "docresolver#_resolveaccess src/publisher/builder/docresolver.js~docresolver#_resolveaccess,docresolver#_resolveaccess",
    "test-file/src/ConfigTest/AutoPrivateTest.js.html#lineNumber4",
    "test config.autoPrivate: false",
    "test"
  ],
  [
    "",
    "test-file/src/ConfigTest/AutoPrivateTest.js.html#lineNumber20",
    "test config.autoPrivate: false treat _class as public",
    "test"
  ],
  [
    "",
    "test-file/src/ConfigTest/AutoPrivateTest.js.html#lineNumber38",
    "test config.autoPrivate: false treat _function as public",
    "test"
  ],
  [
    "",
    "test-file/src/ConfigTest/AutoPrivateTest.js.html#lineNumber32",
    "test config.autoPrivate: false treat _member as public",
    "test"
  ],
  [
    "",
    "test-file/src/ConfigTest/AutoPrivateTest.js.html#lineNumber26",
    "test config.autoPrivate: false treat _method as public",
    "test"
  ],
  [
    "",
    "test-file/src/ConfigTest/AutoPrivateTest.js.html#lineNumber44",
    "test config.autoPrivate: false treat _variable as public",
    "test"
  ],
  [
    "esdoc._usebuiltinexternal esdoc._usebuiltinexternal,esdoc._usebuiltinexternal",
    "test-file/src/ConfigTest/BuiltinExternalTest.js.html#lineNumber4",
    "test config.builtinExternal: false",
    "test"
  ],
  [
    "",
    "test-file/src/ConfigTest/BuiltinExternalTest.js.html#lineNumber20",
    "test config.builtinExternal: false does not have builtin external link",
    "test"
  ],
  [
    "coveragebuilder src/publisher/builder/coveragebuilder.js~coveragebuilder,coveragebuilder",
    "test-file/src/ConfigTest/CoverageTest.js.html#lineNumber4",
    "test config.coverage: false",
    "test"
  ],
  [
    "",
    "test-file/src/ConfigTest/CoverageTest.js.html#lineNumber20",
    "test config.coverage: false does not have coverage",
    "test"
  ],
  [
    "esdoc.generate src/esdoc.js~esdoc.generate,esdoc.generate",
    "test-file/src/ConfigTest/ExcludesTest.js.html#lineNumber4",
    "test config.excludes: [\"Class\\.js\"]",
    "test"
  ],
  [
    "",
    "test-file/src/ConfigTest/ExcludesTest.js.html#lineNumber20",
    "test config.excludes: [\"Class\\.js\"] does not have excluded identifier",
    "test"
  ],
  [
    "publish src/publisher/publish.js~publish,publish",
    "test-file/src/ConfigTest/IncludeSourceTest.js.html#lineNumber4",
    "test config.includeSource: false",
    "test"
  ],
  [
    "",
    "test-file/src/ConfigTest/IncludeSourceTest.js.html#lineNumber20",
    "test config.includeSource: false does not have source code.",
    "test"
  ],
  [
    "publish src/publisher/publish.js~publish,publish",
    "test-file/src/ConfigTest/LintTest.js.html#lineNumber5",
    "test config.lint: false",
    "test"
  ],
  [
    "",
    "test-file/src/ConfigTest/LintTest.js.html#lineNumber10",
    "test config.lint: false does not lint results when invalid code is exits",
    "test"
  ],
  [
    "manualdocbuilder src/publisher/builder/manualdocbuilder.js~manualdocbuilder,manualdocbuilder",
    "test-file/src/ConfigTest/ManualTest.js.html#lineNumber4",
    "test config.manual: null",
    "test"
  ],
  [
    "",
    "test-file/src/ConfigTest/ManualTest.js.html#lineNumber20",
    "test config.manual: null does not have manual.",
    "test"
  ],
  [
    "plugin plugin,plugin",
    "test-file/src/ConfigTest/PluginsTest.js.html#lineNumber5",
    "test config.plugins: [...]",
    "test"
  ],
  [
    "",
    "test-file/src/ConfigTest/PluginsTest.js.html#lineNumber22",
    "test config.plugins: [...] call each handlers",
    "test"
  ],
  [
    "",
    "test-file/src/ConfigTest/PluginsTest.js.html#lineNumber49",
    "test config.plugins: [...] call multi plugins",
    "test"
  ],
  [
    "",
    "test-file/src/ConfigTest/PluginsTest.js.html#lineNumber39",
    "test config.plugins: [...] custom document by each handlers",
    "test"
  ],
  [
    "docbuilder#_buildlayoutdoc src/publisher/builder/docbuilder.js~docbuilder#_buildlayoutdoc,docbuilder#_buildlayoutdoc",
    "test-file/src/ConfigTest/ScriptsTest.js.html#lineNumber4",
    "test config.scripts: [\"./test/fixture/script/custom.js\"]",
    "test"
  ],
  [
    "",
    "test-file/src/ConfigTest/ScriptsTest.js.html#lineNumber20",
    "test config.scripts: [\"./test/fixture/script/custom.js\"] has custom script",
    "test"
  ],
  [
    "docbuilder#_buildlayoutdoc src/publisher/builder/docbuilder.js~docbuilder#_buildlayoutdoc,docbuilder#_buildlayoutdoc",
    "test-file/src/ConfigTest/StylesTest.js.html#lineNumber4",
    "test config.styles: [\"./test/fixture/style/custom.css\"]",
    "test"
  ],
  [
    "",
    "test-file/src/ConfigTest/StylesTest.js.html#lineNumber20",
    "test config.styles: [\"./test/fixture/style/custom.css\"] has custom style",
    "test"
  ],
  [
    "publish src/publisher/publish.js~publish,publish",
    "test-file/src/ConfigTest/TestTest.js.html#lineNumber4",
    "test config.test: null",
    "test"
  ],
  [
    "",
    "test-file/src/ConfigTest/TestTest.js.html#lineNumber20",
    "test config.test: null does not have test integration",
    "test"
  ],
  [
    "docresolver#_resolveundocumentidentifier src/publisher/builder/docresolver.js~docresolver#_resolveundocumentidentifier,docresolver#_resolveundocumentidentifier",
    "test-file/src/ConfigTest/UndocumentIdentifierTest.js.html#lineNumber4",
    "test config.undocumentIdentifier: false",
    "test"
  ],
  [
    "",
    "test-file/src/ConfigTest/UndocumentIdentifierTest.js.html#lineNumber20",
    "test config.undocumentIdentifier: false does not have undocument identifier",
    "test"
  ],
  [
    "docresolver#_resolveunexportidentifier src/publisher/builder/docresolver.js~docresolver#_resolveunexportidentifier,docresolver#_resolveunexportidentifier",
    "test-file/src/ConfigTest/UnexportIdentifierTest.js.html#lineNumber4",
    "test config.unexportIdentifier: true",
    "test"
  ],
  [
    "",
    "test-file/src/ConfigTest/UnexportIdentifierTest.js.html#lineNumber20",
    "test config.unexportIdentifier: true has unexport identifier",
    "test"
  ],
  [
    "coveragebuilder src/publisher/builder/coveragebuilder.js~coveragebuilder,coveragebuilder",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber5",
    "test coverage",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber19",
    "test coverage has coverage details",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber40",
    "test coverage has coverage details file/src/Abstract/Definition.js.html",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber41",
    "test coverage has coverage details file/src/Abstract/Override.js.html",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber42",
    "test coverage has coverage details file/src/Access/Class.js.html",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber43",
    "test coverage has coverage details file/src/Access/Function.js.html",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber44",
    "test coverage has coverage details file/src/Access/Method.js.html",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber45",
    "test coverage has coverage details file/src/Access/Property.js.html#errorLines=6",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber46",
    "test coverage has coverage details file/src/Access/Variable.js.html",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber47",
    "test coverage has coverage details file/src/Async/Function.js.html",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber48",
    "test coverage has coverage details file/src/Async/Method.js.html",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber49",
    "test coverage has coverage details file/src/Class/Definition.js.html",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber50",
    "test coverage has coverage details file/src/ClassProperty/Definition.js.html",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber51",
    "test coverage has coverage details file/src/Computed/Method.js.html",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber52",
    "test coverage has coverage details file/src/Computed/Property.js.html",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber53",
    "test coverage has coverage details file/src/Decorator/Definition.js.html",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber54",
    "test coverage has coverage details file/src/Deprecated/Class.js.html#errorLines=7",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber55",
    "test coverage has coverage details file/src/Deprecated/Function.js.html",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber56",
    "test coverage has coverage details file/src/Deprecated/Variable.js.html",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber57",
    "test coverage has coverage details file/src/Desc/Class.js.html",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber58",
    "test coverage has coverage details file/src/Desc/Function.js.html",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber59",
    "test coverage has coverage details file/src/Desc/Markdown.js.html",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber60",
    "test coverage has coverage details file/src/Desc/MultiLine.js.html",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber61",
    "test coverage has coverage details file/src/Desc/Variable.js.html",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber62",
    "test coverage has coverage details file/src/Destructuring/Array.js.html",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber63",
    "test coverage has coverage details file/src/Destructuring/Object.js.html",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber64",
    "test coverage has coverage details file/src/Duplication/Definition.js.html",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber65",
    "test coverage has coverage details file/src/Emits/Function.js.html#errorLines=7",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber66",
    "test coverage has coverage details file/src/Emits/Method.js.html#errorLines=14,16",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber67",
    "test coverage has coverage details file/src/Example/Caption.js.html",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber68",
    "test coverage has coverage details file/src/Example/Class.js.html",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber69",
    "test coverage has coverage details file/src/Example/Function.js.html",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber70",
    "test coverage has coverage details file/src/Example/Variable.js.html",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber71",
    "test coverage has coverage details file/src/Experimental/Class.js.html",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber72",
    "test coverage has coverage details file/src/Experimental/Function.js.html",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber73",
    "test coverage has coverage details file/src/Experimental/Variable.js.html",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber74",
    "test coverage has coverage details file/src/ExponentiationOperator/Definition.js.html",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber75",
    "test coverage has coverage details file/src/Export/AnonymousClass.js.html",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber76",
    "test coverage has coverage details file/src/Export/AnonymousFunction.js.html",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber77",
    "test coverage has coverage details file/src/Export/ArrowFunction.js.html#errorLines=18",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber78",
    "test coverage has coverage details file/src/Export/Class.js.html#errorLines=25",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber79",
    "test coverage has coverage details file/src/Export/ClassIndirectDefault.js.html",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber80",
    "test coverage has coverage details file/src/Export/Default.js.html",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber81",
    "test coverage has coverage details file/src/Export/Extends.js.html",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber82",
    "test coverage has coverage details file/src/Export/Function.js.html#errorLines=33",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber83",
    "test coverage has coverage details file/src/Export/FunctionIndirectDefault.js.html",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber84",
    "test coverage has coverage details file/src/Export/Multiple.js.html",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber85",
    "test coverage has coverage details file/src/Export/Named.js.html",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber86",
    "test coverage has coverage details file/src/Export/NewExpression.js.html",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber87",
    "test coverage has coverage details file/src/Export/NewExpressionIndirect.js.html",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber88",
    "test coverage has coverage details file/src/Export/NewExpressionProperty.js.html",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber89",
    "test coverage has coverage details file/src/Export/Variable.js.html#errorLines=23,24",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber90",
    "test coverage has coverage details file/src/Export/VariableIndirectDefault.js.html",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber91",
    "test coverage has coverage details file/src/Extends/Builtin.js.html#errorLines=6",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber92",
    "test coverage has coverage details file/src/Extends/Deep.js.html#errorLines=1,12,14,16,18,22,24,26,28,3,30,33,35,37,39,43,45,47,49,5,51,54,56,58,60,7,9",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber93",
    "test coverage has coverage details file/src/Extends/Expression.js.html#errorLines=11",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber94",
    "test coverage has coverage details file/src/Extends/Inner.js.html#errorLines=1",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber95",
    "test coverage has coverage details file/src/Extends/Mixin.js.html#errorLines=17,9",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber96",
    "test coverage has coverage details file/src/Extends/Outer.js.html",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber97",
    "test coverage has coverage details file/src/Extends/Property.js.html",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber98",
    "test coverage has coverage details file/src/External/Definition.js.html",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber99",
    "test coverage has coverage details file/src/Generator/Function.js.html",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber100",
    "test coverage has coverage details file/src/Generator/Method.js.html",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber101",
    "test coverage has coverage details file/src/Guess/Param.js.html#errorLines=10,12,14,16,18,20,22,24,6,8",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber102",
    "test coverage has coverage details file/src/Guess/Property.js.html#errorLines=10,12,14,6,8",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber103",
    "test coverage has coverage details file/src/Guess/Return.js.html#errorLines=11,16,21,26,6",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber104",
    "test coverage has coverage details file/src/Guess/Variable.js.html#errorLines=1,3,5,7",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber105",
    "test coverage has coverage details file/src/Ignore/Class.js.html",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber106",
    "test coverage has coverage details file/src/Ignore/Function.js.html",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber107",
    "test coverage has coverage details file/src/Ignore/Variable.js.html",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber108",
    "test coverage has coverage details file/src/Interface/Definition.js.html",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber109",
    "test coverage has coverage details file/src/Interface/Implements.js.html",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber110",
    "test coverage has coverage details file/src/Invalid/DocSyntax.js.html",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber111",
    "test coverage has coverage details file/src/JSX/Definition.js.html",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber112",
    "test coverage has coverage details file/src/Link/Class.js.html",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber113",
    "test coverage has coverage details file/src/Link/Function.js.html",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber114",
    "test coverage has coverage details file/src/Link/Variable.js.html",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber115",
    "test coverage has coverage details file/src/Lint/Invalid.js.html",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber116",
    "test coverage has coverage details file/src/Listens/Function.js.html",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber117",
    "test coverage has coverage details file/src/Listens/Method.js.html",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber118",
    "test coverage has coverage details file/src/Param/Function.js.html",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber119",
    "test coverage has coverage details file/src/Param/Method.js.html",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber120",
    "test coverage has coverage details file/src/Property/Return.js.html",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber121",
    "test coverage has coverage details file/src/Return/Function.js.html",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber122",
    "test coverage has coverage details file/src/Return/Method.js.html",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber123",
    "test coverage has coverage details file/src/See/Class.js.html",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber124",
    "test coverage has coverage details file/src/See/Function.js.html",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber125",
    "test coverage has coverage details file/src/See/Variable.js.html",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber126",
    "test coverage has coverage details file/src/Since/Class.js.html",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber127",
    "test coverage has coverage details file/src/Since/Function.js.html",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber128",
    "test coverage has coverage details file/src/Since/Variable.js.html",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber129",
    "test coverage has coverage details file/src/Throws/Function.js.html",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber130",
    "test coverage has coverage details file/src/Throws/Method.js.html",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber131",
    "test coverage has coverage details file/src/Todo/Class.js.html",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber132",
    "test coverage has coverage details file/src/Todo/Function.js.html",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber133",
    "test coverage has coverage details file/src/Todo/Variable.js.html",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber134",
    "test coverage has coverage details file/src/TrailingComma/Definition.js.html",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber135",
    "test coverage has coverage details file/src/Type/Array.js.html",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber136",
    "test coverage has coverage details file/src/Type/Class.js.html#errorLines=11,2",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber137",
    "test coverage has coverage details file/src/Type/Complex.js.html#errorLines=2",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber138",
    "test coverage has coverage details file/src/Type/Default.js.html",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber139",
    "test coverage has coverage details file/src/Type/External.js.html",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber140",
    "test coverage has coverage details file/src/Type/Function.js.html",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber141",
    "test coverage has coverage details file/src/Type/Generics.js.html",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber142",
    "test coverage has coverage details file/src/Type/Literal.js.html",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber143",
    "test coverage has coverage details file/src/Type/Nullable.js.html#errorLines=2",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber144",
    "test coverage has coverage details file/src/Type/Object.js.html",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber145",
    "test coverage has coverage details file/src/Type/Optional.js.html",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber146",
    "test coverage has coverage details file/src/Type/Record.js.html",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber147",
    "test coverage has coverage details file/src/Type/Spread.js.html",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber148",
    "test coverage has coverage details file/src/Type/Typedef.js.html",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber149",
    "test coverage has coverage details file/src/Type/Union.js.html",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber150",
    "test coverage has coverage details file/src/Typedef/Definition.js.html",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber151",
    "test coverage has coverage details file/src/Undocument/Definition.js.html#errorLines=2",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber152",
    "test coverage has coverage details file/src/Unknown/Definition.js.html",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber153",
    "test coverage has coverage details file/src/Variable/ArrayPattern.js.html",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber154",
    "test coverage has coverage details file/src/Variable/Definition.js.html",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber155",
    "test coverage has coverage details file/src/Variable/ObjectPattern.js.html",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber156",
    "test coverage has coverage details file/src/Version/Class.js.html",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber157",
    "test coverage has coverage details file/src/Version/Function.js.html",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber158",
    "test coverage has coverage details file/src/Version/Variable.js.html",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/CoverageTest/CoverageTest.js.html#lineNumber10",
    "test coverage has coverage summary",
    "test"
  ],
  [
    "* classdocbuilder#_buildinheritedsummaryhtml *,* src/publisher/builder/classdocbuilder.js~classdocbuilder#_buildinheritedsummaryhtml,classdocbuilder#_buildinheritedsummaryhtml",
    "test-file/src/HTMLTest/DocumentTest/ExtendsTest/DeepTest.js.html#lineNumber7",
    "test deep extends",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ExtendsTest/DeepTest.js.html#lineNumber70",
    "test deep extends TestExtendsDeepRectangle",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ExtendsTest/DeepTest.js.html#lineNumber74",
    "test deep extends TestExtendsDeepRectangle has direct subclass.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ExtendsTest/DeepTest.js.html#lineNumber84",
    "test deep extends TestExtendsDeepShape",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ExtendsTest/DeepTest.js.html#lineNumber88",
    "test deep extends TestExtendsDeepShape has direct subclass.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ExtendsTest/DeepTest.js.html#lineNumber97",
    "test deep extends TestExtendsDeepShape has indirect subclass.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ExtendsTest/DeepTest.js.html#lineNumber9",
    "test deep extends TestExtendsDeepSquare",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ExtendsTest/DeepTest.js.html#lineNumber13",
    "test deep extends TestExtendsDeepSquare has extends chain.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ExtendsTest/DeepTest.js.html#lineNumber29",
    "test deep extends TestExtendsDeepSquare has super^1 class methods and more.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ExtendsTest/DeepTest.js.html#lineNumber49",
    "test deep extends TestExtendsDeepSquare has super^2 class methods and more.",
    "test"
  ],
  [
    "docfactory#_inspectexportdefaultdeclaration docfactory#_inspectexportnameddeclaration src/factory/docfactory.js~docfactory#_inspectexportdefaultdeclaration,docfactory#_inspectexportdefaultdeclaration src/factory/docfactory.js~docfactory#_inspectexportnameddeclaration,docfactory#_inspectexportnameddeclaration",
    "test-file/src/HTMLTest/DocumentTest/ExportTest/NewExpressionIndirectTest.js.html#lineNumber7",
    "test default export with new expression and indirect.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ExportTest/NewExpressionIndirectTest.js.html#lineNumber32",
    "test default export with new expression and indirect. has class description",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ExportTest/NewExpressionIndirectTest.js.html#lineNumber9",
    "test default export with new expression and indirect. has instance description",
    "test"
  ],
  [
    "docfactory#_inspectexportdefaultdeclaration docfactory#_inspectexportnameddeclaration src/factory/docfactory.js~docfactory#_inspectexportdefaultdeclaration,docfactory#_inspectexportdefaultdeclaration src/factory/docfactory.js~docfactory#_inspectexportnameddeclaration,docfactory#_inspectexportnameddeclaration",
    "test-file/src/HTMLTest/DocumentTest/ExportTest/NewExpressionPropertyTest.js.html#lineNumber7",
    "test default export with new expression and property.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ExportTest/NewExpressionPropertyTest.js.html#lineNumber32",
    "test default export with new expression and property. has class description",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ExportTest/NewExpressionPropertyTest.js.html#lineNumber9",
    "test default export with new expression and property. has instance description",
    "test"
  ],
  [
    "docfactory#_inspectexportdefaultdeclaration docfactory#_inspectexportnameddeclaration src/factory/docfactory.js~docfactory#_inspectexportdefaultdeclaration,docfactory#_inspectexportdefaultdeclaration src/factory/docfactory.js~docfactory#_inspectexportnameddeclaration,docfactory#_inspectexportnameddeclaration",
    "test-file/src/HTMLTest/DocumentTest/ExportTest/NewExpressionTest.js.html#lineNumber7",
    "test default export with new expression.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ExportTest/NewExpressionTest.js.html#lineNumber9",
    "test default export with new expression. default export",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ExportTest/NewExpressionTest.js.html#lineNumber34",
    "test default export with new expression. default export has class description",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ExportTest/NewExpressionTest.js.html#lineNumber11",
    "test default export with new expression. default export has instance description",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ExportTest/NewExpressionTest.js.html#lineNumber54",
    "test default export with new expression. named export",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ExportTest/NewExpressionTest.js.html#lineNumber79",
    "test default export with new expression. named export has class description",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ExportTest/NewExpressionTest.js.html#lineNumber56",
    "test default export with new expression. named export has instance description",
    "test"
  ],
  [
    "* *,*",
    "test-file/src/HTMLTest/DocumentTest/ExportTest/ArrowFunctionTest.js.html#lineNumber4",
    "test export arrow function",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ExportTest/ArrowFunctionTest.js.html#lineNumber8",
    "test export arrow function has default import path with direct arrow function definition.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ExportTest/ArrowFunctionTest.js.html#lineNumber17",
    "test export arrow function has named import path with direct arrow function definition.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ExportTest/ArrowFunctionTest.js.html#lineNumber48",
    "test export arrow function has named import path with indirect function definition.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ExportTest/ArrowFunctionTest.js.html#lineNumber39",
    "test export arrow function has named import path with undocument",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ExportTest/ArrowFunctionTest.js.html#lineNumber26",
    "test export arrow function is not documented with direct arrow function expression",
    "test"
  ],
  [
    "* * *,* *,*",
    "test-file/src/HTMLTest/DocumentTest/ExportTest/ClassTest.js.html#lineNumber7",
    "test export class",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ExportTest/ClassTest.js.html#lineNumber9",
    "test export class has default import path with direct class definition.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ExportTest/ClassTest.js.html#lineNumber17",
    "test export class has named import path with direct.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ExportTest/ClassTest.js.html#lineNumber25",
    "test export class has named import path with indirect class definition",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ExportTest/ClassTest.js.html#lineNumber33",
    "test export class has named import path with indirect class expression",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ExportTest/ClassTest.js.html#lineNumber41",
    "test export class has named import path with undocument",
    "test"
  ],
  [
    "* * *,* *,*",
    "test-file/src/HTMLTest/DocumentTest/ExportTest/ClassIndirectDefaultTest.js.html#lineNumber7",
    "test export class indirect default",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ExportTest/ClassIndirectDefaultTest.js.html#lineNumber9",
    "test export class indirect default has default import path with indirect class definition.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ExportTest/ClassTest.js.html#lineNumber49",
    "test export class is not documented.",
    "test"
  ],
  [
    "* *,*",
    "test-file/src/HTMLTest/DocumentTest/ExportTest/FunctionTest.js.html#lineNumber4",
    "test export function",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ExportTest/FunctionTest.js.html#lineNumber8",
    "test export function has default import path with direct function definition.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ExportTest/FunctionTest.js.html#lineNumber17",
    "test export function has named import path with direct function definition.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ExportTest/FunctionTest.js.html#lineNumber26",
    "test export function has named import path with direct function expression",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ExportTest/FunctionTest.js.html#lineNumber61",
    "test export function has named import path with direct generator function definition.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ExportTest/FunctionTest.js.html#lineNumber79",
    "test export function has named import path with indirect function definition.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ExportTest/FunctionTest.js.html#lineNumber70",
    "test export function has named import path with undocument",
    "test"
  ],
  [
    "* *,*",
    "test-file/src/HTMLTest/DocumentTest/ExportTest/FunctionIndirectDefaultTest.js.html#lineNumber4",
    "test export function indirect default",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ExportTest/FunctionIndirectDefaultTest.js.html#lineNumber7",
    "test export function indirect default has default import path with indirect function definition",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ExportTest/FunctionTest.js.html#lineNumber35",
    "test export function is not documented with direct function definition",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ExportTest/FunctionTest.js.html#lineNumber48",
    "test export function is not documented with direct function expression",
    "test"
  ],
  [
    "* *,*",
    "test-file/src/HTMLTest/DocumentTest/ExportTest/VariableTest.js.html#lineNumber4",
    "test export variable",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ExportTest/VariableTest.js.html#lineNumber8",
    "test export variable has default import path with direct variable definition.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ExportTest/VariableTest.js.html#lineNumber17",
    "test export variable has named import path with direct variable definition.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ExportTest/VariableTest.js.html#lineNumber54",
    "test export variable has named import path with indirect variable definition.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ExportTest/VariableTest.js.html#lineNumber39",
    "test export variable has named import path with none doc comment",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ExportTest/VariableTest.js.html#lineNumber63",
    "test export variable has named import path with unknown type.",
    "test"
  ],
  [
    "* *,*",
    "test-file/src/HTMLTest/DocumentTest/ExportTest/VariableIndirectDefaultTest.js.html#lineNumber4",
    "test export variable indirect default",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ExportTest/VariableIndirectDefaultTest.js.html#lineNumber8",
    "test export variable indirect default has default import path with indirect variable definition.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ExportTest/VariableTest.js.html#lineNumber26",
    "test export variable is not documented with direct variable definition",
    "test"
  ],
  [
    "",
    "test-file/src/ConfigTest/FindConfigPathTest.js.html#lineNumber4",
    "test finding config path:",
    "test"
  ],
  [
    "",
    "test-file/src/ConfigTest/FindConfigPathTest.js.html#lineNumber26",
    "test finding config path: can find .esdoc.js",
    "test"
  ],
  [
    "",
    "test-file/src/ConfigTest/FindConfigPathTest.js.html#lineNumber20",
    "test finding config path: can find .esdoc.json",
    "test"
  ],
  [
    "",
    "test-file/src/ConfigTest/FindConfigPathTest.js.html#lineNumber32",
    "test finding config path: can find package.js",
    "test"
  ],
  [
    "identifiersdocbuilder src/publisher/builder/identifiersdocbuilder.js~identifiersdocbuilder,identifiersdocbuilder",
    "test-file/src/HTMLTest/IdentifiersTest/IdentifiersTest.js.html#lineNumber4",
    "test identifiers",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/IdentifiersTest/IdentifiersTest.js.html#lineNumber8",
    "test identifiers has class summary.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/IdentifiersTest/IdentifiersTest.js.html#lineNumber54",
    "test identifiers has external summary.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/IdentifiersTest/IdentifiersTest.js.html#lineNumber27",
    "test identifiers has function summary.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/IdentifiersTest/IdentifiersTest.js.html#lineNumber17",
    "test identifiers has interface summary.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/IdentifiersTest/IdentifiersTest.js.html#lineNumber45",
    "test identifiers has typedef summary.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/IdentifiersTest/IdentifiersTest.js.html#lineNumber36",
    "test identifiers has variable summary.",
    "test"
  ],
  [
    "* *,*",
    "test-file/src/HTMLTest/DocumentTest/IgnoreTest/ClassTest.js.html#lineNumber4",
    "test ignore class",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/IgnoreTest/ClassTest.js.html#lineNumber6",
    "test ignore class TestIgnoreClass1",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/IgnoreTest/ClassTest.js.html#lineNumber8",
    "test ignore class TestIgnoreClass1 is not documented.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/IgnoreTest/ClassTest.js.html#lineNumber14",
    "test ignore class TestIgnoreClass2",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/IgnoreTest/ClassTest.js.html#lineNumber18",
    "test ignore class TestIgnoreClass2 does not have ignored member.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/IgnoreTest/ClassTest.js.html#lineNumber24",
    "test ignore class TestIgnoreClass2 does not have ignored method.",
    "test"
  ],
  [
    "indexdocbuilder src/publisher/builder/indexdocbuilder.js~indexdocbuilder,indexdocbuilder",
    "test-file/src/HTMLTest/IndexTest/IndexTest.js.html#lineNumber4",
    "test index",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/IndexTest/IndexTest.js.html#lineNumber8",
    "test index has README.md",
    "test"
  ],
  [
    "testdocbuilder testdocbuilder#_buildtestdescribedochtml src/publisher/builder/testdocbuilder.js~testdocbuilder,testdocbuilder src/publisher/builder/testdocbuilder.js~testdocbuilder#_buildtestdescribedochtml,testdocbuilder#_buildtestdescribedochtml",
    "test-file/src/HTMLTest/TestTest/TestTest.js.html#lineNumber7",
    "test integration of test",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/TestTest/TestTest.js.html#lineNumber63",
    "test integration of test context style",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/TestTest/TestTest.js.html#lineNumber65",
    "test integration of test context style has context",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/TestTest/TestTest.js.html#lineNumber77",
    "test integration of test context style has context it",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/TestTest/TestTest.js.html#lineNumber11",
    "test integration of test describe/it style",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/TestTest/TestTest.js.html#lineNumber13",
    "test integration of test describe/it style has describe",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/TestTest/TestTest.js.html#lineNumber25",
    "test integration of test describe/it style has it",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/TestTest/TestTest.js.html#lineNumber37",
    "test integration of test describe/it style has nested describe",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/TestTest/TestTest.js.html#lineNumber49",
    "test integration of test describe/it style has nested it",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/TestTest/TestTest.js.html#lineNumber90",
    "test integration of test suite/test style",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/TestTest/TestTest.js.html#lineNumber116",
    "test integration of test suite/test style has nested suite",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/TestTest/TestTest.js.html#lineNumber128",
    "test integration of test suite/test style has nested test",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/TestTest/TestTest.js.html#lineNumber92",
    "test integration of test suite/test style has suite",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/TestTest/TestTest.js.html#lineNumber104",
    "test integration of test suite/test style has test",
    "test"
  ],
  [
    "classdocbuilder src/publisher/builder/classdocbuilder.js~classdocbuilder,classdocbuilder",
    "test-file/src/HTMLTest/TestTest/TestLinkTest.js.html#lineNumber4",
    "test link of test",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/TestTest/TestLinkTest.js.html#lineNumber8",
    "test link of test has link of test at class",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/TestTest/TestLinkTest.js.html#lineNumber21",
    "test link of test has link of test at constructor",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/TestTest/TestLinkTest.js.html#lineNumber37",
    "test link of test has link of test at member",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/TestTest/TestLinkTest.js.html#lineNumber53",
    "test link of test has link of test at method",
    "test"
  ],
  [
    "manualdocbuilder src/publisher/builder/manualdocbuilder.js~manualdocbuilder,manualdocbuilder",
    "test-file/src/HTMLTest/ManualTest/ManualTest.js.html#lineNumber4",
    "test manual",
    "test"
  ],
  [
    "manualdocbuilder#_buildmanualindex src/publisher/builder/manualdocbuilder.js~manualdocbuilder#_buildmanualindex,manualdocbuilder#_buildmanualindex",
    "test-file/src/HTMLTest/ManualTest/ManualTest.js.html#lineNumber175",
    "test manual test each heading tags",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/ManualTest/ManualTest.js.html#lineNumber242",
    "test manual test each heading tags has advanced heading tags",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/ManualTest/ManualTest.js.html#lineNumber278",
    "test manual test each heading tags has changelog heading tags",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/ManualTest/ManualTest.js.html#lineNumber233",
    "test manual test each heading tags has configuration heading tags",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/ManualTest/ManualTest.js.html#lineNumber188",
    "test manual test each heading tags has design heading tags",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/ManualTest/ManualTest.js.html#lineNumber251",
    "test manual test each heading tags has example heading tags",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/ManualTest/ManualTest.js.html#lineNumber269",
    "test manual test each heading tags has faq heading tags",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/ManualTest/ManualTest.js.html#lineNumber197",
    "test manual test each heading tags has installation heading tags",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/ManualTest/ManualTest.js.html#lineNumber179",
    "test manual test each heading tags has overview heading tags",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/ManualTest/ManualTest.js.html#lineNumber260",
    "test manual test each heading tags has reference heading tags",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/ManualTest/ManualTest.js.html#lineNumber206",
    "test manual test each heading tags has tutorial heading tags",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/ManualTest/ManualTest.js.html#lineNumber215",
    "test manual test each heading tags has usage heading tags",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/ManualTest/ManualTest.js.html#lineNumber224",
    "test manual test each heading tags has usage2 heading tags",
    "test"
  ],
  [
    "manualdocbuilder#_buildmanual src/publisher/builder/manualdocbuilder.js~manualdocbuilder#_buildmanual,manualdocbuilder#_buildmanual",
    "test-file/src/HTMLTest/ManualTest/ManualTest.js.html#lineNumber289",
    "test manual test each manual",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/ManualTest/ManualTest.js.html#lineNumber349",
    "test manual test each manual has changelog",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/ManualTest/ManualTest.js.html#lineNumber325",
    "test manual test each manual has configuration",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/ManualTest/ManualTest.js.html#lineNumber333",
    "test manual test each manual has example",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/ManualTest/ManualTest.js.html#lineNumber341",
    "test manual test each manual has faq",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/ManualTest/ManualTest.js.html#lineNumber301",
    "test manual test each manual has installation",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/ManualTest/ManualTest.js.html#lineNumber291",
    "test manual test each manual has overview",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/ManualTest/ManualTest.js.html#lineNumber317",
    "test manual test each manual has tutorial",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/ManualTest/ManualTest.js.html#lineNumber309",
    "test manual test each manual has usage",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/ManualTest/ManualTest.js.html#lineNumber6",
    "test manual test navigation",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/ManualTest/ManualTest.js.html#lineNumber8",
    "test manual test navigation has manual link in header",
    "test"
  ],
  [
    "manualdocbuilder#_buildmanualnav src/publisher/builder/manualdocbuilder.js~manualdocbuilder#_buildmanualnav,manualdocbuilder#_buildmanualnav",
    "test-file/src/HTMLTest/ManualTest/ManualTest.js.html#lineNumber16",
    "test manual test navigation has manual navigation",
    "test"
  ],
  [
    "docfactory#_inspectexportnameddeclaration src/factory/docfactory.js~docfactory#_inspectexportnameddeclaration,docfactory#_inspectexportnameddeclaration",
    "test-file/src/HTMLTest/DocumentTest/ExportTest/MultipleTest.js.html#lineNumber4",
    "test multiple export",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ExportTest/MultipleTest.js.html#lineNumber6",
    "test multiple export is documented.",
    "test"
  ],
  [
    "docbuilder#_buildnavdoc src/publisher/builder/docbuilder.js~docbuilder#_buildnavdoc,docbuilder#_buildnavdoc",
    "test-file/src/HTMLTest/NavTest/NavTest.js.html#lineNumber4",
    "test navigation:",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/NavTest/NavTest.js.html#lineNumber8",
    "test navigation: has class",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/NavTest/NavTest.js.html#lineNumber53",
    "test navigation: has external.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/NavTest/NavTest.js.html#lineNumber26",
    "test navigation: has function.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/NavTest/NavTest.js.html#lineNumber17",
    "test navigation: has interface.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/NavTest/NavTest.js.html#lineNumber44",
    "test navigation: has typedef.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/NavTest/NavTest.js.html#lineNumber35",
    "test navigation: has variable.",
    "test"
  ],
  [
    "* *,*",
    "test-file/src/HTMLTest/DocumentTest/ReturnTest/FunctionTest.js.html#lineNumber4",
    "test return",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ReturnTest/FunctionTest.js.html#lineNumber8",
    "test return testReturnFunction1",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ReturnTest/FunctionTest.js.html#lineNumber22",
    "test return testReturnFunction1 in details",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ReturnTest/FunctionTest.js.html#lineNumber24",
    "test return testReturnFunction1 in details has return.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ReturnTest/FunctionTest.js.html#lineNumber10",
    "test return testReturnFunction1 in summary",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ReturnTest/FunctionTest.js.html#lineNumber12",
    "test return testReturnFunction1 in summary has return.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ReturnTest/FunctionTest.js.html#lineNumber39",
    "test return testReturnFunction2",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ReturnTest/FunctionTest.js.html#lineNumber53",
    "test return testReturnFunction2 in details",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ReturnTest/FunctionTest.js.html#lineNumber55",
    "test return testReturnFunction2 in details has return.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ReturnTest/FunctionTest.js.html#lineNumber41",
    "test return testReturnFunction2 in summary",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ReturnTest/FunctionTest.js.html#lineNumber43",
    "test return testReturnFunction2 in summary has return.",
    "test"
  ],
  [
    "",
    "test-file/src/DocTest/SearchTest.js.html#lineNumber4",
    "test search",
    "test"
  ],
  [
    "",
    "test-file/src/DocTest/SearchTest.js.html#lineNumber33",
    "test search has class index",
    "test"
  ],
  [
    "",
    "test-file/src/DocTest/SearchTest.js.html#lineNumber103",
    "test search has external index",
    "test"
  ],
  [
    "",
    "test-file/src/DocTest/SearchTest.js.html#lineNumber113",
    "test search has file index",
    "test"
  ],
  [
    "",
    "test-file/src/DocTest/SearchTest.js.html#lineNumber73",
    "test search has function index",
    "test"
  ],
  [
    "",
    "test-file/src/DocTest/SearchTest.js.html#lineNumber63",
    "test search has interface index",
    "test"
  ],
  [
    "",
    "test-file/src/DocTest/SearchTest.js.html#lineNumber43",
    "test search has member index",
    "test"
  ],
  [
    "",
    "test-file/src/DocTest/SearchTest.js.html#lineNumber53",
    "test search has method index",
    "test"
  ],
  [
    "",
    "test-file/src/DocTest/SearchTest.js.html#lineNumber123",
    "test search has test file index",
    "test"
  ],
  [
    "",
    "test-file/src/DocTest/SearchTest.js.html#lineNumber133",
    "test search has test index",
    "test"
  ],
  [
    "",
    "test-file/src/DocTest/SearchTest.js.html#lineNumber93",
    "test search has typedef index",
    "test"
  ],
  [
    "",
    "test-file/src/DocTest/SearchTest.js.html#lineNumber83",
    "test search has variable index",
    "test"
  ],
  [
    "filedocbuilder src/publisher/builder/filedocbuilder.js~filedocbuilder,filedocbuilder",
    "test-file/src/HTMLTest/FileTest/FileTest.js.html#lineNumber4",
    "test source code file",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/FileTest/FileTest.js.html#lineNumber8",
    "test source code file has source code.",
    "test"
  ],
  [
    "docfactory#_traversecomments * docresolver#_resolveundocumentidentifier src/factory/docfactory.js~docfactory#_traversecomments,docfactory#_traversecomments *,* src/publisher/builder/docresolver.js~docresolver#_resolveundocumentidentifier,docresolver#_resolveundocumentidentifier",
    "test-file/src/DocTest/UndocumentTest.js.html#lineNumber8",
    "test undocument",
    "test"
  ],
  [
    "",
    "test-file/src/DocTest/UndocumentTest.js.html#lineNumber10",
    "test undocument has undocument tag.",
    "test"
  ],
  [
    "* *,*",
    "test-file/src/DocTest/UnknownTest.js.html#lineNumber4",
    "test unknown tag",
    "test"
  ],
  [
    "",
    "test-file/src/DocTest/UnknownTest.js.html#lineNumber6",
    "test unknown tag has unknown tag.",
    "test"
  ],
  [
    "functiondoc#_$async functiondoc#_$async,functiondoc#_$async",
    "test-file/src/HTMLTest/DocumentTest/AsyncTest/FunctionTest.js.html#lineNumber4",
    "testAsyncFunction",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/AsyncTest/FunctionTest.js.html#lineNumber20",
    "testAsyncFunction in details",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/AsyncTest/FunctionTest.js.html#lineNumber22",
    "testAsyncFunction in details has async mark.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/AsyncTest/FunctionTest.js.html#lineNumber8",
    "testAsyncFunction in summary",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/AsyncTest/FunctionTest.js.html#lineNumber10",
    "testAsyncFunction in summary has async mark",
    "test"
  ],
  [
    "* *,*",
    "test-file/src/HTMLTest/DocumentTest/DeprecatedTest/FunctionTest.js.html#lineNumber4",
    "testDeprecatedFunction:",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/DeprecatedTest/FunctionTest.js.html#lineNumber20",
    "testDeprecatedFunction: in details",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/DeprecatedTest/FunctionTest.js.html#lineNumber22",
    "testDeprecatedFunction: in details has deprecated message of member and method.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/DeprecatedTest/FunctionTest.js.html#lineNumber8",
    "testDeprecatedFunction: in summary",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/DeprecatedTest/FunctionTest.js.html#lineNumber10",
    "testDeprecatedFunction: in summary has deprecated message.",
    "test"
  ],
  [
    "* *,*",
    "test-file/src/HTMLTest/DocumentTest/DeprecatedTest/VariableTest.js.html#lineNumber4",
    "testDeprecatedVariable:",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/DeprecatedTest/VariableTest.js.html#lineNumber20",
    "testDeprecatedVariable: in details",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/DeprecatedTest/VariableTest.js.html#lineNumber22",
    "testDeprecatedVariable: in details has deprecated message.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/DeprecatedTest/VariableTest.js.html#lineNumber8",
    "testDeprecatedVariable: in summary",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/DeprecatedTest/VariableTest.js.html#lineNumber10",
    "testDeprecatedVariable: in summary has deprecated message.",
    "test"
  ],
  [
    "* *,*",
    "test-file/src/HTMLTest/DocumentTest/DescTest/FunctionTest.js.html#lineNumber4",
    "testDescFunction",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/DescTest/FunctionTest.js.html#lineNumber20",
    "testDescFunction in details",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/DescTest/FunctionTest.js.html#lineNumber22",
    "testDescFunction in details has desc.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/DescTest/FunctionTest.js.html#lineNumber8",
    "testDescFunction in summary",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/DescTest/FunctionTest.js.html#lineNumber10",
    "testDescFunction in summary has desc",
    "test"
  ],
  [
    "* *,*",
    "test-file/src/HTMLTest/DocumentTest/DescTest/VariableTest.js.html#lineNumber4",
    "testDescVariable",
    "test"
  ],
  [
    "* *,*",
    "test-file/src/HTMLTest/DocumentTest/ExamleTest/VariableTest.js.html#lineNumber4",
    "testDescVariable",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/DescTest/VariableTest.js.html#lineNumber20",
    "testDescVariable in details",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ExamleTest/VariableTest.js.html#lineNumber8",
    "testDescVariable in details",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ExamleTest/VariableTest.js.html#lineNumber10",
    "testDescVariable in details has desc.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/DescTest/VariableTest.js.html#lineNumber22",
    "testDescVariable in details has desc.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/DescTest/VariableTest.js.html#lineNumber8",
    "testDescVariable in summary",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/DescTest/VariableTest.js.html#lineNumber10",
    "testDescVariable in summary has desc",
    "test"
  ],
  [
    "* *,*",
    "test-file/src/HTMLTest/DocumentTest/EmitsTest/FunctionTest.js.html#lineNumber4",
    "testEmitsFunction",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/EmitsTest/FunctionTest.js.html#lineNumber8",
    "testEmitsFunction in details",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/EmitsTest/FunctionTest.js.html#lineNumber10",
    "testEmitsFunction in details has desc.",
    "test"
  ],
  [
    "* *,*",
    "test-file/src/HTMLTest/DocumentTest/ExamleTest/FunctionTest.js.html#lineNumber4",
    "testExampleFunction",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ExamleTest/FunctionTest.js.html#lineNumber8",
    "testExampleFunction in details",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ExamleTest/FunctionTest.js.html#lineNumber10",
    "testExampleFunction in details has desc.",
    "test"
  ],
  [
    "* *,*",
    "test-file/src/HTMLTest/DocumentTest/ExperimentalTest/FunctionTest.js.html#lineNumber4",
    "testExperimentalFunction",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ExperimentalTest/FunctionTest.js.html#lineNumber20",
    "testExperimentalFunction in details",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ExperimentalTest/FunctionTest.js.html#lineNumber22",
    "testExperimentalFunction in details has desc.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ExperimentalTest/FunctionTest.js.html#lineNumber8",
    "testExperimentalFunction in summary",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ExperimentalTest/FunctionTest.js.html#lineNumber10",
    "testExperimentalFunction in summary has desc",
    "test"
  ],
  [
    "* *,*",
    "test-file/src/HTMLTest/DocumentTest/ExperimentalTest/VariableTest.js.html#lineNumber4",
    "testExperimentalVariable",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ExperimentalTest/VariableTest.js.html#lineNumber20",
    "testExperimentalVariable in details",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ExperimentalTest/VariableTest.js.html#lineNumber22",
    "testExperimentalVariable in details has desc.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ExperimentalTest/VariableTest.js.html#lineNumber8",
    "testExperimentalVariable in summary",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ExperimentalTest/VariableTest.js.html#lineNumber10",
    "testExperimentalVariable in summary has desc",
    "test"
  ],
  [
    "* *,*",
    "test-file/src/HTMLTest/DocumentTest/ExportTest/AnonymousFunctionTest.js.html#lineNumber4",
    "testExportAnonymousFunction",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ExportTest/AnonymousFunctionTest.js.html#lineNumber20",
    "testExportAnonymousFunction in details",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ExportTest/AnonymousFunctionTest.js.html#lineNumber22",
    "testExportAnonymousFunction in details has desc.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ExportTest/AnonymousFunctionTest.js.html#lineNumber8",
    "testExportAnonymousFunction in summary",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ExportTest/AnonymousFunctionTest.js.html#lineNumber10",
    "testExportAnonymousFunction in summary has desc",
    "test"
  ],
  [
    "* *,*",
    "test-file/src/HTMLTest/DocumentTest/GeneratorTest/FunctionTest.js.html#lineNumber4",
    "testGeneratorFunction",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/GeneratorTest/FunctionTest.js.html#lineNumber20",
    "testGeneratorFunction in details",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/GeneratorTest/FunctionTest.js.html#lineNumber22",
    "testGeneratorFunction in details has generator mark.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/GeneratorTest/FunctionTest.js.html#lineNumber8",
    "testGeneratorFunction in summary",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/GeneratorTest/FunctionTest.js.html#lineNumber10",
    "testGeneratorFunction in summary has generator mark",
    "test"
  ],
  [
    "paramparser#guesstype paramparser#guesstype,paramparser#guesstype",
    "test-file/src/HTMLTest/DocumentTest/GuessTest/VariableTest.js.html#lineNumber4",
    "testGuessVariable",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/GuessTest/VariableTest.js.html#lineNumber38",
    "testGuessVariable in details",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/GuessTest/VariableTest.js.html#lineNumber40",
    "testGuessVariable in details has guessed type.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/GuessTest/VariableTest.js.html#lineNumber8",
    "testGuessVariable in summary",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/GuessTest/VariableTest.js.html#lineNumber10",
    "testGuessVariable in summary has guessed type.",
    "test"
  ],
  [
    "* *,*",
    "test-file/src/HTMLTest/DocumentTest/IgnoreTest/FunctionTest.js.html#lineNumber4",
    "testIgnoreFunction",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/IgnoreTest/FunctionTest.js.html#lineNumber8",
    "testIgnoreFunction is not documented.",
    "test"
  ],
  [
    "* *,*",
    "test-file/src/HTMLTest/DocumentTest/IgnoreTest/VariableTest.js.html#lineNumber4",
    "testIgnoreVariable",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/IgnoreTest/VariableTest.js.html#lineNumber8",
    "testIgnoreVariable is not documented.",
    "test"
  ],
  [
    "docresolver#_resolvelink src/publisher/builder/docresolver.js~docresolver#_resolvelink,docresolver#_resolvelink",
    "test-file/src/HTMLTest/DocumentTest/LinkTest/FunctionTest.js.html#lineNumber4",
    "testLinkFunction",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/LinkTest/FunctionTest.js.html#lineNumber8",
    "testLinkFunction has link.",
    "test"
  ],
  [
    "docresolver#_resolvelink src/publisher/builder/docresolver.js~docresolver#_resolvelink,docresolver#_resolvelink",
    "test-file/src/HTMLTest/DocumentTest/LinkTest/VariableTest.js.html#lineNumber4",
    "testLinkVariable",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/LinkTest/VariableTest.js.html#lineNumber8",
    "testLinkVariable has link.",
    "test"
  ],
  [
    "* *,*",
    "test-file/src/HTMLTest/DocumentTest/ListensTest/FunctionTest.js.html#lineNumber4",
    "testListensFunction",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ListensTest/FunctionTest.js.html#lineNumber8",
    "testListensFunction has listens.",
    "test"
  ],
  [
    "* *,*",
    "test-file/src/HTMLTest/DocumentTest/ParamTest/FunctionTest.js.html#lineNumber4",
    "testParamFunction",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ParamTest/FunctionTest.js.html#lineNumber20",
    "testParamFunction in details",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ParamTest/FunctionTest.js.html#lineNumber22",
    "testParamFunction in details has param.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ParamTest/FunctionTest.js.html#lineNumber8",
    "testParamFunction in summary",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ParamTest/FunctionTest.js.html#lineNumber10",
    "testParamFunction in summary has param.",
    "test"
  ],
  [
    "* *,*",
    "test-file/src/HTMLTest/DocumentTest/SeeTest/FunctionTest.js.html#lineNumber4",
    "testSeeFunction",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/SeeTest/FunctionTest.js.html#lineNumber8",
    "testSeeFunction has see.",
    "test"
  ],
  [
    "* *,*",
    "test-file/src/HTMLTest/DocumentTest/SeeTest/VariableTest.js.html#lineNumber4",
    "testSeeVariable",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/SeeTest/VariableTest.js.html#lineNumber8",
    "testSeeVariable has see.",
    "test"
  ],
  [
    "* *,*",
    "test-file/src/HTMLTest/DocumentTest/SinceTest/FunctionTest.js.html#lineNumber4",
    "testSinceFunction",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/SinceTest/FunctionTest.js.html#lineNumber20",
    "testSinceFunction in detail",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/SinceTest/FunctionTest.js.html#lineNumber22",
    "testSinceFunction in detail has since.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/SinceTest/FunctionTest.js.html#lineNumber8",
    "testSinceFunction in summary",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/SinceTest/FunctionTest.js.html#lineNumber10",
    "testSinceFunction in summary has since.",
    "test"
  ],
  [
    "* *,*",
    "test-file/src/HTMLTest/DocumentTest/SinceTest/VariableTest.js.html#lineNumber4",
    "testSinceVariable",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/SinceTest/VariableTest.js.html#lineNumber20",
    "testSinceVariable in detail",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/SinceTest/VariableTest.js.html#lineNumber22",
    "testSinceVariable in detail has since.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/SinceTest/VariableTest.js.html#lineNumber8",
    "testSinceVariable in summary",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/SinceTest/VariableTest.js.html#lineNumber10",
    "testSinceVariable in summary has since.",
    "test"
  ],
  [
    "* *,*",
    "test-file/src/HTMLTest/DocumentTest/ThrowsTest/FunctionTest.js.html#lineNumber4",
    "testThrowsFunction",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/ThrowsTest/FunctionTest.js.html#lineNumber8",
    "testThrowsFunction has throws.",
    "test"
  ],
  [
    "* *,*",
    "test-file/src/HTMLTest/DocumentTest/TodoTest/FunctionTest.js.html#lineNumber4",
    "testTodoFunction",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/TodoTest/FunctionTest.js.html#lineNumber8",
    "testTodoFunction has todo.",
    "test"
  ],
  [
    "* *,*",
    "test-file/src/HTMLTest/DocumentTest/TodoTest/VariableTest.js.html#lineNumber4",
    "testTodoVariable",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/TodoTest/VariableTest.js.html#lineNumber8",
    "testTodoVariable has see.",
    "test"
  ],
  [
    "variabledoc src/doc/variabledoc.js~variabledoc,variabledoc",
    "test-file/src/HTMLTest/DocumentTest/VariableTest/ArrayPatterTest.js.html#lineNumber4",
    "testVariableArrayPattern",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/VariableTest/ArrayPatterTest.js.html#lineNumber20",
    "testVariableArrayPattern in details",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/VariableTest/ArrayPatterTest.js.html#lineNumber22",
    "testVariableArrayPattern in details has desc.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/VariableTest/ArrayPatterTest.js.html#lineNumber8",
    "testVariableArrayPattern in summary",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/VariableTest/ArrayPatterTest.js.html#lineNumber10",
    "testVariableArrayPattern in summary has desc",
    "test"
  ],
  [
    "variabledoc src/doc/variabledoc.js~variabledoc,variabledoc",
    "test-file/src/HTMLTest/DocumentTest/VariableTest/DefinitionTest.js.html#lineNumber4",
    "testVariableDefinition",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/VariableTest/DefinitionTest.js.html#lineNumber20",
    "testVariableDefinition in details",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/VariableTest/DefinitionTest.js.html#lineNumber22",
    "testVariableDefinition in details has desc.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/VariableTest/DefinitionTest.js.html#lineNumber8",
    "testVariableDefinition in summary",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/VariableTest/DefinitionTest.js.html#lineNumber10",
    "testVariableDefinition in summary has desc",
    "test"
  ],
  [
    "variabledoc src/doc/variabledoc.js~variabledoc,variabledoc",
    "test-file/src/HTMLTest/DocumentTest/VariableTest/ObjectPatterTest.js.html#lineNumber4",
    "testVariableObjectPattern",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/VariableTest/ObjectPatterTest.js.html#lineNumber20",
    "testVariableObjectPattern in details",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/VariableTest/ObjectPatterTest.js.html#lineNumber22",
    "testVariableObjectPattern in details has desc.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/VariableTest/ObjectPatterTest.js.html#lineNumber8",
    "testVariableObjectPattern in summary",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/VariableTest/ObjectPatterTest.js.html#lineNumber10",
    "testVariableObjectPattern in summary has desc",
    "test"
  ],
  [
    "* *,*",
    "test-file/src/HTMLTest/DocumentTest/VersionTest/FunctionTest.js.html#lineNumber4",
    "testVersionFunction",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/VersionTest/FunctionTest.js.html#lineNumber20",
    "testVersionFunction in details",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/VersionTest/FunctionTest.js.html#lineNumber22",
    "testVersionFunction in details has version.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/VersionTest/FunctionTest.js.html#lineNumber8",
    "testVersionFunction in summary",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/VersionTest/FunctionTest.js.html#lineNumber10",
    "testVersionFunction in summary has version",
    "test"
  ],
  [
    "* *,*",
    "test-file/src/HTMLTest/DocumentTest/VersionTest/VariableTest.js.html#lineNumber4",
    "testVersionVariable",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/VersionTest/VariableTest.js.html#lineNumber20",
    "testVersionVariable in details",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/VersionTest/VariableTest.js.html#lineNumber22",
    "testVersionVariable in details has desc.",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/VersionTest/VariableTest.js.html#lineNumber8",
    "testVersionVariable in summary",
    "test"
  ],
  [
    "",
    "test-file/src/HTMLTest/DocumentTest/VersionTest/VariableTest.js.html#lineNumber10",
    "testVersionVariable in summary has version",
    "test"
  ]
]