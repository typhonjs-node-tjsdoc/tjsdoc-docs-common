import path from 'path';

export default class ConfigData
{
   /**
    * Generates the pre-validation data structure for bulk checking a TJSDocConfig object. If a field is present it will
    * be validated otherwise no particular fields are checked.
    *
    * @returns {object}
    */
   static defaultValues()
   {
      const dirPath = path.resolve(__dirname);

      return {
         'access': ['public', 'protected', 'private'],

         'autoPrivate': true,

         'builtinVirtual': true,

         'compactData': false,

         'compressData': false,

         'compressOutput': false,

         'compressFormat': 'tar.gz',

         'copyPackage': true,

         'coverage': true,

         'debug': false,

         'emptyDestination': false,

         'excludes': [],

         'includeSource': true,

         'index': './README.md',

         'lint': true,

         'logLevel': 'info',

         'manual.coverage': true,

         'outputASTData': false,

         'outputDocData': false,

         'package': './package.json',

         'plugins': [],

         'publisher': `${dirPath}/publisher/publish.js`,

         'scripts': [],

         'separateDataArchives': false,

         'styles': [],

         'test.excludes': [],

         'undocumentIdentifier': true,

         'unexportIdentifier': false
      };
   }

   /**
    * Generates the pre-validation data structure for bulk checking a TJSDocConfig object. If a field is present it will
    * be validated otherwise no particular fields are checked.
    *
    * @param {EventProxy}  eventbus - The plugin manager eventbus proxy.
    *
    * @returns {object}
    */
   static postValidate(eventbus)
   {
      const preValidateData = ConfigData.preValidate(eventbus);

      return Object.assign({}, preValidateData,
      {
         destination: { required: true, test: 'entry|array', type: 'string' },

         publisher: { required: true, test: 'entry', type: 'string' },

         source: { required: true, test: 'entry|array', type: 'string' }
      });
   }

   /**
    * Generates the pre-validation data structure for bulk checking a TJSDocConfig object. If a field is present it will
    * be validated otherwise no particular fields are checked.
    *
    * @param {EventProxy}  eventbus - The plugin manager eventbus proxy.
    *
    * @returns {object}
    */
   static preValidate(eventbus)
   {
      return {
         'access': { required: false, test: 'array', expected: new Set(['private', 'protected', 'public']) },

         'autoPrivate': { required: false, test: 'entry', type: 'boolean' },

         'builtinVirtual': { required: false, test: 'entry', type: 'boolean' },

         'compactData': { required: false, test: 'entry', type: 'boolean' },

         'compressData': { required: false, test: 'entry', type: 'boolean' },

         'compressFormat': { required: false, test: 'entry', expected: new Set(['tar.gz', 'zip']) },

         'compressOutput': { required: false, test: 'entry', type: 'boolean' },

         'copyPackage': { required: false, test: 'entry', type: 'boolean' },

         'coverage': { required: false, test: 'entry', type: 'boolean' },

         'debug': { required: false, test: 'entry', type: 'boolean' },

         'destination': { required: false, test: 'entry|array', type: 'string' },

         'emptyDestination': { required: false, test: 'entry', type: 'boolean' },

         'excludes': { required: false, test: 'array', expected: (entry) => new RegExp(entry) },

         'extends': { required: false, test: 'entry|array', expected: 'string' },

         'includeSource': { required: false, test: 'entry', type: 'boolean' },

         'index': { required: false, test: 'entry', type: 'string' },

         'lint': { required: false, test: 'entry', type: 'boolean' },

         'logLevel': { required: false, test: 'entry', expected:
          (entry) => eventbus.triggerSync('log:is:valid:log:level', entry), message: 'invalid log level' },

         'manual.coverage': { required: false, test: 'entry', type: 'boolean' },

         'outputASTData': { required: false, test: 'entry', type: 'boolean' },

         'outputDocData': { required: false, test: 'entry', type: 'boolean' },

         'package': { required: false, test: 'entry', type: 'string' },

         //config.plugins && Validator.objectArray(config, 'plugins',
         // (entry) => eventbus.triggerSync('plugins:is:valid:plugin:config', entry), 'invalid plugin config');

         'publisher': { required: false, test: 'entry', type: 'string' },

         'scripts': { required: false, test: 'array', type: 'string' },

         'source': { required: false, test: 'entry|array', type: 'string' },

         'separateDataArchives': { required: false, test: 'entry', type: 'boolean' },

         'styles': { required: false, test: 'array', type: 'string' },

         'test.includes': { required: false, test: 'array', expected: (entry) => new RegExp(entry) },

         'test.excludes': { required: false, test: 'array', expected: (entry) => new RegExp(entry) },

         'test.source': { required: false, test: 'entry|array', type: 'string' },

         'test.type': { required: false, test: 'entry', expected: new Set(['mocha']) },

         'undocumentIdentifier': { required: false, test: 'entry', type: 'boolean' },

         'unexportIdentifier': { required: false, test: 'entry', type: 'boolean' }
      };
   }

   /**
    * Returns config keys that are a string and are upgraded to an array or are already an array to be merged.
    *
    * @returns {Set<string>}
    */
   static upgradeMergeSet()
   {
      return new Set(
      [
         'access',
         'excludes',
         'extends',
         'includes',
         'pathExtensions',
         'plugins',
         'scripts',
         //'source', //TODO UNCOMMENT AFTER SOURCE GLOBS
         'styles'
      ]);
   }
}

