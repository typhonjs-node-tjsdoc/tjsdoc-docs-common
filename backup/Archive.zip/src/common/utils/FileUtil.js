import archiver   from 'archiver';
import fs         from 'fs-extra';
import path       from 'path';

/**
 * Creates several general utility methods related to file access bound to the eventbus.
 *
 * @evßentbustarget
 * @param {PluginEvent}    ev - An event proxy for the main eventbus.
 */
export function onPluginLoad(ev)
{
   const eventbus = ev.eventbus;

   /**
    *
    * @type {Array}
    */
   const archiverStack = [];

   /**
    * Provides a unique counter for temporary archives.
    * @type {number}
    */
   let archiveCntr = 0;

   /**
    * Gets the current archiver instance.
    *
    * @returns {*}
    */
   function getArchive()
   {
      return archiverStack.length > 0 ? archiverStack[archiverStack.length - 1] : null;
   }

   /**
    * Pops an archiver instance off the stack.
    *
    * @returns {*}
    */
   function popArchive()
   {
      return archiverStack.length > 0 ? archiverStack.pop() : null;
   }

   /**
    * Helper event binding to create a compressed archive relative to the output destination. All subsequent file
    * write and copy operations will add to the existing archive. You must invoke 'tjsdoc:util:archive:finalize' to
    * complete the archive process.
    *
    * @param {string}   destPath - Destination path and file name; the compress format extension will be appended.
    * @param {boolean}  addToParent - If a parent archiver exists then add child archive to it and delete local file.
    * @param {boolean}  [silent=false] - When true `output: <destPath>` is logged.
    */
   eventbus.on('tjsdoc:util:archive:create', (destPath, addToParent = true, silent = false) =>
   {
      if (typeof silent === 'boolean' && !silent)
      {
         eventbus.trigger('log:info:raw', `creating archive: ${destPath}`);
      }

      const config = eventbus.triggerSync('tjsdoc:get:config');

      const compressFormat = config.compressFormat;

      // Add archive format to `destPath`.
      destPath = `${destPath}.${compressFormat}`;

      let resolvedDest = path.resolve(config.destination, destPath);

      // Allow config parameter `separateDataArchives` to override addToParent.
      addToParent = addToParent && !config.separateDataArchives;

      // If a child archive is being created, `addToParent` is true and `config.separateDataFiles` is false then
      // change the resolved destination to a temporary file so that the parent instance can add it before finalizing.
      if (archiverStack.length > 0 && addToParent)
      {
         const dirName = path.dirname(resolvedDest);

         resolvedDest = `${dirName}${path.sep}.temp-${archiveCntr++}`;
      }

      let archive;

      switch (compressFormat)
      {
         case 'tar.gz':
            archive = archiver('tar', { gzip: true, gzipOptions: { level: 9 } });
            break;

         case 'zip':
            archive = archiver('zip', { zlib: { level: 9 } });
            break;

         default:
            throw new Error(`Unknown compression format: '${compressFormat}'.`);
      }

      // Make sure the resolved destination is a valid directory; if not create it...
      fs.ensureDirSync(path.dirname(resolvedDest));

      const stream = fs.createWriteStream(resolvedDest);

      // Catch any archiver errors.
      archive.on('error', (err) => { throw err; });

      // Pipe archive data to the file.
      archive.pipe(stream);

      // Create an archive instance holding relevant data for tracking children archives.
      const instance =
      {
         archive,
         destPath,
         resolvedDest,
         stream,
         addToParent,
         childPromises: []
      };

      archiverStack.push(instance);
   });

   /**
    * Helper event binding to finalize an active archive. You must first invoke 'tjsdoc:util:archive:create'.
    *
    * @param {boolean}  [silent=false] - When true `output: <destPath>` is logged.
    */
   eventbus.on('tjsdoc:util:archive:finalize', (silent = false) =>
   {
      const instance = popArchive();

      if (instance !== null)
      {
         const parentInstance = getArchive();

         // If `addToParent` is true and there is a parent instance then push a new Promise into the parents
         // `childPromises` array and add callbacks to the current instances file stream to resolve the Promise.
         if (instance.addToParent && parentInstance !== null)
         {
            parentInstance.childPromises.push(new Promise((resolve, reject) =>
            {
               // Add event callbacks to instance stream such that on close the Promise is resolved.
               instance.stream.on('close', () =>
               {
                  resolve({ resolvedDest: instance.resolvedDest, destPath: instance.destPath });
               });

               // Any errors will reject the promise.
               instance.stream.on('error', reject);
            }));
         }

         if (typeof silent === 'boolean' && !silent)
         {
            eventbus.trigger('log:info:raw', `finalizing archive: ${instance.destPath}`);
         }

         // Resolve any child promises before finalizing current instance.
         Promise.all(instance.childPromises).then((results) =>
         {
            // There are temporary child archives to insert into the current instance.
            for (const result of results)
            {
               // Append temporary archive to requested relative destPath.
               instance.archive.append(fs.createReadStream(result.resolvedDest), { name: result.destPath });

               // Remove temporary archive.
               fs.removeSync(result.resolvedDest);
            }

            // finalize the archive (ie we are done appending files but streams have to finish yet)
            instance.archive.finalize();
         });
      }
      else
      {
         eventbus.trigger('log:warn', `No active archive to finalize.`);
      }
   });

   /**
    * Helper event binding to copy a source path / file relative to the output destination.
    *
    * @param {string}   srcPath - Source path.
    * @param {string}   destPath - Destination path.
    * @param {boolean}  [silent=false] - When true `output: <destPath>` is logged.
    */
   eventbus.on('tjsdoc:util:copy:file', (srcPath, destPath, silent = false) =>
   {
      if (typeof silent === 'boolean' && !silent) { eventbus.trigger('log:info:raw', `output: ${destPath}`); }

      const config = eventbus.triggerSync('tjsdoc:get:config');

      const instance = getArchive();

      if (instance !== null)
      {
         if (fs.statSync(srcPath).isDirectory())
         {
            instance.archive.directory(srcPath, destPath);
         }
         else
         {
            instance.archive.file(srcPath, { name: destPath });
         }
      }
      else
      {
         fs.copySync(srcPath, path.resolve(config.destination, destPath));
      }
   });

   /**
    * Helper event binding to empty the `config.destination` directory if `config.emptyDestination` is true.
    *
    * @param {boolean}  [silent=false] - When true `emptying: <config.destination>` is logged.
    */
   eventbus.on('tjsdoc:util:empty:destination', (silent = false) =>
   {
      const config = eventbus.triggerSync('tjsdoc:get:config');

      if (config.emptyDestination)
      {
         if (typeof silent === 'boolean' && !silent)
         {
            eventbus.trigger('log:info:raw', `emptying: ${config.destination}`);
         }

         fs.emptyDirSync(path.resolve(config.destination));
      }
   });

   /**
    * Helper event binding to read lines from a file given a start and end line number.
    *
    * @param {string}   filePath - The file path to load.
    * @param {number}   lineStart - The start line
    * @param {number}   lineEnd - The end line
    * @returns {String[]}
    */
   eventbus.on('tjsdoc:util:read:file:lines', (filePath, lineStart, lineEnd) =>
   {
      const lines = fs.readFileSync(filePath).toString().split('\n');
      const targetLines = [];

      if (lineStart < 0) { lineStart = 0; }
      if (lineEnd > lines.length) { lineEnd = lines.length; }

      for (let cntr = lineStart; cntr < lineEnd; cntr++)
      {
         targetLines.push(`${cntr + 1}| ${lines[cntr]}`);
      }

      return targetLines;
   });

   /**
    * Helper event binding to output a file relative to the output destination.
    *
    * @param {object}   fileData - The file data.
    * @param {string}   fileName - A relative file path and name to `config.destination`.
    * @param {boolean}  [silent=false] - When true `output: <destPath>` is logged.
    * @param {encoding} [encoding=utf8] - The encoding type.
    */
   eventbus.on('tjsdoc:util:write:file', (fileData, fileName, silent = false, encoding = 'utf8') =>
   {
      if (typeof silent === 'boolean' && !silent) { eventbus.trigger('log:info:raw', `output: ${fileName}`); }

      const config = eventbus.triggerSync('tjsdoc:get:config');

      const instance = getArchive();

      if (instance !== null)
      {
         instance.archive.append(fileData, { name: fileName });
      }
      else
      {
         fs.outputFileSync(path.resolve(config.destination, fileName), fileData, { encoding });
      }
   });

   /**
    * Helper event binding to output a file relative to the output destination.
    *
    * @param {object}   html - The HTML data.
    * @param {string}   fileName - A relative file path and name to `config.destination`.
    * @param {boolean}  [silent=false] - When true `output: <destPath>` is logged.
    * @param {encoding} [encoding=utf8] - The encoding type.
    */
   eventbus.on('tjsdoc:util:write:html', (html, fileName, silent = false, encoding = 'utf8') =>
   {
      if (typeof silent === 'boolean' && !silent) { eventbus.trigger('log:info:raw', `output: ${fileName}`); }

      const config = eventbus.triggerSync('tjsdoc:get:config');

      html = eventbus.triggerSync('plugins:invoke:sync:event', 'onHandleHTML', { html, fileName }).html;

      const instance = getArchive();

      if (instance !== null)
      {
         instance.archive.append(html, { name: fileName });
      }
      else
      {
         fs.outputFileSync(path.resolve(config.destination, fileName), html, { encoding });
      }
   });
}
