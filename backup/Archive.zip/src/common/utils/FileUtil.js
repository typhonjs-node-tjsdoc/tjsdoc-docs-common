import fs   from 'fs-extra';
import path from 'path';

/**
 * Creates several general utility methods bound to the eventbus.
 *
 * @param {PluginEvent}    ev - An event proxy for the main eventbus.
 */
export function onPluginLoad(ev)
{
   const eventbus = ev.eventbus;
   const config = ev.extra.tjsdocConfig;

   /**
    * Helper event binding to copy a file relative to the output destination.
    *
    * @param {string}   srcPath - Source path.
    * @param {string}   destPath - Destination path.
    * @param {boolean}  [silent=false] - When true `output: <destPath>` is logged.
    */
   eventbus.on('tjsdoc:util:copy', (srcPath, destPath, silent = false) =>
   {
      if (typeof silent === 'boolean' && !silent) { eventbus.trigger('log:info:raw', `output: ${destPath}`); }

      fs.copySync(srcPath, path.resolve(config.destination, destPath));
   });

   /**
    * Helper event binding to read lines from a file given a start and end line number.
    *
    * @param {string}   filePath - The file path to load.
    * @param {number}   lineStart - The start line
    * @param {number}   lineEnd - The end line
    * @returns {String[]}
    */
   eventbus.on('tjsdoc:util:read:file:lines', (filePath, lineStart, lineEnd) =>
   {
      const lines = fs.readFileSync(filePath).toString().split('\n');
      const targetLines = [];

      if (lineStart < 0) { throw Error(`'lineStart' is less than '0'.`); }
      if (lineEnd > lines.length) { throw Error(`'lineEnd' is greater than file line length: ${lines.length}.`); }
      if (lineStart > lineEnd) { throw Error(`'lineStart' is greater than 'lineEnd'.`); }

      //for (let cntr = lineStart - 1; cntr < lineEnd; cntr++)
      for (let cntr = lineStart; cntr < lineEnd; cntr++)
      {
         targetLines.push(`${cntr + 1}| ${lines[cntr]}`);
      }

      return targetLines;
   });

   /**
    * Helper event binding to output a file relative to the output destination.
    *
    * @param {object}   fileData - The file data.
    * @param {string}   fileName - Target file name.
    * @param {boolean}  [silent=false] - When true `output: <destPath>` is logged.
    * @param {encoding} [encoding=utf8] - The encoding type.
    */
   eventbus.on('tjsdoc:util:write:file', (fileData, fileName, silent = false, encoding = 'utf8') =>
   {
      if (typeof silent === 'boolean' && !silent) { eventbus.trigger('log:info:raw', `output: ${fileName}`); }

      fs.outputFileSync(path.resolve(config.destination, fileName), fileData, { encoding });
   });

   /**
    * Helper event binding to output a file relative to the output destination.
    *
    * @param {object}   html - The HTML data.
    * @param {string}   fileName - Target file name.
    * @param {boolean}  [silent=false] - When true `output: <destPath>` is logged.
    * @param {encoding} [encoding=utf8] - The encoding type.
    */
   eventbus.on('tjsdoc:util:write:html', (html, fileName, silent = false, encoding = 'utf8') =>
   {
      if (typeof silent === 'boolean' && !silent) { eventbus.trigger('log:info:raw', `output: ${fileName}`); }

      html = eventbus.triggerSync('plugins:invoke:sync:event', 'onHandleHTML', { html, fileName }).html;

      fs.outputFileSync(path.resolve(config.destination, fileName), html, { encoding });
   });
}
