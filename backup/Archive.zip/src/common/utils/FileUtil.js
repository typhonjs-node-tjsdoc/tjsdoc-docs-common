import archiver   from 'archiver';
import fs         from 'fs-extra';
import path       from 'path';

/**
 * Creates several general utility methods related to file access bound to the eventbus.
 *
 * @param {PluginEvent}    ev - An event proxy for the main eventbus.
 */
export function onPluginLoad(ev)
{
   const eventbus = ev.eventbus;

   const archiverStack = [];

   /**
    * Gets the current archiver.
    *
    * @returns {*}
    */
   function getArchive()
   {
      if (archiverStack.length === 0) { return null; }

      return archiverStack[archiverStack.length - 1].archive;
   }

   /**
    * Pops an archiver off the stack.
    *
    * @returns {*}
    */
   function popArchive()
   {
      if (archiverStack.length === 0) { return null; }

      return archiverStack.pop();
   }

   /**
    * Helper event binding to create a compressed archive relative to the output destination. All subsequent file
    * write and copy operations will add to the existing archive. You must invoke 'tjsdoc:util:archive:finalize' to
    * complete the archive process.
    *
    * @param {string}   destPath - Destination path.
    * @param {boolean}  addToParent - If a parent archiver exists then add child archive to it and delete local file.
    * @param {boolean}  [silent=false] - When true `output: <destPath>` is logged.
    */
   eventbus.on('tjsdoc:util:archive:create', (destPath, addToParent = true, silent = false) =>
   {
      const config = eventbus.triggerSync('tjsdoc:get:config');

      const resolvedDest = path.resolve(config.destination, destPath);

      if (typeof silent === 'boolean' && !silent)
      {
         eventbus.trigger('log:info:raw', `creating archive: ${destPath}`);
      }

      fs.ensureDirSync(path.dirname(resolvedDest));

      const stream = fs.createWriteStream(resolvedDest);
      const archive = archiver('zip');

      archive.on('error', (err) => { throw err; });

      // pipe archive data to the file
      archive.pipe(stream);

      archiverStack.push({ archive, destPath, resolvedDest, stream, addToParent });
   });

   /**
    * Helper event binding to finalize an active archive. You must first invoke 'tjsdoc:util:archive:create'.
    *
    * @param {boolean}  [silent=false] - When true `output: <destPath>` is logged.
    */
   eventbus.on('tjsdoc:util:archive:finalize', (silent = false) =>
   {
      const instance = popArchive();

      if (instance !== null)
      {
         // finalize the archive (ie we are done appending files but streams have to finish yet)
         instance.archive.finalize();

         if (typeof silent === 'boolean' && !silent)
         {
            eventbus.trigger('log:info:raw', `finalizing archive: ${instance.destPath}`);
         }
      }
      else
      {
         eventbus.trigger('log:warn', `No active archive to finalize.`);
      }
   });

   /**
    * Helper event binding to copy a source path / file relative to the output destination.
    *
    * @param {string}   srcPath - Source path.
    * @param {string}   destPath - Destination path.
    * @param {boolean}  [silent=false] - When true `output: <destPath>` is logged.
    */
   eventbus.on('tjsdoc:util:copy:file', (srcPath, destPath, silent = false) =>
   {
      if (typeof silent === 'boolean' && !silent) { eventbus.trigger('log:info:raw', `output: ${destPath}`); }

      const config = eventbus.triggerSync('tjsdoc:get:config');

      const archive = getArchive();

      if (archive !== null)
      {
         if (fs.statSync(srcPath).isDirectory())
         {
            archive.directory(srcPath, destPath);
         }
         else
         {
            archive.file(srcPath, { name: destPath });
         }
      }
      else
      {
         fs.copySync(srcPath, path.resolve(config.destination, destPath));
      }
   });

   /**
    * Helper event binding to read lines from a file given a start and end line number.
    *
    * @param {string}   filePath - The file path to load.
    * @param {number}   lineStart - The start line
    * @param {number}   lineEnd - The end line
    * @returns {String[]}
    */
   eventbus.on('tjsdoc:util:read:file:lines', (filePath, lineStart, lineEnd) =>
   {
      const lines = fs.readFileSync(filePath).toString().split('\n');
      const targetLines = [];

      if (lineStart < 0) { lineStart = 0; }
      if (lineEnd > lines.length) { lineEnd = lines.length; }

      for (let cntr = lineStart; cntr < lineEnd; cntr++)
      {
         targetLines.push(`${cntr + 1}| ${lines[cntr]}`);
      }

      return targetLines;
   });

   /**
    * Helper event binding to output a file relative to the output destination.
    *
    * @param {object}   fileData - The file data.
    * @param {string}   fileName - Target file name.
    * @param {boolean}  [silent=false] - When true `output: <destPath>` is logged.
    * @param {encoding} [encoding=utf8] - The encoding type.
    */
   eventbus.on('tjsdoc:util:write:file', (fileData, fileName, silent = false, encoding = 'utf8') =>
   {
      if (typeof silent === 'boolean' && !silent) { eventbus.trigger('log:info:raw', `output: ${fileName}`); }

      const config = eventbus.triggerSync('tjsdoc:get:config');

      const archive = getArchive();

      if (archive !== null)
      {
         archive.append(fileData, { name: fileName });
      }
      else
      {
         fs.outputFileSync(path.resolve(config.destination, fileName), fileData, { encoding });
      }
   });

   /**
    * Helper event binding to output a file relative to the output destination.
    *
    * @param {object}   html - The HTML data.
    * @param {string}   fileName - Target file name.
    * @param {boolean}  [silent=false] - When true `output: <destPath>` is logged.
    * @param {encoding} [encoding=utf8] - The encoding type.
    */
   eventbus.on('tjsdoc:util:write:html', (html, fileName, silent = false, encoding = 'utf8') =>
   {
      if (typeof silent === 'boolean' && !silent) { eventbus.trigger('log:info:raw', `output: ${fileName}`); }

      const config = eventbus.triggerSync('tjsdoc:get:config');

      html = eventbus.triggerSync('plugins:invoke:sync:event', 'onHandleHTML', { html, fileName }).html;

      const archive = getArchive();

      if (archive !== null)
      {
         archive.append(html, { name: fileName });
      }
      else
      {
         fs.outputFileSync(path.resolve(config.destination, fileName), html, { encoding });
      }
   });
}
