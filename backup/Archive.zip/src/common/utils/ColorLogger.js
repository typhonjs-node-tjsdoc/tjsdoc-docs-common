/**
 * display colorful log. now, not support browser.
 *
 * format:
 * ``[LogLevel] [Time] [File] log text``
 *
 * format with tag:
 * ``[LogLevel] [Time] [File] [Tag] log text``
 *
 * log level and color:
 * - verbose: purple
 * - debug: blue
 * - info: green
 * - warning: yellow
 * - error: red
 *
 * @example
 * import Logger from 'color-logger'
 *
 * // simple usage
 * Logger.v('verbose log');
 *
 * // tag usage
 * let logger = new Logger('MyTag');
 * logger.d('debug log');
 */
export class ColorLogger
{
   constructor(options = {})
   {
      if (typeof options !== 'object') { throw new TypeError(`'options' is not an object.`); }

      this._options = { consoleEnabled: true, showDate: false, showInfo: true };

      this._logLevel = s_LOG_LEVELS['info'];

      this.setOptions(options);
   }

   /**
    * Generates log information from where the logger invocation originated.
    *
    * @param {boolean}  isTrace - If true then process remaining trace.
    *
    * @param {Error}    [error] - An optional Error to trace instead of artificially generating one.
    *
    * @return {{info: string, trace: string}} info: file name and line number; trace: remaining stack trace if enabled.
    * @private
    */
   _getInfo(isTrace, error)
   {
      let info = 'no stack trace';
      const trace = [];

      let processError = error;

      if (!(processError instanceof Error))
      {
         try { throw new Error(); }
         catch (err) { processError = err; }
      }

      // Make sure there is a entry in `processError`.
      if (typeof processError.stack === 'string')
      {
         const lines = processError.stack.split('\n');

         let cntr = 0;

         for (; cntr < lines.length; cntr++)
         {
            if (s_INFO_REGEX.test(lines[cntr])) { continue; }
            if (this._infoFilter && !this._infoFilter.test(lines[cntr])) { continue; }

            const matched = lines[cntr].match(/([\w\d\-_.]*:\d+:\d+)/);

            if (matched !== null)
            {
               info = matched[1];
               break;
            }
         }

         // If gathering trace info continue to push lines to `trace`. Ignoring any lines that originate from
         // ColorLogger or `backbone-esnext-events` plus an optional filter.
         if (isTrace)
         {
            trace.push(lines[cntr]);

            for (cntr++; cntr < lines.length; cntr++)
            {
               if (s_INFO_REGEX.test(lines[cntr])) { continue; }
               if (this._infoFilter && !this._infoFilter.test(lines[cntr])) { continue; }

               trace.push(lines[cntr]);
            }
         }
      }

      return { info, trace: `${trace.join('\n')}` };
   }

   /**
    * Get the log level
    *
    * @returns {*}
    */
   getLogLevel()
   {
      return this._logLevel;
   }

   /**
    * Returns a copy of the logger options.
    *
    * @returns {object} - Logger options.
    */
   getOptions()
   {
      return JSON.parse(JSON.stringify(this._options));
   }

   /**
    * Returns whether the given log level is enabled.
    *
    * @param {string}   level - log level
    * @returns {boolean}
    */
   isLevelEnabled(level)
   {
      const requestedLevel = s_LOG_LEVELS[level];

      if (typeof requestedLevel === 'undefined' || requestedLevel === null)
      {
         console.log(`isLevelEnabled - unknown log level: ${level}`);
         return false;
      }

      return s_IS_LEVEL_ENABLED(this.getLogLevel(), requestedLevel);
   }

   /**
    * Display log message.
    *
    * @param {string}   level - log level: `fatal`, `error`, `warn`, `info`, `debug`, `verbose`, `trace`.
    * @param {boolean}  [nocolor=false] - If true then no color is applied.
    * @param {boolean}  [raw=false] - If true then just the raw message is logged at the given level.
    *
    * @param {...*}     msg - log message.
    *
    * @returns {string|undefined} formatted log message or undefined if log level is not enabled.
    * @private
    */
   _output(level, nocolor = false, raw = false, ...msg)
   {
      if (!s_IS_LEVEL_ENABLED(this.getLogLevel(), s_LOG_LEVELS[level])) { return; }

      const text = [];

      let isTrace = level === 'trace';
      let traceError;

      for (const m of msg)
      {
         if (typeof m === 'object' && !(m instanceof Error))
         {
            text.push(JSON.stringify(m, null, 3));
         }
         else if (m instanceof Error)
         {
            text.push(m.message);

            traceError = m;
            isTrace = true;
         }
         else
         {
            text.push(m);
         }
      }

      const color = nocolor ? '' : s_LEVEL_TO_COLOR[level];

      const spacer = raw ? '' : ' ';

      let info = '';
      let trace = '';

      if (this._options.showInfo && !raw)
      {
         const infoSpace = nocolor ? '' : ' ';

         const result = this._getInfo(isTrace, traceError);

         info = `${infoSpace}[${result.info}]`;
         trace = isTrace ? `\n${result.trace}` : '';
      }

      let now = '';

      if (this._options.showDate && !raw)
      {
         const d = new Date();

         let month = d.getMonth() + 1;
         if (month < 10) { month = `0${month}`; }

         let date = d.getDate();
         if (date < 10) { date = `0${date}`; }

         let hour = d.getHours();
         if (hour < 10) { hour = `0${hour}`; }

         let minutes = d.getMinutes();
         if (minutes < 10) { minutes = `0${minutes}`; }

         let sec = d.getSeconds();
         if (sec < 10) { sec = `0${sec}`; }

         now = ` [${d.getFullYear()}-${month}-${date}T${hour}:${minutes}:${sec}.${d.getMilliseconds()}Z]`;
      }

      const log = `${color}${now}${info}${spacer}${text.join(' ')}${trace}[0m`;

      if (this._options.consoleEnabled)
      {
         console.log(log);
      }

      return log;
   }

   setInfoFilter(regex)
   {
      if (!(regex instanceof RegExp)) { throw new TypeError(`'regex' is not an instance of 'RegExp'.`); }

      this._infoFilter = regex;
   }

   /**
    * Sets the current log level.
    *
    * @param {string}   level - log level
    * @returns {boolean}
    */
   setLogLevel(level)
   {
      const requestedLevel = s_LOG_LEVELS[level];

      if (typeof requestedLevel === 'undefined' || requestedLevel === null)
      {
         console.log(`setLogLevel - unknown log level: ${level}`);
         return false;
      }

      this._logLevel = requestedLevel;
      return true;
   }

   /**
    * Set optional parameters.
    *
    * @param {object} options - Defines optional parameters to set.
    */
   setOptions(options = {})
   {
      if (typeof options !== 'object') { throw new TypeError(`'options' is not an object.`); }

      if (typeof options.consoleEnabled === 'boolean') { this._options.consoleEnabled = options.consoleEnabled; }
      if (typeof options.showDate === 'boolean') { this._options.showDate = options.showDate; }
      if (typeof options.showInfo === 'boolean') { this._options.showInfo = options.showInfo; }
   }

   // Logging methods -----------------------------------------------------------------------------------------------

   /**
    * Display fatal (light red) log.
    * @param {...*} msg - log message.
    * @returns {string} formatted log message.
    */
   fatal(...msg) { return this._output('fatal', false, false, ...msg); }

   /**
    * Display fatal log.
    * @param {...*} msg - log message.
    * @returns {string} formatted log message.
    */
   fatalNoColor(...msg) { return this._output('fatal', true, false, ...msg); }

   /**
    * Display raw fatal log (no style / no color).
    * @param {...*} msg - log message.
    * @returns {string} formatted log message.
    */
   fatalRaw(...msg) { return this._output('fatal', true, true, ...msg); }

   /**
    * Display error(red) log.
    * @param {...*} msg - log message.
    * @returns {string} formatted log message.
    */
   error(...msg) { return this._output('error', false, false, ...msg); }

   /**
    * Display error log.
    * @param {...*} msg - log message.
    * @returns {string} formatted log message.
    */
   errorNoColor(...msg) { return this._output('error', true, false, ...msg); }

   /**
    * Display raw error log (no style / no color).
    * @param {...*} msg - log message.
    * @returns {string} formatted log message.
    */
   errorRaw(...msg) { return this._output('error', true, true, ...msg); }

   /**
    * Display warning (yellow) log.
    * @param {...*} msg - log message.
    * @returns {string} formatted log message.
    */
   warn(...msg) { return this._output('warn', false, false, ...msg); }

   /**
    * Display warning log.
    * @param {...*} msg - log message.
    * @returns {string} formatted log message.
    */
   warnNoColor(...msg) { return this._output('warn', true, false, ...msg); }

   /**
    * Display raw warn log (no style / no color).
    * @param {...*} msg - log message.
    * @returns {string} formatted log message.
    */
   warnRaw(...msg) { return this._output('warn', true, true, ...msg); }

   /**
    * Display info (green) log.
    * @param {...*} msg - log message.
    * @returns {string} formatted log message.
    */
   info(...msg) { return this._output('info', false, false, ...msg); }

   /**
    * Display info log.
    * @param {...*} msg - log message.
    * @returns {string} formatted log message.
    */
   infoNoColor(...msg) { return this._output('info', true, false, ...msg); }

   /**
    * Display raw info log (no style / no color).
    * @param {...*} msg - log message.
    * @returns {string} formatted log message.
    */
   infoRaw(...msg) { return this._output('info', true, true, ...msg); }

   /**
    * Display debug (blue) log.
    * @param {...*} msg - log message.
    * @returns {string} formatted log message.
    */
   debug(...msg) { return this._output('debug', false, false, ...msg); }

   /**
    * Display debug log.
    * @param {...*} msg - log message.
    * @returns {string} formatted log message.
    */
   debugNoColor(...msg) { return this._output('debug', true, false, ...msg); }

   /**
    * Display raw debug log (no style / no color).
    * @param {...*} msg - log message.
    * @returns {string} formatted log message.
    */
   debugRaw(...msg) { return this._output('debug', true, true, ...msg); }

   /**
    * Display verbose (purple) log.
    * @param {...*} msg - log message.
    * @returns {string} formatted log message.
    */
   verbose(...msg) { return this._output('verbose', false, false, ...msg); }

   /**
    * Display verbose log.
    * @param {...*} msg - log message.
    * @returns {string} formatted log message.
    */
   verboseNoColor(...msg) { return this._output('verbose', true, false, ...msg); }

   /**
    * Display raw verbose log (no style / no color).
    * @param {...*} msg - log message.
    * @returns {string} formatted log message.
    */
   verboseRaw(...msg) { return this._output('verbose', true, true, ...msg); }

   /**
    * Display trace (purple) log.
    * @param {...*} msg - log message.
    * @returns {string} formatted log message.
    */
   trace(...msg) { return this._output('trace', false, false, ...msg); }

   /**
    * Display trace log.
    * @param {...*} msg - log message.
    * @returns {string} formatted log message.
    */
   traceNoColor(...msg) { return this._output('trace', true, false, ...msg); }

   /**
    * Display raw trace log (no style / no color).
    * @param {...*} msg - log message.
    * @returns {string} formatted log message.
    */
   traceRaw(...msg) { return this._output('trace', true, true, ...msg); }
}

const s_INFO_REGEX = new RegExp('(ColorLogger|backbone-esnext-events)');

/**
 * ASCII ESCAPE SEQUENCE https://en.wikipedia.org/wiki/ANSI_escape_code#Colors
 * @type {{n: string, v: string, d: string, i: string, w: string, e: string}}
 */
const s_LEVEL_TO_COLOR =
{
   fatal: '[1;31m[F]', // light red
   error: '[31m[E]',   // red
   warn: '[33m[W]',    // yellow
   info: '[32m[I]',    // green
   debug: '[34m[D]',   // blue
   verbose: '[35m[V]', // purple
   trace: '[1;36m[T]'  // light cyan
};

const s_LOG_LEVELS =
{
   off: 8,
   fatal: 7,
   error: 6,
   warn: 5,
   info: 4,
   verbose: 3,
   debug: 2,
   trace: 1,
   all: 0
};

const s_IS_LEVEL_ENABLED = (currentLevel, requestedLevel) =>
{
   return Number.isInteger(currentLevel) && Number.isInteger(requestedLevel) && currentLevel <= requestedLevel;
};

const logger = new ColorLogger();

export default logger;

/**
 * Wires up Logger on the plugin eventbus.
 *
 * @param {PluginEvent} ev - The plugin event.
 *
 * @see https://www.npmjs.com/package/typhonjs-plugin-manager
 *
 * @ignore
 */
export function onPluginLoad(ev)
{
   const eventbus = ev.eventbus;

   eventbus.on('log:fatal', logger.fatal, logger);
   eventbus.on('log:fatal:nocolor', logger.fatalNoColor, logger);
   eventbus.on('log:fatal:raw', logger.fatalRaw, logger);
   eventbus.on('log:error', logger.error, logger);
   eventbus.on('log:error:nocolor', logger.errorNoColor, logger);
   eventbus.on('log:error:raw', logger.errorRaw, logger);
   eventbus.on('log:warn', logger.warn, logger);
   eventbus.on('log:warn:nocolor', logger.warnNoColor, logger);
   eventbus.on('log:warn:raw', logger.warnRaw, logger);
   eventbus.on('log:info', logger.info, logger);
   eventbus.on('log:info:nocolor', logger.infoNoColor, logger);
   eventbus.on('log:info:raw', logger.infoRaw, logger);
   eventbus.on('log:debug', logger.debug, logger);
   eventbus.on('log:debug:nocolor', logger.debugNoColor, logger);
   eventbus.on('log:debug:raw', logger.debugRaw, logger);
   eventbus.on('log:verbose', logger.verbose, logger);
   eventbus.on('log:verbose:nocolor', logger.verboseNoColor, logger);
   eventbus.on('log:verbose:raw', logger.verboseRaw, logger);
   eventbus.on('log:trace', logger.trace, logger);
   eventbus.on('log:trace:nocolor', logger.traceNoColor, logger);
   eventbus.on('log:trace:raw', logger.traceRaw, logger);

   eventbus.on('log:get:level', logger.getLogLevel, logger);
   eventbus.on('log:get:options', logger.getOptions, logger);
   eventbus.on('log:is:level:enabled', logger.isLevelEnabled, logger);
   eventbus.on('log:set:info:filter', logger.setInfoFilter, logger);
   eventbus.on('log:set:level', logger.setLogLevel, logger);
   eventbus.on('log:set:options', logger.setOptions, logger);
}
