import fs from 'fs';

/**
 * Logger for invalid code which can not be parsed with TJSDoc.
 */

/**
 * Wires up InvalidCodeLogger on the plugin eventbus.
 *
 * @param {PluginEvent} ev - The plugin event.
 *
 * @ignore
 */
export function onPluginLoad(ev)
{
   const eventbus = ev.eventbus;

   const traverseErrors = [];

   eventbus.on('tjsdoc:add:invalid:code', addInvalidCode);
   eventbus.on('tjsdoc:log:invalid:code:errors', logInvalidCode);

   /**
    * Helper event binding to add a traverse error.
    *
    * @param {string}   type - The type of error: `code` or `file`.
    * @param {string}   filePathOrCode - The filepath of traversal failure or in memory code.
    * @param {ASTNode}  node - The AST node where traversal failed.
    * @param {object}   parseError - Error from parser.
    * @param {Error}    [fatalError] - Any associated fatal error.
    */
   function addInvalidCode(type, filePathOrCode, node, parseError, fatalError)
   {
      if (typeof type !== 'string') { throw new TypeError(`'type' is not a 'string'.`); }
      if (typeof filePathOrCode !== 'string') { throw new TypeError(`'filePathOrCode' is not a 'string'.`); }

      traverseErrors.push({ type, filePathOrCode, node, parseError, fatalError });
   }

   /**
    * Logs all invalid code found.
    */
   function logInvalidCode()
   {
      // Separate errors generated from internal failures of TJSDoc.
      const nonFatalErrors = traverseErrors.filter((error) => { return typeof error.fatalError === 'undefined'; });
      const fatalErrors = traverseErrors.filter((error) => { return typeof error.fatalError !== 'undefined'; });

      if (nonFatalErrors.length > 0)
      {
         eventbus.trigger('log:info:raw', '\n[33m==================================[0m');
         eventbus.trigger('log:info:raw', `[32mInvalidCodeLogger warnings[0m`);
         eventbus.trigger('log:info:raw', '[33m==================================[0m');

         // warning title (yellow), body (light yellow)
         showErrors(nonFatalErrors, 'warning:', 'log:warn:raw', '[33m', '[32m');
      }

      if (fatalErrors.length > 0)
      {
         eventbus.trigger('log:info:raw', '\n[31m==================================[0m');
         eventbus.trigger('log:info:raw', `[1;31mInvalidCodeLogger errors (internal TJSDoc failure)\n[0m`);
         eventbus.trigger('log:info:raw',
          `[1;31mPlease report an issue below after checking if a similar one already exists:[0m`);
         eventbus.trigger('log:info:raw', `[1;31mhttps://github.com/typhonjs-doc/tjsdoc/issues[0m`);
         eventbus.trigger('log:info:raw', '[31m==================================[0m');

         // error title (red), body (light red)
         showErrors(fatalErrors, 'error:', 'log:error:raw', '[31m', '[1;31m');
      }
   }

   /**
    *
    * @param errors
    * @param label
    * @param event
    * @param headerColor
    * @param bodyColor
    */
   function showErrors(errors, label, event, headerColor, bodyColor)
   {
      for (const error of errors)
      {
         switch (error.type)
         {
            case 'code':
               if (error.node)
               {
                  showCodeNode(error.filePathOrCode, error.node, error.message, label, event, headerColor, bodyColor);
               }
               else if (error.parseError)
               {
                  showCodeError(error.filePathOrCode, error.parseError, error.message, label, event, headerColor,
                   bodyColor);
               }
               break;

            case 'file':
               if (error.node)
               {
                  showFileNode(error.filePathOrCode, error.node, label, event, headerColor, bodyColor);
               }
               else if (error.parseError)
               {
                  showFileError(error.filePathOrCode, error.parseError, label, event, headerColor, bodyColor);
               }
               break;
         }

         if (error.fatalError)
         {
            eventbus.trigger('log:error', error.fatalError);
         }
      }
   }

   /**
    * Show error from in memory code.
    *
    * @param {string}   code - In memory code.
    *
    * @param {object}   error - Parser error object.
    *
    * @param {*}        [message] - Additional message to prepend.
    */
   function showCodeError(code, error, message = void 0, label, event, headerColor, bodyColor)
   {
      if (typeof code !== 'string') { throw new TypeError(`'code' is not a 'string'.`); }
      if (typeof node !== 'object') { throw new TypeError(`'node' is not an 'object'.`); }

      const lines = code.split('\n');
      const start = Math.max(error.loc.line - 3, 1);
      const end = Math.min(error.loc.line + 3, lines.length);
      const targetLines = [];

      for (let cntr = start - 1; cntr < end; cntr++)
      {
         targetLines.push(`${cntr + 1}| ${lines[cntr]}`);
      }

      eventbus.trigger('log:error:raw', '\n[31merror: could not parse the following code.[32m');

      if (typeof message !== 'undefined') { eventbus.trigger('log:error:raw', `[32m${message}`); }

      eventbus.trigger('log:error:raw', `[32m${targetLines.join('\n')}[0m`);
   }

   /**
    * Show log.
    *
    * @param {string} code - In memory code.
    *
    * @param {ASTNode} node - fail parsing node.
    *
    * @param {*} [message] - Additional message to prepend.
    */
   function showCodeNode(code, node, message = void 0, label, event, headerColor, bodyColor)
   {
      if (typeof code !== 'string') { throw new TypeError(`'code' is not a 'string'.`); }
      if (typeof node !== 'object') { throw new TypeError(`'node' is not an 'object'.`); }

      const result = eventbus.triggerSync('tjsdoc:ast:get:code:comment:and:first:line:from:node', code, node, true);

      eventbus.trigger('log:warn:raw', '\n[31mwarning: could not process the following code.[32m');

      if (typeof message !== 'undefined') { eventbus.trigger('log:warn:raw', `[32m${message}`); }

      eventbus.trigger('log:warn:raw', `${result.text}[0m`);
   }

   /**
    * Show error from file.
    *
    * @param {string} filePath - Invalid code in this file.
    *
    * @param {object} error - Parser error object.
    */
   function showFileError(filePath, error, label, event, headerColor, bodyColor)
   {
      const lines = fs.readFileSync(filePath).toString().split('\n');
      const start = Math.max(error.loc.line - 3, 1);
      const end = Math.min(error.loc.line + 3, lines.length);
      const targetLines = [];

      for (let cntr = start - 1; cntr < end; cntr++)
      {
         targetLines.push(`${cntr + 1}| ${lines[cntr]}`);
      }

      eventbus.trigger(event, `\n${headerColor}${label} could not process the following code.[0m`);
      eventbus.trigger(event, `${headerColor}${filePath}[0m`);
      eventbus.trigger(event, `${bodyColor}${targetLines.join('\n')}[0m`);
   }

   /**
    * Show log.
    *
    * @param {string} filePath - invalid code in this file.
    *
    * @param {ASTNode} node - fail parsing node.
    */
   function showFileNode(filePath, node, label, event, headerColor, bodyColor)
   {
      if (typeof filePath !== 'string') { throw new TypeError(`'filePath' is not a 'string'.`); }
      if (typeof node !== 'object') { throw new TypeError(`'node' is not an 'object'.`); }

      const result = eventbus.triggerSync('tjsdoc:ast:get:file:comment:and:first:line:from:node', filePath, node, true);

      eventbus.trigger(event, `\n${headerColor}${label} could not process the following code.[0m`);
      eventbus.trigger(event, `${headerColor}${filePath}[0m`);
      eventbus.trigger(event, `${bodyColor}${result.text}[0m`);
   }
}
