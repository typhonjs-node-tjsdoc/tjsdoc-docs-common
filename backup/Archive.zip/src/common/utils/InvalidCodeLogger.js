import fs from 'fs';

/**
 * Logger for invalid code which can not be parsed with TJSDoc.
 */

/**
 * Wires up InvalidCodeLogger on the plugin eventbus.
 *
 * @param {PluginEvent} ev - The plugin event.
 *
 * @ignore
 */
export function onPluginLoad(ev)
{
   const eventbus = ev.eventbus;

   eventbus.on('log:show:code:node', showCodeNode);
   eventbus.on('log:show:code:error', showCodeError);
   eventbus.on('log:show:file:node', showFileNode);
   eventbus.on('log:show:file:error', showFileError);

   eventbus.on('log:show:error', showError);

   /**
    * Show error from in memory code.
    *
    * @param {string}   code - In memory code.
    *
    * @param {Error}    error - Error object.
    *
    * @param {*}        [message] - Additional message to prepend.
    */
   function showCodeError(code, error, message = void 0)
   {
      if (typeof code !== 'string') { throw new TypeError(`'code' is not a 'string'.`); }
      if (typeof node !== 'object') { throw new TypeError(`'node' is not an 'object'.`); }

      const lines = code.split('\n');
      const start = Math.max(error.loc.line - 3, 1);
      const end = Math.min(error.loc.line + 3, lines.length);
      const targetLines = [];

      for (let cntr = start - 1; cntr < end; cntr++)
      {
         targetLines.push(`${cntr + 1}| ${lines[cntr]}`);
      }

      console.log('[31mwarning: could not parse the following code.[32m');

      if (typeof message !== 'undefined') { console.log(message); }

      console.log(`${targetLines.join('\n')}[0m`);
   }

   /**
    * Show log.
    *
    * @param {string} code - In memory code.
    *
    * @param {ASTNode} node - fail parsing node.
    *
    * @param {*} [message] - Additional message to prepend.
    */
   function showCodeNode(code, node, message = void 0)
   {
      if (typeof code !== 'string') { throw new TypeError(`'code' is not a 'string'.`); }
      if (typeof node !== 'object') { throw new TypeError(`'node' is not an 'object'.`); }

      const result = eventbus.triggerSync('tjsdoc:ast:get:code:comment:and:first:line:from:node', code, node, true);

      console.log('[31merror: could not process the following code.[32m');

      if (typeof message !== 'undefined') { console.log(message); }

      console.log(`${result.text}[0m`);
   }

   /**
    * Show error.
    *
    * @param {Error} error - Target error.
    */
   function showError(error)
   {
      console.log(`[31m${error}[0m`);
   }

   /**
    * Show log.
    *
    * @param {string} filePath - invalid code in this file.
    *
    * @param {ASTNode} node - fail parsing node.
    */
   function showFileNode(filePath, node)
   {
      if (typeof filePath !== 'string') { throw new TypeError(`'filePath' is not a 'string'.`); }
      if (typeof node !== 'object') { throw new TypeError(`'node' is not an 'object'.`); }

      const result = eventbus.triggerSync('tjsdoc:ast:get:file:comment:and:first:line:from:node', filePath, node, true);

      eventbus.trigger('log:n', '[31merror: could not process the following code.[32m');
      eventbus.trigger('log:n', filePath);
      eventbus.trigger('log:n', `[32m${result.text}[0m`);
   }

   /**
    * Show error from file.
    *
    * @param {string} filePath - Invalid code in this file.
    *
    * @param {Error} error - Error object.
    */
   function showFileError(filePath, error)
   {
      const lines = fs.readFileSync(filePath).toString().split('\n');
      const start = Math.max(error.loc.line - 3, 1);
      const end = Math.min(error.loc.line + 3, lines.length);
      const targetLines = [];

      for (let cntr = start - 1; cntr < end; cntr++)
      {
         targetLines.push(`${cntr + 1}| ${lines[cntr]}`);
      }

      eventbus.trigger('log:n', '[31mwarning: could not parse the following code.[32m');
      eventbus.trigger('log:n', filePath);
      eventbus.trigger('log:n', `[32m${targetLines.join('\n')}[0m`);
   }
}
