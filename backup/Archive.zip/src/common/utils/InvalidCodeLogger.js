/**
 * Wires up InvalidCodeLogger on the plugin eventbus. The following event bindings are available:
 *
 * `tjsdoc:add:invalid:code`: Takes a data object which adds an invalid code object to be stored.
 *
 * `tjsdoc:log:invalid:code:errors`: Invokes `log:error:raw` or `log:warn:raw` with the formatted data.
 *
 * @param {PluginEvent} ev - The plugin event.
 */
export function onPluginLoad(ev)
{
   const eventbus = ev.eventbus;

   const invalidCode = [];

   eventbus.on('tjsdoc:add:invalid:code', addInvalidCode);
   eventbus.on('tjsdoc:log:invalid:code', logInvalidCode);

   /**
    * Helper event binding to add invalid code data. While most provided data is optional the following entries are
    * mandatory: either `filePath` or `code` in addition to `node` or `parseError` must be defined.
    *
    * @param {object}      data - The data object containing info or the invalid code.
    * @property {string}   [filePath] - The filepath of traversal failure or in memory code.
    * @property {string}   [code] - The filepath of traversal failure or in memory code.
    * @property {ASTNode}  [node] - The AST node where traversal failed.
    * @property {object}   [parseError] - Error from parser.
    * @property {Error}    [fatalError] - Any associated fatal error.
    */
   function addInvalidCode(data = {})
   {
      if (typeof data !== 'object') { throw new TypeError(`'data' is not an 'object'.`); }

      if (typeof data.type !== 'undefined')
      {
         throw new ReferenceError(`'data.type' is automatically assigned; please remove it.`);
      }

      if (typeof data.filePath !== 'string' && typeof data.code !== 'string')
      {
         throw new ReferenceError(`'data.filePath' or 'data.code' is required to be a 'string'.`);
      }

      if (data.node && typeof data.node !== 'object') { throw new TypeError(`'data.parseError' is not an 'object'.`); }

      if (data.parserError && typeof data.parserError !== 'object')
      {
         throw new TypeError(`'data.parserError' is not an 'object'.`);
      }

      if (data.fatalError && !(data.fatalError instanceof Error))
      {
         throw new TypeError(`'data.fatalError' is not an 'Error'.`);
      }

      if (typeof data.filePath === 'string' && typeof data.code === 'string')
      {
         throw new Error(`'data.filePath' or 'data.code' is required to be a 'string'.`);
      }

      if (typeof data.node !== 'object' && typeof data.parserError !== 'object')
      {
         throw new ReferenceError(`'data.node' or 'data.parserError' is required to be an 'object'.`);
      }

      // Determine type of invalid code.
      const type = data.code ? 'code' : 'file';

      invalidCode.push(Object.assign({ type }, data));
   }

   /**
    * Logs all invalid code previously added. Entries without `error.fatalError` defined are output first as warnings
    * and any entries with `error.fatalError` defined are output last as errors in addition to logging the fatal error.
    */
   function logInvalidCode()
   {
      // Separate errors generated from internal failures of TJSDoc.
      const nonFatalEntries = invalidCode.filter((entry) => { return typeof entry.fatalError === 'undefined'; });
      const fatalEntries = invalidCode.filter((entry) => { return typeof entry.fatalError !== 'undefined'; });

      if (nonFatalEntries.length > 0)
      {
         eventbus.trigger('log:warn:raw', '\n[33m==================================[0m');
         eventbus.trigger('log:warn:raw', `[32mInvalidCodeLogger warnings[0m`);
         eventbus.trigger('log:warn:raw', '[33m==================================[0m');

         // warning title (yellow), body (light yellow)
         showEntries(nonFatalEntries, 'warning:', 'log:warn:raw', '[33m', '[32m');
      }

      if (fatalEntries.length > 0)
      {
         eventbus.trigger('log:error:raw', '\n[31m==================================[0m');
         eventbus.trigger('log:error:raw', `[1;31mInvalidCodeLogger errors (internal TJSDoc failure)\n[0m`);
         eventbus.trigger('log:error:raw',
          `[1;31mPlease report an issue below after checking if a similar one already exists:[0m`);
         eventbus.trigger('log:error:raw', `[1;31mhttps://github.com/typhonjs-doc/tjsdoc/issues[0m`);
         eventbus.trigger('log:error:raw', '[31m==================================[0m');

         // error title (red), body (light red)
         showEntries(fatalEntries, 'error:', 'log:error:raw', '[31m', '[1;31m');
      }
   }

   /**
    * Logs an array of invalid code entries.
    *
    * @param {Array}    entries - An array of invalid code entries to log.
    * @param {string}   label - A label to lead the log entry.
    * @param {string}   event - Log event to invoke.
    * @param {string}   headerColor - ANSI color to apply for header entry / message.
    * @param {string}   bodyColor - ANSI color to apply to body of entry.
    */
   function showEntries(entries, label, event, headerColor, bodyColor)
   {
      for (const entry of entries)
      {
         switch (entry.type)
         {
            case 'code':
               if (entry.node)
               {
                  showCodeNode(entry, label, event, headerColor, bodyColor);
               }
               else if (entry.parserError)
               {
                  showCodeParserError(entry, label, event, headerColor, bodyColor);
               }
               break;

            case 'file':
               if (entry.parserError)
               {
                  showFileParserError(entry, label, event, headerColor, bodyColor);
               }
               else if (entry.node)
               {
                  showFileNode(entry, label, event, headerColor, bodyColor);
               }
               break;
         }

         // Output any fatal error after logging the invalid code.
         if (entry.fatalError) { eventbus.trigger('log:error', entry.fatalError); }
      }
   }

   /**
    * Show invalid code entry from in memory code from a parser error.
    *
    * @param      {object}   entry - A data entry with `code`, `parseError`.
    *
    * @property   {object}   code - Code to parse / log.
    *
    * @property   {object}   parserError - Parser error object.
    *
    * @property   {string}   [message] - Additional message to prepend.
    *
    * @param      {string}   label - A string to prepend to the body entry.
    *
    * @param      {string}   event - The log event to invoke.
    *
    * @param      {string}   headerColor - An ANSI color code to apply to the header.
    *
    * @param      {string}   bodyColor - An ANSI color code to apply to the body.
    */
   function showCodeParserError(entry, label, event, headerColor, bodyColor)
   {
      const lines = entry.code.split('\n');
      const start = Math.max(entry.parserError.loc.line - 5, 0);
      const end = Math.min(entry.parserError.loc.line + 3, lines.length);
      const targetLines = [];

      for (let cntr = start; cntr < end; cntr++) { targetLines.push(`${cntr + 1}| ${lines[cntr]}`); }

      eventbus.trigger(event, `\n${headerColor}${label} could not process the following code.[0m`);

      if (typeof entry.message !== 'undefined') { eventbus.trigger(event, `${headerColor}${entry.message}[0m`); }

      eventbus.trigger(event, `${bodyColor}${targetLines.join('\n')}[0m`);
   }

   /**
    * Show invalid code entry from in memory code from an AST node.
    *
    * @param      {object}   entry - A data entry with `code`, `parseError`.
    *
    * @property   {object}   code - Code to parse / log.
    *
    * @property   {ASTNode}  node - An AST node to use to find comments and first line of node.
    *
    * @property   {string}   [message] - Additional message to prepend.
    *
    * @param      {string}   label - A string to prepend to the body entry.
    *
    * @param      {string}   event - The log event to invoke.
    *
    * @param      {string}   headerColor - An ANSI color code to apply to the header.
    *
    * @param      {string}   bodyColor - An ANSI color code to apply to the body.
    */
   function showCodeNode(entry, label, event, headerColor, bodyColor)
   {
      const result = eventbus.triggerSync('tjsdoc:ast:get:code:comment:and:first:line:from:node', entry.code,
       entry.node, true);

      eventbus.trigger(event, `\n${headerColor}${label} could not process the following code.[0m`);

      if (typeof entry.message !== 'undefined') { eventbus.trigger(event, `${headerColor}${entry.message}[0m`); }

      eventbus.trigger(event, `${bodyColor}${result.text}[0m`);
   }

   /**
    * Show invalid code entry from a file and a parser error.
    *
    * @param      {object}   entry - A data entry with `code`, `parseError`.
    *
    * @property   {object}   code - Code to parse / log.
    *
    * @property   {object}   parserError - Parser error object.
    *
    * @property   {string}   [message] - Additional message to prepend.
    *
    * @param      {string}   label - A string to prepend to the body entry.
    *
    * @param      {string}   event - The log event to invoke.
    *
    * @param      {string}   headerColor - An ANSI color code to apply to the header.
    *
    * @param      {string}   bodyColor - An ANSI color code to apply to the body.
    */
   function showFileParserError(entry, label, event, headerColor, bodyColor)
   {
      const start = entry.parserError.loc.line - 5;
      const end = entry.parserError.loc.line + 3;

      const targetLines = eventbus.triggerSync('tjsdoc:util:read:file:lines', entry.filePath, start, end);

      eventbus.trigger(event, `\n${headerColor}${label} could not process the following code.[0m`);

      if (typeof entry.message !== 'undefined') { eventbus.trigger(event, `${headerColor}${entry.message}[0m`); }

      eventbus.trigger(event, `${headerColor}${entry.filePath}[0m`);
      eventbus.trigger(event, `${bodyColor}${targetLines.join('\n')}[0m`);
   }

   /**
    * Show invalid code entry from a file and an AST node.
    *
    * @param      {object}   entry - A data entry with `code`, `parseError`.
    *
    * @property   {object}   code - Code to parse / log.
    *
    * @property   {ASTNode}  node - An AST node to use to find comments and first line of node.
    *
    * @property   {string}   [message] - Additional message to prepend.
    *
    * @param      {string}   label - A string to prepend to the body entry.
    *
    * @param      {string}   event - The log event to invoke.
    *
    * @param      {string}   headerColor - An ANSI color code to apply to the header.
    *
    * @param      {string}   bodyColor - An ANSI color code to apply to the body.
    */
   function showFileNode(entry, label, event, headerColor, bodyColor)
   {
      const result = eventbus.triggerSync('tjsdoc:ast:get:file:comment:and:first:line:from:node', entry.filePath,
       entry.node, true);

      eventbus.trigger(event, `\n${headerColor}${label} could not process the following code.[0m`);

      if (typeof entry.message !== 'undefined') { eventbus.trigger(event, `${headerColor}${entry.message}[0m`); }

      eventbus.trigger(event, `${headerColor}${entry.filePath}[0m`);
      eventbus.trigger(event, `${bodyColor}${result.text}[0m`);
   }
}
