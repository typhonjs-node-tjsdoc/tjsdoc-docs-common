/**
 * display colorful log. now, not support browser.
 *
 * format:
 * ``[LogLevel] [Time] [File] log text``
 *
 * format with tag:
 * ``[LogLevel] [Time] [File] [Tag] log text``
 *
 * log level and color:
 * - verbose: purple
 * - debug: blue
 * - info: green
 * - warning: yellow
 * - error: red
 *
 * @example
 * import Logger from 'color-logger'
 *
 * // simple usage
 * Logger.v('verbose log');
 *
 * // tag usage
 * let logger = new Logger('MyTag');
 * logger.d('debug log');
 */
export class ColorLogger
{
   constructor(options = {})
   {
      if (typeof options !== 'object') { throw new TypeError(`'options' is not an object.`); }

      this._options = { consoleEnabled: true, errorIndex: 4, showDate: false, showInfo: true };

      this.setOptions(options);
   }

   /**
    * Log information from where the logger invocation originated.
    *
    * @return {string} File name and line number.
    * @private
    */
   _getInfo()
   {
      let info;
      try
      {
         throw new Error();
      }
      catch (err)
      {
         const lines = err.stack.split('\n');
         const line = lines[this._options.errorIndex];
         const matched = line.match(/([\w\d\-_.]*:\d+:\d+)/);

         info = matched[1];
      }

      return info;
   }

   /**
    * Returns a copy of the logger options.
    *
    * @returns {object} - Logger options.
    */
   getOptions()
   {
      return JSON.parse(JSON.stringify(this._options));
   }

   /**
    * Display log message.
    *
    * @param {string} level - log level. v, d, i, w, e.
    *
    * @param {...*} msg - log message.
    *
    * @returns {string} formatted log message.
    * @private
    */
   _output(level, ...msg)
   {
      const text = [];

      for (const m of msg)
      {
         text.push(typeof m === 'object' ? JSON.stringify(m, null, 3) : m);
      }

      const color = s_LEVEL_TO_COLOR[level];

      const spacer = level !== 'n' ? ' ' : '';

      let info = '';

      if (this._options.showInfo && level !== 'n') { info = ` [${this._getInfo()}]`; }

      let now = '';

      if (this._options.showDate)
      {
         const d = new Date();

         let month = d.getMonth() + 1;
         if (month < 10) { month = `0${month}`; }

         let date = d.getDate();
         if (date < 10) { date = `0${date}`; }

         let hour = d.getHours();
         if (hour < 10) { hour = `0${hour}`; }

         let minutes = d.getMinutes();
         if (minutes < 10) { minutes = `0${minutes}`; }

         let sec = d.getSeconds();
         if (sec < 10) { sec = `0${sec}`; }

         now = ` [${d.getFullYear()}-${month}-${date}T${hour}:${minutes}:${sec}.${d.getMilliseconds()}Z]`;
      }

      const log = `${color}${now}${info}${spacer}${text.join(' ')}[0m`;

      if (this._options.consoleEnabled) { console.log(log); }

      return log;
   }


   /**
    * Set optional parameters.
    *
    * @param {object} options - Defines optional parameters to set.
    */
   setOptions(options = {})
   {
      if (typeof options !== 'object') { throw new TypeError(`'options' is not an object.`); }

      if (typeof options.consoleEnabled === 'boolean') { this._options.consoleEnabled = options.consoleEnabled; }
      if (typeof options.errorIndex === 'number') { this._options.errorIndex = options.errorIndex; }
      if (typeof options.showDate === 'boolean') { this._options.showDate = options.showDate; }
      if (typeof options.showInfo === 'boolean') { this._options.showInfo = options.showInfo; }
   }

   /**
    * Display verbose(purple) log.
    *
    * @param {...*} msg - log message.
    *
    * @returns {string} formatted log message.
    */
   v(...msg)
   {
      return this._output('v', ...msg);
   }

   /**
    * Display debug(blue) log.
    *
    * @param {...*} msg - log message.
    *
    * @returns {string} formatted log message.
    */
   d(...msg)
   {
      return this._output('d', ...msg);
   }

   /**
    * Display normal(no color) log.
    *
    * @param {...*} msg - log message.
    *
    * @returns {string} formatted log message.
    */
   n(...msg)
   {
      return this._output('n', ...msg);
   }

   /**
    * Display info(green) log.
    *
    * @param {...*} msg - log message.
    *
    * @returns {string} formatted log message.
    */
   i(...msg)
   {
      return this._output('i', ...msg);
   }

   /**
    * Display warning(yellow) log.
    *
    * @param {...*} msg - log message.
    *
    * @returns {string} formatted log message.
    */
   w(...msg)
   {
      return this._output('w', ...msg);
   }

   /**
    * Display error(red) log.
    *
    * @param {...*} msg - log message.
    *
    * @returns {string} formatted log message.
    */
   e(...msg)
   {
      return this._output('e', ...msg);
   }
}

/**
 * ASCII ESCAPE SEQUENCE https://en.wikipedia.org/wiki/ANSI_escape_code#Colors
 * @type {{n: string, v: string, d: string, i: string, w: string, e: string}}
 */
const s_LEVEL_TO_COLOR =
{
   n: '',         // no color
   v: '[35m[V]', // purple
   d: '[34m[D]', // blue
   i: '[32m[I]', // green
   w: '[33m[W]', // yellow
   e: '[31m[E]'  // red
};

const logger = new ColorLogger();
logger.debug = true;

const s_BUS_LOGGER = new ColorLogger({ errorIndex: 9 });
s_BUS_LOGGER.debug = true;

export default logger;

/**
 * Wires up Logger on the plugin eventbus.
 *
 * @param {PluginEvent} ev - The plugin event.
 *
 * @see https://www.npmjs.com/package/typhonjs-plugin-manager
 *
 * @ignore
 */
export function onPluginLoad(ev)
{
   const eventbus = ev.eventbus;

   eventbus.on('log:debug', s_BUS_LOGGER.d, s_BUS_LOGGER);
   eventbus.on('log:d', s_BUS_LOGGER.d, s_BUS_LOGGER);

   eventbus.on('log:error', s_BUS_LOGGER.e, s_BUS_LOGGER);
   eventbus.on('log:e', s_BUS_LOGGER.e, s_BUS_LOGGER);

   eventbus.on('log:info', s_BUS_LOGGER.i, s_BUS_LOGGER);
   eventbus.on('log:i', s_BUS_LOGGER.i, s_BUS_LOGGER);

   eventbus.on('log:nocolor', s_BUS_LOGGER.n, s_BUS_LOGGER);
   eventbus.on('log:n', s_BUS_LOGGER.n, s_BUS_LOGGER);

   eventbus.on('log:verbose', s_BUS_LOGGER.v, s_BUS_LOGGER);
   eventbus.on('log:v', s_BUS_LOGGER.v, s_BUS_LOGGER);

   eventbus.on('log:warn', s_BUS_LOGGER.w, s_BUS_LOGGER);
   eventbus.on('log:w', s_BUS_LOGGER.w, s_BUS_LOGGER);

   eventbus.on('log:set:options', s_BUS_LOGGER.setOptions, s_BUS_LOGGER);
}
