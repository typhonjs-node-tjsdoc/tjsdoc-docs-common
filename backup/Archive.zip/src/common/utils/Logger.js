import logger from 'color-logger';

/**
 * Overwrite private method `_getInfo` to take into account the eventbus method stack so that the info message
 * correctly shows the location of the log message.
 *
 * @return {string} - file name and line number.
 * @private
 */
logger._getInfo = () =>
{
   let info;
   try
   {
      throw new Error();
   }
   catch (err)
   {
      const lines = err.stack.split('\n');
      const line = lines[8]; // This is changed from `4`.
      const matched = line.match(/([\w\d\-_.]*:\d+:\d+)/);
      info = matched[1];
   }

   return info;
};

/**
 * Wires up Logger on the plugin eventbus.
 *
 * @param {PluginEvent} ev - The plugin event.
 *
 * @ignore
 */
export function onPluginLoad(ev)
{
   const eventbus = ev.eventbus;

   eventbus.on('log:debug', logger.d, logger);
   eventbus.on('log:d', logger.d, logger);

   eventbus.on('log:error', logger.e, logger);
   eventbus.on('log:e', logger.e, logger);

   eventbus.on('log:info', logger.i, logger);
   eventbus.on('log:i', logger.i, logger);

   eventbus.on('log:nocolor', logger.n, logger);
   eventbus.on('log:n', logger.n, logger);

   eventbus.on('log:verbose', logger.v, logger);
   eventbus.on('log:v', logger.v, logger);

   eventbus.on('log:warn', logger.w, logger);
   eventbus.on('log:w', logger.w, logger);

   eventbus.on('log:set:debug', (value) => { logger.debug = value; });
}
