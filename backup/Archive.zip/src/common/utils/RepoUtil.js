import fs from 'fs';

/**
 * Creates several general utility methods bound to the eventbus.
 *
 * @param {PluginEvent}    ev - An event proxy for the main eventbus.
 */
export function onPluginLoad(ev)
{
   const eventbus = ev.eventbus;
   const tjsdocPackageObj = ev.extra.packageObj;

   eventbus.on('tjsdoc:util:get:package:data', getPackageData);
   eventbus.on('tjsdoc:util:get:package:data:from:error', getPackageDataFromError);

   /**
    * Get essential info for the target repo. By default the root `package.json` is searched, but if another package
    * object is passed into this event binding it will be used instead.
    *
    * @param {NPMPackageObject} packageObj - A loaded `package.json` object.
    *
    * @returns {NPMPackageData}
    */
   function getPackageData(packageObj = tjsdocPackageObj)
   {
      let bugsURL, repoURL;

      // repository url

      if (packageObj.repository)
      {
         repoURL = s_PARSE_URL(packageObj.repository.url ? packageObj.repository.url : packageObj.repository);
      }

      // bugs url
      if (packageObj.bugs)
      {
         bugsURL = s_PARSE_URL(packageObj.bugs.url ? packageObj.bugs.url : packageObj.bugs);
      }

      // Index info.
      return {
         name: packageObj.name,
         version: packageObj.version,
         description: packageObj.description,
         author: packageObj.author,
         homepage: packageObj.homepage,
         license: packageObj.license,
         main: packageObj.main,
         repository: { url: repoURL },
         bugs: { url: bugsURL }
      };
   }

   /**
    * Attempts to load any associated `package.json` file from any NPM module detected in the first line of the
    * error trace. The logger is queried with the error generating a filtered stack trace.
    *
    * @param {Error} err - An error with stack trace to examine.
    *
    * @returns {NPMPackageData|undefined}
    */
   function getPackageDataFromError(err)
   {
      const traceInfo = eventbus.triggerSync('log:get:trace:info', err, true);

      let packageInfo;

      if (Array.isArray(traceInfo.trace) && traceInfo.trace.length > 0)
      {
         // Matches full path to last NPM module, last node_module directory name
         const matches = (/^.*\((\/.*(\/node_modules\/(.*?)\/))/g).exec(`${traceInfo.trace[0]}`);

         const modulePath = matches !== null && matches.length >= 1 ? matches[1] : void 0;

         if (typeof modulePath === 'string')
         {
            try
            {
               const packageObj = JSON.parse(fs.readFileSync(`${modulePath}package.json`, { encode: 'utf8' }));

               packageInfo = getPackageData(packageObj);
            }
            catch (packageErr)
            { /* nop */ }
         }
      }

      return packageInfo;
   }
}

const s_PARSE_URL = (parseURL) =>
{
   let url;

   if (typeof parseURL === 'string')
   {
      if (parseURL.indexOf('git@github.com:') === 0)
      {
         // url: git@github.com:foo/bar.git
         const matched = parseURL.match(/^git@github\.com:(.*)\.git$/);

         if (matched && matched[1])
         {
            url = `https://github.com/${matched[1]}`;
         }
      }
      else if (parseURL.match(/^[\w\d\-_]+\/[\w\d\-_]+$/))
      {
         // url: foo/bar
         url = `https://github.com/${parseURL}`;
      }
      else if (parseURL.match(/^git\+https:\/\/github.com\/.*\.git$/))
      {
         // git+https://github.com/foo/bar.git
         const matched = parseURL.match(/^git\+(https:\/\/github.com\/.*)\.git$/);

         url = matched[1];
      }
      else if (parseURL.match(/(https?:\/\/.*$)/))
      {
         // other url
         const matched = parseURL.match(/(https?:\/\/.*$)/);

         url = matched[1];
      }
      else
      {
         url = '';
      }
   }

   return url;
};
