/**
 * Wires up ASTNodeContainer on the plugin eventbus.
 *
 * Provides simple storage for AST nodes and incrementing an id number sequentially on addition.
 *
 * @param {PluginEvent} ev - The plugin event.
 *
 * @ignore
 */
export function onPluginLoad(ev)
{
   const eventbus = ev.eventbus;

   let docId = 0;

   const nodes = {};

   eventbus.on('tjsdoc:ast:add:node', add);
   eventbus.on('tjsdoc:ast:get:node', get);

   /**
    * Adds an AST node.
    *
    * @param {ASTNode}  node - An AST node to store
    *
    * @returns {number} ID for this node.
    */
   function add(node)
   {
      nodes[docId] = node;
      return docId++;
   }

   /**
    * Gets an AST node by ID.
    *
    * @param {number}   id - An ID to retrieve a stored node.
    *
    * @returns {ASTNode}
    */
   function get(id)
   {
      return nodes[id];
   }
}
