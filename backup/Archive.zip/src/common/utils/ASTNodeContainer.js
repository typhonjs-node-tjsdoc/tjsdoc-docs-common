export default class ASTNodeContainer
{
   constructor()
   {
      this._docId = 0;
      this._nodes = {};
   }

   add(node)
   {
      this._nodes[this._docId] = node;
      return this._docId++;
   }

   get(id)
   {
      return this._nodes[id];
   }
}

const s_BUS_NODE_CONTAINER = new ASTNodeContainer();

/**
 * Wires up ASTNodeContainer on the plugin eventbus.
 *
 * @param {PluginEvent} ev - The plugin event.
 *
 * @ignore
 */
export function onPluginLoad(ev)
{
   const eventbus = ev.eventbus;

   eventbus.on('ast:add:node', s_BUS_NODE_CONTAINER.add, s_BUS_NODE_CONTAINER);
   eventbus.on('ast:get:node', s_BUS_NODE_CONTAINER.get, s_BUS_NODE_CONTAINER);
}
