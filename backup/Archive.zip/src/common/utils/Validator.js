export default class Validator
{
   //static validate(config, validationData = {})
   //{
   //   if (typeof config !== 'object') { throw new TypeError(`'config' is not an 'object'.`); }
   //   if (typeof validationData !== 'object') { throw new TypeError(`'validationData' is not an 'object'.`); }
   //
   //   for (const key of Object.keys(validationData))
   //   {
   //      if (!validationData.hasOwnProperty(key)) { continue; }
   //
   //      const entry = validationData[key];
   //
   //      // Missing required entry so exit now.
   //      if (entry.required && typeof config[key] === 'undefined')
   //      {
   //         throw new Error(`missing entry: '${key}.`);
   //      }
   //
   //      // A non-required entry is missing so continue to next entry.
   //      if (!entry.required && typeof config[key] === 'undefined') { continue; }
   //
   //      switch(entry.test)
   //      {
   //         case 'array':
   //            ObjectUtil.validateArray(config, key, entry.expected, entry.message);
   //            break;
   //
   //         case 'entry':
   //            ObjectUtil.validateEntry(config, key, entry.type, entry.expected, entry.message);
   //            break;
   //
   //         case 'entry|array':
   //            ObjectUtil.validateEntryOrArray(config, key, entry.expected, entry.message);
   //            break;
   //      }
   //   }
   //}
   //
   ///**
   // * Validates config entry with a typeof check and potentially tests against the values in any given expected set.
   // *
   // * @param {TJSDocConfig}      config - TJSDoc config object to test.
   // *
   // * @param {string}            entry - Entry in config object to test.
   // *
   // * @param {string}            [type] - Tests with a typeof check.
   // *
   // * @param {function|Set<*>}   [expected] - Optional set of expected values to test against.
   // *
   // * @param {string}            [message] - Optional message to include.
   // */
   //static validateEntry(config, entry, type = void 0, expected = void 0, message = void 0)
   //{
   //   const configEntry = config[entry];
   //
   //   if (type && typeof configEntry !== type) { throw new TypeError(`'config.${entry}' is not a '${type}'.`); }
   //
   //   if (expected instanceof Set && !expected.has(configEntry))
   //   {
   //      throw new Error(`'config.${entry}', '${configEntry}', is not an expected value: ${JSON.stringify(expected)}.`);
   //   }
   //   else if (typeof expected === 'function')
   //   {
   //      try
   //      {
   //         const result = expected(configEntry);
   //
   //         if (typeof result === 'undefined' || !result) { throw new Error(message); }
   //      }
   //      catch (err)
   //      {
   //         throw new Error(`'config.${entry}', '${configEntry}', failed to validate: ${err.message}.`);
   //      }
   //   }
   //}
   //
   ///**
   // * Validates all array entries against the values in the expected Set.
   // *
   // * @param {TJSDocConfig}            config - TJSDoc config object to test.
   // *
   // * @param {string}                  entry - Entry in config object to test.
   // *
   // * @param {function|string|Set<*>}  [expected] - Optional function, string, or set of expected values to test
   // *                                               against.
   // *
   // * @param {string}                  [message] - Optional message to include.
   // */
   //static validateArray(config, entry, expected = void 0, message = void 0)
   //{
   //   const configArray = config[entry];
   //
   //   if (!Array.isArray(configArray)) { throw new TypeError(`'config.${entry}' is not an 'array'.`); }
   //
   //   // If expected is a function then test all array entries against the test function. If expected is a Set then
   //   // test all array entries for inclusion in the set. Otherwise if expected is a string then test that all array
   //   // entries as a `typeof` test against expected.
   //   if (expected instanceof Set)
   //   {
   //      for (let cntr = 0; cntr < configArray.length; cntr++)
   //      {
   //         if (!expected.has(configArray[cntr]))
   //         {
   //            throw new Error(`'config.${entry}' entry [${cntr}], '${configArray[cntr]}', is not an expected value: ${
   //             JSON.stringify(expected)}.`);
   //         }
   //      }
   //   }
   //   else if (typeof expected === 'function')
   //   {
   //      for (let cntr = 0; cntr < configArray.length; cntr++)
   //      {
   //         try
   //         {
   //            const result = expected(configArray[cntr]);
   //
   //            if (typeof result === 'undefined' || !result) { throw new Error(message); }
   //         }
   //         catch (err)
   //         {
   //            throw new Error(`'config.${entry}' entry [${cntr}], '${configArray[cntr]}', failed validation: ${
   //             err.message}.`);
   //         }
   //      }
   //   }
   //   else if (typeof expected === 'string')
   //   {
   //      for (let cntr = 0; cntr < configArray.length; cntr++)
   //      {
   //         if (!(typeof configArray[cntr] === expected))
   //         {
   //            throw new Error(`'config.${entry}' entry [${cntr}], '${configArray[cntr]}', is not a '${expected}'.`);
   //         }
   //      }
   //   }
   //}
   //
   ///**
   // * Dispatches validation of config entry to string or array validation depending on config entry type.
   // *
   // * @param {TJSDocConfig}            config - TJSDoc config object to test.
   // *
   // * @param {string}                  entry - Entry in config object to test.
   // *
   // * @param {function|string|Set<*>}  [expected] - Optional function, string, or set of expected values to test
   // *                                               against.
   // *
   // * @param {string}                  [message] - Optional message to include.
   // */
   //static validateEntryOrArray(config, entry, expected = void 0, message = void 0)
   //{
   //   const configEntry = config[entry];
   //
   //   if (Array.isArray(configEntry))
   //   {
   //      ObjectUtil.validateArray(config, entry, expected, message);
   //   }
   //   else
   //   {
   //      const type = typeof expected;
   //
   //      ObjectUtil.validateEntry(config, entry, type === 'string' ? expected : void 0,
   //       type === 'function' || type instanceof Set ? expected : void 0, message);
   //   }
   //}
}
