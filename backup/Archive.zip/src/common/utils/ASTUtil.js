import walker from 'typhonjs-ast-walker';

/**
 * Wires up walker on the plugin eventbus.
 *
 * @param {PluginEvent} ev - The plugin event.
 *
 * @ignore
 */
export function onPluginLoad(ev)
{
   const eventbus = ev.eventbus;

   eventbus.on('ast:walker:traverse', s_TRAVERSE);
}

/**
 * traverse ast nodes.
 *
 * @param {AST}                                    ast - target AST.
 * @param {function(node: Object, parent: Object)} callback - this is called with each node.
 *
 * @ignore
 */
const s_TRAVERSE = (ast, callback) =>
{
   walker.traverse(ast, { enterNode: (node, parent) => { return callback(node, parent); } });
};
