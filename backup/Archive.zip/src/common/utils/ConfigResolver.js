import fs                  from 'fs';
import path                from 'path';
import stripJsonComments   from 'strip-json-comments';

import ObjectUtil          from './ObjectUtil.js';

/*
 Some of the following code has been adapted from ESLint for supporting config extension.
 Please see: https://github.com/eslint/eslint

 ESLint
 Copyright JS Foundation and other contributors, https://js.foundation

 Permission is hereby granted, free of charge, to any person obtaining a copy
 of this software and associated documentation files (the "Software"), to deal
 in the Software without restriction, including without limitation the rights
 to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in
 all copies or substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 THE SOFTWARE.
 */

/**
 * Provides the default common config resolution process resolving any extensions and setting default values.
 */
export default class ConfigResolver
{
   /**
    * Instantiate ConfigResolver
    *
    * @param {object}      [defaultValues] - Any default values to apply after resolution.
    *
    * @param {object}      [preValidateData] - Any pre-validation data applied against loaded configs.
    *
    * @param {object}      [postValidateData] - Any post-validation data applied after all configs loaded.
    *
    * @param {Set<string>} [upgradeMergeSet] - A Set containing keys that are upgraded to an array and merged.
    *
    * @param {EventProxy}  [eventbus] - The plugin manager eventbus proxy.
    */
   constructor(defaultValues = {}, preValidateData = {}, postValidateData = {}, upgradeMergeSet = new Set(),
    eventbus = void 0)
   {
      this._defaultValues = defaultValues;

      this._preValidateData = preValidateData;

      this._postValidateData = postValidateData;

      this._upgradeMergeSet = upgradeMergeSet;

      this._eventbus = eventbus;
   }

   /**
    * Applies values from the "extends" field in a configuration file.
    *
    * @param {Object}      config The configuration information.
    *
    * @param {string}      filePath The file path from which the configuration information was loaded.
    *
    * @param {string}      [relativeTo] The path to resolve relative to.
    *
    * @param {function}    [validate] - A function performing validation.
    *
    * @param {string[]}    [loadedConfigs] The config files already loaded.
    *
    * @returns {Object} A new configuration object with all of the "extends" fields loaded and merged.
    */
   _applyExtends(config, filePath, relativeTo, validate, loadedConfigs = [])
   {
      let configExtends = config.extends;

      // Normalize into an array for easier handling
      if (!Array.isArray(config.extends)) { configExtends = [config.extends]; }

      // Make the last element in an array take the highest precedence
      config = configExtends.reduceRight((previousValue, parentPath) =>
      {
         if (this._isFilePath(parentPath))
         {
            // If the `extends` path is relative, use the directory of the current configuration
            // file as the reference point. Otherwise, use as-is.
            parentPath = (!path.isAbsolute(parentPath) ?
             path.join(relativeTo || path.dirname(filePath), parentPath) : parentPath);
         }

         // Early out if this path has already been loaded; prevents circular dependencies.
         if (loadedConfigs.indexOf(parentPath) >= 0) { return previousValue; }

         if (this._eventbus) { this._eventbus.trigger('log:info:raw', `resolving config extends: ${parentPath}`); }

         // Stores the loaded config path.
         loadedConfigs.push(parentPath);

         return this._deepMerge(this._load(parentPath, relativeTo, validate, loadedConfigs), previousValue);
      }, config);

      return config;
   }

   /**
    * Merges two config objects. This will not only add missing keys, but will also modify values to match.
    *
    * If an object key is included in this._upgradeMergeSet it will be upgraded and merged into an array without
    * duplicating elements.
    *
    * @param {Object}   target - Config object.
    *
    * @param {Object}   src - Config object. Overrides in this config object will take priority over the base.
    *
    * @param {boolean}  [combine] - Whether to combine arrays or not.
    *
    * @param {string}   [parentKey] - The parent key of the merged items if any.
    *
    * @returns {Object} merged config object.
    */
   _deepMerge(target, src, combine = false, parentKey = void 0)
   {
      /*
       The MIT License (MIT)
       Copyright (c) 2012 Nicholas Fisher
       Permission is hereby granted, free of charge, to any person obtaining a copy
       of this software and associated documentation files (the "Software"), to deal
       in the Software without restriction, including without limitation the rights
       to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
       copies of the Software, and to permit persons to whom the Software is
       furnished to do so, subject to the following conditions:
       The above copyright notice and this permission notice shall be included in
       all copies or substantial portions of the Software.
       THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
       IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
       FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
       AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
       LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
       OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
       THE SOFTWARE.
       */

      // This code is taken from deepmerge repo (https://github.com/KyleAMathews/deepmerge) and modified to meet
      // our needs.
      const array = Array.isArray(src) || Array.isArray(target);

      let dst = array && [] || {};

      combine = !!combine;

      if (array)
      {
         target = target || [];

         // src could be a string, so check for array
         if (Array.isArray(src) && src.length > 1)
         {
            dst = dst.concat(src);
         }
         else
         {
            dst = dst.concat(target);
         }

         if (typeof src !== "object" && !Array.isArray(src))
         {
            src = [src];
         }

         // Plugin merging is handled separately in reverse order and is skipped in merging object elements below.
         if (parentKey === 'plugins' && Array.isArray(target))
         {
            // Push target plugin config if not found in merged destination.
            target.forEach((plugin) =>
            {
               if (!dst.find((dstPlugin) => dstPlugin.name === plugin.name)) { dst.push(plugin); }
            });

            // Replace any existing plugin config in destination that matches a plugin config name from source.
            src.forEach((plugin) =>
            {
               const index = dst.findIndex((dstPlugin) => dstPlugin.name === plugin.name);

               // Potentially remove old plugin with matching name to new plugin.
               if (index >= 0) { dst.splice(index, 1); }

               // Add the new plugin to head of array.
               dst.unshift(plugin);
            });
         }

         Object.keys(src).forEach((srcElement, srcIndex) =>
         {
            srcElement = src[srcIndex];

            if (typeof dst[srcIndex] === "undefined")
            {
               dst[srcIndex] = srcElement;
            }
            else if (typeof srcElement === "object")
            {
               if (parentKey !== 'plugins')
               {
                  dst[srcIndex] = this._deepMerge(target[srcIndex], srcElement, combine, parentKey);
               }
            }
            else
            {
               if (!combine)
               {
                  dst[srcIndex] = srcElement;
               }
               else
               {
                  if (dst.indexOf(srcElement) === -1)
                  {
                     dst.push(srcElement);
                  }
               }
            }
         });
      }
      else
      {
         if (target && typeof target === "object")
         {
            Object.keys(target).forEach((targetKey) =>
            {
               dst[targetKey] = target[targetKey];
            });
         }

         Object.keys(src).forEach((srcKey) =>
         {
            // Potentially upgrade any single value to an array.
            if (this._upgradeMergeSet.has(srcKey) && !Array.isArray(src[srcKey]))
            {
               src[srcKey] = [src[srcKey]];
            }

            if (Array.isArray(src[srcKey]) || Array.isArray(target[srcKey]))
            {
               dst[srcKey] = this._deepMerge(target[srcKey], src[srcKey], this._upgradeMergeSet.has(srcKey), srcKey);
            }
            else if (typeof src[srcKey] !== 'object' || !src[srcKey])
            {
               dst[srcKey] = src[srcKey];
            }
            else
            {
               dst[srcKey] = this._deepMerge(target[srcKey] || {}, src[srcKey], combine, srcKey);
            }
         });
      }

      return dst;
   }

   /**
    * Determines if a given string represents a filepath or not using the same conventions as require(), meaning that
    * the first character must be non-alphanumeric and not the @ sign which is used for scoped packages to be considered
    * a file path.
    *
    * @param {string} filePath The string to check.
    *
    * @returns {boolean} True if it's a filepath, false if not.
    */
   _isFilePath(filePath)
   {
      return path.isAbsolute(filePath) || !(/\w|@/.test(filePath.charAt(0)));
   }

   /**
    * Loads a configuration file from the given file path.
    *
    * @param {string}      filePath The filename or package name to load the configuration information from.
    *
    * @param {string}      [relativeTo] The path to resolve relative to.
    *
    * @param {function}    [validate] - A function performing validation.
    *
    * @param {string[]}    [loadedConfigs] The config files already loaded.
    *
    * @returns {Object} The configuration information.
    */
   _load(filePath, relativeTo = '', validate, loadedConfigs)
   {
      let config, dirname;

      // Resolve relative file path otherwise assume filePath is from an NPM module.
      if (this._isFilePath(filePath))
      {
         const resolvedPath = path.resolve(relativeTo, filePath);
         dirname = path.dirname(resolvedPath);

         const ext = path.extname(resolvedPath);

         if (ext === '.js')
         {
            config = require(resolvedPath);
         }
         else
         {
            const configJSON = fs.readFileSync(resolvedPath, { encode: 'utf8' }).toString();

            config = JSON.parse(stripJsonComments(configJSON));
         }
      }
      else
      {
         config = require(filePath);
      }

      // Perform pre-validation for the loaded config.
      if (validate) { validate(config); }

      if (config)
      {
         // If an `extends` property is defined, it represents a configuration file to use as a `parent`. Load the
         // referenced file and merge the configuration recursively.
         if (config.extends)
         {
            config = this._applyExtends(config, filePath, dirname, validate, loadedConfigs);
         }
      }

      return config;
   }

   /**
    * Validates a config object for any missing or incorrect parameters after resolving.
    *
    * @param {object}   config - A config object to validate.
    *
    * @param {string}   [configName='config'] - Optional name of the config object.
    */
   postValidate(config, configName = 'config')
   {
      if (this._postValidateData) { ObjectUtil.validate(config, this._postValidateData, configName); }
   }

   /**
    * Validates a config object for any missing or incorrect parameters before and during resolving extended config
    * data.
    *
    * @param {object}   config - A config object to validate.
    *
    * @param {string}   [configName='config'] - Optional name of the config object.
    */
   preValidate(config, configName = 'config')
   {
      if (this._preValidateData) { ObjectUtil.validate(config, this._preValidateData, configName); }
   }

   /**
    * Resolves any config extension and sets missing default config values.
    *
    * @param {TJSDocConfig}   config - The TJSDoc config to resolve.
    *
    * @override
    */
   resolve(config)
   {
      if (typeof config !== 'object') { throw new TypeError(`'config' is not an 'object'.`); }

      this.preValidate(config);

      const resolvedConfig = this._resolveExtends(config);

      this.setDefaultValues(resolvedConfig);

      this.postValidate(resolvedConfig);

      return resolvedConfig;
   }

   _resolveExtends(config)
   {
      if (!config.extends) { return JSON.parse(JSON.stringify(config)); }

      // TODO: This could be wrong when released as an NPM module!
      const dirPath = path.resolve(__dirname, '../../');

      const loadedConfigs = [];

      let resolvedConfig;

      try
      {
         resolvedConfig = this._applyExtends(config, dirPath, void 0, this.preValidate, loadedConfigs);
      }
      catch (err)
      {
         // Add the sequence of loaded config files so the user is able to see where the error occurred.
         err.message += `\nReferenced from: \n${loadedConfigs.join('\n')}`;

         throw err;
      }

      // Replace any merged `extends` entries with the resolved loaded order / extends entries.
      if (loadedConfigs.length > 0)
      {
         delete resolvedConfig.extends;

         resolvedConfig.extends = loadedConfigs;
      }

      // Reverse plugin order so that the earliest plugins in extended config chains appear first.
      if (Array.isArray(resolvedConfig.plugins)) { resolvedConfig.plugins.reverse(); }

      return resolvedConfig;
   }

   /**
    * Sets default config values.
    *
    * @param {TJSDocConfig}   config - A TJSDoc config.
    */
   setDefaultValues(config)
   {
      if (this._defaultValues) { ObjectUtil.safeSetAll(config, this._defaultValues); }
   }
}
