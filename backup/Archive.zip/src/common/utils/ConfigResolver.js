import path from 'path';

/**
 * Provides the default common config resolution process resolving any extensions and setting default values.
 */
export default class ConfigResolver
{
   /**
    * Instantiate ConfigResolver
    *
    * @param {EventProxy}  eventbus - The plugin eventbus proxy.
    */
   constructor(eventbus)
   {
      this._eventbus = eventbus;
   }

   /**
    * Resolves any config extension and sets missing default config values.
    *
    * @param {TJSDocConfig}   config - The TJSDoc config to resolve.
    *
    * @override
    */
   resolve(config)
   {
      if (typeof config !== 'object') { throw new TypeError(`'config' is not an 'object'.`); }

      const resolvedConfig = this._resolveExtends(config);

      this.setDefaultValues(resolvedConfig);

      return resolvedConfig;
   }

   _resolveExtends(config)
   {
      if (!config.extends)
      {
console.log('!! ConfigResolver - _resolveExtends - 0 - no config.extends');
         return JSON.parse(JSON.stringify(config));
      }

      const dirPath = path.resolve(__dirname, '../../');

console.log('!! ConfigResolver - resolveExtends - 1 - dirPath: ' + dirPath);

      return s_APPLY_EXTENDS(config, dirPath, this._eventbus);
   }

   /**
    * Sets default config values.
    *
    * @param {TJSDocConfig}   config - A TJSDoc config.
    */
   setDefaultValues(config)
   {
      const dirPath = path.resolve(__dirname);

      if (!config.access) { config.access = ['public', 'protected', 'private']; }

      if (!config.compressFormat) { config.compressFormat = 'tar.gz'; }

      if (!config.excludes) { config.excludes = []; }

      if (!config.index) { config.index = './README.md'; }

      if (!config.logLevel) { config.logLevel = 'info'; }

      if (!config.package) { config.package = './package.json'; }

      if (!config.plugins) { config.plugins = []; }

      if (!config.publisher) { config.publisher = `${dirPath}/../publisher/publish.js`; }

      if (!config.scripts) { config.scripts = []; }

      if (!config.styles) { config.styles = []; }

      if (!('autoPrivate' in config)) { config.autoPrivate = true; }

      if (!('builtinVirtual' in config)) { config.builtinVirtual = true; }

      if (!('compactData' in config)) { config.compactData = false; }

      if (!('compressData' in config)) { config.compressData = false; }

      if (!('compressOutput' in config)) { config.compressOutput = false; }

      if (!('copyPackage' in config)) { config.copyPackage = true; }

      if (!('coverage' in config)) { config.coverage = true; }

      if (!('debug' in config)) { config.debug = false; }

      if (!('emptyDestination' in config)) { config.emptyDestination = false; }

      if (!('includeSource' in config)) { config.includeSource = true; }

      if (!('lint' in config)) { config.lint = true; }

      if (!('outputASTData' in config)) { config.outputASTData = false; }

      if (!('outputDocData' in config)) { config.outputDocData = false; }

      if (!('separateDataArchives' in config)) { config.separateDataArchives = false; }

      if (!('undocumentIdentifier' in config)) { config.undocumentIdentifier = true; }

      if (!('unexportIdentifier' in config)) { config.unexportIdentifier = false; }

      if (config.test)
      {
         if (!config.test.excludes) { config.test.excludes = []; }
      }

      if (config.manual)
      {
         if (!('coverage' in config.manual)) { config.manual.coverage = true; }
      }
   }

   /**
    * Validates a TJSDoc config file for any missing or incorrect parameters.
    *
    * @param {TJSDocConfig}   config - A TJSDoc config to validate.
    */
   validate(config)
   {
      // Ensure that `config.publisher` is defined.
      if (typeof config.publisher !== 'string') { throw new TypeError(`'config.publisher' is not a 'string'.`); }

      if (config.test)
      {
         if (typeof config.test.type !== 'string') { throw new TypeError(`'config.test.type' is not a 'string'.`); }
         if (typeof config.test.source === 'undefined') { throw new TypeError(`'config.test.source' is not defined.`); }

         config.test.type = config.test.type.toLowerCase();

         if (config.test.type !== 'mocha')
         {
            throw new Error(`'config.test.type' is not 'mocha'. Only Mocha tests are supported.`);
         }
      }
   }
}

/**
 * Applies values from the "extends" field in a configuration file.
 *
 * @param {Object} config The configuration information.
 *
 * @param {string} filePath The file path from which the configuration information was loaded.
 *
 * @param {EventProxy} eventbus -
 *
 * @param {string} [relativeTo] The path to resolve relative to.
 *
 * @returns {Object} A new configuration object with all of the "extends" fields loaded and merged.
 */
const s_APPLY_EXTENDS = (config, filePath, eventbus, relativeTo) =>
{
   let configExtends = config.extends;

   // normalize into an array for easier handling
   if (!Array.isArray(config.extends))
   {
      configExtends = [config.extends];
   }

console.log('!! ConfigResolver - s_APPLY_EXTENDS - 0 - filePath: ' + filePath);
console.log('!! ConfigResolver - s_APPLY_EXTENDS - 1 - relativeTo: ' + relativeTo);

   // Make the last element in an array take the highest precedence
   config = configExtends.reduceRight((previousValue, parentPath) =>
   {
      if (s_IS_FILEPATH(parentPath))
      {
console.log('!! ConfigResolver - s_APPLY_EXTENDS - 2A - parentPath: ' + parentPath);

console.log('!! ConfigResolver - s_APPLY_EXTENDS - 2B - !path.isAbsolute(parentPath): ' + !path.isAbsolute(parentPath));
console.log('!! ConfigResolver - s_APPLY_EXTENDS - 2C - path.dirname(filePath): ' + path.dirname(filePath));
console.log('!! ConfigResolver - s_APPLY_EXTENDS - 2D - path.join: ' + path.join(relativeTo || path.dirname(filePath), parentPath));

         /*
          * If the `extends` path is relative, use the directory of the current configuration
          * file as the reference point. Otherwise, use as-is.
          */
         parentPath = (!path.isAbsolute(parentPath) ?
          path.join(relativeTo || path.dirname(filePath), parentPath) : parentPath);

/*
 const s_LOAD = (filePath, eventbus, relativeTo = '') =>
 {
 const resolvedPath = path.resolve(relativeTo, filePath);
 const dirname = path.dirname(resolvedPath);

 */
console.log('!! ConfigResolver - s_APPLY_EXTENDS - 2E - parentPath: ' + parentPath);
      }

      try
      {
         eventbus.trigger('log:info:raw', `loading: ${parentPath}`);

console.log('!! ConfigResolver - s_APPLY_EXTENDS - 3 - previousValue: ' + JSON.stringify(previousValue));

         const mergedConfig = s_DEEP_MERGE(s_LOAD(parentPath, eventbus, relativeTo), previousValue);

console.log('!! ConfigResolver - s_APPLY_EXTENDS - 4 - mergedConfig: ' + JSON.stringify(mergedConfig));

         return mergedConfig;

         //return s_DEEP_MERGE(s_LOAD(parentPath, eventbus, relativeTo), previousValue);
      }
      catch (err)
      {
        /*
          * If the file referenced by `extends` failed to load, add the path
          * to the configuration file that referenced it to the error
          * message so the user is able to see where it was referenced from,
          * then re-throw.
          */
          err.message += `\nReferenced from: ${filePath}`;
         throw err;
      }

   }, config);

   return config;
};

/**
 * Merges two config objects. This will not only add missing keys, but will also modify values to match.
 *
 * @param {Object} target config object
 * @param {Object} src config object. Overrides in this config object will take priority over base.
 * @param {boolean} [combine] Whether to combine arrays or not
 *
 * @returns {Object} merged config object.
 */
const s_DEEP_MERGE = (target, src, combine) =>
{
   /*
    The MIT License (MIT)
    Copyright (c) 2012 Nicholas Fisher
    Permission is hereby granted, free of charge, to any person obtaining a copy
    of this software and associated documentation files (the "Software"), to deal
    in the Software without restriction, including without limitation the rights
    to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
    copies of the Software, and to permit persons to whom the Software is
    furnished to do so, subject to the following conditions:
    The above copyright notice and this permission notice shall be included in
    all copies or substantial portions of the Software.
    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
    OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
    THE SOFTWARE.
    */

   /*
    * This code is taken from deepmerge repo
    * (https://github.com/KyleAMathews/deepmerge)
    * and modified to meet our needs.
    */
   const array = Array.isArray(src) || Array.isArray(target);
   let dst = array && [] || {};

   combine = !!combine;

   if (array)
   {
      target = target || [];

      // src could be a string, so check for array
      if (Array.isArray(src) && src.length > 1)
      {
         dst = dst.concat(src);
      }
      else
      {
         dst = dst.concat(target);
      }

      if (typeof src !== "object" && !Array.isArray(src))
      {
         src = [src];
      }

      Object.keys(src).forEach((e, i) =>
      {
         e = src[i];

         if (typeof dst[i] === "undefined")
         {
            dst[i] = e;
         }
         else if (typeof e === "object")
         {
            dst[i] = s_DEEP_MERGE(target[i], e, combine);
         }
         else
         {
            if (!combine)
            {
               dst[i] = e;
            }
            else
            {
               if (dst.indexOf(e) === -1)
               {
                  dst.push(e);
               }
            }
         }
      });
   }
   else
   {
      if (target && typeof target === "object")
      {
         Object.keys(target).forEach((key) =>
         {
            dst[key] = target[key];
         });
      }

      Object.keys(src).forEach((key) =>
      {
         if (Array.isArray(src[key]) || Array.isArray(target[key]))
         {
            dst[key] = s_DEEP_MERGE(target[key], src[key], key === "plugins");
         }
         else if (typeof src[key] !== "object" || !src[key])
         {
            dst[key] = src[key];
         }
         else
         {
            dst[key] = s_DEEP_MERGE(target[key] || {}, src[key], combine);
         }
      });
   }

   return dst;
};

/**
 * Determines if a given string represents a filepath or not using the same conventions as require(), meaning that the
 * first character must be non-alphanumeric and not the @ sign which is used for scoped packages to be considered a
 * file path.
 *
 * @param {string} filePath The string to check.
 *
 * @returns {boolean} True if it's a filepath, false if not.
 */
const s_IS_FILEPATH = (filePath) =>
{
   return path.isAbsolute(filePath) || !(/\w|@/.test(filePath.charAt(0)));
};

/**
 * Loads a configuration file from the given file path.
 *
 * @param {string} filePath The filename or package name to load the configuration information from.
 *
 * @param {string} [relativeTo] The path to resolve relative to.
 *
 * @param {EventProxy} eventbus -
 *
 * @returns {Object} The configuration information.
 */
const s_LOAD = (filePath, eventbus, relativeTo = '') =>
{
   let dirname, resolvedPath;

   if (s_IS_FILEPATH(filePath))
   {
      resolvedPath = path.resolve(relativeTo, filePath);
      dirname = path.dirname(resolvedPath);
   }
   else
   {
      resolvedPath = filePath;
   }

console.log('!! ConfigResolver - s_LOAD - relativeTo: ' + relativeTo);
console.log('!! ConfigResolver - s_LOAD - filePath: ' + filePath);
console.log('!! ConfigResolver - s_LOAD - resolvedPath: ' + resolvedPath);


   let config = s_LOAD_CONFIG_FILE(resolvedPath);

console.log('!! ConfigResolver - s_LOAD - config: ' + JSON.stringify(config));

   if (config)
   {
      /**
       * If an `extends` property is defined, it represents a configuration file to use as
       * a "parent". Load the referenced file and merge the configuration recursively.
       */
      if (config.extends)
      {
         config = s_APPLY_EXTENDS(config, filePath, eventbus, dirname);
      }
   }

   return config;
};

/**
 * Loads a configuration file regardless of the source. Inspects the file path to determine the correctly way to load
 * the config file.
 *
 * @param {Object} filePath - The path to the configuration.
 *
 * @returns {Object} The configuration information.
 */
const s_LOAD_CONFIG_FILE = (filePath) =>
{
   let config;

console.log('!! ConfigResolver - s_LOAD_CONFIG_FILE - filePath: ' + JSON.stringify(filePath));

   config = require(filePath);

   //switch (path.extname(filePath))
   //{
   //   case ".js":
   //      config = loadJSConfigFile(filePath);
   //      if (file.configName)
   //      {
   //         config = config.configs[file.configName];
   //      }
   //      break;
   //
   //   case ".json":
   //      if (path.basename(filePath) === "package.json")
   //      {
   //         config = loadPackageJSONConfigFile(filePath);
   //         if (config === null)
   //         {
   //            return null;
   //         }
   //      }
   //      else
   //      {
   //         config = loadJSONConfigFile(filePath);
   //      }
   //      break;
   //}

   return config;
};
