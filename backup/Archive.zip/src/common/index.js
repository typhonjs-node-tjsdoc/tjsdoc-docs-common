import path from 'path';

/**
 * Adds all common runtime plugins.
 *
 * @param {PluginEvent} ev - The plugin event.
 *
 * @ignore
 */
export function onPluginLoad(ev)
{
   const eventbus = ev.eventbus;
   const dirPath = path.resolve(__dirname);

   eventbus.trigger('plugins:add', { name: `${dirPath}/doc/resolver/CoreDocResolver.js` });
   eventbus.trigger('plugins:add', { name: `${dirPath}/doc/utils/LintDocLogger.js` });
   eventbus.trigger('plugins:add', { name: `${dirPath}/utils/ASTNodeContainer.js` });
   eventbus.trigger('plugins:add', { name: `${dirPath}/utils/FileUtil.js` });
   eventbus.trigger('plugins:add', { name: `${dirPath}/utils/InvalidCodeLogger.js` });
   eventbus.trigger('plugins:add', { name: `${dirPath}/utils/NamingUtil.js` });
   eventbus.trigger('plugins:add', { name: `${dirPath}/utils/PathResolver.js` });
   eventbus.trigger('plugins:add', { name: `${dirPath}/utils/RepoUtil.js` });
}
