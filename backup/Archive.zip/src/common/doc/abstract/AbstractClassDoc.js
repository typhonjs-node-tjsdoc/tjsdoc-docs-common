import eventbus            from 'backbone-esnext-eventbus';
import fs                  from 'fs-extra';

import AbstractModuleDoc   from './AbstractModuleDoc.js';

/**
 * Provides the common base for documenting classes.
 *
 * The following tags / annotations are supported by AbstractClassDoc and children implementations:
 *
 * `@extends`, `@implements`, `@interface`
 *
 * Child classes must implement the following methods:
 *
 * _$name()
 *
 * _$extends()
 */
export default class AbstractClassDoc extends AbstractModuleDoc
{
   /** specify ``class`` to kind. */
   _$kind()
   {
      this._value.kind = 'class';
   }

   /** take out self memberof from file path. */
   _$memberof()
   {
      this._value.memberof = this._pathResolver.filePath;
   }

   /** for @interface */
   _$interface()
   {
      const tag = this._find(['@interface']);

      if (tag)
      {
         this._value.interface = ['', 'true', true].includes(tag.tagValue);
      }
      else
      {
         this._value.interface = false;
      }
   }

   /** for @implements */
   _$implements()
   {
      const values = this._findAllTagValues(['@implements']);

      if (!values) { return; }

      this._value.implements = [];

      for (const value of values)
      {
         const { typeText } = eventbus.triggerSync('parse:param:value', value,
          { type: true, name: false, desc: false });

         this._value.implements.push(typeText);
      }
   }

   /**
    * The following methods provide the @xxx tags / annotations supported in ExternalDoc. Adding methods makes it easy
    * to detect any unknown tags when a method is missing. Child classes may also add the tags that they support.
    */

   _tag_extend() {}
   _tag_extends() {}
   _tag_implement() {}
   _tag_implements() {}
   _tag_interface() {}

   /**
    * read selection text in file.
    *
    * @param {string} filePath - target file full path.
    * @param {number} line - line number (one origin).
    * @param {number} startColumn - start column number (one origin).
    * @param {number} endColumn - end column number (one origin).
    * @returns {string} selection text
    * @private
    */
   _readSelection(filePath, line, startColumn, endColumn)
   {
      const code = fs.readFileSync(filePath).toString();
      const lines = code.split('\n');
      const selectionLine = lines[line - 1];
      const tmp = [];

      for (let i = startColumn; i < endColumn; i++)
      {
         tmp.push(selectionLine.charAt(i));
      }

      return tmp.join('');
   }
}
