import path from 'path';

/**
 * Used for tests until a better solution is put in place.
 * @ignore
 */
export const _results = [];

/**
 * Lint output logger. Detects parameter mismatches between code and documentation and logs the results.
 */

/**
 * Creates several general utility methods bound to the eventbus.
 *
 * @param {PluginEvent}    ev - An event proxy for the main eventbus.
 */
export function onPluginLoad(ev)
{
   const eventbus = ev.eventbus;

   eventbus.on('tjsdoc:log:lint:doc:warnings', exec);

   /**
    * Executes writing source code for each file
    */
   function exec()
   {
      const results = [];
      const docs = eventbus.triggerSync('tjsdoc:docs:find', { kind: ['method', 'function'] });

      for (const doc of docs)
      {
         if (doc.undocument) { continue; }

         const node = eventbus.triggerSync('tjsdoc:ast:get:node', doc.__docId__);

         // Get AST / parser specific parsing of the node returning any method params.
         const codeParams = eventbus.triggerSync('tjsdoc:ast:get:method:params:from:node', node);

         const docParams = getParamsFromDoc(doc);

         if (match(codeParams, docParams)) { continue; }

         results.push({ node, doc, codeParams, docParams });
      }

      _results.push(...results);

      showResult(eventbus, results);
   }

   /**
    * get variable names of method argument.
    *
    * @param {DocObject} doc - target doc object.
    *
    * @returns {string[]} variable names.
    * @private
    */
   function getParamsFromDoc(doc)
   {
      const params = doc.params || [];

      return params.map((v) => v.name).filter((v) => !v.includes('.')).filter((v) => !v.includes('['));
   }

   /**
    * Checks if code parameters matches document parameters.
    *
    * @param {string[]}  codeParams - Code parameters.
    * @param {string[]}  docParams - Document parameters.
    *
    * @returns {boolean}
    * @private
    */
   function match(codeParams, docParams)
   {
      if (codeParams.length !== docParams.length) { return false; }

      for (let i = 0; i < codeParams.length; i++)
      {
         if (codeParams[i] === '*')
         {
            // do nothing
         }
         else if (codeParams[i] !== docParams[i])
         {
            return false;
         }
      }

      return true;
   }

   /**
    * Show invalid lint code.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    *
    * @param {Array<{doc: DocObject, node: ASTNode, codeParams: string[], docParams: string[]}>} results - target
    *
    * @private
    */
   function showResult(eventbus, results)
   {
      // Early out if there are no results to show.
      if (results.length <= 0) { return; }

      const config = eventbus.triggerSync('tjsdoc:get:config');

      const sourceDir = path.dirname(path.resolve(config.source));

      eventbus.trigger('log:info:raw', '\n[33m==================================[0m');
      eventbus.trigger('log:info:raw', `[33mLintDocLogger warnings:[0m`);
      eventbus.trigger('log:info:raw', '[33m==================================[0m');

      for (const result of results)
      {
         const doc = result.doc;
         const node = result.node;
         const filePath = doc.longname.split('~')[0];
         const name = doc.longname.split('~')[1];
         const absFilePath = path.resolve(sourceDir, filePath);

         const comment = eventbus.triggerSync('tjsdoc:ast:get:file:comment:and:first:line:from:node',
          absFilePath, node);

         eventbus.trigger('log:info:raw',
          `\n[33mwarning: signature mismatch: ${name} ${filePath}#${comment.startLine}[32m`);

         eventbus.trigger('log:info:raw', `[32m${comment.text}[0m'`);
      }
   }
}
