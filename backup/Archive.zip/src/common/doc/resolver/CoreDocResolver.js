/**
 * Resolve various core properties in DocDB / TaffyDB data.
 *
 * @param {PluginEvent}    ev - An event proxy for the main eventbus.
 */
export function onPluginLoad(ev)
{
   const eventbus = ev.eventbus;

   eventbus.on('tjsdoc:core:doc:resolver:resolve', resolve);

   /**
    * Resolve various properties.
    */
   function resolve()
   {
      eventbus.trigger('log:info:raw', 'resolve: extends chain');
      _resolveExtendsChain();

      eventbus.trigger('log:info:raw', 'resolve: necessary');
      _resolveNecessary();

      eventbus.trigger('log:info:raw', 'resolve: access');
      _resolveAccess();

      eventbus.trigger('log:info:raw', 'resolve: unexported identifier');
      _resolveUnexportIdentifier();

      eventbus.trigger('log:info:raw', 'resolve: undocument identifier');
      _resolveUndocumentIdentifier();

      eventbus.trigger('log:info:raw', 'resolve: duplication');
      _resolveDuplication();

      eventbus.trigger('log:info:raw', 'resolve: ignore');
      _resolveIgnore();
   }

   /**
    * Resolve ignore property. Remove docs that has ignore property.
    *
    * @private
    */
   function _resolveIgnore()
   {
      const docs = eventbus.triggerSync('tjsdoc:docs:find', { ignore: true });

      for (const doc of docs)
      {
         const longname = doc.longname.replace(/[$]/g, '\\$');
         const regex = new RegExp(`^${longname}[.~#]`);

         eventbus.triggerSync('tjsdoc:docs:query', { longname: { regex } }).remove();
      }

      eventbus.triggerSync('tjsdoc:docs:query', { ignore: true }).remove();
   }

   /**
    * Resolve access property. If doc does not have access property, the doc is public. but if the name starts with '_',
    * the doc is considered private if TJSDocConfig parameter `autoPrivate` is true.
    *
    * @private
    */
   function _resolveAccess()
   {
      const config = eventbus.triggerSync('tjsdoc:get:config');

      const access = config.access || ['public', 'protected', 'private'];
      const autoPrivate = config.autoPrivate;

      eventbus.triggerSync('tjsdoc:docs:query').update(function()
      {
         if (!this.access)
         {
            /** @ignore */
            this.access = autoPrivate && this.name.charAt(0) === '_' ? 'private' : 'public';
         }

         if (!access.includes(this.access))
         {
            /** @ignore */
            this.ignore = true;
         }

         return this;
      });
   }

   /**
    * Resolve unexport identifier doc. The ignore property is added to non-exported docs.
    *
    * @private
    */
   function _resolveUnexportIdentifier()
   {
      const config = eventbus.triggerSync('tjsdoc:get:config');

      if (!config.unexportIdentifier)
      {
         eventbus.triggerSync('tjsdoc:docs:query', { 'export': false }).update({ ignore: true });
      }
   }

   /**
    * Resolve undocument identifier doc. The ignore property is added docs that have no documentation tags.
    *
    * @private
    */
   function _resolveUndocumentIdentifier()
   {
      const config = eventbus.triggerSync('tjsdoc:get:config');

      if (!config.undocumentIdentifier)
      {
         eventbus.triggerSync('tjsdoc:docs:query', { undocument: true }).update({ ignore: true });
      }
   }

   /**
    * Resolve class extends chain.
    *
    * Add following special properties:
    * - ``_custom_extends_chain``: ancestor class chain.
    * - ``_custom_direct_subclasses``: class list that directly extends target doc.
    * - ``_custom_indirect_subclasses``: class list that indirectly extends target doc.
    * - ``_custom_indirect_implements``: class list that indirectly implements target doc.
    * - ``_custom_direct_implemented``: class list that directly implements target doc.
    * - ``_custom_indirect_implemented``: class list that indirectly implements target doc.
    *
    * @private
    */
   function _resolveExtendsChain()
   {
      const extendsChain = (doc) =>
      {
         if (!doc.extends) { return; }

         const selfDoc = doc;

         // traverse super class.
         const chains = [];

         do
         {
            const superClassDoc = eventbus.triggerSync('tjsdoc:docs:find:by:name', doc.extends[0])[0];

            if (superClassDoc)
            {
               // this is circular extends
               if (superClassDoc.longname === selfDoc.longname) { break; }

               chains.push(superClassDoc.longname);
               doc = superClassDoc;
            }
            else
            {
               chains.push(doc.extends[0]);

               break;
            }
         } while (doc.extends);


         if (chains.length)
         {
            // direct subclass
            let superClassDoc = eventbus.triggerSync('tjsdoc:docs:find:by:name', chains[0])[0];

            if (superClassDoc)
            {
               if (!superClassDoc._custom_direct_subclasses) { superClassDoc._custom_direct_subclasses = []; }

               superClassDoc._custom_direct_subclasses.push(selfDoc.longname);
            }

            // indirect subclass
            for (const superClassLongname of chains.slice(1))
            {
               superClassDoc = eventbus.triggerSync('tjsdoc:docs:find:by:name', superClassLongname)[0];

               if (superClassDoc)
               {
                  if (!superClassDoc._custom_indirect_subclasses) { superClassDoc._custom_indirect_subclasses = []; }

                  superClassDoc._custom_indirect_subclasses.push(selfDoc.longname);
               }
            }

            // indirect implements and mixes
            for (const superClassLongname of chains)
            {
               superClassDoc = eventbus.triggerSync('tjsdoc:docs:find:by:name', superClassLongname)[0];

               if (!superClassDoc) { continue; }

               // indirect implements
               if (superClassDoc.implements)
               {
                  if (!selfDoc._custom_indirect_implements) { selfDoc._custom_indirect_implements = []; }

                  selfDoc._custom_indirect_implements.push(...superClassDoc.implements);
               }
            }

            // extends chains
            selfDoc._custom_extends_chains = chains.reverse();
         }
      };

      const implemented = (doc) =>
      {
         const selfDoc = doc;

         // direct implemented (like direct subclass)
         for (const superClassLongname of selfDoc.implements || [])
         {
            const superClassDoc = eventbus.triggerSync('tjsdoc:docs:find:by:name', superClassLongname)[0];

            if (!superClassDoc) { continue; }
            if (!superClassDoc._custom_direct_implemented) { superClassDoc._custom_direct_implemented = []; }

            superClassDoc._custom_direct_implemented.push(selfDoc.longname);
         }

         // indirect implemented (like indirect subclass)
         for (const superClassLongname of selfDoc._custom_indirect_implements || [])
         {
            const superClassDoc = eventbus.triggerSync('tjsdoc:docs:find:by:name', superClassLongname)[0];

            if (!superClassDoc) { continue; }
            if (!superClassDoc._custom_indirect_implemented) { superClassDoc._custom_indirect_implemented = []; }

            superClassDoc._custom_indirect_implemented.push(selfDoc.longname);
         }
      };

      const docs = eventbus.triggerSync('tjsdoc:docs:find', { kind: 'class' });

      for (const doc of docs)
      {
         extendsChain(doc);
         implemented(doc);
      }
   }

   /**
    * Resolve necessary identifiers.
    *
    * ```javascript
    * class Foo {}
    *
    * export default Bar extends Foo {}
    * ```
    *
    * ``Foo`` is not exported, but ``Bar`` extends ``Foo``.
    * ``Foo`` is necessary.
    * So, ``Foo`` must be exported by force.
    *
    * @private
    */
   function _resolveNecessary()
   {
      eventbus.triggerSync('tjsdoc:docs:query', { 'export': false }).update(function()
      {
         const doc = this;
         const childNames = [];

         if (doc._custom_direct_subclasses) { childNames.push(...doc._custom_direct_subclasses); }
         if (doc._custom_indirect_subclasses) { childNames.push(...doc._custom_indirect_subclasses); }
         if (doc._custom_direct_implemented) { childNames.push(...doc._custom_direct_implemented); }
         if (doc._custom_indirect_implemented) { childNames.push(...doc._custom_indirect_implemented); }

         for (const childName of childNames)
         {
            const childDoc = eventbus.triggerSync('tjsdoc:docs:find', { longname: childName })[0];

            if (!childDoc) { continue; }

            if (!childDoc.ignore && childDoc.export)
            {
               doc.export = true;
               return doc;
            }
         }
      });
   }

   /**
    * Resolve duplicated identifiers. Member docs are possible duplication sources. Other docs are not considered
    * duplicates.
    *
    * @private
    */
   function _resolveDuplication()
   {
      const docs = eventbus.triggerSync('tjsdoc:docs:find', { kind: 'member' });
      const ignoreId = [];

      for (const doc of docs)
      {
         // member duplicate with getter/setter/method.
         // when it, remove member.
         // getter/setter/method are high priority.
         const nonMemberDup = eventbus.triggerSync('tjsdoc:docs:find',
          { longname: doc.longname, kind: { '!is': 'member' } });

         if (nonMemberDup.length)
         {
            ignoreId.push(doc.___id);
            continue;
         }

         const dup = eventbus.triggerSync('tjsdoc:docs:find', { longname: doc.longname, kind: 'member' });

         if (dup.length > 1)
         {
            const ids = dup.map((v) => v.___id);

            ids.sort((a, b) => { return a < b ? -1 : 1; });
            ids.shift();

            ignoreId.push(...ids);
         }
      }

      eventbus.triggerSync('tjsdoc:docs:query', { ___id: ignoreId }).update(function()
      {
         this.ignore = true;

         return this;
      });
   }
}
