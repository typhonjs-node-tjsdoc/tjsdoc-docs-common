import AbstractDoc from './abstract/AbstractDoc.js';

/**
 * Doc from source code in memory. (Used for dynamically loading virtual external & typedef types).
 */
export default class MemoryDoc extends AbstractDoc
{
   /**
    * create instance.
    *
    * @param {AST}            ast - this is AST that contains this doc.
    *
    * @param {ASTNode}        node - this is self node.
    *
    * @param {PathResolver}   pathResolver - this is file path resolver that contains this doc.
    *
    * @param {Tag[]}          commentTags - this is tags that self node has.
    *
    * @param {EventProxy}     eventbus - An event proxy for the main eventbus.
    *
    * @param {String}         code - this is the in memory code that defines this doc.
    */
   constructor(ast, node, pathResolver, commentTags = [], eventbus, code)
   {
      super(ast, node, pathResolver, commentTags, eventbus);

      this._memoryCode = code;
   }

   /** specify ``memory`` to kind. */
   _$kind()
   {
      this._value.kind = 'memory';
   }

   /** take out self name from file path */
   _$name()
   {
      this._value.name = 'In memory code';
   }

   /** specify name to longname */
   _$longname()
   {
      this._value.longname = 'In memory code';
   }

   /** specify memory content to value.content */
   _$content()
   {
      this._value.content = this._memoryCode;
   }
}
