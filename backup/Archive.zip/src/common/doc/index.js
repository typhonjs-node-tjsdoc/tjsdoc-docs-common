// Export common docs
export { default as ExternalDoc }   from './ExternalDoc.js';
export { default as FileDoc }       from './FileDoc.js';
export { default as MemoryDoc }     from './MemoryDoc.js';
export { default as TestFileDoc }   from './TestFileDoc.js';
