import markdown from './utils/markdown.js';

/**
 * Resolve various properties in DocDB / TaffyDB data.
 */
export default class DocResolver
{
   /**
    * Resolve various properties.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    */
   static resolve(eventbus)
   {
      console.log('resolve: extends chain');
      DocResolver._resolveExtendsChain(eventbus);

      console.log('resolve: necessary');
      DocResolver._resolveNecessary(eventbus);

      console.log('resolve: access');
      DocResolver._resolveAccess(eventbus);

      console.log('resolve: unexported identifier');
      DocResolver._resolveUnexportIdentifier(eventbus);

      console.log('resolve: undocument identifier');
      DocResolver._resolveUndocumentIdentifier(eventbus);

      console.log('resolve: duplication');
      DocResolver._resolveDuplication(eventbus);

      console.log('resolve: ignore');
      DocResolver._resolveIgnore(eventbus);

      console.log('resolve: link');
      DocResolver._resolveLink(eventbus);

      console.log('resolve: markdown in description');
      DocResolver._resolveMarkdown(eventbus);

      console.log('resolve: test relation');
      DocResolver._resolveTestRelation(eventbus);
   }

   /**
    * Resolve ignore property. Remove docs that has ignore property.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    *
    * @private
    */
   static _resolveIgnore(eventbus)
   {
      const docs = eventbus.triggerSync('tjsdoc:docs:find', { ignore: true });

      for (const doc of docs)
      {
         const longname = doc.longname.replace(/[$]/g, '\\$');
         const regex = new RegExp(`^${longname}[.~#]`);

         eventbus.triggerSync('tjsdoc:docs:query', { longname: { regex } }).remove();
      }

      eventbus.triggerSync('tjsdoc:docs:query', { ignore: true }).remove();
   }

   /**
    * Resolve access property. If doc does not have access property, the doc is public. but if the name starts with '_',
    * the doc is considered private if TJSDocConfig parameter `autoPrivate` is true.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    *
    * @private
    */
   static _resolveAccess(eventbus)
   {
      const config = eventbus.triggerSync('tjsdoc:get:config');

      const access = config.access || ['public', 'protected', 'private'];
      const autoPrivate = config.autoPrivate;

      eventbus.triggerSync('tjsdoc:docs:query').update(function()
      {
         if (!this.access)
         {
            /** @ignore */
            this.access = autoPrivate && this.name.charAt(0) === '_' ? 'private' : 'public';
         }

         if (!access.includes(this.access))
         {
            /** @ignore */
            this.ignore = true;
         }

         return this;
      });
   }

   /**
    * Resolve unexport identifier doc. The ignore property is added to non-exported docs.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    *
    * @private
    */
   static _resolveUnexportIdentifier(eventbus)
   {
      const config = eventbus.triggerSync('tjsdoc:get:config');

      if (!config.unexportIdentifier)
      {
         eventbus.triggerSync('tjsdoc:docs:query', { 'export': false }).update({ ignore: true });
      }
   }

   /**
    * Resolve undocument identifier doc. The ignore property is added docs that have no documentation tags.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    *
    * @private
    */
   static _resolveUndocumentIdentifier(eventbus)
   {
      const config = eventbus.triggerSync('tjsdoc:get:config');

      if (!config.undocumentIdentifier)
      {
         eventbus.triggerSync('tjsdoc:docs:query', { undocument: true }).update({ ignore: true });
      }
   }

   /**
    * Resolve description as markdown.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    *
    * @private
    */
   static _resolveMarkdown(eventbus)
   {
      const convert = (doc) =>
      {
         for (const key of Object.keys(doc))
         {
            const value = doc[key];

            if (key === 'description' && typeof value === 'string')
            {
               doc[`${key}Raw`] = doc[key];
               doc[key] = markdown(value, false);
            }
            else if (typeof value === 'object' && value)
            {
               convert(value);
            }
         }
      };

      for (const doc of eventbus.triggerSync('tjsdoc:docs:find')) { convert(doc); }
   }

   /**
    * Resolve @link tags as HTML links.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    *
    * @private
    * @todo Resolve all ``description`` property.
    */
   static _resolveLink(eventbus)
   {
      const link = (str) =>
      {
         if (!str) { return str; }

         return str.replace(/\{@link ([\w#_\-.:~\/$]+)}/g, (str, longname) =>
         {
            return eventbus.triggerSync('tjsdoc:publisher:get:doc:html:link', longname, longname);
         });
      };

      eventbus.triggerSync('tjsdoc:docs:query').each((v) =>
      {
         v.description = link(v.description);

         if (v.params)
         {
            for (const param of v.params)
            {
               param.description = link(param.description);
            }
         }

         if (v.properties)
         {
            for (const property of v.properties)
            {
               property.description = link(property.description);
            }
         }

         if (v.return)
         {
            v.return.description = link(v.return.description);
         }

         if (v.throws)
         {
            for (const _throw of v.throws)
            {
               _throw.description = link(_throw.description);
            }
         }

         if (v.see)
         {
            for (let i = 0; i < v.see.length; i++)
            {
               if (v.see[i].indexOf('{@link') === 0)
               {
                  v.see[i] = link(v.see[i]);
               }
               else if (v.see[i].indexOf('<a href') === 0)
               {
                  // ignore
               }
               else
               {
                  v.see[i] = `<a href="${v.see[i]}">${v.see[i]}</a>`;
               }
            }
         }
      });
   }

   /**
    * Resolve class extends chain.
    *
    * Add following special properties:
    * - ``_custom_extends_chain``: ancestor class chain.
    * - ``_custom_direct_subclasses``: class list that directly extends target doc.
    * - ``_custom_indirect_subclasses``: class list that indirectly extends target doc.
    * - ``_custom_indirect_implements``: class list that indirectly implements target doc.
    * - ``_custom_direct_implemented``: class list that directly implements target doc.
    * - ``_custom_indirect_implemented``: class list that indirectly implements target doc.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    *
    * @private
    */
   static _resolveExtendsChain(eventbus)
   {
      const extendsChain = (doc) =>
      {
         if (!doc.extends) { return; }

         const selfDoc = doc;

         // traverse super class.
         const chains = [];

         do
         {
            const superClassDoc = eventbus.triggerSync('tjsdoc:docs:find:by:name', doc.extends[0])[0];

            if (superClassDoc)
            {
               // this is circular extends
               if (superClassDoc.longname === selfDoc.longname) { break; }

               chains.push(superClassDoc.longname);
               doc = superClassDoc;
            }
            else
            {
               chains.push(doc.extends[0]);

               break;
            }
         } while (doc.extends);


         if (chains.length)
         {
            // direct subclass
            let superClassDoc = eventbus.triggerSync('tjsdoc:docs:find:by:name', chains[0])[0];

            if (superClassDoc)
            {
               if (!superClassDoc._custom_direct_subclasses) { superClassDoc._custom_direct_subclasses = []; }

               superClassDoc._custom_direct_subclasses.push(selfDoc.longname);
            }

            // indirect subclass
            for (const superClassLongname of chains.slice(1))
            {
               superClassDoc = eventbus.triggerSync('tjsdoc:docs:find:by:name', superClassLongname)[0];

               if (superClassDoc)
               {
                  if (!superClassDoc._custom_indirect_subclasses) { superClassDoc._custom_indirect_subclasses = []; }

                  superClassDoc._custom_indirect_subclasses.push(selfDoc.longname);
               }
            }

            // indirect implements and mixes
            for (const superClassLongname of chains)
            {
               superClassDoc = eventbus.triggerSync('tjsdoc:docs:find:by:name', superClassLongname)[0];

               if (!superClassDoc) { continue; }

               // indirect implements
               if (superClassDoc.implements)
               {
                  if (!selfDoc._custom_indirect_implements) { selfDoc._custom_indirect_implements = []; }

                  selfDoc._custom_indirect_implements.push(...superClassDoc.implements);
               }
            }

            // extends chains
            selfDoc._custom_extends_chains = chains.reverse();
         }
      };

      const implemented = (doc) =>
      {
         const selfDoc = doc;

         // direct implemented (like direct subclass)
         for (const superClassLongname of selfDoc.implements || [])
         {
            const superClassDoc = eventbus.triggerSync('tjsdoc:docs:find:by:name', superClassLongname)[0];

            if (!superClassDoc) { continue; }
            if (!superClassDoc._custom_direct_implemented) { superClassDoc._custom_direct_implemented = []; }

            superClassDoc._custom_direct_implemented.push(selfDoc.longname);
         }

         // indirect implemented (like indirect subclass)
         for (const superClassLongname of selfDoc._custom_indirect_implements || [])
         {
            const superClassDoc = eventbus.triggerSync('tjsdoc:docs:find:by:name', superClassLongname)[0];

            if (!superClassDoc) { continue; }
            if (!superClassDoc._custom_indirect_implemented) { superClassDoc._custom_indirect_implemented = []; }

            superClassDoc._custom_indirect_implemented.push(selfDoc.longname);
         }
      };

      const docs = eventbus.triggerSync('tjsdoc:docs:find', { kind: 'class' });

      for (const doc of docs)
      {
         extendsChain(doc);
         implemented(doc);
      }
   }

   /**
    * Resolve necessary identifiers.
    *
    * ```javascript
    * class Foo {}
    *
    * export default Bar extends Foo {}
    * ```
    *
    * ``Foo`` is not exported, but ``Bar`` extends ``Foo``.
    * ``Foo`` is necessary.
    * So, ``Foo`` must be exported by force.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    *
    * @private
    */
   static _resolveNecessary(eventbus)
   {
      eventbus.triggerSync('tjsdoc:docs:query', { 'export': false }).update(function()
      {
         const doc = this;
         const childNames = [];

         if (doc._custom_direct_subclasses) { childNames.push(...doc._custom_direct_subclasses); }
         if (doc._custom_indirect_subclasses) { childNames.push(...doc._custom_indirect_subclasses); }
         if (doc._custom_direct_implemented) { childNames.push(...doc._custom_direct_implemented); }
         if (doc._custom_indirect_implemented) { childNames.push(...doc._custom_indirect_implemented); }

         for (const childName of childNames)
         {
            const childDoc = eventbus.triggerSync('tjsdoc:docs:find', { longname: childName })[0];

            if (!childDoc) { continue; }

            if (!childDoc.ignore && childDoc.export)
            {
               doc.export = true;
               return doc;
            }
         }
      });
   }

   /**
    * Resolve tests and identifier relationships adding the following special properties:
    * - ``_custom_tests``: longnames of test doc.
    * - ``_custom_test_targets``: longnames of identifier.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    *
    * @private
    */
   static _resolveTestRelation(eventbus)
   {
      const testDocs = eventbus.triggerSync('tjsdoc:docs:find', { kind: ['testDescribe', 'testIt'] });

      for (const testDoc of testDocs)
      {
         const testTargets = testDoc.testTargets;

         if (!testTargets) { continue; }

         for (const testTarget of testTargets)
         {
            const doc = eventbus.triggerSync('tjsdoc:docs:find:by:name', testTarget)[0];

            if (doc)
            {
               if (!doc._custom_tests) { doc._custom_tests = []; }

               doc._custom_tests.push(testDoc.longname);

               if (!testDoc._custom_test_targets) { testDoc._custom_test_targets = []; }

               testDoc._custom_test_targets.push([doc.longname, testTarget]);
            }
            else
            {
               if (!testDoc._custom_test_targets) { testDoc._custom_test_targets = []; }

               testDoc._custom_test_targets.push([testTarget, testTarget]);
            }
         }
      }

      // test full description
      for (const testDoc of testDocs)
      {
         const desc = [];
         const parents = (testDoc.memberof.split('~')[1] || '').split('.');

         for (const parent of parents)
         {
            const doc = eventbus.triggerSync('tjsdoc:docs:find', { kind: ['testDescribe', 'testIt'], name: parent })[0];

            if (!doc) { continue; }

            desc.push(doc.descriptionRaw);
         }

         desc.push(testDoc.descriptionRaw);
         testDoc.testFullDescription = desc.join(' ');
      }
   }

   /**
    * Resolve duplicated identifiers. Member docs are possible duplication sources. Other docs are not considered
    * duplicates.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    *
    * @private
    */
   static _resolveDuplication(eventbus)
   {
      const docs = eventbus.triggerSync('tjsdoc:docs:find', { kind: 'member' });
      const ignoreId = [];

      for (const doc of docs)
      {
         // member duplicate with getter/setter/method.
         // when it, remove member.
         // getter/setter/method are high priority.
         const nonMemberDup = eventbus.triggerSync('tjsdoc:docs:find',
          { longname: doc.longname, kind: { '!is': 'member' } });

         if (nonMemberDup.length)
         {
            ignoreId.push(doc.___id);
            continue;
         }

         const dup = eventbus.triggerSync('tjsdoc:docs:find', { longname: doc.longname, kind: 'member' });

         if (dup.length > 1)
         {
            const ids = dup.map((v) => v.___id);

            ids.sort((a, b) => { return a < b ? -1 : 1; });
            ids.shift();

            ignoreId.push(...ids);
         }
      }

      eventbus.triggerSync('tjsdoc:docs:query', { ___id: ignoreId }).update(function()
      {
         this.ignore = true;

         return this;
      });
   }
}
