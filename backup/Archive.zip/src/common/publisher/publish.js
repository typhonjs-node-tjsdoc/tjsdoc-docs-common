import * as Builder        from './builder/';
import PublishDocResolver  from './PublishDocResolver.js';
import PublisherEvents     from './PublisherEvents.js';

/**
 * Publish documentation as static HTML + resources.
 *
 * An eventbus proxy must be passed in so that the default publish action can be overridden for instance when running
 * tests. This publisher registers several event bindings on the eventbus; please see {@link PublisherEvents}.
 *
 * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
 */
function publish(eventbus)
{
   // Add the IceCap plugin for DOM / template generation.
   eventbus.trigger('plugins:add', { name: 'typhonjs-ice-cap' });

   /**
    * @type TJSDocConfig
    */
   const config = eventbus.triggerSync('tjsdoc:get:config');

   // Set IceCap debug mode if `config.debug` is true. Helps find any errors in template generation.
   eventbus.trigger('ice:cap:set:debug', config.debug);

   // Potentially empty `config.destination` if `config.emptyDestination` is true.
   eventbus.trigger('tjsdoc:util:empty:destination');

   // Note the compression format extension will automatically be added.
   if (config.compressOutput) { eventbus.trigger('tjsdoc:util:archive:create', 'docs'); }

   // Optionally output raw document / tag data.
   if (config.outputDocData)
   {
      // Write doc data as JSON to 'docData.json'
      const docData = eventbus.triggerSync('tjsdoc:get:doc:data');

      const docDataJSON = config.compactData ? JSON.stringify(docData) : JSON.stringify(docData, null, 3);

      // Note the compression format extension will automatically be added.
      if (config.compressData) { eventbus.trigger('tjsdoc:util:archive:create', 'docData'); }

      eventbus.trigger('tjsdoc:util:write:file', docDataJSON, 'docData.json');

      if (config.compressData) { eventbus.trigger('tjsdoc:util:archive:finalize'); }
   }

   // Registers several publishing related event bindings for outputting and structuring static HTML documentation.
   PublisherEvents.register(eventbus);

   // Processes and resolves any publisher specific DocDB data.
   PublishDocResolver.resolve(eventbus);

   // Optional output.
   if (config.coverage) { Builder.Coverage.exec(eventbus); }
   if (config.outputASTData) { Builder.ASTDoc.exec(eventbus); }

   Builder.ClassDoc.exec(eventbus);
   Builder.FileDoc.exec(eventbus);
   Builder.IdentifiersDoc.exec(eventbus);
   Builder.IndexDoc.exec(eventbus);
   Builder.ManualDoc.exec(eventbus);
   Builder.SearchIndex.exec(eventbus);
   Builder.SingleDoc.exec(eventbus);
   Builder.SourceDoc.exec(eventbus);
   Builder.StaticFile.exec(eventbus);

   const packageJSON = eventbus.triggerSync('tjsdoc:get:package:json');

   // Copy package.json if it is defined and `copyPackage` TJSDoc config parameter is true.
   if (packageJSON && config.copyPackage)
   {
      eventbus.trigger('tjsdoc:util:write:file', packageJSON, 'package.json');
   }

   // If test source is defined then build / output test coverage.
   if (config.test)
   {
      Builder.TestDoc.exec(eventbus);
      Builder.TestFileDoc.exec(eventbus);
   }

   if (config.compressOutput) { eventbus.trigger('tjsdoc:util:archive:finalize'); }

   // If documentation coverage is enabled then output a text description of results.
   if (config.coverage)
   {
      const coverage = eventbus.triggerSync('tjsdoc:publisher:get:coverage');

      eventbus.trigger('log:info:raw', '==================================');
      eventbus.trigger('log:info:raw',
       `Coverage: ${coverage.coverage} (${coverage.actualCount}/${coverage.expectCount})`);
      eventbus.trigger('log:info:raw', '==================================');
   }
}

export default publish;

/**
 * Wires up publisher to plugin eventbus.
 *
 * @param {PluginEvent} ev - The plugin event.
 *
 * @ignore
 */
export function onPluginLoad(ev)
{
   ev.eventbus.on('tjsdoc:publisher:publish', publish);
}
