import IceCap           from 'ice-cap';

import * as Builder     from './builder/';
import DocResolver      from './DocResolver.js';
import PublisherEvents  from './PublisherEvents.js';

/**
 * Publish documentation as static HTML + resources.
 *
 * An eventbus proxy must be passed in so that the default publish action can be overridden for instance when running
 * tests. This publisher registers several event bindings on the eventbus; please see {@link PublisherEvents}.
 *
 * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
 */
function publish(eventbus)
{
   /**
    * @type TJSDocConfig
    */
   const config = eventbus.triggerSync('tjsdoc:get:config');

   IceCap.debug = !!config.debug;

   // Optionally output raw document / tag data.
   if (config.outputDocData)
   {
      // Write doc data as JSON to 'docData.json'
      const docDataJSON = JSON.stringify(eventbus.triggerSync('tjsdoc:get:doc:data'), null, 3);

      eventbus.trigger('tjsdoc:util:write:file', docDataJSON, 'docData.json');
   }

   // Registers several publishing related event bindings for outputting and structuring static HTML documentation.
   PublisherEvents.register(eventbus);

   // Processes and resolves DocDB data.
   DocResolver.resolve(eventbus);

   // Optional output.
   if (config.coverage) { Builder.Coverage.exec(eventbus); }
   if (config.outputAST) { Builder.ASTDoc.exec(eventbus); }

   Builder.ClassDoc.exec(eventbus);
   Builder.FileDoc.exec(eventbus);
   Builder.IdentifiersDoc.exec(eventbus);
   Builder.IndexDoc.exec(eventbus);
   Builder.ManualDoc.exec(eventbus);
   Builder.SearchIndex.exec(eventbus);
   Builder.SingleDoc.exec(eventbus);
   Builder.SourceDoc.exec(eventbus);
   Builder.StaticFile.exec(eventbus);

   const packageJSON = eventbus.triggerSync('tjsdoc:get:package:json');

   // Copy package.json if it is defined and `copyPackage` TJSDoc config parameter is true.
   if (packageJSON && config.copyPackage)
   {
      eventbus.trigger('tjsdoc:util:write:file', packageJSON, 'package.json');
   }

   // If test source is defined then build / output test coverage.
   if (config.test)
   {
      Builder.TestDoc.exec(eventbus);
      Builder.TestFileDoc.exec(eventbus);
   }

   // If documentation coverage is enabled then output a text description of results.
   if (config.coverage)
   {
      const coverage = eventbus.triggerSync('tjsdoc:publisher:get:coverage');

      eventbus.trigger('log:info:raw', '==================================');
      eventbus.trigger('log:info:raw',
       `Coverage: ${coverage.coverage} (${coverage.actualCount}/${coverage.expectCount})`);
      eventbus.trigger('log:info:raw', '==================================');
   }
}

export default publish;

/**
 * Wires up publisher to plugin eventbus.
 *
 * @param {PluginEvent} ev - The plugin event.
 *
 * @ignore
 */
export function onPluginLoad(ev)
{
   ev.eventbus.on('tjsdoc:publisher:publish', publish);
}
