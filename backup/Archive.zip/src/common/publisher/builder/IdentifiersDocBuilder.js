import IceCap from 'ice-cap';

/**
 * Identifier output builder.
 */
export default class IdentifiersDocBuilder
{
   /**
    * Executes writing identifiers / reference page.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    */
   static exec(eventbus)
   {
      const ice = eventbus.triggerSync('tjsdoc:publisher:get:html:layout');
      const title = eventbus.triggerSync('tjsdoc:publisher:get:title', 'Index');

      ice.load('content', IdentifiersDocBuilder._buildIdentifierDoc(eventbus));
      ice.text('title', title, IceCap.MODE_WRITE);

      eventbus.trigger('tjsdoc:util:write:html', ice.html, 'identifiers.html');
   }

   /**
    * Build identifier output.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    *
    * @return {IceCap} built output.
    * @private
    */
   static _buildIdentifierDoc(eventbus)
   {
      const indexInfo = eventbus.triggerSync('tjsdoc:get:repo:info');
      const ice = new IceCap(eventbus.triggerSync('tjsdoc:publisher:get:template', 'identifiers.html'));

      ice.text('title', indexInfo.title);
      ice.text('version', indexInfo.version, 'append');
      ice.text('url', indexInfo.url);
      ice.attr('url', 'href', indexInfo.url);
      ice.text('description', indexInfo.desc);

      ice.load('classSummary', eventbus.triggerSync('tjsdoc:publisher:get:doc:html:summary', null, 'class',
       'Class Summary'), 'append');

      ice.load('interfaceSummary', eventbus.triggerSync('tjsdoc:publisher:get:doc:html:summary', null, 'interface',
       'Interface Summary'), 'append');

      ice.load('functionSummary', eventbus.triggerSync('tjsdoc:publisher:get:doc:html:summary', null, 'function',
       'Function Summary'), 'append');

      ice.load('variableSummary', eventbus.triggerSync('tjsdoc:publisher:get:doc:html:summary', null, 'variable',
       'Variable Summary'), 'append');

      ice.load('typedefSummary', eventbus.triggerSync('tjsdoc:publisher:get:doc:html:summary', null, 'typedef',
       'Typedef Summary'), 'append');

      ice.load('externalSummary', eventbus.triggerSync('tjsdoc:publisher:get:doc:html:summary', null, 'external',
       'External Summary'), 'append');

      return ice;
   }
}
