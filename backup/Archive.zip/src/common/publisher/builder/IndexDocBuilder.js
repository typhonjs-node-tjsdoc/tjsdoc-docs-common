import fs                  from 'fs';
import IceCap              from 'ice-cap';
import path                from 'path';

import markdown            from '../utils/markdown.js';

/**
 * Index output builder.
 *
 * Outputs the main `index.html` file for generated documentation including any README.md or other file specified by
 * `config.index`.
 */
export default class IndexDocBuilder
{
   /**
    * Executes writing `index.html`.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    */
   static exec(eventbus)
   {
      const ice = eventbus.triggerSync('tjsdoc:publisher:get:html:layout');
      const title = eventbus.triggerSync('tjsdoc:publisher:get:title');

      ice.load('content', IndexDocBuilder._buildIndexDoc(eventbus));
      ice.text('title', title, IceCap.MODE_WRITE);

      eventbus.trigger('tjsdoc:util:write:html', ice.html, 'index.html');
   }

   /**
    * Build index output including converting `config.index` to HTML from markdown.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    *
    * @returns {string} html of index output.
    * @private
    */
   static _buildIndexDoc(eventbus)
   {
      const config = eventbus.triggerSync('tjsdoc:get:config');

      if (!config.index) { return 'Please create README.md'; }

      let indexContent;

      try
      {
         indexContent = fs.readFileSync(config.index, { encode: 'utf8' }).toString();
      }
      catch (err)
      {
         return 'Please create README.md';
      }

      const html = eventbus.triggerSync('tjsdoc:publisher:get:template', 'index.html');
      const ice = new IceCap(html);
      const ext = path.extname(config.index);

      if (['.md', '.markdown'].includes(ext))
      {
         ice.load('index', markdown(indexContent));
      }
      else
      {
         ice.load('index', indexContent);
      }

      return ice.html;
   }
}
