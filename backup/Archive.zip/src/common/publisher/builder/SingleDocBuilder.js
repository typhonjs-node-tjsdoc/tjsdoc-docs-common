import IceCap from 'ice-cap';

/**
 * Single output builder class.
 * "single" means function, variable, typedef, external, etc...
 */
export default class SingleDocBuilder
{
   /**
    * execute building output.
    */
   static exec(eventbus)
   {
      const ice = eventbus.triggerSync('tjsdoc:publisher:get:html:layout');

      ice.autoClose = false;

      const kinds = ['function', 'variable', 'typedef'];

      for (const kind of kinds)
      {
         const docs = eventbus.triggerSync('tjsdoc:docs:find', { kind });

         if (!docs.length) { continue; }

         const fileName = eventbus.triggerSync('tjsdoc:publisher:get:doc:file:name', docs[0]);
         const baseUrl = eventbus.triggerSync('tjsdoc:publisher:get:file:url:base', fileName);

         let title = kind.replace(/^(\w)/, (c) => c.toUpperCase());

         title = eventbus.triggerSync('tjsdoc:publisher:get:title', title);

         ice.load('content', SingleDocBuilder._buildSingleDoc(eventbus, kind), IceCap.MODE_WRITE);
         ice.attr('baseUrl', 'href', baseUrl, IceCap.MODE_WRITE);
         ice.text('title', title, IceCap.MODE_WRITE);

         eventbus.trigger('tjsdoc:util:write:html', ice.html, fileName);
      }
   }

   /**
    * build single output.
    *
    * @param {string} kind - target kind property.
    *
    * @returns {string} html of single output
    * @private
    */
   static _buildSingleDoc(eventbus, kind)
   {
      const title = kind.replace(/^(\w)/, (c) => c.toUpperCase());
      const ice = new IceCap(eventbus.triggerSync('tjsdoc:publisher:get:template', 'single.html'));

      ice.text('title', title);

      ice.load('summaries', eventbus.triggerSync('tjsdoc:publisher:get:doc:html:summary', null, kind,
       'Summary'), 'append');

      ice.load('details', eventbus.triggerSync('tjsdoc:publisher:get:html:detail', null, kind, ''));

      return ice.html;
   }
}
