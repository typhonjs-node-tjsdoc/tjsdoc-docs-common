/**
 * Search index of identifier builder class.
 */
export default class SearchIndexBuilder
{
   /**
    * execute building output.
    */
   static exec(eventbus)
   {
      const searchIndex = [];
      const docs = eventbus.triggerSync('tjsdoc:docs:find', {});

      for (const doc of docs)
      {
         let indexText;
         let url;
         let displayText;

         if (doc.importPath)
         {
            displayText = `<span>${doc.name}</span> <span class="search-result-import-path">${doc.importPath}</span>`;
            indexText = `${doc.importPath}~${doc.name}`.toLowerCase();

            url = eventbus.triggerSync('tjsdoc:publisher:get:doc:url', doc);
         }
         else if (doc.kind === 'testDescribe' || doc.kind === 'testIt')
         {
            displayText = doc.testFullDescription;
            indexText = [...(doc.testTargets || []), ...(doc._custom_test_targets || [])].join(' ').toLowerCase();

            const filePath = doc.longname.split('~')[0];
            const fileDoc = eventbus.triggerSync('tjsdoc:docs:find', { kind: 'testFile', longname: filePath })[0];

            url = `${eventbus.triggerSync('tjsdoc:publisher:get:doc:url', fileDoc)}#lineNumber${doc.lineNumber}`;
         }
         else if (doc.kind === 'external')
         {
            displayText = doc.longname;
            indexText = displayText.toLowerCase();

            url = doc.externalLink;
         }
         else
         {
            displayText = doc.longname;
            indexText = displayText.toLowerCase();

            url = eventbus.triggerSync('tjsdoc:publisher:get:doc:url', doc);
         }

         let kind = doc.kind;

         switch (kind)
         {
            case 'constructor':
               kind = 'method';
               break;

            case 'get':
            case 'set':
               kind = 'member';
               break;

            case 'testDescribe':
            case 'testIt':
               kind = 'test';
               break;
         }

         searchIndex.push([indexText, url, displayText, kind]);
      }

      searchIndex.sort((a, b) =>
      {
         if (a[2] === b[2])
         {
            return 0;
         }
         else if (a[2] < b[2])
         {
            return -1;
         }
         else
         {
            return 1;
         }
      });

      const javascript = `window.esdocSearchIndex = ${JSON.stringify(searchIndex, null, 2)}`;

      eventbus.trigger('tjsdoc:util:write:html', javascript, 'script/search_index.js');
   }
}
