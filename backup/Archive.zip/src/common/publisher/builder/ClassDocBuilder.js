import IceCap        from 'ice-cap';

import parseExample  from '../utils/parseExample.js';

/**
 * Class Output Builder.
 *
 * The static HTML is output to `config.destination`/class
 */
export default class ClassDocBuilder
{
   /**
    * Executes writing class HTML output.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    */
   static exec(eventbus)
   {
      const ice = eventbus.triggerSync('tjsdoc:publisher:get:html:layout');
      const docs = eventbus.triggerSync('tjsdoc:docs:find', { kind: ['class'] });

      ice.autoDrop = false;

      for (const doc of docs)
      {
         const fileName = eventbus.triggerSync('tjsdoc:publisher:get:doc:file:name', doc);
         const baseUrl = eventbus.triggerSync('tjsdoc:publisher:get:file:url:base', fileName);
         const title = eventbus.triggerSync('tjsdoc:publisher:get:title', doc);

         ice.load('content', ClassDocBuilder._buildClassDoc(eventbus, doc), IceCap.MODE_WRITE);
         ice.attr('baseUrl', 'href', baseUrl, IceCap.MODE_WRITE);
         ice.text('title', title, IceCap.MODE_WRITE);

         eventbus.trigger('tjsdoc:util:write:html', ice.html, fileName);
      }
   }

   /**
    * Build class output.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    * @param {DocObject}   doc - class doc object.
    *
    * @returns {IceCap} built output.
    * @private
    */
   static _buildClassDoc(eventbus, doc)
   {
      const expressionExtends = ClassDocBuilder._buildExpressionExtendsHTML(eventbus, doc);
      const mixinClasses = ClassDocBuilder._buildMixinClassesHTML(eventbus, doc);
      const extendsChain = ClassDocBuilder._buildExtendsChainHTML(eventbus, doc);
      const directSubclass = ClassDocBuilder._buildDirectSubclassHTML(eventbus, doc);
      const indirectSubclass = ClassDocBuilder._buildIndirectSubclassHTML(eventbus, doc);

      const instanceDocs = eventbus.triggerSync('tjsdoc:docs:find', { kind: 'variable' }).filter((v) =>
      {
         return v.type && v.type.types.includes(doc.longname);
      });

      const ice = new IceCap(eventbus.triggerSync('tjsdoc:publisher:get:template', 'class.html'));

      // header
      if (doc.export && doc.importPath && doc.importStyle)
      {
         const link = eventbus.triggerSync('tjsdoc:publisher:get:doc:file:link:html', doc, doc.importPath);

         ice.into('importPath', `import ${doc.importStyle} from '${link}'`, (code, ice) =>
         {
            ice.load('importPathCode', code);
         });
      }

      ice.text('access', doc.access);
      ice.text('kind', doc.interface ? 'interface' : 'class');
      ice.load('source', eventbus.triggerSync('tjsdoc:publisher:get:doc:file:link:html', doc, 'source'), 'append');
      ice.text('since', doc.since, 'append');
      ice.text('version', doc.version, 'append');

      ice.into('expressionExtends', expressionExtends,
       (expressionExtends, ice) => ice.load('expressionExtendsCode', expressionExtends));

      ice.load('mixinExtends', mixinClasses, 'append');
      ice.load('extendsChain', extendsChain, 'append');
      ice.load('directSubclass', directSubclass, 'append');
      ice.load('indirectSubclass', indirectSubclass, 'append');

      ice.load('implements', eventbus.triggerSync('tjsdoc:publisher:get:docs:link:html',
       doc.implements, null, false, ', '), 'append');

      ice.load('indirectImplements', eventbus.triggerSync('tjsdoc:publisher:get:docs:link:html',
       doc._custom_indirect_implements, null, false, ', '), 'append');

      ice.load('directImplemented', eventbus.triggerSync('tjsdoc:publisher:get:docs:link:html',
       doc._custom_direct_implemented, null, false, ', '), 'append');

      ice.load('indirectImplemented', eventbus.triggerSync('tjsdoc:publisher:get:docs:link:html',
       doc._custom_indirect_implemented, null, false, ', '), 'append');

      // self
      ice.text('name', doc.name);
      ice.load('description', doc.description);

      ice.load('deprecated', eventbus.triggerSync('tjsdoc:publisher:get:doc:deprecated:html', doc));
      ice.load('experimental', eventbus.triggerSync('tjsdoc:publisher:get:doc:experimental:html', doc));
      ice.load('see', eventbus.triggerSync('tjsdoc:publisher:get:docs:link:html', doc.see), 'append');
      ice.load('todo', eventbus.triggerSync('tjsdoc:publisher:get:docs:link:html', doc.todo), 'append');
      ice.load('decorator', eventbus.triggerSync('tjsdoc:publisher:get:doc:decorator:html', doc), 'append');

      ice.into('instanceDocs', instanceDocs, (instanceDocs, ice) =>
      {
         ice.loop('instanceDoc', instanceDocs, (i, instanceDoc, ice) =>
         {
            ice.load('instanceDoc', eventbus.triggerSync('tjsdoc:publisher:get:doc:link:html', instanceDoc.longname));
         });
      });

      ice.into('exampleDocs', doc.examples, (examples, ice) =>
      {
         ice.loop('exampleDoc', examples, (i, example, ice) =>
         {
            const parsed = parseExample(example);

            ice.text('exampleCode', parsed.body);
            ice.text('exampleCaption', parsed.caption);
         });
      });

      ice.into('tests', doc._custom_tests, (tests, ice) =>
      {
         ice.loop('test', tests, (i, test, ice) =>
         {
            const testDoc = eventbus.triggerSync('tjsdoc:docs:find', { longname: test })[0];

            ice.load('test', eventbus.triggerSync('tjsdoc:publisher:get:doc:file:link:html', testDoc,
             testDoc.testFullDescription));
         });
      });

      // summary
      ice.load('staticMemberSummary', eventbus.triggerSync('tjsdoc:publisher:get:doc:html:summary', doc, 'member',
       'Members', true));

      ice.load('staticMethodSummary', eventbus.triggerSync('tjsdoc:publisher:get:doc:html:summary', doc, 'method',
       'Methods', true));

      ice.load('constructorSummary', eventbus.triggerSync('tjsdoc:publisher:get:doc:html:summary', doc, 'constructor',
       'Constructor', false));

      ice.load('memberSummary', eventbus.triggerSync('tjsdoc:publisher:get:doc:html:summary', doc, 'member',
       'Members', false));

      ice.load('methodSummary', eventbus.triggerSync('tjsdoc:publisher:get:doc:html:summary', doc, 'method',
       'Methods', false));

      ice.load('inheritedSummary', ClassDocBuilder._buildInheritedSummaryHTML(eventbus, doc), 'append');


      // detail
      ice.load('staticMemberDetails', eventbus.triggerSync('tjsdoc:publisher:get:html:detail', doc, 'member',
       'Members', true));

      ice.load('staticMethodDetails', eventbus.triggerSync('tjsdoc:publisher:get:html:detail', doc, 'method',
       'Methods', true));

      ice.load('constructorDetails', eventbus.triggerSync('tjsdoc:publisher:get:html:detail', doc, 'constructor',
       'Constructors', false));

      ice.load('memberDetails', eventbus.triggerSync('tjsdoc:publisher:get:html:detail', doc, 'member',
       'Members', false));

      ice.load('methodDetails', eventbus.triggerSync('tjsdoc:publisher:get:html:detail', doc, 'method',
       'Methods', false));

      return ice;
   }

   /**
    * Build mixin extends HTML.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    * @param {DocObject}   doc - target class doc.
    *
    * @return {string} mixin extends HTML.
    * @private
    */
   static _buildMixinClassesHTML(eventbus, doc)
   {
      if (!doc.extends) { return ''; }
      if (doc.extends.length <= 1) { return ''; }

      const links = [];

      for (const longname of doc.extends)
      {
         links.push(eventbus.triggerSync('tjsdoc:publisher:get:doc:link:html', longname));
      }

      return `<div>${links.join(', ')}</div>`;
   }

   /**
    * Build expression extends HTML.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    * @param {DocObject}   doc - target class doc.
    *
    * @return {string} expression extends HTML.
    * @private
    */
   static _buildExpressionExtendsHTML(eventbus, doc)
   {
      if (!doc.expressionExtends) { return ''; }

      const html = doc.expressionExtends.replace(/[A-Z_$][a-zA-Z0-9_$]*/g, (v) =>
      {
         return eventbus.triggerSync('tjsdoc:publisher:get:doc:link:html', v);
      });

      return `class ${doc.name} extends ${html}`;
   }

   /**
    * Build class ancestor extends chain.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    * @param {DocObject}   doc - target class doc.
    *
    * @returns {string} extends chain links HTML.
    * @private
    */
   static _buildExtendsChainHTML(eventbus, doc)
   {
      if (!doc._custom_extends_chains) { return ''; }
      if (doc.extends.length > 1) { return ''; }

      const links = [];

      for (const longname of doc._custom_extends_chains)
      {
         links.push(eventbus.triggerSync('tjsdoc:publisher:get:doc:link:html', longname));
      }

      links.push(doc.name);

      return `<div>${links.join(' → ')}</div>`;
   }

   /**
    * Build in-direct subclass list.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    * @param {DocObject}   doc - target class doc.
    *
    * @returns {string} HTML of in-direct subclass links.
    * @private
    */
   static _buildIndirectSubclassHTML(eventbus, doc)
   {
      if (!doc._custom_indirect_subclasses) { return ''; }

      const links = [];

      for (const longname of doc._custom_indirect_subclasses)
      {
         links.push(eventbus.triggerSync('tjsdoc:publisher:get:doc:link:html', longname));
      }

      return `<div>${links.join(', ')}</div>`;
   }

   /**
    * Build direct subclass list.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    * @param {DocObject}   doc - target class doc.
    *
    * @returns {string} HTML of direct subclass links.
    * @private
    */
   static _buildDirectSubclassHTML(eventbus, doc)
   {
      if (!doc._custom_direct_subclasses) { return ''; }

      const links = [];

      for (const longname of doc._custom_direct_subclasses)
      {
         links.push(eventbus.triggerSync('tjsdoc:publisher:get:doc:link:html', longname));
      }

      return `<div>${links.join(', ')}</div>`;
   }

   /**
    * Build inherited method / member summary.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    * @param {DocObject}   doc - target class doc.
    *
    * @returns {string} HTML of inherited method/member from ancestor classes.
    * @private
    */
   static _buildInheritedSummaryHTML(eventbus, doc)
   {
      if (['class', 'interface'].indexOf(doc.kind) === -1) { return ''; }

      const longnames = [...doc._custom_extends_chains || []];

      const html = [];

      for (const longname of longnames)
      {
         const superDoc = eventbus.triggerSync('tjsdoc:docs:find', { longname })[0];

         if (!superDoc) { continue; }

         const targetDocs = eventbus.triggerSync('tjsdoc:docs:find',
          { memberof: longname, kind: ['member', 'method', 'get', 'set'] });

         targetDocs.sort((a, b) =>
         {
            if (a.static !== b.static) { return -(a.static - b.static); }

            let order = { get: 0, set: 0, member: 1, method: 2 };

            if (order[a.kind] !== order[b.kind])
            {
               return order[a.kind] - order[b.kind];
            }

            order = { 'public': 0, 'protected': 1, 'private': 2 };

            if (a.access !== b.access) { return order[a.access] - order[b.access]; }

            if (a.name !== b.name) { return a.name < b.name ? -1 : 1; }

            order = { get: 0, set: 1, member: 2 };

            return order[a.kind] - order[b.kind];
         });

         const title = `<span class="toggle closed"></span> From ${superDoc.kind} ${
          eventbus.triggerSync('tjsdoc:publisher:get:doc:link:html', longname, superDoc.name)}`;

         const result = eventbus.triggerSync('tjsdoc:publisher:get:docs:summary', targetDocs, '----------',
          false, superDoc.kind);

         if (result)
         {
            result.load('title', title, IceCap.MODE_WRITE);
            html.push(result.html);
         }
      }

      return html.join('\n');
   }
}
