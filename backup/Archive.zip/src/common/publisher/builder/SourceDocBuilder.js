import fs         from 'fs';
import path       from 'path';

import dateForUTC from '../utils/dateForUTC.js';

/**
 * Source output builder.
 */
export default class SourceDocBuilder
{
   /**
    * Executes writing source index.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    */
   static exec(eventbus)
   {
      const ice = eventbus.triggerSync('tjsdoc:publisher:get:ice:cap:layout');
      const fileName = 'source.html';
      const baseUrl = eventbus.triggerSync('tjsdoc:publisher:get:file:url:base', fileName);
      const title = eventbus.triggerSync('tjsdoc:publisher:get:title', 'Source');

      ice.attr('baseUrl', 'href', baseUrl);
      ice.load('content', SourceDocBuilder._buildSourceHTML(eventbus));
      ice.text('title', title, 'write');

      eventbus.trigger('tjsdoc:util:write:html', ice.html, fileName);
   }

   /**
    * Build source list output HTML.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    *
    * @returns {string} HTML of source list.
    * @private
    */
   static _buildSourceHTML(eventbus)
   {
      const ice = eventbus.triggerSync('tjsdoc:publisher:get:ice:cap:template', 'source.html');
      const docs = eventbus.triggerSync('tjsdoc:docs:find', { kind: 'file' });
      const config = eventbus.triggerSync('tjsdoc:get:config');
      const useCoverage = config.coverage;

      const coverage = eventbus.triggerSync('tjsdoc:publisher:get:coverage');

      let coverageFiles;

      if (useCoverage) { coverageFiles = coverage.files; }

      ice.drop('coverageBadge', !useCoverage);
      ice.attr('files', 'data-use-coverage', !!useCoverage);

      if (useCoverage)
      {
         const actual = coverage.actualCount;
         const expect = coverage.expectCount;
         const coverageCount = `${actual}/${expect}`;

         ice.text('totalCoverageCount', coverageCount);
      }

      ice.loop('file', docs, (i, doc, ice) =>
      {
         const sourceDirPath = path.resolve(config.source);
         const filePath = doc.longname;
         const absFilePath = path.resolve(path.dirname(sourceDirPath), filePath);
         const content = fs.readFileSync(absFilePath).toString();
         const lines = content.split('\n').length - 1;
         const stat = fs.statSync(absFilePath);
         const date = dateForUTC(stat.ctime);

         let coverageRatio;
         let coverageCount;
         let undocumentLines;

         if (useCoverage && coverageFiles[filePath])
         {
            const actual = coverageFiles[filePath].actualCount;
            const expect = coverageFiles[filePath].expectCount;

            coverageRatio = `${Math.floor(100 * actual / expect)} %`;
            coverageCount = `${actual}/${expect}`;

            undocumentLines = coverageFiles[filePath].undocumentLines.sort().join(',');
         }
         else
         {
            coverageRatio = '-';
         }

         const identifierDocs = eventbus.triggerSync('tjsdoc:docs:find',
          { longname: { left: `${doc.longname}~` }, kind: ['class', 'function', 'variable'] });

         const identifiers = identifierDocs.map((doc) =>
         {
            return eventbus.triggerSync('tjsdoc:publisher:get:doc:html:link', doc.longname);
         });

         if (undocumentLines)
         {
            const url = eventbus.triggerSync('tjsdoc:publisher:get:doc:url', doc);

            const link = eventbus.triggerSync('tjsdoc:publisher:get:doc:html:file:link', doc).replace(/href=".*\.html"/,
             `href="${url}#errorLines=${undocumentLines}"`);

            ice.load('filePath', link);
         }
         else
         {
            ice.load('filePath', eventbus.triggerSync('tjsdoc:publisher:get:doc:html:file:link', doc));
         }

         ice.text('coverage', coverageRatio);
         ice.text('coverageCount', coverageCount);
         ice.text('lines', lines);
         ice.text('updated', date);
         ice.text('size', `${stat.size} byte`);
         ice.load('identifier', identifiers.join('\n') || '-');
      });

      return ice.html;
   }
}
