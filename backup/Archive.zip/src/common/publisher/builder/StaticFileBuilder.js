import path from 'path';

/**
 * Static file output builder class.
 */
export default class StaticFileBuilder
{
   /**
    * execute build output.
    */
   static exec(eventbus)
   {
      eventbus.trigger('tjsdoc:util:copy', path.resolve(__dirname, '../template/css'), './css');
      eventbus.trigger('tjsdoc:util:copy', path.resolve(__dirname, '../template/script'), './script');
      eventbus.trigger('tjsdoc:util:copy', path.resolve(__dirname, '../template/image'), './image');

      const config = eventbus.triggerSync('tjsdoc:get:config');

      // see DocBuilder#_buildLayoutDoc
      const scripts = config.scripts || [];

      for (let i = 0; i < scripts.length; i++)
      {
         const userScript = scripts[i];
         const name = `./user/script/${i}-${path.basename(userScript)}`;

         eventbus.trigger('tjsdoc:util:copy', userScript, name);
      }

      const styles = config.styles || [];

      for (let i = 0; i < styles.length; i++)
      {
         const userStyle = styles[i];
         const name = `./user/css/${i}-${path.basename(userStyle)}`;

         eventbus.trigger('tjsdoc:util:copy', userStyle, name);
      }
   }
}
