import cheerio    from 'cheerio';
import fs         from 'fs';
import path       from 'path';

import markdown   from '../utils/markdown.js';

/**
 * Manual output builder.
 */
export default class ManualDocBuilder
{
   /**
    * Executes writing manual based on `config.manual`.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    */
   static exec(eventbus)
   {
      const config = eventbus.triggerSync('tjsdoc:get:config');

      if (!config.manual) { return; }

      const manualConfig = ManualDocBuilder._getManualConfig(eventbus);
      const ice = eventbus.triggerSync('tjsdoc:publisher:get:ice:cap:layout');

      ice.autoDrop = false;
      ice.attr('rootContainer', 'class', ' manual-root');

      {
         const fileName = 'manual/index.html';
         const baseUrl = eventbus.triggerSync('tjsdoc:publisher:get:file:url:base', fileName);

         ManualDocBuilder._buildManualIndex(eventbus, manualConfig);

         ice.load('content', ManualDocBuilder._buildManualCardIndex(eventbus, manualConfig), 'write');
         ice.load('nav', ManualDocBuilder._buildManualNav(eventbus, manualConfig), 'write');
         ice.text('title', 'Manual', 'write');
         ice.attr('baseUrl', 'href', baseUrl, 'write');
         ice.attr('rootContainer', 'class', ' manual-index');

         eventbus.trigger('tjsdoc:util:write:html', ice.html, fileName);

         if (config.manual.globalIndex)
         {
            ice.attr('baseUrl', 'href', './', 'write');

            eventbus.trigger('tjsdoc:util:write:html', ice.html, 'index.html');
         }

         ice.attr('rootContainer', 'class', ' manual-index', 'remove');
      }

      for (const item of manualConfig)
      {
         if (!item.paths) { continue; }

         for (const filePath of item.paths)
         {
            const fileName = ManualDocBuilder._getManualOutputFileName(item, filePath);
            const baseUrl = eventbus.triggerSync('tjsdoc:publisher:get:file:url:base', fileName);

            ice.load('content', ManualDocBuilder._buildManual(eventbus, item, filePath), 'write');
            ice.load('nav', ManualDocBuilder._buildManualNav(eventbus, manualConfig), 'write');
            ice.text('title', item.label, 'write');
            ice.attr('baseUrl', 'href', baseUrl, 'write');

            eventbus.trigger('tjsdoc:util:write:html', ice.html, fileName);
         }
      }

      if (config.manual.asset)
      {
         eventbus.trigger('tjsdoc:util:copy', config.manual.asset, 'manual/asset');
      }

      // badge
      {
         const ratio = Math.floor(100 * (manualConfig.length - 1) / 10);

         let color;

         if (ratio < 50)
         {
            color = '#db654f';
         }
         else if (ratio < 90)
         {
            color = '#dab226';
         }
         else
         {
            color = '#4fc921';
         }

         let badge = eventbus.triggerSync('tjsdoc:publisher:get:template', 'image/manual-badge.svg');

         badge = badge.replace(/@value@/g, `${ratio}%`);
         badge = badge.replace(/@color@/g, color);

         eventbus.trigger('tjsdoc:util:write:file', badge, 'manual-badge.svg');
      }
   }

   /**
    * Get manual config based on `config.manual`.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    *
    * @returns {ManualConfigItem[]} built manual config.
    * @private
    */
   static _getManualConfig(eventbus)
   {
      const config = eventbus.triggerSync('tjsdoc:get:config');

      const m = config.manual;
      const manualConfig = [];

      if (m.overview) { manualConfig.push({ label: 'Overview', paths: m.overview }); }
      if (m.design) { manualConfig.push({ label: 'Design', paths: m.design }); }
      if (m.installation) { manualConfig.push({ label: 'Installation', paths: m.installation }); }
      if (m.tutorial) { manualConfig.push({ label: 'Tutorial', paths: m.tutorial }); }
      if (m.usage) { manualConfig.push({ label: 'Usage', paths: m.usage }); }
      if (m.configuration) { manualConfig.push({ label: 'Configuration', paths: m.configuration }); }
      if (m.advanced) { manualConfig.push({ label: 'Advanced', paths: m.advanced }); }
      if (m.example) { manualConfig.push({ label: 'Example', paths: m.example }); }

      manualConfig.push({ label: 'Reference', fileName: 'identifiers.html', references: true });

      if (m.faq) { manualConfig.push({ label: 'FAQ', paths: m.faq }); }
      if (m.changelog) { manualConfig.push({ label: 'Changelog', paths: m.changelog }); }

      return manualConfig;
   }

   /**
    * Build manual navigation.
    *
    * @param {EventProxy}           eventbus - An event proxy for the main eventbus.
    *
    * @param {ManualConfigItem[]}   manualConfig - target manual config.
    *
    * @return {IceCap} built navigation
    * @private
    */
   static _buildManualNav(eventbus, manualConfig)
   {
      const ice = ManualDocBuilder._buildManualIndex(eventbus, manualConfig);
      const $root = cheerio.load(ice.html).root();

      $root.find('.github-markdown').removeClass('github-markdown');

      return $root.html();
   }

   /**
    * Build manual.
    *
    * @param {EventProxy}        eventbus - An event proxy for the main eventbus.
    *
    * @param {ManualConfigItem}  item - target manual config item.
    *
    * @param {string}            filePath - target manual file path.
    *
    * @return {IceCap} built manual.
    * @private
    */
   static _buildManual(eventbus, item, filePath)
   {
      const html = ManualDocBuilder._convertMDToHTML(filePath);
      const ice = eventbus.triggerSync('tjsdoc:publisher:get:ice:cap:template', 'manual.html');

      ice.text('title', item.label);
      ice.load('content', html);

      // convert relative src to base url relative src.
      const $root = cheerio.load(ice.html).root();

      $root.find('img').each((i, el) =>
      {
         const $el = cheerio(el);
         const src = $el.attr('src');

         if (!src) { return; }
         if (src.match(/^http[s]?:/)) { return; }
         if (src.charAt(0) === '/') { return; }

         $el.attr('src', `./manual/${src}`);
      });

      $root.find('a').each((i, el) =>
      {
         const $el = cheerio(el);
         const href = $el.attr('href');

         if (!href) { return; }
         if (href.match(/^http[s]?:/)) { return; }
         if (href.charAt(0) === '/') { return; }
         if (href.charAt(0) === '#') { return; }

         $el.attr('href', `./manual/${href}`);
      });

      return $root.html();
   }

   /**
    * Build manual card style index.
    *
    * @param {EventProxy}           eventbus - An event proxy for the main eventbus.
    *
    * @param {ManualConfigItem[]}   manualConfig - target manual config.
    *
    * @return {IceCap} built index.
    * @private
    */
   static _buildManualCardIndex(eventbus, manualConfig)
   {
      const config = eventbus.triggerSync('tjsdoc:get:config');
      const cards = [];

      for (const manualItem of manualConfig)
      {
         if (manualItem.references)
         {
            const filePath = path.resolve(config.destination, 'identifiers.html');
            const html = fs.readFileSync(filePath).toString();
            const $ = cheerio.load(html);
            const card = $('.content').html();
            const identifiers = eventbus.triggerSync('tjsdoc:docs:find:all:identifiers:kind:grouping');

            const sectionCount = identifiers.class.length + identifiers.interface.length + identifiers.function.length
             + identifiers.typedef.length + identifiers.external.length;

            cards.push(
            {
               label: 'References',
               link: 'identifiers.html',
               card,
               type: 'reference',
               sectionCount
            });

            continue;
         }

         for (const filePath of manualItem.paths)
         {
            const type = manualItem.label.toLowerCase();
            const fileName = ManualDocBuilder._getManualOutputFileName(manualItem, filePath);
            const html = ManualDocBuilder._buildManual(eventbus, manualItem, filePath);
            const $root = cheerio.load(html).root();
            const h1Count = $root.find('h1').length;
            const sectionCount = $root.find('h1,h2,h3,h4,h5').length;

            $root.find('h1').each((i, el) =>
            {
               const $el = cheerio(el);
               const label = $el.text();
               const link = h1Count === 1 ? fileName : `${fileName}#${$el.attr('id')}`;

               let card = `<h1>${label}</h1>`;

               const nextAll = $el.nextAll();

               for (let cntr = 0; cntr < nextAll.length; cntr++)
               {
                  const next = nextAll.get(cntr);
                  const tagName = next.tagName.toLowerCase();

                  if (tagName === 'h1') { return; }

                  const $next = cheerio(next);

                  card += `<${tagName}>${$next.html()}</${tagName}>`;
               }

               cards.push({ label, link, card, type, sectionCount });
            });
         }
      }

      const ice = eventbus.triggerSync('tjsdoc:publisher:get:ice:cap:template', 'manualCardIndex.html');

      ice.loop('cards', cards, (i, card, ice) =>
      {
         ice.text('label-inner', card.label);
         ice.attr('label', 'class', `manual-color manual-color-${card.type}`);

         const sectionCount = Math.min((card.sectionCount / 5) + 1, 5);

         ice.attr('label', 'data-section-count', '■'.repeat(sectionCount));

         ice.attr('link', 'href', card.link);
         ice.load('card', card.card);
      });

      if (config.manual.index)
      {
         const userIndex = ManualDocBuilder._convertMDToHTML(config.manual.index);

         ice.load('manualUserIndex', userIndex);
      }
      else
      {
         ice.drop('manualUserIndex', true);
      }

      ice.drop('manualBadge', !config.manual.coverage);

      return ice;
   }

   /**
    * Build manual index.
    *
    * @param {EventProxy}           eventbus - An event proxy for the main eventbus.
    *
    * @param {ManualConfigItem[]}   manualConfig - target manual config.
    *
    * @return {IceCap} built index.
    * @private
    */
   static _buildManualIndex(eventbus, manualConfig)
   {
      const ice = eventbus.triggerSync('tjsdoc:publisher:get:ice:cap:template', 'manualIndex.html');
      const _manualConfig = manualConfig.filter((item) => (item.paths && item.paths.length) || item.references);

      ice.loop('manual', _manualConfig, (i, item, ice) =>
      {
         const toc = [];

         if (item.references)
         {
            const identifiers = eventbus.triggerSync('tjsdoc:docs:find:all:identifiers:kind:grouping');

            toc.push({ label: 'Reference', link: 'identifiers.html', indent: 'indent-h1' });

            if (identifiers.class.length)
            {
               toc.push(
               {
                  label: 'Class',
                  link: 'identifiers.html#class',
                  indent: 'indent-h2'
               });
            }

            if (identifiers.interface.length)
            {
               toc.push(
               {
                  label: 'Interface',
                  link: 'identifiers.html#interface',
                  indent: 'indent-h2'
               });
            }

            if (identifiers.function.length)
            {
               toc.push(
               {
                  label: 'Function',
                  link: 'identifiers.html#function',
                  indent: 'indent-h2'
               });
            }

            if (identifiers.variable.length)
            {
               toc.push(
               {
                  label: 'Variable',
                  link: 'identifiers.html#variable',
                  indent: 'indent-h2'
               });
            }

            if (identifiers.typedef.length)
            {
               toc.push(
               {
                  label: 'Typedef',
                  link: 'identifiers.html#typedef',
                  indent: 'indent-h2'
               });
            }

            if (identifiers.external.length)
            {
               toc.push(
               {
                  label: 'External',
                  link: 'identifiers.html#external',
                  indent: 'indent-h2'
               });
            }

            toc[0].sectionCount = identifiers.class.length + identifiers.interface.length + identifiers.function.length
             + identifiers.typedef.length + identifiers.external.length;
         }
         else
         {
            for (const filePath of item.paths)
            {
               const fileName = ManualDocBuilder._getManualOutputFileName(item, filePath);
               const html = ManualDocBuilder._convertMDToHTML(filePath);
               const $root = cheerio.load(html).root();
               const h1Count = $root.find('h1').length;
               const sectionCount = $root.find('h1,h2,h3,h4,h5').length;

               $root.find('h1,h2,h3,h4,h5').each((i, el) =>
               {
                  const $el = cheerio(el);
                  const label = $el.text();
                  const indent = `indent-${el.tagName.toLowerCase()}`;

                  let link = `${fileName}#${$el.attr('id')}`;

                  if (el.tagName.toLowerCase() === 'h1' && h1Count === 1) { link = fileName; }

                  toc.push({ label, link, indent, sectionCount });
               });
            }
         }

         ice.attr('manual', 'data-toc-name', item.label.toLowerCase());

         ice.loop('manualNav', toc, (i, tocItem, ice) =>
         {
            if (tocItem.indent === 'indent-h1')
            {
               ice.attr('manualNav', 'class',
                `${tocItem.indent} manual-color manual-color-${item.label.toLowerCase()}`);

               const sectionCount = Math.min((tocItem.sectionCount / 5) + 1, 5);

               ice.attr('manualNav', 'data-section-count', '■'.repeat(sectionCount));
            }
            else
            {
               ice.attr('manualNav', 'class', tocItem.indent);
            }

            ice.attr('manualNav', 'data-link', tocItem.link.split('#')[0]);
            ice.text('link', tocItem.label);
            ice.attr('link', 'href', tocItem.link);
         });
      });

      return ice;
   }

   /**
    * Get manual file name.
    *
    * @param {ManualConfigItem}  item - target manual config item.
    *
    * @param {string}            filePath - target manual markdown file path.
    *
    * @returns {string} file name.
    * @private
    */
   static _getManualOutputFileName(item, filePath)
   {
      if (item.fileName) { return item.fileName; }

      const fileName = path.parse(filePath).name;

      return `manual/${item.label.toLowerCase()}/${fileName}.html`;
   }

   /**
    * Convert markdown to html. If markdown has only one `h1` and its text is `item.label`, remove the `h1`.
    * because duplication of `h1` in output HTML.
    *
    * @param {string} filePath - target.
    *
    * @returns {string} converted html.
    * @private
    */
   static _convertMDToHTML(filePath)
   {
      const content = fs.readFileSync(filePath).toString();
      const html = markdown(content);
      const $root = cheerio.load(html).root();

      return $root.html();
   }
}
