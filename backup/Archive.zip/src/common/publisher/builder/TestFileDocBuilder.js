import IceCap from 'ice-cap';

/**
 * Test file output HTML builder.
 */
export default class TestFileDocBuilder
{
   /**
    * Executes building output HTML.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    */
   static exec(eventbus)
   {
      const ice = eventbus.triggerSync('tjsdoc:publisher:get:html:layout');
      const docs = eventbus.triggerSync('tjsdoc:docs:find', { kind: 'testFile' });

      for (const doc of docs)
      {
         const fileName = eventbus.triggerSync('tjsdoc:publisher:get:doc:file:name', doc);
         const baseUrl = eventbus.triggerSync('tjsdoc:publisher:get:file:url:base', fileName);
         const title = eventbus.triggerSync('tjsdoc:publisher:get:title', doc);

         ice.load('content', TestFileDocBuilder._buildFileDoc(eventbus, doc), IceCap.MODE_WRITE);
         ice.attr('baseUrl', 'href', baseUrl, IceCap.MODE_WRITE);
         ice.text('title', title, IceCap.MODE_WRITE);

         eventbus.trigger('tjsdoc:util:write:html', ice.html, fileName);
      }
   }

   /**
    * Build test file output HTML.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    *
    * @param {DocObject} doc - target file doc object.
    *
    * @returns {string} HTML of file output.
    * @private
    */
   static _buildFileDoc(eventbus, doc)
   {
      const ice = new IceCap(eventbus.triggerSync('tjsdoc:publisher:get:template', 'file.html'));

      ice.text('title', doc.longname);
      ice.text('content', doc.content);
      ice.drop('emptySourceCode', !!doc.content);

      return ice.html;
   }
}
