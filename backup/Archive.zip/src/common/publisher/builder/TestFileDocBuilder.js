/**
 * Test file output HTML builder.
 */
export default class TestFileDocBuilder
{
   /**
    * Executes building output HTML.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    */
   static exec(eventbus)
   {
      const ice = eventbus.triggerSync('tjsdoc:publisher:get:ice:cap:layout');
      const docs = eventbus.triggerSync('tjsdoc:docs:find', { kind: 'testFile' });

      for (const doc of docs)
      {
         const fileName = eventbus.triggerSync('tjsdoc:publisher:get:doc:file:name', doc);
         const baseUrl = eventbus.triggerSync('tjsdoc:publisher:get:file:url:base', fileName);
         const title = eventbus.triggerSync('tjsdoc:publisher:get:title', doc);

         ice.load('content', TestFileDocBuilder._buildFileDoc(eventbus, doc), 'write');
         ice.attr('baseUrl', 'href', baseUrl, 'write');
         ice.text('title', title, 'write');

         eventbus.trigger('tjsdoc:util:write:html', ice.html, fileName);
      }
   }

   /**
    * Build test file output HTML.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    *
    * @param {DocObject} doc - target file doc object.
    *
    * @returns {string} HTML of file output.
    * @private
    */
   static _buildFileDoc(eventbus, doc)
   {
      const ice = eventbus.triggerSync('tjsdoc:publisher:get:ice:cap:template', 'file.html');

      ice.text('title', doc.longname);
      ice.text('content', doc.content);
      ice.drop('emptySourceCode', !!doc.content);

      return ice.html;
   }
}
