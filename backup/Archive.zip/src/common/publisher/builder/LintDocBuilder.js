import path from 'path';

/** @ignore */
export const _results = [];

/**
 * Lint output builder. Detects parameter mismatches between code and documentation.
 */
export default class LintDocBuilder
{
   /**
    * Executes writing source code for each file
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    */
   static exec(eventbus)
   {
      const results = [];
      const docs = eventbus.triggerSync('tjsdoc:docs:find', { kind: ['method', 'function'] });

      for (const doc of docs)
      {
         if (doc.undocument) { continue; }

         const node = eventbus.triggerSync('tjsdoc:ast:get:node', doc.__docId__);

         // Get AST / parser specific parsing of the node returning any method params.
         const codeParams = eventbus.triggerSync('tjsdoc:ast:get:method:params:from:node', node);

         const docParams = LintDocBuilder._getParamsFromDoc(doc);

         if (LintDocBuilder._match(codeParams, docParams)) { continue; }

         results.push({ node, doc, codeParams, docParams });
      }

      _results.push(...results);

      LintDocBuilder._showResult(eventbus, results);
   }

   /**
    * get variable names of method argument.
    *
    * @param {DocObject} doc - target doc object.
    *
    * @returns {string[]} variable names.
    * @private
    */
   static _getParamsFromDoc(doc)
   {
      const params = doc.params || [];

      return params.map((v) => v.name).filter((v) => !v.includes('.')).filter((v) => !v.includes('['));
   }

   /**
    * Checks if code parameters matches document parameters.
    *
    * @param {string[]}  codeParams - Code parameters.
    * @param {string[]}  docParams - Document parameters.
    *
    * @returns {boolean}
    * @private
    */
   static _match(codeParams, docParams)
   {
      if (codeParams.length !== docParams.length) { return false; }

      for (let i = 0; i < codeParams.length; i++)
      {
         if (codeParams[i] === '*')
         {
            // do nothing
         }
         else if (codeParams[i] !== docParams[i])
         {
            return false;
         }
      }

      return true;
   }

   /**
    * Show invalid lint code.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    *
    * @param {Array<{doc: DocObject, node: ASTNode, codeParams: string[], docParams: string[]}>} results - target
    *
    * @private
    */
   static _showResult(eventbus, results)
   {
      const config = eventbus.triggerSync('tjsdoc:get:config');

      const sourceDir = path.dirname(path.resolve(config.source));

      for (const result of results)
      {
         const doc = result.doc;
         const node = result.node;
         const filePath = doc.longname.split('~')[0];
         const name = doc.longname.split('~')[1];
         const absFilePath = path.resolve(sourceDir, filePath);

         const comment = eventbus.triggerSync('tjsdoc:ast:get:file:comment:and:first:line:from:node',
          absFilePath, node);

         console.log(`[33mwarning: signature mismatch: ${name} ${filePath}#${comment.startLine}[32m`);
         console.log(comment.text);
         console.log('[0m');
      }
   }
}
