/**
 * AST Output Builder.
 *
 * The parsed AST for the project is output to `config.destination`/ast
 */
export default class ASTDocBuilder
{
   /**
    * Executes writing AST output.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    */
   static exec(eventbus)
   {
      const config = eventbus.triggerSync('tjsdoc:get:config');

      // Note the compression format extension will automatically be added.
      if (config.compressData) { eventbus.trigger('tjsdoc:util:archive:create', 'ast'); }

      for (const ast of eventbus.triggerSync('tjsdoc:get:ast:data'))
      {
         const astJSON = config.compactData ? JSON.stringify(ast.ast) : JSON.stringify(ast.ast, null, 3);
         const filePath = `ast/${ast.filePath}.json`;

         eventbus.trigger('tjsdoc:util:write:file', astJSON, filePath);
      }

      if (config.compressData) { eventbus.trigger('tjsdoc:util:archive:finalize'); }
   }
}
