/**
 * AST Output Builder.
 *
 * The parsed AST for the project is output to `config.destination`/ast
 */
export default class ASTDocBuilder
{
   /**
    * Executes writing AST output.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    */
   static exec(eventbus)
   {
      const config = eventbus.triggerSync('tjsdoc:get:config');

      if (config.compressJSON) { eventbus.trigger('tjsdoc:util:archive:create', 'ast.zip'); }

      for (const ast of eventbus.triggerSync('tjsdoc:get:ast:data'))
      {
         const astJSON = config.compactJSON ? JSON.stringify(ast.ast) : JSON.stringify(ast.ast, null, 3);
         const filePath = `ast/${ast.filePath}.json`;

         eventbus.trigger('tjsdoc:util:write:file', astJSON, filePath);
      }

      if (config.compressJSON) { eventbus.trigger('tjsdoc:util:archive:finalize'); }
   }
}
