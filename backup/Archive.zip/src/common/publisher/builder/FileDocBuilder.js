/**
 * File output builder.
 *
 * Outputs source code for each file.
 */
export default class FileDocBuilder
{
   /**
    * Executes writing source code for each file.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    */
   static exec(eventbus)
   {
      const ice = eventbus.triggerSync('tjsdoc:publisher:get:ice:cap:layout');
      const docs = eventbus.triggerSync('tjsdoc:docs:find', { kind: 'file' });

      for (const doc of docs)
      {
//const childDocs = eventbus.triggerSync('tjsdoc:docs:find', { __esModuleId__: doc.__docId__ });
//const childDocData = childDocs.reduce((a, b) => { return `${a} docId: ${b.__docId__} type: ${b.kind}; `; }, '');
//eventbus.trigger('log:error', 'FileDocBuilder - exec - doc.__docId__: ' + doc.__docId__ +'; childDocs length: ' + childDocs.length + '; childDocData: ' + childDocData);

         const fileName = eventbus.triggerSync('tjsdoc:publisher:get:doc:file:name', doc);
         const baseUrl = eventbus.triggerSync('tjsdoc:publisher:get:file:url:base', fileName);
         const title = eventbus.triggerSync('tjsdoc:publisher:get:title', doc);

         ice.load('content', FileDocBuilder._buildFileDoc(eventbus, doc), 'write');
         ice.attr('baseUrl', 'href', baseUrl, 'write');
         ice.text('title', title, 'write');

         eventbus.trigger('tjsdoc:util:write:html', ice.html, fileName);
      }
   }

   /**
    * Build file output HTML.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    * @param {DocObject}   doc - target file doc object.
    *
    * @returns {string} HTML of file page.
    * @private
    */
   static _buildFileDoc(eventbus, doc)
   {
      const ice = eventbus.triggerSync('tjsdoc:publisher:get:ice:cap:template', 'file.html');

      ice.text('title', doc.longname);
      ice.text('content', doc.content);
      ice.drop('emptySourceCode', !!doc.content);

      return ice.html;
   }
}
