import escape        from 'escape-html';
import fs            from 'fs-extra';
import IceCap        from 'ice-cap';
import path          from 'path';

import parseExample  from './utils/parseExample.js';
import shorten       from './utils/shorten.js';

/**
 * Defines several event bindings which aid in the publishing process.
 *
 * 'tjsdoc:publisher:get:doc:decorator:html' -
 * 'tjsdoc:publisher:get:doc:deprecated:html' -
 * 'tjsdoc:publisher:get:doc:experimental:html' -
 * 'tjsdoc:publisher:get:doc:file:link:html' -
 * 'tjsdoc:publisher:get:doc:file:name' -
 * 'tjsdoc:publisher:get:doc:html:summary' -
 * 'tjsdoc:publisher:get:doc:link:html' -
 * 'tjsdoc:publisher:get:doc:link:type:html' -
 * 'tjsdoc:publisher:get:doc:overide:method' -
 * 'tjsdoc:publisher:get:doc:overide:method:description' -
 * 'tjsdoc:publisher:get:doc:signature:html' -
 * 'tjsdoc:publisher:get:doc:url' -
 * 'tjsdoc:publisher:get:docs:detail' -
 * 'tjsdoc:publisher:get:docs:link:html' -
 * 'tjsdoc:publisher:get:docs:summary' -
 * 'tjsdoc:publisher:get:file:url:base' -
 * 'tjsdoc:publisher:get:html:detail' -
 * 'tjsdoc:publisher:get:html:layout' -
 * 'tjsdoc:publisher:get:html:nav' -
 * 'tjsdoc:publisher:get:html:properties' -
 * 'tjsdoc:publisher:get:template' -
 * 'tjsdoc:publisher:get:title' -
 */
export default class PublisherEvents
{
   /**
    * Registers and defines implicitly all functions exposed via event bindings.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    */
   static register(eventbus)
   {
      // Register all events on the eventbus.
      eventbus.on('tjsdoc:publisher:get:doc:decorator:html', getDecoratorHTML);
      eventbus.on('tjsdoc:publisher:get:doc:deprecated:html', getDeprecatedHTML);
      eventbus.on('tjsdoc:publisher:get:doc:experimental:html', getExperimentalHTML);
      eventbus.on('tjsdoc:publisher:get:doc:file:link:html', getFileDocLinkHTML);
      eventbus.on('tjsdoc:publisher:get:doc:file:name', getOutputFileName);
      eventbus.on('tjsdoc:publisher:get:doc:html:summary', getHTMLSummary);
      eventbus.on('tjsdoc:publisher:get:doc:link:html', getDocLinkHTML);
      eventbus.on('tjsdoc:publisher:get:doc:link:type:html', getTypeDocLinkHTML);
      eventbus.on('tjsdoc:publisher:get:doc:overide:method', getOverrideMethod);
      eventbus.on('tjsdoc:publisher:get:doc:overide:method:description', getOverrideMethodDescription);
      eventbus.on('tjsdoc:publisher:get:doc:signature:html', getSignatureHTML);
      eventbus.on('tjsdoc:publisher:get:doc:url', getURL);
      eventbus.on('tjsdoc:publisher:get:docs:detail', getDetailDocs);
      eventbus.on('tjsdoc:publisher:get:docs:link:html', getDocsLinkHTML);
      eventbus.on('tjsdoc:publisher:get:docs:summary', getDocsSummary);
      eventbus.on('tjsdoc:publisher:get:file:url:base', getFileBaseURL);
      eventbus.on('tjsdoc:publisher:get:html:detail', getDetailHTML);
      eventbus.on('tjsdoc:publisher:get:html:layout', getHTMLLayout);
      eventbus.on('tjsdoc:publisher:get:html:nav', getHTMLNav);
      eventbus.on('tjsdoc:publisher:get:html:properties', getHTMLProperties);
      eventbus.on('tjsdoc:publisher:get:template', getTemplate);
      eventbus.on('tjsdoc:publisher:get:title', getTitle);

      // Define implicit methods below. Note that eventbus is internally referenced. --------------------------------

      /**
       * build decorator description.
       *
       * @param {DocObject} doc - target doc object.
       *
       * @returns {string} description. if doc does not override ancestor method, returns empty.
       * @private
       */
      function getDecoratorHTML(doc)
      {
         if (!doc.decorators) { return ''; }

         const links = [];

         for (const decorator of doc.decorators)
         {
            const link = getDocLinkHTML(decorator.name, decorator.name, false, 'function');

            links.push(decorator.arguments ? `<li>${link}${decorator.arguments}</li>` : `<li>${link}</li>`);
         }

         if (!links.length) { return ''; }

         return `<ul>${links.join('\n')}</ul>`;
      }

      /**
       * build deprecated html.
       *
       * @param {DocObject} doc - target doc object.
       *
       * @returns {string} if doc is not deprecated, returns empty.
       * @private
       */
      function getDeprecatedHTML(doc)
      {
         if (doc.deprecated)
         {
            const deprecated = [`this ${doc.kind} was deprecated.`];

            if (typeof doc.deprecated === 'string') { deprecated.push(doc.deprecated); }

            return deprecated.join(' ');
         }
         else
         {
            return '';
         }
      }

      /**
       * build detail output html by docs.
       *
       * @param {DocObject[]} docs - target docs.
       * @param {string}      title - detail title.
       *
       * @return {IceCap} detail output.
       * @private
       */
      function getDetailDocs(docs, title)
      {
         const ice = new IceCap(getTemplate('details.html'));

         ice.text('title', title);
         ice.drop('title', !docs.length);

         ice.loop('detail', docs, (i, doc, ice) =>
         {
            const scope = doc.static ? 'static' : 'instance';

            ice.attr('anchor', 'id', `${scope}-${doc.kind}-${doc.name}`);
            ice.text('generator', doc.generator ? '*' : '');
            ice.text('async', doc.async ? 'async' : '');
            ice.text('name', doc.name);
            ice.text('abstract', doc.abstract ? 'abstract' : '');
            ice.text('access', doc.access);
            ice.load('signature', getSignatureHTML(doc));
            ice.load('description', doc.description || getOverrideMethodDescription(doc));

            if (['get', 'set'].includes(doc.kind))
            {
               ice.text('kind', doc.kind);
            }
            else
            {
               ice.drop('kind');
            }

            if (doc.export && doc.importPath && doc.importStyle)
            {
               const link = getFileDocLinkHTML(doc, doc.importPath);

               ice.into('importPath', `import ${doc.importStyle} from '${link}'`, (code, ice) =>
               {
                  ice.load('importPathCode', code);
               });
            }
            else
            {
               ice.drop('importPath');
            }

            if (['member', 'method', 'get', 'set'].includes(doc.kind))
            {
               ice.text('static', doc.static ? 'static' : '');
            }
            else
            {
               ice.drop('static');
            }

            ice.load('source', getFileDocLinkHTML(doc, 'source'));
            ice.text('since', doc.since, 'append');
            ice.load('deprecated', getDeprecatedHTML(doc));
            ice.load('experimental', getExperimentalHTML(doc));
            ice.text('version', doc.version, 'append');
            ice.load('see', getDocsLinkHTML(doc.see), 'append');
            ice.load('todo', getDocsLinkHTML(doc.todo), 'append');
            ice.load('override', getOverrideMethod(doc));
            ice.load('decorator', getDecoratorHTML(doc), 'append');

            let isFunction = false;

            if (['method', 'constructor', 'function'].indexOf(doc.kind) !== -1) { isFunction = true; }
            if (doc.kind === 'typedef' && doc.params && doc.type.types[0] === 'function') { isFunction = true; }

            if (isFunction)
            {
               ice.load('properties', getHTMLProperties(doc.params, 'Params:'));
            }
            else
            {
               ice.load('properties', getHTMLProperties(doc.properties, 'Properties:'));
            }

            // return
            if (doc.return)
            {
               ice.load('returnDescription', doc.return.description);

               const typeNames = [];

               for (const typeName of doc.return.types)
               {
                  typeNames.push(getTypeDocLinkHTML(typeName));
               }

               if (typeof doc.return.nullable === 'boolean')
               {
                  const nullable = doc.return.nullable;

                  ice.load('returnType', `${typeNames.join(' | ')} (nullable: ${nullable})`);
               }
               else
               {
                  ice.load('returnType', typeNames.join(' | '));
               }

               ice.load('returnProperties', getHTMLProperties(doc.properties, 'Return Properties:'));
            }
            else
            {
               ice.drop('returnParams');
            }

            // throws
            if (doc.throws)
            {
               ice.loop('throw', doc.throws, (i, exceptionDoc, ice) =>
               {
                  ice.load('throwName', getDocLinkHTML(exceptionDoc.types[0]));
                  ice.load('throwDesc', exceptionDoc.description);
               });
            }
            else
            {
               ice.drop('throwWrap');
            }

            // fires
            if (doc.emits)
            {
               ice.loop('emit', doc.emits, (i, emitDoc, ice) =>
               {
                  ice.load('emitName', getDocLinkHTML(emitDoc.types[0]));
                  ice.load('emitDesc', emitDoc.description);
               });
            }
            else
            {
               ice.drop('emitWrap');
            }

            // listens
            if (doc.listens)
            {
               ice.loop('listen', doc.listens, (i, listenDoc, ice) =>
               {
                  ice.load('listenName', getDocLinkHTML(listenDoc.types[0]));
                  ice.load('listenDesc', listenDoc.description);
               });
            }
            else
            {
               ice.drop('listenWrap');
            }

            // example
            ice.into('example', doc.examples, (examples, ice) =>
            {
               ice.loop('exampleDoc', examples, (i, exampleDoc, ice) =>
               {
                  const parsed = parseExample(exampleDoc);

                  ice.text('exampleCode', parsed.body);
                  ice.text('exampleCaption', parsed.caption);
               });
            });

            // tests
            ice.into('tests', doc._custom_tests, (tests, ice) =>
            {
               ice.loop('test', tests, (i, test, ice) =>
               {
                  const testDoc = eventbus.triggerSync('tjsdoc:docs:find', { longname: test })[0];

                  ice.load('test', getFileDocLinkHTML(testDoc, testDoc.testFullDescription));
               });
            });
         });

         return ice;
      }

      /**
       * build detail output html by parent doc.
       *
       * @param {DocObject}   doc - parent doc object.
       * @param {string}      kind - target kind property.
       * @param {string}      title - detail title.
       * @param {boolean}     [isStatic=true] - target static property.
       *
       * @returns {string} html of detail.
       * @private
       */
      function getDetailHTML(doc, kind, title, isStatic = true)
      {
         const accessDocs = eventbus.triggerSync('tjsdoc:docs:find:access:docs', doc, kind, isStatic);

         let html = '';

         for (const accessDoc of accessDocs)
         {
            const docs = accessDoc[1];

            if (!docs.length) { continue; }

            let prefix = '';

            if (docs[0].static) { prefix = 'Static '; }

            const _title = `${prefix}${accessDoc[0]} ${title}`;
            const result = getDetailDocs(docs, _title);

            if (result) { html += result.html; }
         }

         return html;
      }

      /**
       * build html link to identifier.
       *
       * @param {string}   longname - link to
       * @param {string}   [text] - link text. default is name property of doc object.
       * @param {boolean}  [inner=false] - if true, use inner link.
       * @param {string}   [kind] - specify target kind property.
       *
       * @returns {string} html of link.
       */
      function getDocLinkHTML(longname, text = null, inner = false, kind = null)
      {
         if (!longname) { return ''; }

         if (typeof longname !== 'string') { throw new Error(JSON.stringify(longname)); }

         const doc = eventbus.triggerSync('tjsdoc:docs:find:by:name', longname, kind)[0];

         if (!doc)
         {
            // if longname is HTML tag, not escape.
            return longname.indexOf('<') === 0 ? `<span>${longname}</span>` : `<span>${escape(text || longname)}</span>`;
         }

         if (doc.kind === 'external')
         {
            text = doc.name;

            return `<span><a href="${doc.externalLink}">${text}</a></span>`;
         }
         else
         {
            text = escape(text || doc.name);

            const url = getURL(doc, inner);

            return url ? `<span><a href="${url}">${text}</a></span>` : `<span>${text}</span>`;
         }
      }

      /**
       * build html links to identifiers
       *
       * @param {string[]} longnames - link to these.
       * @param {string}   [text] - link text. default is name property of doc object.
       * @param {boolean}  [inner=false] - if true, use inner link.
       * @param {string}   [separator='\n'] - used link separator.
       *
       * @returns {string} html links.
       * @private
       */
      function getDocsLinkHTML(longnames, text = null, inner = false, separator = '\n')
      {
         if (!longnames) { return ''; }
         if (!longnames.length) { return ''; }

         const links = [];

         for (const longname of longnames)
         {
            if (!longname) { continue; }

            const link = getDocLinkHTML(longname, text, inner);

            links.push(`<li>${link}</li>`);
         }

         if (!links.length) { return ''; }

         return `<ul>${links.join(separator)}</ul>`;
      }

      /**
       * build summary output html by docs.
       *
       * @param {DocObject[]} docs - target docs.
       * @param {string}      title - summary title.
       * @param {boolean}     [innerLink=false] - if true, link in summary is inner link.
       *
       * @return {IceCap} summary output.
       * @private
       */
      function getDocsSummary(docs, title, innerLink = false)
      {
         if (docs.length === 0) { return null; }

         const ice = new IceCap(getTemplate('summary.html'));

         ice.text('title', title);

         ice.loop('target', docs, (i, doc, ice) =>
         {
            ice.text('generator', doc.generator ? '*' : '');
            ice.text('async', doc.async ? 'async' : '');
            ice.text('abstract', doc.abstract ? 'abstract' : '');
            ice.text('access', doc.access);
            ice.load('signature', getSignatureHTML(doc));
            ice.load('description', shorten(doc, true));
            ice.load('name', getDocLinkHTML(doc.longname, null, innerLink, doc.kind));

            if (['get', 'set'].includes(doc.kind))
            {
               ice.text('kind', doc.kind);
            }
            else
            {
               ice.drop('kind');
            }

            if (['member', 'method', 'get', 'set'].includes(doc.kind))
            {
               ice.text('static', doc.static ? 'static' : '');
            }
            else
            {
               ice.drop('static');
            }

            ice.text('since', doc.since);
            ice.load('deprecated', getDeprecatedHTML(doc));
            ice.load('experimental', getExperimentalHTML(doc));
            ice.text('version', doc.version);
         });

         return ice;
      }

      /**
       * build experimental html.
       *
       * @param {DocObject} doc - target doc object.
       *
       * @returns {string} if doc is not experimental, returns empty.
       * @private
       */
      function getExperimentalHTML(doc)
      {
         if (doc.experimental)
         {
            const experimental = [`this ${doc.kind} is experimental.`];

            if (typeof doc.experimental === 'string') { experimental.push(doc.experimental); }

            return experimental.join(' ');
         }
         else
         {
            return '';
         }
      }

      /**
       * get base url html page. it is used html base tag.
       *
       * @param {string} fileName - output file path.
       *
       * @returns {string} base url.
       */
      function getFileBaseURL(fileName)
      {
         return '../'.repeat(fileName.split('/').length - 1);
      }

      /**
       * build html link to file page.
       *
       * @param {DocObject}   doc - target doc object.
       * @param {string|null} [text=null] - link text.
       *
       * @returns {string} html of link.
       * @private
       */
      function getFileDocLinkHTML(doc, text = null)
      {
         if (!doc) { return ''; }

         let fileDoc;

         if (doc.kind === 'file' || doc.kind === 'testFile')
         {
            fileDoc = doc;
         }
         else
         {
            const filePath = doc.longname.split('~')[0];

            fileDoc = eventbus.triggerSync('tjsdoc:docs:find',
             { kind: ['file', 'testFile'], longname: filePath })[0];
         }

         if (!fileDoc) { return ''; }

         if (!text) { text = fileDoc.name; }

         if (doc.kind === 'file' || doc.kind === 'testFile')
         {
            return `<span><a href="${getURL(fileDoc)}">${text}</a></span>`;
         }
         else
         {
            return `<span><a href="${getURL(fileDoc)}#lineNumber${doc.lineNumber}">${text}</a></span>`;
         }
      }

      /**
       * Gets the common HTML layout including the left-hand navigation. The default left-hand navigation is loaded by
       * triggering `tjsdoc:publisher:get:html:nav` which invokes `getHTMLNav`. To provide a new left-hand navigation
       * register a new event binding to return the HTML and pass in this event path to load it.
       *
       * @param {string}   [navEvent=tjsdoc:publisher:get:html:nav] - Optional event to trigger sync to receive the
       *                                                              left-hand navigation HTML.
       *
       * @return {IceCap} layout output.
       */
      function getHTMLLayout(navEvent = 'tjsdoc:publisher:get:html:nav')
      {
         const config = eventbus.triggerSync('tjsdoc:get:config');

         const info = eventbus.triggerSync('tjsdoc:get:repo:info');

         const ice = new IceCap(getTemplate('layout.html'), { autoClose: false });

         if (typeof global.$$tjsdoc_version === 'string')
         {
            ice.text('esdocVersion', `(${global.$$tjsdoc_version})`);
         }
         else
         {
            ice.drop('esdocVersion');
         }

         if (info.url)
         {
            ice.attr('repoURL', 'href', info.url);

            if (info.url.match(new RegExp('^https?://github.com/')))
            {
               ice.attr('repoURL', 'class', 'repo-url-github');
            }
         }
         else
         {
            ice.drop('repoURL');
         }

         ice.drop('testLink', !config.test);

         // see StaticFileBuilder#exec
         ice.loop('userScript', config.scripts || [], (i, userScript, ice) =>
         {
            const name = `user/script/${i}-${path.basename(userScript)}`;

            ice.attr('userScript', 'src', name);
         });

         ice.loop('userStyle', config.styles || [], (i, userStyle, ice) =>
         {
            const name = `user/css/${i}-${path.basename(userStyle)}`;

            ice.attr('userStyle', 'href', name);
         });

         ice.drop('manualHeaderLink', !config.manual);

         if (config.manual && config.manual.globalIndex)
         {
            ice.drop('manualHeaderLink');
         }

         ice.load('nav', eventbus.triggerSync(navEvent));

         return ice;
      }

      /**
       * build common navigation output.
       *
       * @return {IceCap} navigation output.
       * @private
       */
      function getHTMLNav()
      {
         const html = getTemplate('nav.html');
         const ice = new IceCap(html);

         const kind = ['class', 'function', 'variable', 'typedef', 'external'];
         const allDocs = eventbus.triggerSync('tjsdoc:docs:find', { kind }).filter((v) => !v.builtinVirtual);
         const kindOrder = { 'class': 0, 'interface': 1, 'function': 2, 'variable': 3, 'typedef': 4, 'external': 5 };

         allDocs.sort((a, b) =>
         {
            const filePathA = a.longname.split('~')[0];
            const filePathB = b.longname.split('~')[0];
            const dirPathA = path.dirname(filePathA);
            const dirPathB = path.dirname(filePathB);
            const kindA = a.interface ? 'interface' : a.kind;
            const kindB = b.interface ? 'interface' : b.kind;

            if (dirPathA === dirPathB)
            {
               if (kindA === kindB)
               {
                  return a.longname > b.longname ? 1 : -1;
               }
               else
               {
                  return kindOrder[kindA] > kindOrder[kindB] ? 1 : -1;
               }
            }
            else
            {
               return dirPathA > dirPathB ? 1 : -1;
            }
         });

         let lastDirPath = '.';

         ice.loop('doc', allDocs, (i, doc, ice) =>
         {
            const filePath = doc.longname.split('~')[0].replace(/^.*?[/]/, '');
            const dirPath = path.dirname(filePath);
            const kind = doc.interface ? 'interface' : doc.kind;
            const kindText = kind.charAt(0).toUpperCase();
            const kindClass = `kind-${kind}`;

            ice.load('name', getDocLinkHTML(doc.longname));
            ice.load('kind', kindText);
            ice.attr('kind', 'class', kindClass);
            ice.text('dirPath', dirPath);
            ice.drop('dirPath', lastDirPath === dirPath);

            lastDirPath = dirPath;
         });

         return ice;
      }

      /**
       * build properties output.
       *
       * @param {ParsedParam[]}  [properties=[]] - properties in doc object.
       * @param {string}         title - output title.
       *
       * @return {IceCap} built properties output.
       * @private
       */
      function getHTMLProperties(properties = [], title = 'Properties:')
      {
         const ice = new IceCap(getTemplate('properties.html'));

         ice.text('title', title);

         ice.loop('property', properties, (i, prop, ice) =>
         {
            ice.autoDrop = false;
            ice.attr('property', 'data-depth', prop.name.split('.').length - 1);
            ice.text('name', prop.name);
            ice.attr('name', 'data-depth', prop.name.split('.').length - 1);
            ice.load('description', prop.description);

            const typeNames = [];

            for (const typeName of prop.types)
            {
               typeNames.push(getTypeDocLinkHTML(typeName));
            }

            ice.load('type', typeNames.join(' | '));

            // appendix
            const appendix = [];

            if (prop.optional)
            {
               appendix.push('<li>optional</li>');
            }

            if ('defaultValue' in prop)
            {
               appendix.push(`<li>default: ${prop.defaultValue}</li>`);
            }

            if (typeof prop.nullable === 'boolean')
            {
               appendix.push(`<li>nullable: ${prop.nullable}</li>`);
            }

            if (appendix.length)
            {
               ice.load('appendix', `<ul>${appendix.join('\n')}</ul>`);
            }
            else
            {
               ice.text('appendix', '');
            }
         });

         if (!properties || properties.length === 0)
         {
            ice.drop('properties');
         }

         return ice;
      }

      /**
       * build summary output html by parent doc.
       *
       * @param {DocObject}   doc - parent doc object.
       * @param {string}      kind - target kind property.
       * @param {string}      title - summary title.
       * @param {boolean}     [isStatic=true] - target static property.
       *
       * @returns {string} html of summary.
       * @private
       */
      function getHTMLSummary(doc, kind, title, isStatic = true)
      {
         const accessDocs = eventbus.triggerSync('tjsdoc:docs:find:access:docs', doc, kind, isStatic);

         let html = '';

         for (const accessDoc of accessDocs)
         {
            const docs = accessDoc[1];

            if (!docs.length) { continue; }

            let prefix = '';

            if (docs[0].static) { prefix = 'Static '; }

            const _title = `${prefix}${accessDoc[0]} ${title}`;
            const result = getDocsSummary(docs, _title);

            if (result) { html += result.html; }
         }

         return html;
      }

      /**
       * build method of ancestor class link html.
       *
       * @param {DocObject} doc - target doc object.
       *
       * @returns {string} html link. if doc does not override ancestor method, returns empty.
       * @private
       */
      function getOverrideMethod(doc)
      {
         const parentDoc = eventbus.triggerSync('tjsdoc:docs:find:by:name', doc.memberof)[0];

         if (!parentDoc) { return ''; }
         if (!parentDoc._custom_extends_chains) { return ''; }

         const chains = [...parentDoc._custom_extends_chains].reverse();

         for (const longname of chains)
         {
            const superClassDoc = eventbus.triggerSync('tjsdoc:docs:find:by:name', longname)[0];

            if (!superClassDoc) { continue; }

            const superMethodDoc = eventbus.triggerSync('tjsdoc:docs:find',
             { name: doc.name, memberof: superClassDoc.longname })[0];

            if (!superMethodDoc) { continue; }

            return getDocLinkHTML(superMethodDoc.longname, `${superClassDoc.name}#${superMethodDoc.name}`, true);
         }

         return '';
      }

      /**
       * build method of ancestor class description.
       *
       * @param {DocObject} doc - target doc object.
       *
       * @returns {string} description. if doc does not override ancestor method, returns empty.
       * @private
       */
      function getOverrideMethodDescription(doc)
      {
         const parentDoc = eventbus.triggerSync('tjsdoc:docs:find:by:name', doc.memberof)[0];

         if (!parentDoc) { return ''; }
         if (!parentDoc._custom_extends_chains) { return ''; }

         const chains = [...parentDoc._custom_extends_chains].reverse();

         for (const longname of chains)
         {
            const superClassDoc = eventbus.triggerSync('tjsdoc:docs:find:by:name', longname)[0];

            if (!superClassDoc) { continue; }

            const superMethodDoc = eventbus.triggerSync('tjsdoc:docs:find',
             { name: doc.name, memberof: superClassDoc.longname })[0];

            if (!superMethodDoc) { continue; }

            if (superMethodDoc.description) { return superMethodDoc.description; }
         }

         return '';
      }

      /**
       * get file name of output html page.
       *
       * @param {DocObject} doc - target doc object.
       *
       * @returns {string} file name.
       */
      function getOutputFileName(doc)
      {
         switch (doc.kind)
         {
            case 'variable':
               return 'variable/index.html';

            case 'function':
               return 'function/index.html';

            case 'member': // fall
            case 'method': // fall
            case 'constructor': // fall
            case 'set': // fall
            case 'get':
            {
               const parentDoc = eventbus.triggerSync('tjsdoc:docs:find', { longname: doc.memberof })[0];

               return getOutputFileName(parentDoc);
            }

            case 'external':
               return 'external/index.html';

            case 'typedef':
               return 'typedef/index.html';

            case 'class':
               return `class/${doc.longname}.html`;

            case 'file':
               return `file/${doc.longname}.html`;

            case 'testFile':
               return `test-file/${doc.longname}.html`;

            case 'testDescribe':
               return 'test.html';

            case 'testIt':
               return 'test.html';

            default:
               throw new Error('DocBuilder: can not resolve file name.');
         }
      }

      /**
       * build identifier signature html.
       *
       * @param {DocObject} doc - target doc object.
       *
       * @returns {string} signature html.
       * @private
       */
      function getSignatureHTML(doc)
      {
         // call signature
         const callSignatures = [];

         if (doc.params)
         {
            for (const param of doc.params)
            {
               const paramName = param.name;

               if (paramName.indexOf('.') !== -1) { continue; } // for object property
               if (paramName.indexOf('[') !== -1) { continue; } // for array property

               const types = [];

               for (const typeName of param.types)
               {
                  types.push(getTypeDocLinkHTML(typeName));
               }

               callSignatures.push(`${paramName}: ${types.join(' | ')}`);
            }
         }

         // return signature
         const returnSignatures = [];

         if (doc.return)
         {
            for (const typeName of doc.return.types)
            {
               returnSignatures.push(getTypeDocLinkHTML(typeName));
            }
         }

         // type signature
         let typeSignatures = [];

         if (doc.type)
         {
            for (const typeName of doc.type.types)
            {
               typeSignatures.push(getTypeDocLinkHTML(typeName));
            }
         }

         // callback is not need type. because type is always function.
         if (doc.kind === 'function')
         {
            typeSignatures = [];
         }

         let html = '';

         if (callSignatures.length)
         {
            html = `(${callSignatures.join(', ')})`;
         }
         else if (['function', 'method', 'constructor'].includes(doc.kind))
         {
            html = '()';
         }

         if (returnSignatures.length) { html = `${html}: ${returnSignatures.join(' | ')}`; }
         if (typeSignatures.length) { html = `${html}: ${typeSignatures.join(' | ')}`; }

         return html;
      }

      /**
       * Gets an html template.
       *
       * @param {string} fileName - template file name.
       *
       * @return {string} html of template.
       * @protected
       */
      function getTemplate(fileName)
      {
         const filePath = path.resolve(__dirname, `./template/${fileName}`);

         return fs.readFileSync(filePath, { encoding: 'utf-8' });
      }

      /**
       * get output html page title. use ``title`` in {@link TJSDocConfig}.
       *
       * @param {DocObject} doc - target doc object.
       *
       * @returns {string} page title.
       */
      function getTitle(doc = '')
      {
         const config = eventbus.triggerSync('tjsdoc:get:config');

         const name = doc.name || doc.toString();

         if (!name)
         {
            return config.title ? `${config.title} API Document` : 'API Document';
         }

         return config.title ? `${name} | ${config.title} API Document` : `${name} | API Document`;
      }

      /**
       * Get html link of type.
       *
       * @param {string} typeName - type name(e.g. ``number[]``, ``Map<number, string>``)
       *
       * @returns {string} html of link.
       * @private
       * @todo re-implement with parser combinator.
       */
      function getTypeDocLinkHTML(typeName)
      {
         // e.g. number[]
         let matched = typeName.match(/^(.*?)\[\]$/);

         if (matched)
         {
            typeName = matched[1];

            return `<span>${getDocLinkHTML(typeName, typeName)}<span>[]</span></span>`;
         }

         // e.g. function(a: number, b: string): boolean
         matched = typeName.match(/function *\((.*?)\)(.*)/);

         if (matched)
         {
            const functionLink = getDocLinkHTML('function');

            if (!matched[1] && !matched[2]) { return `<span>${functionLink}<span>()</span></span>`; }

            let innerTypes = [];

            if (matched[1])
            {
               // bad hack: Map.<string, boolean> => Map.<string\Z boolean>
               // bad hack: {a: string, b: boolean} => {a\Y string\Z b\Y boolean}
               const inner = matched[1]
                .replace(/<.*?>/g, (a) => a.replace(/,/g, '\\Z'))
                 .replace(/{.*?}/g, (a) => a.replace(/,/g, '\\Z').replace(/:/g, '\\Y'));

               innerTypes = inner.split(',').map((v) =>
               {
                  const tmp = v.split(':').map((v) => v.trim());

                  if (tmp.length !== 2) { throw new SyntaxError(`Invalid function type annotation: \`${matched[0]}\``); }

                  const paramName = tmp[0];
                  const typeName = tmp[1].replace(/\\Z/g, ',').replace(/\\Y/g, ':');

                  return `${paramName}: ${getTypeDocLinkHTML(typeName)}`;
               });
            }

            let returnType = '';

            if (matched[2])
            {
               const type = matched[2].split(':')[1];

               if (type) { returnType = `: ${getTypeDocLinkHTML(type.trim())}`; }
            }

            return `<span>${functionLink}<span>(${innerTypes.join(', ')})</span>${returnType}</span>`;
         }

         // e.g. {a: number, b: string}
         matched = typeName.match(/^\{(.*?)\}$/);

         if (matched)
         {
            if (!matched[1]) { return '{}'; }

            // bad hack: Map.<string, boolean> => Map.<string\Z boolean>
            // bad hack: {a: string, b: boolean} => {a\Y string\Z b\Y boolean}
            const inner = matched[1]
             .replace(/<.*?>/g, (a) => a.replace(/,/g, '\\Z'))
              .replace(/{.*?}/g, (a) => a.replace(/,/g, '\\Z').replace(/:/g, '\\Y'));

            const innerTypes = inner.split(',').map((v) =>
            {
               const tmp = v.split(':').map((v) => v.trim());
               const paramName = tmp[0];

               let typeName = tmp[1].replace(/\\Z/g, ',').replace(/\\Y/g, ':');

               if (typeName.includes('|'))
               {
                  typeName = typeName.replace(/^\(/, '').replace(/\)$/, '');

                  const typeNames = typeName.split('|').map((v) => v.trim());
                  const html = [];

                  for (const unionType of typeNames)
                  {
                     html.push(getTypeDocLinkHTML(unionType));
                  }
                  return `${paramName}: ${html.join('|')}`;
               }
               else
               {
                  return `${paramName}: ${getTypeDocLinkHTML(typeName)}`;
               }
            });

            return `{${innerTypes.join(', ')}}`;
         }

         // e.g. Map<number, string>
         matched = typeName.match(/^(.*?)\.?<(.*?)>$/);

         if (matched)
         {
            const mainType = matched[1];
            // bad hack: Map.<string, boolean> => Map.<string\Z boolean>
            // bad hack: {a: string, b: boolean} => {a\Y string\Z b\Y boolean}

            const inner = matched[2]
             .replace(/<.*?>/g, (a) => a.replace(/,/g, '\\Z'))
              .replace(/{.*?}/g, (a) => a.replace(/,/g, '\\Z').replace(/:/g, '\\Y'));

            const innerTypes = inner.split(',').map((v) =>
            {
               return v.split('|').map((vv) =>
               {
                  vv = vv.trim().replace(/\\Z/g, ',').replace(/\\Y/g, ':');

                  return getTypeDocLinkHTML(vv);
               }).join('|');
            });

            // html
            return `${getDocLinkHTML(mainType, mainType)}<${innerTypes.join(', ')}>`;
         }

         if (typeName.indexOf('...') === 0)
         {
            typeName = typeName.replace('...', '');

            if (typeName.includes('|'))
            {
               const typeNames = typeName.replace('(', '').replace(')', '').split('|');
               const typeLinks = typeNames.map((v) => getDocLinkHTML(v));

               return `...(${typeLinks.join('|')})`;
            }
            else
            {
               return `...${getDocLinkHTML(typeName)}`;
            }
         }
         else if (typeName.indexOf('?') === 0)
         {
            typeName = typeName.replace('?', '');

            return `?${getDocLinkHTML(typeName)}`;
         }
         else
         {
            return getDocLinkHTML(typeName);
         }
      }

      /**
       * gat url of output html page.
       *
       * @param {DocObject} doc - target doc object.
       *
       * @returns {string} url of output html. it is relative path from output root dir.
       */
      function getURL(doc)
      {
         let inner = false;

         if (['variable', 'function', 'member', 'typedef', 'method', 'constructor', 'get', 'set'].includes(doc.kind))
         {
            inner = true;
         }

         if (inner)
         {
            const scope = doc.static ? 'static' : 'instance';
            const fileName = getOutputFileName(doc);

            return `${fileName}#${scope}-${doc.kind}-${doc.name}`;
         }
         else
         {
            return getOutputFileName(doc);
         }
      }
   }
}
