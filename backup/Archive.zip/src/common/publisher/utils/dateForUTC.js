/**
 * get UTC date string.
 *
 * @param {Date} date - target date object.
 *
 * @returns {string} UTC date string(yyyy-mm-dd hh:mm:ss)
 */
export default function dateForUTC(date)
{
   const pad = (num, len) =>
   {
      const count = Math.max(0, len - `${num}`.length);

      return '0'.repeat(count) + num;
   };

   const year = date.getUTCFullYear();
   const month = pad(date.getUTCMonth() + 1, 2);
   const day = pad(date.getUTCDay() + 1, 2);
   const hours = pad(date.getUTCHours(), 2);
   const minutes = pad(date.getUTCMinutes(), 2);
   const seconds = pad(date.getUTCSeconds(), 2);

   return `${year}-${month}-${day} ${hours}:${minutes}:${seconds} (UTC)`;
}
