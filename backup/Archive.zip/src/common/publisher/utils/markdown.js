import marked from 'marked';
import escape from 'escape-html';

/**
 * convert markdown text to html.
 *
 * @param {string} text - markdown text.
 * @param {boolean} [breaks=false] if true, break line. FYI gfm is not breaks.
 *
 * @return {string} html.
 */
export default function markdown(text, breaks = false)
{
   const availableTags =
    ['span', 'a', 'p', 'div', 'img', 'h1', 'h2', 'h3', 'h4', 'h5', 'br', 'hr', 'li', 'ul', 'ol', 'code', 'pre'];

   const availableAttributes = ['src', 'href', 'title', 'class', 'id', 'name', 'width', 'height', 'target'];

   // compiled
   return marked(text,
   {
      gfm: true,
      tables: true,
      breaks,
      sanitize: true,
      sanitizer: (tag) =>
      {
         if (tag.match(/<!--.*-->/)) { return tag; }

         const tagName = tag.match(/^<\/?(\w+)/)[1];

         if (!availableTags.includes(tagName)) { return escape(tag); }

         // sanitized tag
         return tag.replace(/([\w\-]+)=(["'].*?["'])/g, (_, attr, val) =>
         {
            if (!availableAttributes.includes(attr)) { return ''; }
            if (val.indexOf('javascript:') !== -1) { return ''; }

            return `${attr}=${val}`;
         });
      },
      highlight: (code) =>
      {
         // return `<pre class="source-code"><code class="prettyprint">${escape(code)}</code></pre>`;
         return `<code class="source-code prettyprint">${escape(code)}</code>`;
      }
   });
}
