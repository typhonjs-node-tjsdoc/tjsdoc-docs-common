import fs   from 'fs-extra';
import path from 'path';

/**
 * Creates several general utility methods bound to the eventbus.
 *
 * @param {EventProxy}     eventbus - An event proxy for the main eventbus.
 * @param {TJSDocConfig}   config - The TJSDoc config.
 */
export default function createUtilityEventBindings(eventbus, config)
{
   /**
    * Helper event binding to copy a file relative to the output destination.
    *
    * @param {string}   srcPath - Source path.
    * @param {string}   destPath - Destination path.
    * @param {boolean}  [silent=false] - When true `output: <destPath>` is logged.
    */
   eventbus.on('tjsdoc:util:copy', (srcPath, destPath, silent = false) =>
   {
      if (typeof silent === 'boolean' && !silent) { console.log(`output: ${destPath}`); }

      fs.copySync(srcPath, path.resolve(config.destination, destPath));
   });

   /**
    * Helper event binding to output a file relative to the output destination.
    *
    * @param {object}   fileData - The file data.
    * @param {string}   fileName - Target file name.
    * @param {boolean}  [silent=false] - When true `output: <destPath>` is logged.
    * @param {encoding} [encoding=utf8] - The encoding type.
    */
   eventbus.on('tjsdoc:util:write:file', (fileData, fileName, silent = false, encoding = 'utf8') =>
   {
      if (typeof silent === 'boolean' && !silent) { console.log(`output: ${fileName}`); }

      fs.outputFileSync(path.resolve(config.destination, fileName), fileData, { encoding });
   });

   /**
    * Helper event binding to output a file relative to the output destination.
    *
    * @param {object}   html - The HTML data.
    * @param {string}   fileName - Target file name.
    * @param {boolean}  [silent=false] - When true `output: <destPath>` is logged.
    * @param {encoding} [encoding=utf8] - The encoding type.
    */
   eventbus.on('tjsdoc:util:write:html', (html, fileName, silent = false, encoding = 'utf8') =>
   {
      if (typeof silent === 'boolean' && !silent) { console.log(`output: ${fileName}`); }

      html = eventbus.triggerSync('plugins:invoke:sync:event', 'onHandleHTML', { html, fileName }).html;

      fs.outputFileSync(path.resolve(config.destination, fileName), html, { encoding });
   });
}
