/**
 * Creates event binding utility event bindings.
 *
 * @param {EventProxy}     eventbus - An event proxy for the main eventbus.
 * @param {TJSDocConfig}   config - The TJSDoc config.
 * @param {PackageObj}     packageObj - The target repo package.json object.
 */
export default function createRepoEventBindings(eventbus, config, packageObj)
{
   /**
    * Get essential info for the target repo.
    *
    * @returns {{title: string, version: string, url: string}}
    */
   eventbus.on('tjsdoc:get:repo:info', () =>
   {
      // repository url
      let url = null;

      if (packageObj.repository)
      {
         url = packageObj.repository.url ? packageObj.repository.url : packageObj.repository;

         if (typeof url === 'string')
         {
            if (url.indexOf('git@github.com:') === 0)
            {
               // url: git@github.com:foo/bar.git
               const matched = url.match(/^git@github\.com:(.*)\.git$/);

               if (matched && matched[1])
               {
                  url = `https://github.com/${matched[1]}`;
               }
            }
            else if (url.match(/^[\w\d\-_]+\/[\w\d\-_]+$/))
            {
               // url: foo/bar
               url = `https://github.com/${url}`;
            }
            else if (url.match(/^git\+https:\/\/github.com\/.*\.git$/))
            {
               // git+https://github.com/foo/bar.git
               const matched = url.match(/^git\+(https:\/\/github.com\/.*)\.git$/);

               url = matched[1];
            }
            else if (url.match(/(https?:\/\/.*$)/))
            {
               // other url
               const matched = url.match(/(https?:\/\/.*$)/);

               url = matched[1];
            }
            else
            {
               url = '';
            }
         }
         else
         {
            url = null;
         }
      }

      // Index info.
      return {
         title: config.title || packageObj.name,
         version: config.version || packageObj.version,
         url
      };
   });
}
