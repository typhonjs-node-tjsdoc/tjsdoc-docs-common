/**
 * Provides a generic parser error with start and end lines for the error.
 */
export default class ParserError extends Error
{
   constructor(line = 0, column = 0, message = void 0, position = void 0, fileName = void 0)
   {
      super(message, fileName, line);

      this.line = line;
      this.column = column;
      this.position = position;

      Object.freeze(this);
   }
}
