import path from 'path';

/**
 * Adds all common runtime utility plugins.
 *
 * @param {PluginEvent} ev - The plugin event.
 *
 * @ignore
 */
export function onPluginLoad(ev)
{
   const eventbus = ev.eventbus;
   const dirPath = path.resolve(__dirname);

   eventbus.trigger('plugins:add', { name: `typhonjs-path-resolver` });

   eventbus.trigger('plugins:add', { name: `${dirPath}/ASTNodeContainer.js` });
   eventbus.trigger('plugins:add', { name: `${dirPath}/FileUtil.js` });
   eventbus.trigger('plugins:add', { name: `${dirPath}/InvalidCodeLogger.js` });
   eventbus.trigger('plugins:add', { name: `${dirPath}/NamingUtil.js` });
   eventbus.trigger('plugins:add', { name: `${dirPath}/RepoUtil.js` });
   eventbus.trigger('plugins:add', { name: `${dirPath}/TraverseUtil.js` });
}
