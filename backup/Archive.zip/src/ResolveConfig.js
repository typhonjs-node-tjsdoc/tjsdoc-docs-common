//import path from 'path';
//
//export default class ResolveConfig
//{
//   static resolve(config, pluginManager, eventbus)
//   {
//
//   }
//}
//
///**
// * Determines if a given string represents a filepath or not using the same
// * conventions as require(), meaning that the first character must be nonalphanumeric
// * and not the @ sign which is used for scoped packages to be considered a file path.
// * @param {string} filePath The string to check.
// * @returns {boolean} True if it's a filepath, false if not.
// * @private
// */
//const s_IS_FILEPATH = (filePath) =>
//{
//   return path.isAbsolute(filePath) || !(/\w|@/.test(filePath.charAt(0)));
//};
//
///**
// * Merges two config objects. This will not only add missing keys, but will also modify values to match.
// * @param {Object} target config object
// * @param {Object} src config object. Overrides in this config object will take priority over base.
// * @param {boolean} [combine] Whether to combine arrays or not
// * @param {boolean} [isRule] Whether its a rule
// * @returns {Object} merged config object.
// */
//const s_DEEP_MERGE = (target, src, combine) =>
//{
//   /*
//    The MIT License (MIT)
//    Copyright (c) 2012 Nicholas Fisher
//    Permission is hereby granted, free of charge, to any person obtaining a copy
//    of this software and associated documentation files (the "Software"), to deal
//    in the Software without restriction, including without limitation the rights
//    to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
//    copies of the Software, and to permit persons to whom the Software is
//    furnished to do so, subject to the following conditions:
//    The above copyright notice and this permission notice shall be included in
//    all copies or substantial portions of the Software.
//    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
//    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
//    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
//    OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
//    THE SOFTWARE.
//    */
//
//   /*
//    * This code is taken from deepmerge repo
//    * (https://github.com/KyleAMathews/deepmerge)
//    * and modified to meet our needs.
//    */
//   const array = Array.isArray(src) || Array.isArray(target);
//   let dst = array && [] || {};
//
//   combine = !!combine;
//
//   if (array)
//   {
//      target = target || [];
//
//      // src could be a string, so check for array
//      //if (isRule && Array.isArray(src) && src.length > 1)
//      //{
//      //   dst = dst.concat(src);
//      //}
//      //else
//      {
//         dst = dst.concat(target);
//      }
//
//      if (typeof src !== "object" && !Array.isArray(src))
//      {
//         src = [src];
//      }
//
//      Object.keys(src).forEach((e, i) =>
//      {
//         e = src[i];
//
//         if (typeof dst[i] === "undefined")
//         {
//            dst[i] = e;
//         }
//         else if (typeof e === "object")
//         {
//            dst[i] = s_DEEP_MERGE(target[i], e, combine);
//         }
//         else
//         {
//            if (!combine)
//            {
//               dst[i] = e;
//            }
//            else
//            {
//               if (dst.indexOf(e) === -1)
//               {
//                  dst.push(e);
//               }
//            }
//         }
//      });
//   }
//   else
//   {
//      if (target && typeof target === "object")
//      {
//         Object.keys(target).forEach((key) =>
//         {
//            dst[key] = target[key];
//         });
//      }
//
//      Object.keys(src).forEach((key) =>
//      {
//         if (Array.isArray(src[key]) || Array.isArray(target[key]))
//         {
//            dst[key] = s_DEEP_MERGE(target[key], src[key], key === "plugins");
//         }
//         else if (typeof src[key] !== "object" || !src[key])
//         {
//            dst[key] = src[key];
//         }
//         else
//         {
//            dst[key] = s_DEEP_MERGE(target[key] || {}, src[key], combine);
//         }
//      });
//   }
//
//   return dst;
//};
//
///**
// * Applies values from the "extends" field in a configuration file.
// * @param {Object} config The configuration information.
// * @param {string} filePath The file path from which the configuration information
// *      was loaded.
// * @param {string} [relativeTo] The path to resolve relative to.
// * @param {PluginManager} pluginManager -
// * @param {EventProxy} eventbus -
// *
// *
// * @returns {Object} A new configuration object with all of the "extends" fields
// *      loaded and merged.
// * @private
// */
//const s_APPLY_EXTENDS = (config, filePath, relativeTo, pluginManager, eventbus) =>
//{
//   let configExtends = config.extends;
//
//   // normalize into an array for easier handling
//   if (!Array.isArray(config.extends))
//   {
//      configExtends = [config.extends];
//   }
//
//   // Make the last element in an array take the highest precedence
//   config = configExtends.reduceRight((previousValue, parentPath) =>
//   {
//      if (s_IS_FILEPATH(parentPath))
//      {
//         /*
//          * If the `extends` path is relative, use the directory of the current configuration
//          * file as the reference point. Otherwise, use as-is.
//          */
//         parentPath = (!path.isAbsolute(parentPath) ?
//          path.join(relativeTo || path.dirname(filePath), parentPath) : parentPath);
//      }
//
//      try
//      {
//         eventbus.trigger('log:info:raw', `loading: ${parentPath}`);
//
//         return s_DEEP_MERGE(s_LOAD(parentPath, relativeTo), previousValue);
//      }
//      catch (err)
//      {
//        /*
//          * If the file referenced by `extends` failed to load, add the path
//          * to the configuration file that referenced it to the error
//          * message so the user is able to see where it was referenced from,
//          * then re-throw.
//          */
//          err.message += `\nReferenced from: ${filePath}`;
//         throw err;
//      }
//
//   }, config);
//
//   return config;
//};
//
///**
// * Loads a configuration file from the given file path.
// * @param {string} filePath The filename or package name to load the configuration
// *      information from.
// * @param {string} [relativeTo] The path to resolve relative to.
// * @param {PluginManager} pluginManager -
// * @param {EventProxy} eventbus -
//
// * @returns {Object} The configuration information.
// * @private
// */
//const s_LOAD = (filePath, relativeTo, pluginManager, eventbus) =>
//{
//   const resolvedPath = resolve(filePath, relativeTo);
//   const dirname = path.dirname(resolvedPath.filePath);
//
//   let config = s_LOAD_CONFIG_FILE(resolvedPath);
//
//   if (config)
//   {
//      // ensure plugins are properly loaded first
//      if (config.plugins)
//      {
//         pluginManager.addAll(config.plugins);
//      }
//
//      /*
//       * If an `extends` property is defined, it represents a configuration file to use as
//       * a "parent". Load the referenced file and merge the configuration recursively.
//       */
//      if (config.extends)
//      {
//         config = s_APPLY_EXTENDS(config, filePath, dirname, pluginManager, eventbus);
//      }
//   }
//
//   return config;
//};
//
///**
// * Loads a configuration file regardless of the source. Inspects the file path
// * to determine the correctly way to load the config file.
// * @param {Object} file The path to the configuration.
// * @returns {Object} The configuration information.
// * @private
// */
//const s_LOAD_CONFIG_FILE = (file) =>
//{
//   const filePath = file.filePath;
//   let config;
//
//   switch (path.extname(filePath))
//   {
//      case ".js":
//         config = loadJSConfigFile(filePath);
//         if (file.configName)
//         {
//            config = config.configs[file.configName];
//         }
//         break;
//
//      case ".json":
//         if (path.basename(filePath) === "package.json")
//         {
//            config = loadPackageJSONConfigFile(filePath);
//            if (config === null)
//            {
//               return null;
//            }
//         }
//         else
//         {
//            config = loadJSONConfigFile(filePath);
//         }
//         break;
//   }
//
//   return config;
//};
