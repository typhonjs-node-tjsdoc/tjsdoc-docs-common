/**
 * @typedef {Object} AST
 *
 * @property {Object}   body
 * @property {Object[]} leadingComments
 *
 * @see https://github.com/babel/babylon/blob/master/ast/spec.md
 */

/**
 * @typedef {Object} ASTData
 *
 * @property {string} filePath
 * @property {AST}    ast
 */

/**
 * @typedef {Object} ASTNode
 *
 * @property {string}   type
 * @property {Object}   [superClass]
 * @property {Object[]} [leadingComments]
 * @property {Object[]} [trailingComments]
 * @property {Object[]} [body]
 * @property {ASTNode}  [parent] - this is customize by TJSDoc
 *
 * @see https://github.com/babel/babylon/blob/master/ast/spec.md
 */

/**
 * @typedef {Object} CoverageObject
 *
 * @property {string}                  coverage - ratio.
 * @property {number}                  expectCount - all identifier count.
 * @property {number}                  actualCount - documented identifier count.
 * @property {Object<string, Object>}  files - file name and coverage.
 */

/**
 * @typedef {Object} Decorator
 *
 * @property {string}   name - The decorator name.
 * @property {string}   arguments - Argument string
 */

/**
 * Parsed doc comment.
 *
 * @typedef {Object} DocObject
 */

/**
 * @typedef {Object} IceCap
 * @see https://www.npmjs.com/package/typhonjs-ice-cap
 */

/**
 * @typedef {Object} ManualConfigItem
 *
 * @property {string}   label
 * @property {string[]} paths
 * @property {string}   [fileName]
 * @property {string}   [reference]
 */

/**
 * @typedef {Object} NPMPackageData
 *
 * @property {string}   name
 * @property {string}   version
 * @property {string}   description
 * @property {string}   author
 * @property {string}   homepage
 * @property {string}   license
 * @property {string}   main
 * @property {object}   repository
 * @property {object}   bugs
 * @property {string}   formattedMessage
 */

/**
 * @typedef {Object} NPMPackageObject
 * @see https://docs.npmjs.com/files/package.json
 */

/**
 * @typedef {Object} ParsedParam
 *
 * @property {boolean}  [nullable]
 * @property {string[]} types
 * @property {boolean}  [spread]
 * @property {boolean}  [optional]
 * @property {string}   [defaultValue]
 * @property {*}        [defaultRaw]
 * @property {string}   [name]
 * @property {string}   [description]
 */

/**
 * @typedef {Object} Taffy
 * @see http://www.taffydb.com/
 */

/**
 * doc comment tag.
 *
 * @typedef {Object} Tag
 *
 * @property {string}   tagName
 * @property {*}        tagValue
 */

/**
 * Configuration for test sources.
 *
 * @typedef {Object} TestConfig
 *
 * @property {string}   type - Must be 'mocha'.
 * @property {string}   source
 * @property {string[]} [excludes=[]]
 * @property {string[]} [includes=['\\.(js|jsm|jsx)$']]
 */

/**
 * TJSDocCLI uses argv
 *
 * @typedef {Object} TJSDocCLIArgv
 *
 * @property {boolean}  [h] - for help
 * @property {boolean}  [help] - for help
 * @property {boolean}  [v] - for version
 * @property {boolean}  [version] - for version
 * @property {string}   [c] - for config file path
 * @property {string[]} [_] - for source directory path
 */

/**
 * TJSDoc config object.
 *
 * @typedef {Object} TJSDocConfig
 *
 * @property {string|string[]}   source - directory path of javascript source code.
 * @property {string}            destination - directory path of output.
 * @property {string[]}          [access=['public', 'protected', 'private']]
 * @property {boolean}           [autoPrivate=true]
 * @property {boolean}           [builtinVirtual=true]
 * @property {boolean}           [compactData=false] - If true then JSON output (AST & docData) is compacted.
 * @property {boolean}           [compressFormat=tar.gz] - Either `tar.gz` or `zip`; determines any archive output file extension and compression type.
 * @property {boolean}           [compressData=false] - If true then all data / JSON output (AST & docData) is compressed.
 * @property {boolean}           [compressOutput=false] - If true then all output is compressed to `docs.zip` in destination directory.
 * @property {boolean}           [copyPackage=true] - If true package.json is copied into the destination directory.
 * @property {boolean}           [coverage=true]
 * @property {boolean}           [debug=false]
 * @property {boolean}           [emptyDestination=false] - If true before publishing the output destination is emptied.
 * @property {string[]}          [excludes=[]]
 * @property {string|string[]}   [extends] - A string that specifies a configuration or an array of strings where each additional configuration extends the preceding configurations.
 * @property {string[]}          [includes=['\\.(js|jsm|jsx)$']]
 * @property {string}            [includeSource=true] - If true source code is present in file / source output.
 * @property {string}            [index='./README.md']
 * @property {string}            [lint=true] - Provide linting information for documentation issues.
 * @property {string}            [logLevel='info'] - Sets default log level: `off`, `fatal`, `error`, `warn`, `info`, `verbose`, `debug`, `trace`.
 * @property {object}            [manual]
 * @property {boolean}           [manual.globalIndex]
 * @property {string}            [manual.asset]
 * @property {string}            [manual.index]
 * @property {string[]}          [manual.overview]
 * @property {string[]}          [manual.design]
 * @property {string[]}          [manual.installation]
 * @property {string[]}          [manual.usage]
 * @property {string[]}          [manual.tutorial]
 * @property {string[]}          [manual.configuration]
 * @property {string[]}          [manual.example]
 * @property {string[]}          [manual.advanced]
 * @property {string[]}          [manual.faq]
 * @property {string[]}          [manual.changelog]
 * @property {boolean}           [outputASTData=false] - If true then parsed AST data is output into the destination directory.
 * @property {boolean}           [outputDocData=false] - If true then raw document / tag data is output into the destination directory.
 * @property {string}            [package='./package.json']
 * @property {string[]}          [pathExtensions] - An array of path extensions for files; runtime dependent, the Babylon runtime uses: `['.js', '.jsx', '.jsm']`.
 * @property {PluginConfig[]}    [plugins] - An array of plugins to load.
 * @property {string}            [publisher] - The publisher NPM plugin or local implementation.
 * @property {string}            [runtime] - The runtime NPM plugin or local implementation.
 * @property {string[]}          [scripts=[]]
 * @property {boolean}           [separateDataArchives=false] - If true the all data (AST & docData) will result in separate archives when compressing.
 * @property {string[]}          [styles=[]]
 * @property {string}            [title]
 * @property {TestConfig}        [test]
 * @property {boolean}           [unexportIdentifier=false]
 * @property {boolean}           [undocumentIdentifier=true]
 *
 * @see https://tjsdoc.typhonjs.io/config.html
 */
