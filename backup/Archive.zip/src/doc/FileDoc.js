import fs            from 'fs';

import AbstractDoc   from './abstract/AbstractDoc.js';

/**
 * Doc Class from source file.
 */
export default class FileDoc extends AbstractDoc
{
   /**
    * Create instance. File docs are the module, so pass `null` as the module ID to AbstractDoc.
    *
    * @param {AST}            ast - this is AST that contains this doc.
    *
    * @param {ASTNode}        node - this is self node.
    *
    * @param {PathResolver}   pathResolver - this is file path resolver that contains this doc.
    *
    * @param {Tag[]}          commentTags - this is tags that self node has.
    *
    * @param {EventProxy}     eventbus - An event proxy for the main eventbus.
    */
   constructor(ast, node, pathResolver, commentTags = [], eventbus)
   {
      super(null, ast, node, pathResolver, commentTags, eventbus);
   }

   /** specify ``file`` to kind. */
   _$kind()
   {
      this._value.kind = 'file';
   }

   /** take out self name from file path */
   _$name()
   {
      this._value.name = this._pathResolver.filePath;
   }

   /** specify name to longname */
   _$longname()
   {
      this._value.longname = this._pathResolver.filePath;
   }

   /** specify file content to value.content */
   _$content()
   {
      const filePath = this._pathResolver.absolutePath;

      this._value.content = fs.readFileSync(filePath, { encode: 'utf8' }).toString();
   }
}
