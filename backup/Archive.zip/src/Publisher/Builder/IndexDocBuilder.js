import fs         from 'fs';
import IceCap     from 'ice-cap';
import path       from 'path';

import DocBuilder from './DocBuilder.js';
import markdown   from './utils/markdown.js';

/**
 * Index output builder class.
 */
export default class IndexDocBuilder extends DocBuilder
{
   /**
    * create instance.
    *
    * @param {Taffy} data - doc object database.
    * @param {ESDocConfig} config - use config to build output.
    * @param {CoverageObject} coverage - use coverage to build output.
    */
   constructor(data, config, coverage)
   {
      super(data, config);
      this._coverage = coverage;
   }

   /**
    * execute building output.
    *
    * @param {function(html: string, filePath: string)} callback - is called with output.
    */
   exec(callback)
   {
      const ice = this._buildLayoutDoc();
      const title = this._getTitle();

      ice.load('content', this._buildIndexDoc());
      ice.text('title', title, IceCap.MODE_WRITE);

      callback(ice.html, 'index.html');
   }

   /**
    * build index output.
    *
    * @returns {string} html of index output.
    * @private
    */
   _buildIndexDoc()
   {
      if (!this._config.index) { return 'Please create README.md'; }

      let indexContent;

      try
      {
         indexContent = fs.readFileSync(this._config.index, { encode: 'utf8' }).toString();
      }
      catch (err)
      {
         return 'Please create README.md';
      }

      const html = this._readTemplate('index.html');
      const ice = new IceCap(html);
      const ext = path.extname(this._config.index);

      if (['.md', '.markdown'].includes(ext))
      {
         ice.load('index', markdown(indexContent));
      }
      else
      {
         ice.load('index', indexContent);
      }

      return ice.html;
   }
}
