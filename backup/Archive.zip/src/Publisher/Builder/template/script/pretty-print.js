(function ()
{
   prettyPrint();

   var lines, i, id, el;

   lines = document.querySelectorAll('.prettyprint.linenums li[class^="L"]');

   for (i = 0; i < lines.length; i++)
   {
      lines[i].id = 'lineNumber' + (i + 1);
   }

   var matched = location.hash.match(/errorLines=([\d,]+)/);

   if (matched)
   {
      lines = matched[1].split(',');

      for (i = 0; i < lines.length; i++)
      {
         id = '#lineNumber' + lines[i];
         el = document.querySelector(id);
         el.classList.add('error-line');
      }
      return;
   }

   if (location.hash)
   {
      // ``[ ] . ' " @`` are not valid in DOM id. so must escape these.
      id = location.hash.replace(/([\[\].'"@$])/g, '\\$1');

      var line = document.querySelector(id);

      if (line) line.classList.add('active');
   }
})();
