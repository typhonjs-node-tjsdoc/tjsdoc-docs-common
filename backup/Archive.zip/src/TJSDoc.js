import 'babel-polyfill';

import fs            from 'fs';
import mainEventbus  from 'backbone-esnext-eventbus';
import EventProxy    from 'backbone-esnext-events/src/EventProxy';
import path          from 'path';
import PluginManager from 'typhonjs-plugin-manager';

import DocDB         from './common/doc/utils/DocDB.js';

/**
 * API Documentation Generator.
 *
 * @example
 * TJSDoc.generate({ source: './src', destination: './docs' });
 */
export default class TJSDoc
{
   /**
    * Generate documentation.
    *
    * @param {TJSDocConfig} config - config for generation.
    */
   static generate(config)
   {
      // Create an event proxy to automatically remove any additional bindings occurring during runtime.
      const localEventProxy = new EventProxy(mainEventbus);

      // Set `global.$$tjsdoc_version` and add an event binding to get the TJSDoc version.
      s_SET_VERSION(localEventProxy);

      const pluginManager = new PluginManager({ eventbus: mainEventbus });

      // Load the logger plugin and enable auto plugin filters which adds inclusive filters for all plugins added.
      // In addition add inclusive log trace filter to limit info and trace to just tjsdoc source.
      pluginManager.add(
      {
         name: 'typhonjs-color-logger',
         options:
         {
            autoPluginFilters: true,
            filterConfigs:
            [
               {
                  type: 'inclusive',
                  name: 'tjsdoc',
                  filterString: '(typhonjs-doc\/dist|typhonjs-doc\/src|typhonjs-doc\/test\/src)'
               }
            ]
         }
      });

      try
      {
         if (typeof config !== 'object') { throw new TypeError(`'config' is not an 'object'`); }
         if (typeof config.source === 'undefined') { throw new TypeError(`'config.source' is not defined'`); }
         if (typeof config.destination === 'undefined') { throw new TypeError(`'config.destination' is not defined'`); }

         const dirPath = path.resolve(__dirname);

         // All local source currently, but eventually some of the plugins below will be moved to separate NPM modules.
         const internalPlugins =
         [
            { name: `backbone-esnext-events/.tjsdoc/virtual/remote` },
            { name: `typhonjs-ast-walker`, options: { logAutoFilter: false } },
            { name: `typhonjs-plugin-manager/.tjsdoc/virtual/remote` },
            { name: `${dirPath}/babylon/doc/` },
            { name: `${dirPath}/babylon/parser/CommentParser.js` },
            { name: `${dirPath}/babylon/parser/BabylonParser.js` },
            { name: `${dirPath}/babylon/parser/ParamParser.js` },
            { name: `${dirPath}/babylon/utils/BabylonASTUtil.js` },
            { name: `${dirPath}/common/doc/resolver/CoreDocResolver.js` },
            { name: `${dirPath}/common/doc/utils/LintDocLogger.js` },
            { name: `${dirPath}/common/utils/ASTNodeContainer.js` },
            { name: `${dirPath}/common/utils/InvalidCodeLogger.js` },
            { name: `${dirPath}/common/utils/NamingUtil.js` },
            { name: `${dirPath}/common/utils/PathResolver.js` }
         ];

         pluginManager.addAll(internalPlugins);

         // Set default config values that are missing in the provided config.
         this._setDefaultConfig(config, dirPath);

         pluginManager.addAll(config.plugins);

         // Invoke `onStart` plugin callback to signal the start of TJSDoc processing.
         pluginManager.invokeSyncEvent('onStart');

         // Allow external plugins to modify the config file.
         config = pluginManager.invokeSyncEvent('onHandleConfig', { config }).config;

         // Ensure that `config.publisher` is defined.
         if (typeof config.publisher !== 'string') { throw new TypeError(`'config.publisher' is not a string.'`); }

         // Allow any plugins which may alter `config.publisher` a chance to do so before loading.
         pluginManager.add({ name: config.publisher });

         // Load built-in virtual plugins for external definitions.
         if (config.builtinVirtual)
         {
            pluginManager.add({ name: 'tjsdoc-plugin-external-ecmascript' });
            pluginManager.add({ name: 'tjsdoc-plugin-external-webapi' });
         }

         // Create an event binding to return a copy of the config file.
         localEventProxy.on('tjsdoc:get:config', () => { return JSON.parse(JSON.stringify(config)); });

         // Set log level.
         mainEventbus.trigger('log:set:level', config.logLevel);

         let packageObj = {};

         // Load target repo `package.json` and set event bindings for retrieving resources.
         if (config.package)
         {
            try
            {
               const packageJSON = fs.readFileSync(config.package, { encode: 'utf8' });
               packageObj = JSON.parse(packageJSON);

               // Create event bindings to return the target repo package.json as text and loaded object.
               localEventProxy.on('tjsdoc:get:package:json', () => { return packageJSON; });
               localEventProxy.on('tjsdoc:get:package:object', () => { return packageObj; });
            }
            catch (err)
            { /* nop */ }
         }

         // Set extra event data so all PluginEvent callbacks receive `ev.extra.tjsdocConfig` and `ev.extra.packageObj`.
         pluginManager.setExtraEventData(
         {
            tjsdocConfig: JSON.parse(JSON.stringify(config)),
            packageObj
         });

         // Add built-in plugins that require the final TJSDoc config.
         pluginManager.add({ name: 'tjsdoc-file-util', target: `${dirPath}/common/utils/FileUtil.js` });
         pluginManager.add({ name: 'tjsdoc-repo-util', target: `${dirPath}/common/utils/RepoUtil.js` });

         // Stores all doc / tag data and eventually is loaded into the DocDB plugin.
         let docData = [];

         // Stores all parsed AST data.
         const astData = [];

         // Create an event binding to return all ast data.
         localEventProxy.on('tjsdoc:get:ast:data', () => { return astData; }, this);

         // Generate document data.
         this._generate(config, packageObj, docData, astData, localEventProxy);

         // Invoke callback for plugins to load any virtual code.
         const virtualCode =
          mainEventbus.triggerSync('plugins:invoke:sync:event', 'onHandleVirtual', void 0, { code: [] }).code;

         // If there is any virtual code to load then process it. This is useful for dynamically loading external and
         // typedef code references.
         if (Array.isArray(virtualCode))
         {
            virtualCode.forEach((code) =>
            {
               const temp = this._traverseCode(dirPath, code, localEventProxy);

               if (temp !== null && Array.isArray(temp.docData))
               {
                  temp.docData.forEach((v) => v.builtinVirtual = true);

                  docData.push(...temp.docData.filter((v) => v.kind === 'external' || v.kind === 'typedef'));
               }
            });
         }

         // If tests are defined then generate documentation for them.
         if (config.test) { this._generateForTest(config, docData, astData, localEventProxy); }

         // Allows any plugins to modify document data.
         docData = mainEventbus.triggerSync('plugins:invoke:sync:event', 'onHandleTag', void 0, { tag: docData }).tag;

         // Create an event binding to return all ast data.
         localEventProxy.on('tjsdoc:get:doc:data', () => { return docData; }, this);

         // Optionally remove source code from all file / testFile document data.
         if (!config.includeSource)
         {
            for (const value of docData)
            {
               if (['file', 'testFile'].includes(value.kind) && 'content' in value) { value.content = ''; }
            }
         }

         // Add doc database plugin with final doc data.
         pluginManager.add({ name: 'tjsdoc-doc-database', instance: new DocDB(docData) });

         // Invoke core doc resolver which resolves various properties of the DocDB.
         mainEventbus.trigger('tjsdoc:core:doc:resolver:resolve');

         mainEventbus.trigger('log:info:raw', `publishing with: ${config.publisher}`);

         // Invoke publisher which should create the final documentation output.
         mainEventbus.trigger('tjsdoc:publisher:publish', localEventProxy);

         // If documentation linting is enabled then output any lint warnings.
         if (config.lint) { mainEventbus.trigger('tjsdoc:log:lint:doc:warnings'); }

         // Output any invalid code warnings / errors.
         mainEventbus.trigger('tjsdoc:log:invalid:code');

         // Invoke a final handler to plugins signalling that processing is complete.
         pluginManager.invokeSyncEvent('onComplete');

         // Remove any local event bindings.
         localEventProxy.destroy();

         // Must destroy all plugins and have them and pluginManager unregister from the eventbus.
         pluginManager.destroy();
      }
      catch (err)
      {
         // Determine if error occurred in an NPM module. If so attempt to load to any associated
         // package.json for the detected NPM module and post a fatal log message noting as much.
         const packageData = mainEventbus.triggerSync('tjsdoc:util:get:package:data:from:error', err);

         if (typeof packageData === 'object')
         {
            let packageMessage;

            const sep =
             '-----------------------------------------------------------------------------------------------\n';

            // Create a specific message if the module is detected as a TJSDoc module.

            /* eslint-disable prefer-template */
            if (packageData.bugs.url === 'https://github.com/typhonjs-doc/tjsdoc/issues22')
            {
               packageMessage = 'An uncaught fatal error has been detected with a TJSDoc module.\n'
                + 'Please report this error to the issues forum after checking if a similar '
                + 'report already exists:\n' + sep;
            }
            else
            {
               packageMessage = 'An uncaught fatal error has been detected with an external module.\n'
                + 'Please report this error to any issues forum after checking if a similar '
                + 'report already exists:\n' + sep;
            }
            /* eslint-enable prefer-template */

            packageMessage += `${packageData.formattedMessage}\ntjsdoc version: ${global.$$tjsdoc_version}`;

            // Log any uncaught errors as fatal.
            mainEventbus.trigger('log:fatal', packageMessage, sep, err, '\n');
         }
         else
         {
            // Log any uncaught errors as fatal.
            mainEventbus.trigger('log:fatal',
             `An unknown fatal error has occurred; tjsdoc (${global.$$tjsdoc_version}):`, err, '\n');
         }

         // Exit with error code of `1`.
         process.exit(1);
      }
   }

   /**
    * Generate documentation for target repo code.
    *
    * @param {TJSDocConfig}      config - config for generating.
    *
    * @param {object}            packageObj - The loaded target repo package.json
    *
    * @param {DocObject[]}       docData - push DocObject to this.
    *
    * @param {ASTData[]}         astData - push ast to this.
    *
    * @param {EventProxy}        eventbus - An instance of backbone-esnext-events.
    *
    * @private
    */
   static _generate(config, packageObj, docData, astData, eventbus)
   {
      // The target source directory.
      const sourceDirPath = path.resolve(config.source);

      // Create RegExp instances for any includes / excludes definitions.
      const includes = config.includes.map((v) => new RegExp(v));
      const excludes = config.excludes.map((v) => new RegExp(v));

      const packageName = packageObj.name || null;
      const mainFilePath = packageObj.main || null;

      // Walk all source
      this._walk(config.source, (filePath) =>
      {
         const relativeFilePath = path.relative(sourceDirPath, filePath);

         let match = false;

         for (const reg of includes)
         {
            if (relativeFilePath.match(reg))
            {
               match = true;
               break;
            }
         }

         if (!match) { return; }

         for (const reg of excludes)
         {
            if (relativeFilePath.match(reg)) { return; }
         }

         eventbus.trigger('log:info:raw', `parse: ${filePath}`);

         const temp = this._traverseFile(config.source, filePath, eventbus, packageName, mainFilePath);

         if (!temp) { return; }

         docData.push(...temp.docData);

         astData.push({ filePath: `source${path.sep}${relativeFilePath}`, ast: temp.ast });
      });
   }

   /**
    * Generate documentation for test code.
    *
    * @param {TJSDocConfig}   config - config for generating.
    *
    * @param {DocObject[]}    docData - push DocObject to this.
    *
    * @param {AST[]}          astData - push ast to this.
    *
    * @param {EventProxy}     eventbus - An instance of backbone-esnext-events.
    *
    * @private
    */
   static _generateForTest(config, docData, astData, eventbus)
   {
      const includes = config.test.includes.map((v) => new RegExp(v));
      const excludes = config.test.excludes.map((v) => new RegExp(v));

      const sourceDirPath = path.resolve(config.test.source);

      this._walk(config.test.source, (filePath) =>
      {
         const relativeFilePath = path.relative(sourceDirPath, filePath);

         let match = false;

         for (const reg of includes)
         {
            if (relativeFilePath.match(reg))
            {
               match = true;
               break;
            }
         }

         if (!match) { return; }

         for (const reg of excludes)
         {
            if (relativeFilePath.match(reg)) { return; }
         }

         mainEventbus.trigger('log:info:raw', `parse: ${filePath}`);

         const temp = this._traverseForTest(config.test.type, config.test.source, filePath, eventbus);

         if (!temp) { return; }

         docData.push(...temp.docData);

         astData.push({ filePath: `test${path.sep}${relativeFilePath}`, ast: temp.ast });
      });
   }

   /**
    * set default config to specified config.
    *
    * @param {TJSDocConfig}   config - specified config.
    *
    * @param {string}         dirPath - Resolved path of current directory.
    *
    * @private
    */
   static _setDefaultConfig(config, dirPath)
   {
      if (!config.publisher) { config.publisher = `${dirPath}/common/publisher/publish.js`; }

      if (!config.includes) { config.includes = ['\\.(js|es6)$']; }

      if (!config.excludes) { config.excludes = ['\\.config\\.(js|es6)$']; }

      if (!config.access) { config.access = ['public', 'protected']; }

      if (!config.index) { config.index = './README.md'; }

      if (!config.package) { config.package = './package.json'; }

      if (!config.styles) { config.styles = []; }

      if (!config.scripts) { config.scripts = []; }

      if (!config.plugins) { config.plugins = []; }

      if (!('autoPrivate' in config)) { config.autoPrivate = true; }

      if (!('unexportIdentifier' in config)) { config.unexportIdentifier = false; }

      if (!('builtinVirtual' in config)) { config.builtinVirtual = true; }

      if (!('undocumentIdentifier' in config)) { config.undocumentIdentifier = true; }

      if (!('copyPackage' in config)) { config.copyPackage = true; }

      if (!('coverage' in config)) { config.coverage = true; }

      if (!('includeSource' in config)) { config.includeSource = true; }

      if (!('lint' in config)) { config.lint = true; }

      if (!('logLevel' in config)) { config.logLevel = 'info'; }

      if (!('outputAST' in config)) { config.outputAST = false; }

      if (!('outputDocData' in config)) { config.outputDocData = false; }

      if (config.test)
      {
         if (typeof config.test.type === 'undefined') { throw new TypeError(`'config.test.type' is not defined.`); }
         if (typeof config.test.source === 'undefined') { throw new TypeError(`'config.test.source' is not defined.`); }

         if (!config.test.includes) { config.test.includes = ['\\.(js|es6)$']; }
         if (!config.test.excludes) { config.test.excludes = ['\\.config\\.(js|es6)$']; }
      }

      if (config.manual)
      {
         if (!('coverage' in config.manual)) { config.manual.coverage = true; }
      }
   }

   /**
    * walk recursive in directory.
    *
    * @param {string} dirPath - target directory path.
    * @param {function(entryPath: string)} callback - callback for find file.
    *
    * @private
    */
   static _walk(dirPath, callback)
   {
      const entries = fs.readdirSync(dirPath);

      for (const entry of entries)
      {
         const entryPath = path.resolve(dirPath, entry);
         const stat = fs.statSync(entryPath);

         if (stat.isFile())
         {
            callback(entryPath);
         }
         else if (stat.isDirectory())
         {
            this._walk(entryPath, callback);
         }
      }
   }

   /**
    * Traverse doc comments in given code.
    *
    * @param {string}      inDirPath - root directory path.
    *
    * @param {string}      code - target JavaScript code.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    *
    *
    * @returns {Object} - return document that is traversed.
    *
    * @property {DocObject[]} docData - this is contained JavaScript file.
    *
    * @property {AST} ast - this is AST of JavaScript file.
    *
    * @private
    */
   static _traverseCode(inDirPath, code, eventbus)
   {
      let ast;

      let actualCode;
      let message;

      if (typeof code === 'string') { actualCode = code; }

      // A code instance can be an object with an optional message to be displayed with any error.
      if (typeof code === 'object')
      {
         if (typeof code.code === 'string') { actualCode = code.code; }
         if (typeof code.message === 'string') { message = code.message; }
      }

      try
      {
         ast = eventbus.triggerSync('tjsdoc:parse:code', actualCode);
      }
      catch (parserError)
      {
         eventbus.trigger('tjsdoc:add:invalid:code', { code: actualCode, message, parserError });

         return null;
      }

      const factory = eventbus.triggerSync('tjsdoc:create:code:doc:factory', ast, actualCode, inDirPath);

      eventbus.trigger('ast:walker:traverse', ast,
      {
         enterNode: (node, parent) =>
         {
            try
            {
               factory.push(node, parent);
            }
            catch (fatalError)
            {
               eventbus.trigger('tjsdoc:add:invalid:code', { code: actualCode, message, node, fatalError });
            }
         }
      });

      return { docData: factory.docData, ast };
   }

   /**
    * Traverse doc comments in given file.
    *
    * @param {string}      inDirPath - root directory path.
    *
    * @param {string}      filePath - target JavaScript file path.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    *
    * @param {string}      [packageName] - npm package name of target.
    *
    * @param {string}      [mainFilePath] - npm main file path of target.
    *
    *
    * @returns {Object} - return document that is traversed.
    *
    * @property {DocObject[]} docData - this is contained JavaScript file.
    *
    * @property {AST} ast - this is AST of JavaScript file.
    *
    * @private
    */
   static _traverseFile(inDirPath, filePath, eventbus, packageName, mainFilePath)
   {
      let ast;

      try
      {
         ast = eventbus.triggerSync('tjsdoc:parse:file', filePath);
      }
      catch (parserError)
      {
         eventbus.trigger('tjsdoc:add:invalid:code', { filePath, parserError });

         return null;
      }

      const factory = eventbus.triggerSync('tjsdoc:create:file:doc:factory', ast, inDirPath, filePath, packageName,
       mainFilePath);

      eventbus.trigger('ast:walker:traverse', ast,
      {
         enterNode: (node, parent) =>
         {
            try
            {
               factory.push(node, parent);
            }
            catch (fatalError)
            {
               eventbus.trigger('tjsdoc:add:invalid:code', { filePath, node, fatalError });
            }
         }
      });

      return { docData: factory.docData, ast };
   }

   /**
    * Traverse doc comments in test code files.
    *
    * @param {string}      type - test code type.
    *
    * @param {string}      inDirPath - root directory path.
    *
    * @param {string}      filePath - target test code file path.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    *
    *
    * @returns {Object} return document info that is traversed.
    *
    * @property {DocObject[]} docData - this is contained test code.
    *
    * @property {AST} ast - this is AST of test code.
    *
    * @private
    */
   static _traverseForTest(type, inDirPath, filePath, eventbus)
   {
      let ast;

      try
      {
         ast = eventbus.triggerSync('tjsdoc:parse:file', filePath);
      }
      catch (parserError)
      {
         eventbus.trigger('tjsdoc:add:invalid:code', { filePath, parserError });

         return null;
      }

      const factory = eventbus.triggerSync('tjsdoc:create:test:doc:factory', type, ast, inDirPath, filePath);

      eventbus.trigger('ast:walker:traverse', ast,
      {
         enterNode: (node, parent) =>
         {
            try
            {
               factory.push(node, parent);
            }
            catch (fatalError)
            {
               eventbus.trigger('tjsdoc:add:invalid:code', { filePath, node, fatalError });
            }
         }
      });

      return { docData: factory.docData, ast };
   }
}

/**
 * Sets the TJSDoc version in `global.$$tjsdoc_version` and provides and event binding.
 *
 * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
 */
const s_SET_VERSION = (eventbus) =>
{
   // Find package.json
   let packageObj = null;

   try
   {
      const packageFilePath = path.resolve(__dirname, '../package.json');
      const json = fs.readFileSync(packageFilePath, { encode: 'utf8' });

      packageObj = JSON.parse(json);
   }
   catch (err)
   { /* nop */ }

   if (packageObj)
   {
      eventbus.on('tjsdoc:get:version', () => { return packageObj.version; });

      global.$$tjsdoc_version = packageObj.version;
   }
};
