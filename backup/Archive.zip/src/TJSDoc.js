import 'babel-polyfill';

import fs             from 'fs';
import path           from 'path';
import eventbus       from 'backbone-esnext-eventbus';
import PluginManager  from 'typhonjs-plugin-manager';

/**
 * API Documentation Generator.
 *
 * @example
 * let config = {source: './src', destination: './esdoc'};
 * ESDoc.generate(config, (results, config)=>{
 *   console.log(results);
 * });
 */
export default class TJSDoc
{
   /**
    * Generate documentation.
    *
    * @param {TJSDocConfig} config - config for generation.
    * @param {function(results: Object[], asts: Object[], config: TJSDocConfig)} publisher - callback for output html.
    */
   static generate(config, publisher)
   {
      if (typeof publisher !== 'function') { throw new TypeError(`'publisher' is not a 'function'`); }

      if (typeof config !== 'object') { throw new TypeError(`'config' is not an 'object'`); }
      if (typeof config.source === 'undefined') { throw new TypeError(`'config.source' is not defined'`); }
      if (typeof config.destination === 'undefined') { throw new TypeError(`'config.destination' is not defined'`); }

      s_SET_VERSION();

      this._setDefaultConfig(config);

      const dirPath = path.resolve(__dirname);

      const internalPlugins =
      [
         { name: `typhonjs-plugin-manager/.tjsdoc/virtual/remote` },
         { name: `${dirPath}/babylon/doc/` },
         { name: `${dirPath}/babylon/parser/BabylonParser.js` },
         { name: `${dirPath}/babylon/utils/BabylonASTUtil.js` },
         { name: `${dirPath}/common/parser/CommentParser.js` },
         { name: `${dirPath}/common/parser/ParamParser.js` },
         { name: `${dirPath}/common/utils/ASTNodeContainer.js` },
         { name: `${dirPath}/common/utils/ASTUtil.js` },
         { name: `${dirPath}/common/utils/InvalidCodeLogger.js` },
         { name: `${dirPath}/common/utils/Logger.js` },
         { name: `${dirPath}/common/utils/NamingUtil.js` },
         { name: `${dirPath}/common/utils/PathResolver.js` }
      ];

      config.plugins.unshift(...internalPlugins);

      if (config.builtinVirtual)
      {
         config.plugins.push({ name: `tjsdoc-plugin-external-ecmascript` });
         config.plugins.push({ name: `tjsdoc-plugin-external-webapi` });
      }

      const pluginManager = new PluginManager({ eventbus });

      pluginManager.addAll(config.plugins);

      pluginManager.invokeSyncEvent('onStart');

      config = pluginManager.invokeSyncEvent('onHandleConfig', { config }).config;

      eventbus.trigger('log:set:debug', !!config.debug);

      const includes = config.includes.map((v) => new RegExp(v));
      const excludes = config.excludes.map((v) => new RegExp(v));

      let packageName = null;
      let mainFilePath = null;

      if (config.package)
      {
         try
         {
            const packageJSON = fs.readFileSync(config.package, { encode: 'utf8' });
            const packageConfig = JSON.parse(packageJSON);

            packageName = packageConfig.name;
            mainFilePath = packageConfig.main;
         }
         catch (e)
         {
            // ignore
         }
      }

      let results = [];

      const asts = [];
      const sourceDirPath = path.resolve(config.source);

      this._walk(config.source, (filePath) =>
      {
         const relativeFilePath = path.relative(sourceDirPath, filePath);

         let match = false;

         for (const reg of includes)
         {
            if (relativeFilePath.match(reg))
            {
               match = true;
               break;
            }
         }

         if (!match) { return; }

         for (const reg of excludes)
         {
            if (relativeFilePath.match(reg)) { return; }
         }

         console.log(`parse: ${filePath}`);

         const temp = this._traverseFile(config.source, filePath, eventbus, packageName, mainFilePath);

         if (!temp) { return; }

         results.push(...temp.results);

         asts.push({ filePath: `source${path.sep}${relativeFilePath}`, ast: temp.ast });
      });

      const virtualCode =
       eventbus.triggerSync('plugins:invoke:sync:event', 'onHandleVirtual', void 0, { code: [] }).code;

      // If there is any virtual code to load then process it. This is useful for dynamically loading external and
      // typedef code references.
      if (Array.isArray(virtualCode))
      {
         virtualCode.forEach((code) =>
         {
            const temp = this._traverseCode(dirPath, code, eventbus);

            temp.results.forEach((v) => v.builtinVirtual = true);

            results.push(...temp.results.filter((v) => v.kind === 'external' || v.kind === 'typedef'));
         });
      }

      if (config.test) { this._generateForTest(config, results, asts, eventbus); }

      results = eventbus.triggerSync('plugins:invoke:sync:event', 'onHandleTag', void 0, { tag: results }).tag;

      try
      {
         publisher(results, asts, config);
      }
      catch (e)
      {
         eventbus.trigger('log:code:showError', e);

         process.exit(1);
      }

      pluginManager.invokeSyncEvent('onComplete');

      // Must destroy all plugins and have them and pluginManager unregister from the eventbus.
      pluginManager.destroy();
   }

   /**
    * Generate document from test code.
    *
    * @param {TJSDocConfig} config - config for generating.
    * @param {DocObject[]} results - push DocObject to this.
    * @param {AST[]} asts - push ast to this.
    * @param {Events} eventbus - An instance of backbone-esnext-events.
    *
    * @private
    */
   static _generateForTest(config, results, asts, eventbus)
   {
      const includes = config.test.includes.map((v) => new RegExp(v));
      const excludes = config.test.excludes.map((v) => new RegExp(v));

      const sourceDirPath = path.resolve(config.test.source);

      this._walk(config.test.source, (filePath) =>
      {
         const relativeFilePath = path.relative(sourceDirPath, filePath);

         let match = false;

         for (const reg of includes)
         {
            if (relativeFilePath.match(reg))
            {
               match = true;
               break;
            }
         }

         if (!match) { return; }

         for (const reg of excludes)
         {
            if (relativeFilePath.match(reg)) { return; }
         }

         console.log(`parse: ${filePath}`);

         const temp = this._traverseForTest(config.test.type, config.test.source, filePath, eventbus);

         if (!temp) { return; }

         results.push(...temp.results);

         asts.push({ filePath: `test${path.sep}${relativeFilePath}`, ast: temp.ast });
      });
   }

   /**
    * set default config to specified config.
    *
    * @param {TJSDocConfig} config - specified config.
    *
    * @private
    */
   static _setDefaultConfig(config)
   {
      if (!config.includes) { config.includes = ['\\.(js|es6)$']; }

      if (!config.excludes) { config.excludes = ['\\.config\\.(js|es6)$']; }

      if (!config.access) { config.access = ['public', 'protected']; }

      if (!('autoPrivate' in config)) { config.autoPrivate = true; }

      if (!('unexportIdentifier' in config)) { config.unexportIdentifier = false; }

      if (!('builtinVirtual' in config)) { config.builtinVirtual = true; }

      if (!('undocumentIdentifier' in config)) { config.undocumentIdentifier = true; }

      if (!('coverage' in config)) { config.coverage = true; }

      if (!('includeSource' in config)) { config.includeSource = true; }

      if (!('lint' in config)) { config.lint = true; }

      if (!config.index) { config.index = './README.md'; }

      if (!config.package) { config.package = './package.json'; }

      if (!config.styles) { config.styles = []; }

      if (!config.scripts) { config.scripts = []; }

      if (!config.plugins) { config.plugins = []; }

      if (config.test)
      {
         if (typeof config.test.type === 'undefined') { throw new TypeError(`'config.test.type' is not defined.`); }
         if (typeof config.test.source === 'undefined') { throw new TypeError(`'config.test.source' is not defined.`); }

         if (!config.test.includes) { config.test.includes = ['\\.(js|es6)$']; }
         if (!config.test.excludes) { config.test.excludes = ['\\.config\\.(js|es6)$']; }
      }

      if (config.manual)
      {
         if (!('coverage' in config.manual)) { config.manual.coverage = true; }
      }
   }

   /**
    * walk recursive in directory.
    *
    * @param {string} dirPath - target directory path.
    * @param {function(entryPath: string)} callback - callback for find file.
    *
    * @private
    */
   static _walk(dirPath, callback)
   {
      const entries = fs.readdirSync(dirPath);

      for (const entry of entries)
      {
         const entryPath = path.resolve(dirPath, entry);
         const stat = fs.statSync(entryPath);

         if (stat.isFile())
         {
            callback(entryPath);
         }
         else if (stat.isDirectory())
         {
            this._walk(entryPath, callback);
         }
      }
   }

   /**
    * traverse doc comment in JavaScript code.
    *
    * @param {string} inDirPath - root directory path.
    * @param {string} code - target JavaScript code.
    * @param {Events} eventbus - An instance of backbone-esnext-events.
    *
    * @returns {Object} - return document that is traversed.
    * @property {DocObject[]} results - this is contained JavaScript file.
    * @property {AST} ast - this is AST of JavaScript file.
    *
    * @private
    */
   static _traverseCode(inDirPath, code, eventbus)
   {
      let ast;

      try
      {
         ast = eventbus.triggerSync('parse:code', code);
      }
      catch (e)
      {
         eventbus.trigger('log:code:show', code, e);
         return null;
      }

      const factory = eventbus.triggerSync('tjsdoc:create:code:doc:factory', ast, code, inDirPath);

      eventbus.trigger('ast:walker:traverse', ast, (node, parent) =>
      {
         try
         {
            factory.push(node, parent);
         }
         catch (e)
         {
            eventbus.trigger('log:code:show', code, node);
            throw e;
         }
      });

      return { results: factory.results, ast };
   }

   /**
    * traverse doc comment in JavaScript file.
    *
    * @param {string} inDirPath - root directory path.
    * @param {string} filePath - target JavaScript file path.
    * @param {Events} eventbus - An instance of backbone-esnext-events.
    * @param {string} [packageName] - npm package name of target.
    * @param {string} [mainFilePath] - npm main file path of target.
    *
    * @returns {Object} - return document that is traversed.
    * @property {DocObject[]} results - this is contained JavaScript file.
    * @property {AST} ast - this is AST of JavaScript file.
    *
    * @private
    */
   static _traverseFile(inDirPath, filePath, eventbus, packageName, mainFilePath)
   {
      eventbus.trigger('log:i', `parsing: ${filePath}`);

      let ast;

      try
      {
         ast = eventbus.triggerSync('parse:file', filePath);
      }
      catch (e)
      {
         eventbus.trigger('log:code:show:file', filePath, e);
         return null;
      }

      const factory = eventbus.triggerSync('tjsdoc:create:file:doc:factory', ast, inDirPath, filePath, packageName,
       mainFilePath);

      eventbus.trigger('ast:walker:traverse', ast, (node, parent) =>
      {
         try
         {
            factory.push(node, parent);
         }
         catch (e)
         {
            eventbus.trigger('log:code:show', filePath, node);
            throw e;
         }
      });

      return { results: factory.results, ast };
   }

   /**
    * traverse doc comment in test code file.
    *
    * @param {string} type - test code type.
    * @param {string} inDirPath - root directory path.
    * @param {string} filePath - target test code file path.
    * @param {Events} eventbus - An instance of backbone-esnext-events.
    *
    * @returns {Object} return document info that is traversed.
    * @property {DocObject[]} results - this is contained test code.
    * @property {AST} ast - this is AST of test code.
    *
    * @private
    */
   static _traverseForTest(type, inDirPath, filePath, eventbus)
   {
      let ast;

      try
      {
         ast = eventbus.triggerSync('parse:file', filePath);
      }
      catch (e)
      {
         eventbus.trigger('log:code:show:file', filePath, e);

         return null;
      }

      const factory = eventbus.triggerSync('tjsdoc:create:test:doc:factory', type, ast, inDirPath, filePath);

      eventbus.trigger('ast:walker:traverse', ast, (node, parent) =>
      {
         try
         {
            factory.push(node, parent);
         }
         catch (e)
         {
            eventbus.trigger('log:code:show', filePath, node);

            throw e;
         }
      });

      return { results: factory.results, ast };
   }
}

const s_SET_VERSION = () =>
{
   // Find package.json
   let packageObj = null;

   try
   {
      const packageFilePath = path.resolve(__dirname, '../package.json');
      const json = fs.readFileSync(packageFilePath, { encode: 'utf8' });

      packageObj = JSON.parse(json);
   }
   catch (err)
   { /* nop */ }

   if (packageObj)
   {
      global.$$tjsdoc_version = packageObj.version;
   }
};
