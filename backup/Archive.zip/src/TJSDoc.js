import 'babel-polyfill';

import fs                           from 'fs-extra';
import eventbus                     from 'backbone-esnext-eventbus';
import EventProxy                   from 'backbone-esnext-events/src/EventProxy';
import path                         from 'path';
import PluginManager                from 'typhonjs-plugin-manager';

import createRepoEventBindings      from './common/events/createRepoEventBindings.js';
import createUtilityEventBindings   from './common/events/createUtilityEventBindings.js';
import DocDB                        from './common/doc/db/DocDB.js';

/**
 * API Documentation Generator.
 *
 * @example
 * TJSDoc.generate({ source: './src', destination: './docs' });
 */
export default class TJSDoc
{
   /**
    * Generate documentation.
    *
    * @param {TJSDocConfig} config - config for generation.
    */
   static generate(config)
   {
      if (typeof config !== 'object') { throw new TypeError(`'config' is not an 'object'`); }
      if (typeof config.source === 'undefined') { throw new TypeError(`'config.source' is not defined'`); }
      if (typeof config.destination === 'undefined') { throw new TypeError(`'config.destination' is not defined'`); }

      // Create an event proxy to automatically remove any additional bindings occuring during runtime.
      const localEventProxy = new EventProxy(eventbus);

      s_SET_VERSION(localEventProxy);

      const dirPath = path.resolve(__dirname);

      this._setDefaultConfig(config, dirPath);

      if (typeof config.publisher !== 'string') { throw new TypeError(`'config.publisher' is not a string.'`); }

      const internalPlugins =
      [
         { name: `typhonjs-plugin-manager/.tjsdoc/virtual/remote` },
         { name: `${dirPath}/babylon/doc/` },
         { name: `${dirPath}/babylon/parser/CommentParser.js` },
         { name: `${dirPath}/babylon/parser/BabylonParser.js` },
         { name: `${dirPath}/babylon/parser/ParamParser.js` },
         { name: `${dirPath}/babylon/utils/BabylonASTUtil.js` },
         { name: `${dirPath}/common/utils/ASTNodeContainer.js` },
         { name: `${dirPath}/common/utils/ASTUtil.js` },
         { name: `${dirPath}/common/utils/InvalidCodeLogger.js` },
         { name: `${dirPath}/common/utils/Logger.js` },
         { name: `${dirPath}/common/utils/NamingUtil.js` },
         { name: `${dirPath}/common/utils/PathResolver.js` },
         { name: config.publisher }
      ];

      config.plugins.unshift(...internalPlugins);

      if (config.builtinVirtual)
      {
         config.plugins.push({ name: `tjsdoc-plugin-external-ecmascript` });
         config.plugins.push({ name: `tjsdoc-plugin-external-webapi` });
      }

      const pluginManager = new PluginManager({ eventbus });

      pluginManager.addAll(config.plugins);

      pluginManager.invokeSyncEvent('onStart');

      // Allow external plugins to modify the config file.
      config = pluginManager.invokeSyncEvent('onHandleConfig', { config }).config;

      // Create an event binding to return a copy of the config file.
      localEventProxy.on('tjsdoc:get:config', () => { return JSON.parse(JSON.stringify(config)); }, this);

      // Potentially enable debugging
      eventbus.trigger('log:set:debug', !!config.debug);

      // Create utility event bindings for actions such as file copying and writing.
      createUtilityEventBindings(localEventProxy, config);

      const includes = config.includes.map((v) => new RegExp(v));
      const excludes = config.excludes.map((v) => new RegExp(v));

      let packageObj = {};
      let packageName = null;
      let mainFilePath = null;

      if (config.package)
      {
         try
         {
            const packageJSON = fs.readFileSync(config.package, { encode: 'utf8' });
            packageObj = JSON.parse(packageJSON);

            packageName = packageObj.name;
            mainFilePath = packageObj.main;

            // Create an event binding to return a copy of the config file.
            localEventProxy.on('tjsdoc:get:package:json', () => { return packageJSON; }, this);
            localEventProxy.on('tjsdoc:get:package:object', () => { return packageObj; }, this);
         }
         catch (err)
         { /* nop */ }
      }

      createRepoEventBindings(localEventProxy, config, packageObj);

      let docData = [];

      const astData = [];
      const sourceDirPath = path.resolve(config.source);

      // Create an event binding to return all ast data.
      localEventProxy.on('tjsdoc:get:ast:data', () => { return astData; }, this);

      this._walk(config.source, (filePath) =>
      {
         const relativeFilePath = path.relative(sourceDirPath, filePath);

         let match = false;

         for (const reg of includes)
         {
            if (relativeFilePath.match(reg))
            {
               match = true;
               break;
            }
         }

         if (!match) { return; }

         for (const reg of excludes)
         {
            if (relativeFilePath.match(reg)) { return; }
         }

         console.log(`parse: ${filePath}`);

         const temp = this._traverseFile(config.source, filePath, eventbus, packageName, mainFilePath);

         if (!temp) { return; }

         docData.push(...temp.docData);

         astData.push({ filePath: `source${path.sep}${relativeFilePath}`, ast: temp.ast });
      });

      const virtualCode =
       eventbus.triggerSync('plugins:invoke:sync:event', 'onHandleVirtual', void 0, { code: [] }).code;

      // If there is any virtual code to load then process it. This is useful for dynamically loading external and
      // typedef code references.
      if (Array.isArray(virtualCode))
      {
         virtualCode.forEach((code) =>
         {
            const temp = this._traverseCode(dirPath, code, eventbus);

            temp.docData.forEach((v) => v.builtinVirtual = true);

            docData.push(...temp.docData.filter((v) => v.kind === 'external' || v.kind === 'typedef'));
         });
      }

      if (config.test) { this._generateForTest(config, docData, astData, localEventProxy); }

      docData = eventbus.triggerSync('plugins:invoke:sync:event', 'onHandleTag', void 0, { tag: docData }).tag;

      // Create an event binding to return all ast data.
      localEventProxy.on('tjsdoc:get:doc:data', () => { return docData; }, this);

      // If option to remove source code from output then set content to '' for all doc tags.
      if (!config.includeSource)
      {
         for (const value of docData)
         {
            if (['file', 'testFile'].includes(value.kind) && 'content' in value) { value.content = ''; }
         }
      }

      // Add doc database plugin with final doc data.
      pluginManager.add({ name: 'tjsdoc-doc-database', instance: new DocDB(docData) });

      try
      {
         console.log(`publishing with: ${config.publisher}`);

         eventbus.trigger('tjsdoc:publisher:publish', localEventProxy);
      }
      catch (err)
      {
         eventbus.trigger('log:code:show:error', err);

         process.exit(1);
      }

      pluginManager.invokeSyncEvent('onComplete');

      // Remove any local bindings.
      localEventProxy.destroy();

      // Must destroy all plugins and have them and pluginManager unregister from the eventbus.
      pluginManager.destroy();
   }

   /**
    * Generate document from test code.
    *
    * @param {TJSDocConfig}   config - config for generating.
    * @param {DocObject[]}    docData - push DocObject to this.
    * @param {AST[]}          astData - push ast to this.
    * @param {EventProxy}     eventbus - An instance of backbone-esnext-events.
    *
    * @private
    */
   static _generateForTest(config, docData, astData, eventbus)
   {
      const includes = config.test.includes.map((v) => new RegExp(v));
      const excludes = config.test.excludes.map((v) => new RegExp(v));

      const sourceDirPath = path.resolve(config.test.source);

      this._walk(config.test.source, (filePath) =>
      {
         const relativeFilePath = path.relative(sourceDirPath, filePath);

         let match = false;

         for (const reg of includes)
         {
            if (relativeFilePath.match(reg))
            {
               match = true;
               break;
            }
         }

         if (!match) { return; }

         for (const reg of excludes)
         {
            if (relativeFilePath.match(reg)) { return; }
         }

         console.log(`parse: ${filePath}`);

         const temp = this._traverseForTest(config.test.type, config.test.source, filePath, eventbus);

         if (!temp) { return; }

         docData.push(...temp.docData);

         astData.push({ filePath: `test${path.sep}${relativeFilePath}`, ast: temp.ast });
      });
   }

   /**
    * set default config to specified config.
    *
    * @param {TJSDocConfig}   config - specified config.
    *
    * @param {string}         dirPath - Resolved path of current directory.
    *
    * @private
    */
   static _setDefaultConfig(config, dirPath)
   {
      if (!config.publisher) { config.publisher = `${dirPath}/common/publisher/publish.js`; }

      if (!config.includes) { config.includes = ['\\.(js|es6)$']; }

      if (!config.excludes) { config.excludes = ['\\.config\\.(js|es6)$']; }

      if (!config.access) { config.access = ['public', 'protected']; }

      if (!config.index) { config.index = './README.md'; }

      if (!config.package) { config.package = './package.json'; }

      if (!config.styles) { config.styles = []; }

      if (!config.scripts) { config.scripts = []; }

      if (!config.plugins) { config.plugins = []; }

      if (!('autoPrivate' in config)) { config.autoPrivate = true; }

      if (!('unexportIdentifier' in config)) { config.unexportIdentifier = false; }

      if (!('builtinVirtual' in config)) { config.builtinVirtual = true; }

      if (!('undocumentIdentifier' in config)) { config.undocumentIdentifier = true; }

      if (!('copyPackage' in config)) { config.copyPackage = true; }

      if (!('coverage' in config)) { config.coverage = true; }

      if (!('includeSource' in config)) { config.includeSource = true; }

      if (!('lint' in config)) { config.lint = true; }

      if (!('outputAST' in config)) { config.outputAST = false; }

      if (!('outputDocData' in config)) { config.outputDocData = false; }

      if (config.test)
      {
         if (typeof config.test.type === 'undefined') { throw new TypeError(`'config.test.type' is not defined.`); }
         if (typeof config.test.source === 'undefined') { throw new TypeError(`'config.test.source' is not defined.`); }

         if (!config.test.includes) { config.test.includes = ['\\.(js|es6)$']; }
         if (!config.test.excludes) { config.test.excludes = ['\\.config\\.(js|es6)$']; }
      }

      if (config.manual)
      {
         if (!('coverage' in config.manual)) { config.manual.coverage = true; }
      }
   }

   /**
    * walk recursive in directory.
    *
    * @param {string} dirPath - target directory path.
    * @param {function(entryPath: string)} callback - callback for find file.
    *
    * @private
    */
   static _walk(dirPath, callback)
   {
      const entries = fs.readdirSync(dirPath);

      for (const entry of entries)
      {
         const entryPath = path.resolve(dirPath, entry);
         const stat = fs.statSync(entryPath);

         if (stat.isFile())
         {
            callback(entryPath);
         }
         else if (stat.isDirectory())
         {
            this._walk(entryPath, callback);
         }
      }
   }

   /**
    * traverse doc comment in JavaScript code.
    *
    * @param {string} inDirPath - root directory path.
    * @param {string} code - target JavaScript code.
    * @param {Events} eventbus - An instance of backbone-esnext-events.
    *
    * @returns {Object} - return document that is traversed.
    * @property {DocObject[]} docData - this is contained JavaScript file.
    * @property {AST} ast - this is AST of JavaScript file.
    *
    * @private
    */
   static _traverseCode(inDirPath, code, eventbus)
   {
      let ast;

      try
      {
         ast = eventbus.triggerSync('parse:code', code);
      }
      catch (err)
      {
         eventbus.trigger('log:code:show', code, err);
         return null;
      }

      const factory = eventbus.triggerSync('tjsdoc:create:code:doc:factory', ast, code, inDirPath);

      eventbus.trigger('ast:walker:traverse', ast, (node, parent) =>
      {
         try
         {
            factory.push(node, parent);
         }
         catch (err)
         {
            eventbus.trigger('log:code:show', code, node);
            throw err;
         }
      });

      return { docData: factory.docData, ast };
   }

   /**
    * traverse doc comment in JavaScript file.
    *
    * @param {string} inDirPath - root directory path.
    * @param {string} filePath - target JavaScript file path.
    * @param {Events} eventbus - An instance of backbone-esnext-events.
    * @param {string} [packageName] - npm package name of target.
    * @param {string} [mainFilePath] - npm main file path of target.
    *
    * @returns {Object} - return document that is traversed.
    * @property {DocObject[]} docData - this is contained JavaScript file.
    * @property {AST} ast - this is AST of JavaScript file.
    *
    * @private
    */
   static _traverseFile(inDirPath, filePath, eventbus, packageName, mainFilePath)
   {
      eventbus.trigger('log:i', `parsing: ${filePath}`);

      let ast;

      try
      {
         ast = eventbus.triggerSync('parse:file', filePath);
      }
      catch (err)
      {
         eventbus.trigger('log:code:show:file', filePath, err);

         return null;
      }

      const factory = eventbus.triggerSync('tjsdoc:create:file:doc:factory', ast, inDirPath, filePath, packageName,
       mainFilePath);

      eventbus.trigger('ast:walker:traverse', ast, (node, parent) =>
      {
         try
         {
            factory.push(node, parent);
         }
         catch (err)
         {
            eventbus.trigger('log:code:show', filePath, node);
            throw err;
         }
      });

      return { docData: factory.docData, ast };
   }

   /**
    * traverse doc comment in test code file.
    *
    * @param {string} type - test code type.
    * @param {string} inDirPath - root directory path.
    * @param {string} filePath - target test code file path.
    * @param {Events} eventbus - An instance of backbone-esnext-events.
    *
    * @returns {Object} return document info that is traversed.
    * @property {DocObject[]} docData - this is contained test code.
    * @property {AST} ast - this is AST of test code.
    *
    * @private
    */
   static _traverseForTest(type, inDirPath, filePath, eventbus)
   {
      let ast;

      try
      {
         ast = eventbus.triggerSync('parse:file', filePath);
      }
      catch (err)
      {
         eventbus.trigger('log:code:show:file', filePath, err);

         return null;
      }

      const factory = eventbus.triggerSync('tjsdoc:create:test:doc:factory', type, ast, inDirPath, filePath);

      eventbus.trigger('ast:walker:traverse', ast, (node, parent) =>
      {
         try
         {
            factory.push(node, parent);
         }
         catch (err)
         {
            eventbus.trigger('log:code:show', filePath, node);

            throw err;
         }
      });

      return { docData: factory.docData, ast };
   }
}

/**
 * Sets the TJSDoc version in `global.$$tjsdoc_version` and provides and event binding.
 *
 * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
 */
const s_SET_VERSION = (eventbus) =>
{
   // Find package.json
   let packageObj = null;

   try
   {
      const packageFilePath = path.resolve(__dirname, '../package.json');
      const json = fs.readFileSync(packageFilePath, { encode: 'utf8' });

      packageObj = JSON.parse(json);
   }
   catch (err)
   { /* nop */ }

   if (packageObj)
   {
      eventbus.on('tjsdoc:get:version', () => { return packageObj.version; });

      global.$$tjsdoc_version = packageObj.version;
   }
};
