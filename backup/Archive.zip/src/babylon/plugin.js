import path from 'path';

/**
 * Adds all Babylon runtime plugins.
 *
 * @param {PluginEvent} ev - The plugin event.
 *
 * @ignore
 */
export function onPluginLoad(ev)
{
   const eventbus = ev.eventbus;
   const dirPath = path.resolve(__dirname);

   eventbus.trigger('plugins:add', { name: 'typhonjs-ast-walker', options: { logAutoFilter: false } });
   eventbus.trigger('plugins:add', { name: 'tjsdoc-common-runtime', target: `${dirPath}/../common/` });
   eventbus.trigger('plugins:add', { name: `${dirPath}/doc/` });
   eventbus.trigger('plugins:add', { name: `${dirPath}/parser/CommentParser.js` });
   eventbus.trigger('plugins:add', { name: `${dirPath}/parser/BabylonParser.js` });
   eventbus.trigger('plugins:add', { name: `${dirPath}/parser/ParamParser.js` });
   eventbus.trigger('plugins:add', { name: `${dirPath}/utils/BabylonASTUtil.js` });
}
