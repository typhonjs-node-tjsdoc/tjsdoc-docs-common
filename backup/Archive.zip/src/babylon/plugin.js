import path from 'path';

import ConfigData from '../common/ConfigData.js';

/**
 * Adds all Babylon runtime plugins.
 *
 * @param {PluginEvent} ev - The plugin event.
 *
 * @ignore
 */
export function onPluginLoad(ev)
{
   const eventbus = ev.eventbus;
   const dirPath = path.resolve(__dirname);

   eventbus.trigger('plugins:add', { name: 'typhonjs-ast-walker', options: { logAutoFilter: false } });
   eventbus.trigger('plugins:add', { name: 'tjsdoc-common-runtime', target: `${dirPath}/../common/` });
   eventbus.trigger('plugins:add', { name: `${dirPath}/doc/` });
   eventbus.trigger('plugins:add', { name: `${dirPath}/parser/CommentParser.js` });
   eventbus.trigger('plugins:add', { name: `${dirPath}/parser/BabylonParser.js` });
   eventbus.trigger('plugins:add', { name: `${dirPath}/parser/ParamParser.js` });
   eventbus.trigger('plugins:add', { name: `${dirPath}/utils/BabylonASTUtil.js` });

   // TODO: Change to using typhonjs-config-resolver when published on NPM
   // Adds an instance of typhonjs-config-resolver with overridden common TJSDoc config resolver data for usage with
   // Babylon / JS source code.
   eventbus.trigger('plugins:add', { name: 'tjsdoc-config-resolver',
    target: `${dirPath}/../common/utils/ConfigResolver.js`, options:
   {
      eventPrepend: 'tjsdoc',

      resolverData: ConfigData.createResolverData(ev.eventbus,
      {
         defaultValues:
         {
            'includes': ['\\.(js|jsx|jsm)$'],
            'pathExtensions': ['.js', '.jsx', '.jsm'],
            'test.includes': ['\\.(js|jsx|jsm)$']
         }
      })
   } });
}
