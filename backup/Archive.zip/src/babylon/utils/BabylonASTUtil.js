import babelGenerator from 'babel-generator';

/**
 * Utility for AST.
 */
export default class BabylonASTUtil
{
   /**
    * create VariableDeclaration node which has NewExpression.
    *
    * @param {string} name - variable name.
    * @param {string} className - class name.
    * @param {Object} loc - location.
    *
    * @returns {ASTNode} created node.
    */
   static createVariableDeclarationAndNewExpressionNode(name, className, loc)
   {
      const node = {
         type: 'VariableDeclaration',
         kind: 'let',
         loc,
         declarations:
         [
            {
               type: 'VariableDeclarator',
               id: { type: 'Identifier', name },
               init: { type: 'NewExpression', callee: { type: 'Identifier', name: className } }
            }
         ]
      };

      return node;
   }

   /**
    * find ClassDeclaration node.
    *
    * @param {string} name - class name.
    * @param {AST} ast - find in this ast.
    *
    * @returns {ASTNode|null} found ast node.
    */
   static findClassDeclarationNode(name, ast)
   {
      if (!name) { return null; }

      for (const node of ast.program.body)
      {
         if (node.type === 'ClassDeclaration' && node.id.name === name) { return node; }
      }

      return null;
   }

   /**
    * find FunctionDeclaration node.
    *
    * @param {string} name - function name.
    * @param {AST} ast - find in this ast.
    *
    * @returns {ASTNode|null} found ast node.
    */
   static findFunctionDeclarationNode(name, ast)
   {
      if (!name) { return null; }

      for (const node of ast.program.body)
      {
         if (node.type === 'FunctionDeclaration' && node.id.name === name) { return node; }
      }

      return null;
   }

   /**
    * Finds any attached decorators
    *
    * @param {ASTNode}  node - An AST node.
    *
    * @returns {Array<Decorator>|undefined}
    */
   static findDecorators(node)
   {
      if (!node.decorators) { return; }

      const decorators = [];

      for (const decorator of node.decorators)
      {
         const value = {};

         switch (decorator.expression.type)
         {
            case 'Identifier':
               value.name = decorator.expression.name;
               value.arguments = null;
               break;

            case 'CallExpression':
               value.name = decorator.expression.callee.name;
               value.arguments = babelGenerator(decorator.expression).code.replace(/^[^(]+/, '');
               break;

            default:
               throw new Error(`unknown decorator expression type: ${decorator.expression.type}`);
         }

         decorators.push(value);
      }

      return decorators;
   }

   /**
    * Finds the start line number for an AST node.
    *
    * @param {ASTNode}  node - An AST node.
    *
    * @returns {number|undefined}
    */
   static findLineNumberStart(node)
   {
      let number;

      if (node.loc) { number = node.loc.start.line; }

      return number;
   }

   /**
    * Determines the import style of the given node from it's parent node.
    *
    * @param {ASTNode}  node - An AST node.
    * @param {string}   name - Name of the doc tag.
    *
    * @returns {string|null}
    */
   static findImportStyle(node, name)
   {
      let parent = node.parent;

      let importStyle = null;

      while (parent)
      {
         if (parent.type === 'ExportDefaultDeclaration')
         {
            importStyle = name;

            break;
         }
         else if (parent.type === 'ExportNamedDeclaration')
         {
            importStyle = `{${name}}`;

            break;
         }
         parent = parent.parent;
      }

      return importStyle;
   }

   /**
    * Finds any parent export nodes.
    *
    * @param {ASTNode}  node - An AST node.
    *
    * @returns {boolean}
    */
   static findParentExport(node)
   {
      let parent = node.parent;

      let exported = false;

      while (parent)
      {
         if (parent.type === 'ExportDefaultDeclaration')
         {
            exported = true;
         }
         else if (parent.type === 'ExportNamedDeclaration')
         {
            exported = true;
         }

         parent = parent.parent;
      }

      return exported;
   }

   /**
    * find file path in import declaration by name.
    * e.g. can find ``./foo/bar.js`` from ``import Bar from './foo/bar.js'`` by ``Bar``.
    *
    * @param {AST} ast - target AST.
    * @param {string} name - identifier name.
    *
    * @returns {string|null} file path.
    */
   static findPathInImportDeclaration(ast, name)
   {
      let path = null;

      if (eventbus === null || typeof eventbus === 'undefined')
      {
         throw new ReferenceError('eventbus is currently not defined.');
      }

      eventbus.trigger('ast:walker:traverse', ast, (node) =>
      {
         if (node.type !== 'ImportDeclaration') { return; }

         for (const spec of node.specifiers)
         {
            const localName = spec.local.name;
            if (localName === name)
            {
               path = node.source.value;
               return null;  // Quit traversal
            }
         }
      });

      return path;
   }

   /**
    * find VariableDeclaration node which has NewExpression.
    *
    * @param {string} name - variable name.
    * @param {AST} ast - find in this ast.
    *
    * @returns {ASTNode|null} found ast node.
    */
   static findVariableDeclarationAndNewExpressionNode(name, ast)
   {
      if (!name) { return null; }

      for (const node of ast.program.body)
      {
         if (node.type === 'VariableDeclaration' && node.declarations[0].init &&
          node.declarations[0].init.type === 'NewExpression' && node.declarations[0].id.name === name)
         {
            return node;
         }
      }

      return null;
   }

   /**
    * find VariableDeclaration node.
    *
    * @param {string} name - variable name.
    * @param {AST} ast - find in this ast.
    *
    * @returns {ASTNode|null} found ast node.
    */
   static findVariableDeclarationNode(name, ast)
   {
      if (!name) { return null; }

      for (const node of ast.program.body)
      {
         if (node.type === 'VariableDeclaration' && node.declarations[0].id.name === name) { return node; }
      }

      return null;
   }

   /**
    * flatten member expression property name.
    * if node structure is [foo [bar [baz [this] ] ] ], flatten is ``this.baz.bar.foo``
    *
    * @param {ASTNode} node - target member expression node.
    *
    * @returns {string} flatten property.
    */
   static flattenMemberExpression(node)
   {
      const results = [];
      let target = node;

      while (target)
      {
         if (target.type === 'ThisExpression')
         {
            results.push('this');
            break;
         }
         else if (target.type === 'Identifier')
         {
            results.push(target.name);
            break;
         }
         else
         {
            results.push(target.property.name);
            target = target.object;
         }
      }

      return results.reverse().join('.');
   }

   /**
    * Get variable names from method arguments.
    *
    * @param {ASTNode} node - target node.
    *
    * @returns {string[]} variable names.
    */
   static getMethodParamsFromNode(node)
   {
      let params;

      switch (node.type)
      {
         case 'FunctionExpression':
         case 'FunctionDeclaration':
            params = node.params || [];
            break;

         case 'ClassMethod':
            params = node.params || [];
            break;

         case 'ArrowFunctionExpression':
            params = node.params || [];
            break;

         default:
            throw new Error(`unknown node type. type = ${node.type}`);
      }

      const result = [];

      for (const param of params)
      {
         switch (param.type)
         {
            case 'Identifier':
               result.push(param.name);
               break;

            case 'AssignmentPattern':
               if (param.left.type === 'Identifier')
               {
                  result.push(param.left.name);
               }
               else if (param.left.type === 'ObjectPattern')
               {
                  result.push('*');
               }
               break;

            case 'RestElement':
               result.push(param.argument.name);
               break;

            case 'ObjectPattern':
               result.push('*');
               break;

            case 'ArrayPattern':
               result.push('*');
               break;

            default:
               throw new Error(`unknown param type: ${param.type}`);
         }
      }

      return result;
   }

   /**
    * sanitize node. change node type to `Identifier` and empty comment.
    *
    * @param {ASTNode} node - target node.
    */
   static sanitize(node)
   {
      if (!node) { return; }

      node.type = 'Identifier';
      node.name = '_';
      node.leadingComments = [];
      node.trailingComments = [];
   }
}

let eventbus = void 0;

/**
 * Wires up BabylonASTUtil on the plugin eventbus and stores it in a local module scope variable.
 *
 * @param {PluginEvent} ev - The plugin event.
 *
 * @ignore
 */
export function onPluginLoad(ev)
{
   eventbus = ev.eventbus;

   eventbus.on('tjsdoc:ast:create:variable:declaration:new:expression',
    BabylonASTUtil.createVariableDeclarationAndNewExpressionNode);

   eventbus.on('tjsdoc:ast:create:class:declaration', BabylonASTUtil.findClassDeclarationNode);

   eventbus.on('tjsdoc:ast:find:class:declaration', BabylonASTUtil.findClassDeclarationNode);

   eventbus.on('tjsdoc:ast:find:decorators', BabylonASTUtil.findDecorators);

   eventbus.on('tjsdoc:ast:find:function:declaration', BabylonASTUtil.findFunctionDeclarationNode);

   eventbus.on('tjsdoc:ast:find:import:style', BabylonASTUtil.findImportStyle);

   eventbus.on('tjsdoc:ast:find:line:number:start', BabylonASTUtil.findLineNumberStart);

   eventbus.on('tjsdoc:ast:find:parent:export', BabylonASTUtil.findParentExport);

   eventbus.on('tjsdoc:ast:find:path:import:declaration', BabylonASTUtil.findPathInImportDeclaration);

   eventbus.on('tjsdoc:ast:find:variable:declaration', BabylonASTUtil.findVariableDeclarationNode);

   eventbus.on('tjsdoc:ast:find:variable:declaration:new:expression',
    BabylonASTUtil.findVariableDeclarationAndNewExpressionNode);

   eventbus.on('tjsdoc:ast:flatten:member:expression', BabylonASTUtil.flattenMemberExpression);

   eventbus.on('tjsdoc:ast:get:method:params:from:node', BabylonASTUtil.getMethodParamsFromNode);

   eventbus.on('tjsdoc:ast:node:sanitize', BabylonASTUtil.sanitize);
}

/**
 * Removes the reference to the global eventbus.
 *
 * @ignore
 */
export function onPluginUnload()
{
   eventbus = void 0;
}
