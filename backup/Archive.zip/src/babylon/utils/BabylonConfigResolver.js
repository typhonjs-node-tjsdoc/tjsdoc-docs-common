import ConfigResolver   from '../../common/utils/ConfigResolver.js';

import ConfigData       from '../../common/ConfigData.js';

/**
 * Provides any Babylon / ES Module config overrides for setting default config values.
 *
 * @inheritdoc
 */
class BabylonConfigResolver extends ConfigResolver
{
   /**
    * Instantiate BabylonConfigResolver overwriting common default values specific to the Babylon runtime.
    *
    * @param {EventProxy}  eventbus - The plugin eventbus proxy.
    */
   constructor(eventbus)
   {
      super(Object.assign({}, ConfigData.defaultValues(eventbus),
      {
         'includes': ['\\.(js|jsx|jsm)$'],
         'pathExtensions': ['.js', '.jsx', '.jsm'],
         'test.includes': ['\\.(js|jsx|jsm)$']
      }), ConfigData.preValidate(eventbus), ConfigData.postValidate(eventbus), ConfigData.upgradeMergeSet(), eventbus);
   }
}

/**
 * Wires up BabylonConfigResolver on the plugin eventbus. The following event bindings are available:
 *
 * `tjsdoc:config:resolve`: Resolves any config extension and sets missing default config values.
 *
 * @param {PluginEvent} ev - The plugin event.
 */
export function onPluginLoad(ev)
{
   const eventbus = ev.eventbus;

   const resolver = new BabylonConfigResolver(eventbus);

   eventbus.on('tjsdoc:config:resolve', resolver.resolve, resolver);
   eventbus.on('tjsdoc:config:validate', resolver.postValidate, resolver);
}
