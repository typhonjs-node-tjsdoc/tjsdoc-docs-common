import ConfigResolver from '../../common/utils/ConfigResolver.js';

/**
 * Provides any Babylon / ES Module config overrides for setting default config values.
 *
 * @inheritdoc
 */
class BabylonConfigResolver extends ConfigResolver
{
   /**
    * Instantiate BabylonConfigResolver
    *
    * @param {EventProxy}  eventbus - The plugin eventbus proxy.
    */
   constructor(eventbus)
   {
      super(eventbus);
   }

   /**
    * @inheritdoc
    * @override
    */
   setDefaultValues(config)
   {
      super.setDefaultValues(config);

      if (!config.includes) { config.includes = ['\\.(js|jsx|jsm)$']; }

      if (!config.pathExtensions) { config.pathExtensions = ['.js', '.jsx', '.jsm']; }

      if (config.test)
      {
         if (!config.test.includes) { config.test.includes = ['\\.(js|jsx|jsm)$']; }
      }
   }
}

/**
 * Wires up BabylonConfigResolver on the plugin eventbus. The following event bindings are available:
 *
 * `tjsdoc:config:resolve`: Resolves any config extension and sets missing default config values.
 *
 * @param {PluginEvent} ev - The plugin event.
 */
export function onPluginLoad(ev)
{
   const eventbus = ev.eventbus;

   const resolver = new BabylonConfigResolver(eventbus);

   eventbus.on('tjsdoc:config:resolve', resolver.resolve, resolver);
   eventbus.on('tjsdoc:config:validate', resolver.validate, resolver);
}
