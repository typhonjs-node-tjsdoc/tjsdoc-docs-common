import eventbus               from 'backbone-esnext-eventbus';

import AbstractAssignmentDoc  from '../../common/doc/abstract/AbstractAssignmentDoc.js';

/**
 * Doc Class for Assignment AST node.
 */
export default class AssignmentDoc extends AbstractAssignmentDoc
{
   /**
    * take out self name from self node.
    */
   _$name()
   {
      this._value.name = eventbus.triggerSync('ast:flatten:member:expression', this._node.left).replace(/^this\./, '');
   }
}

