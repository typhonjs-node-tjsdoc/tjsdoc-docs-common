import * as Docs        from './BabylonDocs.js';

import DocFactory       from './factory/DocFactory.js';
import TestDocFactory   from './factory/TestDocFactory.js';

export { Docs, DocFactory, TestDocFactory };

/**
 * Wires up two events to retrieve the Babylon docs on the plugin eventbus.
 *
 * 'tjsdoc:get:all:docs': Returns all Babylon docs.
 *
 * 'tjsdoc:get:doc': Returns a single Babylon doc by name.
 *
 * @param {PluginEvent} ev - The plugin event.
 *
 * @ignore
 */
export function onPluginLoad(ev)
{
   const eventbus = ev.eventbus;

   eventbus.on('tjsdoc:create:code:doc:factory', (ast, code, dirPath) =>
   {
      if (typeof ast !== 'object')
      {
         throw new TypeError(`'tjsdoc:create:code:doc:factory' - 'ast' is not an 'object'.`);
      }

      if (typeof code !== 'string')
      {
         throw new TypeError(`'tjsdoc:create:code:doc:factory' - 'code' is not a 'string'.`);
      }

      if (typeof dirPath !== 'string')
      {
         throw new TypeError(`'tjsdoc:create:code:doc:factory' - 'dirPath' is not a 'string'.`);
      }

      const pathResolver = eventbus.triggerSync('create:path:resolver', dirPath, code);

      if (typeof pathResolver !== 'object')
      {
         throw new TypeError(`'tjsdoc:create:code:doc:factory' - Could not create 'pathResolver'.`);
      }

      return new DocFactory(ast, pathResolver, code);
   });

   eventbus.on('tjsdoc:create:file:doc:factory', (ast, dirPath, filePath, packageName, mainFilePath) =>
   {
      if (typeof ast !== 'object') { throw new TypeError(`'tjsdoc:create:file:doc:factory' - 'ast' is not an 'object'.`); }

      if (typeof dirPath !== 'string')
      {
         throw new TypeError(`'tjsdoc:create:file:doc:factory' - 'dirPath' is not a 'string'.`);
      }

      if (typeof filePath !== 'string')
      {
         throw new TypeError(`'tjsdoc:create:file:doc:factory' - 'filePath' is not a 'string'.`);
      }

      const pathResolver = eventbus.triggerSync('create:path:resolver', dirPath, filePath, packageName, mainFilePath);

      if (typeof pathResolver !== 'object')
      {
         throw new TypeError(`'tjsdoc:create:file:doc:factory' - Could not create 'pathResolver'.`);
      }

      return new DocFactory(ast, pathResolver);
   });

   eventbus.on('tjsdoc:create:test:doc:factory', (type, ast, dirPath, filePath) =>
   {
      if (typeof type !== 'string')
      {
         throw new TypeError(`'tjsdoc:create:test:doc:factory' - 'type' is not a 'string'.`);
      }

      if (typeof ast !== 'object')
      {
         throw new TypeError(`'tjsdoc:create:test:doc:factory' - 'ast' is not an 'object'.`);
      }

      if (typeof dirPath !== 'string')
      {
         throw new TypeError(`'tjsdoc:create:test:doc:factory' - 'dirPath' is not a 'string'.`);
      }

      if (typeof filePath !== 'string')
      {
         throw new TypeError(`'tjsdoc:create:test:doc:factory' - 'filePath' is not a 'string'.`);
      }

      const pathResolver = eventbus.triggerSync('create:path:resolver', dirPath, filePath);

      if (typeof pathResolver !== 'object')
      {
         throw new TypeError(`'tjsdoc:create:test:doc:factory' - Could not create 'pathResolver'.`);
      }

      return new TestDocFactory(type, ast, pathResolver);
   });

   eventbus.on('tjsdoc:get:all:docs', () => { return Docs; });

   eventbus.on('tjsdoc:get:doc', (name) =>
   {
      if (typeof name !== 'string') { throw new TypeError(`'tjsdoc:get:doc' - 'name' is not a 'string'.`); }

      if (typeof Docs[name] !== 'undefined')
      {
         throw new ReferenceError(`'tjsdoc:get:doc' - Doc not found for 'name':  '${name}'.`);
      }

      return Docs[name];
   });
}
