import eventbus                  from 'backbone-esnext-eventbus';

import AbstractClassPropertyDoc  from '../../common/doc/abstract/AbstractClassPropertyDoc.js';
import MethodDoc                 from './MethodDoc.js';

/**
 * Doc Class from ClassProperty AST node.
 */
export default class ClassPropertyDoc extends AbstractClassPropertyDoc
{
   /** take out self name from self node */
   _$name()
   {
      this._value.name = this._node.key.name;
   }

   /** borrow {@link MethodDoc#@_memberof} */
   _$memberof()
   {
      Reflect.apply(MethodDoc.prototype._$memberof, this, []);
   }

   /**
    * decide `static`.
    */
   _$static()
   {
      if ('static' in this._node)
      {
         this._value.static = this._node.static;
      }
   }

   /** if @type is not exists, guess type by using self node */
   _$type()
   {
      super._$type();

      if (this._value.type) { return; }

      this._value.type = eventbus.triggerSync('guess:type', this._node.value);
   }
}
