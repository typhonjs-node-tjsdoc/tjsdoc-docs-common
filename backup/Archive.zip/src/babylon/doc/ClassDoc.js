import eventbus            from 'backbone-esnext-eventbus';

import AbstractClassDoc    from '../../common/doc/abstract/AbstractClassDoc.js';

/**
 * Doc Class from Class Declaration AST node.
 */
export default class ClassDoc extends AbstractClassDoc
{
   /** take out self name from self node */
   _$name()
   {
      if (this._node.id)
      {
         this._value.name = this._node.id.name;
      }
      else
      {
         this._value.name = eventbus.triggerSync('filepath:to:name', this._pathResolver.filePath);
      }
   }

   /** for @extends, does not need to use this tag. */
   _$extends()
   {
      const values = this._findAllTagValues(['@extends']);

      if (values)
      {
         this._value.extends = [];

         for (const value of values)
         {
            const { typeText } = eventbus.triggerSync('parse:param:value', value,
             { type: true, name: false, desc: false });

            this._value.extends.push(typeText);
         }

         return;
      }

      if (this._node.superClass)
      {
         const node = this._node;
         const targets = [];

         let longnames = [];

         if (node.superClass.type === 'CallExpression')
         {
            targets.push(node.superClass.callee, ...node.superClass.arguments);
         }
         else
         {
            targets.push(node.superClass);
         }

         for (const target of targets)
         {
            switch (target.type)
            {
               case 'Identifier':
                  longnames.push(this._resolveLongname(target.name));
                  break;

               case 'MemberExpression':
               {
                  const fullIdentifier = eventbus.triggerSync('ast:flatten:member:expression', target);
                  const rootIdentifier = fullIdentifier.split('.')[0];
                  const rootLongname = this._resolveLongname(rootIdentifier);
                  const filePath = rootLongname.replace(/~.*/, '');

                  longnames.push(`${filePath}~${fullIdentifier}`);
                  break;
               }
            }
         }

         if (node.superClass.type === 'CallExpression')
         {
            // expression extends may have non-class, so filter only class by name rule.
            longnames = longnames.filter((v) => v.match(/^[A-Z]|^[$_][A-Z]/));

            const filePath = this._pathResolver.fileFullPath;
            const line = node.superClass.loc.start.line;
            const start = node.superClass.loc.start.column;
            const end = node.superClass.loc.end.column;

            this._value.expressionExtends = this._readSelection(filePath, line, start, end);
         }

         if (longnames.length) { this._value.extends = longnames; }
      }
   }
}
