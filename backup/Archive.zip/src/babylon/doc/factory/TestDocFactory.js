import eventbus   from 'backbone-esnext-eventbus';

import * as Docs  from '../BabylonDocs.js';

const s_ALREADY = Symbol('already');

/**
 * Test doc factory class.
 *
 * @example
 * let factory = new TestDocFactory('mocha', ast, pathResolver);
 * factory.push(node, parentNode);
 * let docData = factory.docData;
 */
export default class TestDocFactory
{
   /**
    * get unique id.
    * @returns {number} unique id.
    * @private
    */
   static _getUniqueId()
   {
      if (!this._sequence) { /** @type {number} */ this._sequence = 0; }

      return this._sequence++;
   }

   /**
    * @type {DocObject[]}
    */
   get docData()
   {
      return [...this._docData];
   }

   /**
    * create instance.
    *
    * @param {string} type - test type. now support only 'mocha'.
    * @param {AST} ast - AST of test code.
    * @param {PathResolver} pathResolver - path resolver of test code.
    */
   constructor(type, ast, pathResolver)
   {
      if (typeof type !== 'string') { throw new TypeError(`'type' is not a 'string'.`); }
      if (typeof ast !== 'object') { throw new TypeError(`'ast' is not an 'object'.`); }

      type = type.toLowerCase();

      if (type !== 'mocha') { throw new Error(`'type' is not 'mocha'. Only Mocha tests are supported.`); }

      /** @type {string} */
      this._type = type;

      /** @type {AST} */
      this._ast = ast;

      /** @type {PathResolver} */
      this._pathResolver = pathResolver;

      /** @type {DocObject[]} */
      this._docData = [];

      // file doc
      const doc = new Docs.TestFileDoc(ast, ast, pathResolver, []);

      this._docData.push(doc.value);
   }

   /**
    * push node, and factory process the node.
    *
    * @param {ASTNode} node - target node.
    * @param {ASTNode} parentNode - parent node of target node.
    */
   push(node, parentNode)
   {
      if (node[s_ALREADY]) { return; }

      node[s_ALREADY] = true;

      Reflect.defineProperty(node, 'parent', { value: parentNode });

      if (this._type === 'mocha') { this._pushForMocha(node, parentNode); }
   }

   /**
    * push node as mocha test code.
    * @param {ASTNode} node - target node.
    * @private
    */
   _pushForMocha(node)
   {
      if (node.type !== 'ExpressionStatement') { return; }

      const expression = node.expression;

      if (expression.type !== 'CallExpression') { return; }

      if (!['describe', 'it', 'context', 'suite', 'test'].includes(expression.callee.name)) { return; }

      expression[s_ALREADY] = true;

      Reflect.defineProperty(expression, 'parent', { value: node });

      let tags = [];

      if (node.leadingComments && node.leadingComments.length)
      {
         const comment = node.leadingComments[node.leadingComments.length - 1];

         tags = eventbus.triggerSync('tjsdoc:parse:comment', comment);
      }

      const uniqueId = this.constructor._getUniqueId();

      expression._tjsdocTestId = uniqueId;
      expression._tjsdocTestName = expression.callee.name + uniqueId;

      const testDoc = new Docs.TestDoc(this._ast, expression, this._pathResolver, tags);

      this._docData.push(testDoc.value);
   }
}
