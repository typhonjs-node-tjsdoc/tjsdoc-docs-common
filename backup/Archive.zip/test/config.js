import path from 'path';

/**
 * Defines the default runtime targets for testing against published modules.
 *
 * @type {*[]}
 */
const s_DEFAULT_TARGET =
[
   {
      name: 'babylon',
      cli: 'tjsdoc-babylon/src/TJSDocBabylonCLI.js', // TODO: This may need to be changed to 'dist' due to require.
      runtime: 'tjsdoc-babylon'
   }
];

/**
 * Defines the development runtime targets for testing against local source code.
 *
 * @type {*[]}
 */
const s_DEV_TARGET =
[
   {
      name: 'babylon',
      cli: path.resolve('./tjsdoc-babylon/src/TJSDocBabylonCLI.js'),
      runtime: path.resolve('./tjsdoc-babylon/src/TJSDocBabylon.js')
   }
];

/**
 * Defines the runtime targets for each NPM test script.
 *
 * @type {object}
 */
const targets =
{
   'dev-test': s_DEV_TARGET,
   'dev-test-coverage': s_DEV_TARGET,

   'test': s_DEFAULT_TARGET,
   'test-coverage': s_DEFAULT_TARGET
};

/**
 * Defines local test category overrides.
 *
 * @type {{config: boolean, doc: boolean, html: boolean, parser: boolean, utils: boolean}}
 */
const category =
{
   config: false,
   doc: true,
   html: false,
   parser: false,
   utils: false
};

const emptyDest = false;

const generateMain = false;

export { category, emptyDest, generateMain, targets };
