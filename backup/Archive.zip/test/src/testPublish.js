import fs         from 'fs-extra';

import DocDB      from '../../src/common/doc/utils/DocDB.js';
import publish    from '../../src/common/publisher/publish.js';

/**
 * Wires up the default publisher to plugin eventbus adding additional processing to remove the destination directory
 * prior to publishing in addition to storing a global DocDB / TaffyDB instance used during testing.
 *
 * @param {PluginEvent} ev - The plugin event.
 *
 * @ignore
 */
export function onPluginLoad(ev)
{
   const eventbus = ev.eventbus;

   eventbus.on('tjsdoc:publisher:publish', (eventbus) =>
   {
      const config = eventbus.triggerSync('tjsdoc:get:config');

      fs.removeSync(config.destination);

      publish(eventbus);

      // Create a global instance of DocDB. This must be created after publish is invoked.
      global.$$tjsdoc_db = new DocDB(eventbus.triggerSync('tjsdoc:get:doc:data'));
   });
}
