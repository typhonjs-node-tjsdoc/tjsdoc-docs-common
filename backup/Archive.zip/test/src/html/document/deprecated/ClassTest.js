import { assert, Util } from '../../../util.js';
import testConfig       from '../../../testConfig.js';

if (testConfig.category.html && testConfig.html.category.document && testConfig.html.document.category.deprecated)
{
   for (const target of testConfig.targets)
   {
      /** @test {AbstractDoc#@deprecated} */
      describe('TestDeprecatedClass:', () =>
      {
         const doc = Util.readDoc(target.name,
          'class/test/fixture/package/src/deprecated/Class.js~TestDeprecatedClass.html');

         describe('in self detail:', () =>
         {
            it('has deprecated message of self.', () =>
            {
               assert.includes(doc, '.self-detail [data-ice="deprecated"]',
                'this class was deprecated. this is deprecated.');
            });
         });

         describe('in summary:', () =>
         {
            it('has deprecated message of member and method.', () =>
            {
               Util.find(doc,
                '[data-ice="summary"] [href="class/test/fixture/package/src/deprecated/Class.js~TestDeprecatedClass.html#instance-member-p1"]',
                 (doc) =>
               {
                  doc = doc.parents('[data-ice="target"]');
                  assert.includes(doc, '[data-ice="deprecated"]', 'this member was deprecated.');
               });

               Util.find(doc,
                '[data-ice="summary"] [href="class/test/fixture/package/src/deprecated/Class.js~TestDeprecatedClass.html#instance-method-method1"]',
                 (doc) =>
               {
                  doc = doc.parents('[data-ice="target"]');
                  assert.includes(doc, '[data-ice="deprecated"]', 'this method was deprecated.');
               });
            });
         });

         describe('in details:', () =>
         {
            it('has deprecated message of member and method.', () =>
            {
               Util.find(doc, '[id="instance-member-p1"]', (doc) =>
               {
                  doc = doc.parents('[data-ice="detail"]');

                  assert.includes(doc, '[data-ice="deprecated"]', 'this member was deprecated.');
               });

               Util.find(doc, '[id="instance-method-method1"]', (doc) =>
               {
                  doc = doc.parents('[data-ice="detail"]');

                  assert.includes(doc, '[data-ice="deprecated"]', 'this method was deprecated.');
               });
            });
         });
      });
   }
}
