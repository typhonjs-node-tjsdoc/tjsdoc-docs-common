import { readDoc, assert, findParent } from './../../../util.js';
import testConfig                      from '../../../testConfig.js';

if (testConfig.category.html && testConfig.html.category.document && testConfig.html.document.category.guess)
{
   /** @test {ParamParser#guessReturn} */
   describe('TestGuessReturn', () =>
   {
      const doc = readDoc('class/src/Guess/Return.js~TestGuessReturn.html');

      describe('in summary', () =>
      {
         it('has guessed return.', () =>
         {
            findParent(doc, '[data-ice="summary"] [href$="#instance-method-method1"]', '[data-ice="target"]', (doc) =>
            {
               assert.includes(doc, null, 'public method1(): number');
            });

            findParent(doc, '[data-ice="summary"] [href$="#instance-method-method2"]', '[data-ice="target"]', (doc) =>
            {
               assert.includes(doc, null, 'public method2(): number[]');
            });

            findParent(doc, '[data-ice="summary"] [href$="#instance-method-method3"]', '[data-ice="target"]', (doc) =>
            {
               assert.includes(doc, null, 'public method3(): {"x1": number, "x2": string}');
            });

            findParent(doc, '[data-ice="summary"] [href$="#instance-method-method4"]', '[data-ice="target"]', (doc) =>
            {
               assert.includes(doc, null, 'public method4(): string');
            });

            findParent(doc, '[data-ice="summary"] [href$="#instance-method-method5"]', '[data-ice="target"]', (doc) =>
            {
               assert.includes(doc, null, 'public method5(): {"a": *, ...obj: Object}');
            });
         });
      });

      describe('in details', () =>
      {
         it('has guessed param.', () =>
         {
            findParent(doc, '[id="instance-method-method1"]', '[data-ice="detail"]', (doc) =>
            {
               assert.includes(doc, 'h3', 'public method1(): number');
            });

            findParent(doc, '[id="instance-method-method2"]', '[data-ice="detail"]', (doc) =>
            {
               assert.includes(doc, 'h3', 'public method2(): number[]');
            });

            findParent(doc, '[id="instance-method-method3"]', '[data-ice="detail"]', (doc) =>
            {
               assert.includes(doc, 'h3', 'public method3(): {"x1": number, "x2": string}');
            });

            findParent(doc, '[id="instance-method-method4"]', '[data-ice="detail"]', (doc) =>
            {
               assert.includes(doc, 'h3', 'public method4(): string');
            });

            findParent(doc, '[id="instance-method-method5"]', '[data-ice="detail"]', (doc) =>
            {
               assert.includes(doc, 'h3', 'public method5(): {"a": *, ...obj: Object}');
            });
         });
      });
   });
}
