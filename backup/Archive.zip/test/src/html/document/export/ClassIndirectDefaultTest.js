import { readDoc, assert } from './../../../util.js';
import testConfig          from '../../../testConfig.js';

if (testConfig.category.html && testConfig.html.category.document && testConfig.html.document.category.export)
{
   /**
    * @test {AbstractDoc#@_export}
    * @test {ClassDocBuilder@_buildClassDoc}
    */
   describe('test export class indirect default', () =>
   {
      it('has default import path with indirect class definition.', () =>
      {
         const doc = readDoc('class/src/export/ClassIndirectDefault.js~TestExportClassIndirectDefault.html');

         assert.includes(doc, '.header-notice [data-ice="importPath"]',
          `import TestExportClassIndirectDefault from 'esdoc-test-fixture/src/export/ClassIndirectDefault.js'`);
      });
   });
}
