import { readDoc }   from './../../../util.js';
import testConfig    from '../../../testConfig.js';

if (testConfig.category.html && testConfig.html.category.document && testConfig.html.document.category.export)
{
   /** @test {DocResolver#_resolveNecessary} */
   describe('TestExportExtendsInner', () =>
   {
      it('is documented.', () =>
      {
         readDoc('class/src/export/Extends.js~TestExportExtendsInner.html');
      });
   });
}
