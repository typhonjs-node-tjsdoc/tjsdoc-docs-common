import { readDoc, assert, find } from './../../../util.js';
import testConfig                from '../../../testConfig.js';

if (testConfig.category.html && testConfig.html.category.document && testConfig.html.document.category.ignore)
{
   /** @test {DocResolver#_resolveIgnore */
   describe('testIgnoreFunction', () =>
   {
      const doc = readDoc('function/index.html');

      it('is not documented.', () =>
      {
         assert.throws(() => find(doc, '[data-ice="summary"] [href$="#static-function-testIgnoreFunction"]', () => {}));
         assert.throws(() => find(doc, '[id="static-function-testIgnoreFunction"]', () => {}));
      });
   });
}
