import { readDoc, assert } from './../../../util.js';
import testConfig          from '../../../testConfig.js';

if (testConfig.category.html && testConfig.html.category.document && testConfig.html.document.category.example)
{
   /** @test {AbstractDoc#@example} */
   describe('TestExampleCaption', () =>
   {
      const doc = readDoc('class/src/Example/Caption.js~TestExampleCaption.html');

      describe('in self detail', () =>
      {
         it('has caption of example.', () =>
         {
            assert.includes(doc, '.self-detail [data-ice="exampleDoc"] [data-ice="exampleCaption"]', 'this is caption');
         });
      });
   });
}
