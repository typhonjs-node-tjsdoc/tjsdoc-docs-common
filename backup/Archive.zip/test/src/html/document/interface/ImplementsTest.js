import { readDoc, assert, find } from './../../../util.js';
import testConfig                from '../../../testConfig.js';

if (testConfig.category.html && testConfig.html.category.document && testConfig.html.document.category.interface)
{
   /** @test {ClassDoc#@implements} */
   describe('TestInterfaceImplements', () =>
   {
      const doc = readDoc('class/src/interface/Implements.js~TestInterfaceImplements.html');

      it('has implements.', () =>
      {
         find(doc, '.self-detail [data-ice="implements"]', (doc) =>
         {
            assert.includes(doc, 'ul', 'TestInterfaceDefinition, TestInterfaceImplementsInner');

            assert.includes(doc, 'ul a[href="class/src/interface/Definition.js~TestInterfaceDefinition.html"]',
             'TestInterfaceDefinition');

            assert.includes(doc, 'ul a[href="class/src/interface/Implements.js~TestInterfaceImplementsInner.html"]',
             'TestInterfaceImplementsInner');
         });
      });
   });
}
