import { readDoc, assert } from './../../../util.js';
import testConfig                      from '../../../testConfig.js';

if (testConfig.category.html && testConfig.html.category.document && testConfig.html.document.category.undocument)
{
   /**
    * @test {DocFactory#_traverseComments}
    * @test {AbstractDoc#@desc}
    * @test {DocResolver#_resolveUndocumentIdentifier}
    */
   describe('TestUndocumentDefinition', () =>
   {
      const doc = readDoc('class/src/Undocument/Definition.js~TestUndocumentDefinition.html');

      it('is exist', () =>
      {
         assert.includes(doc, '.self-detail [data-ice="name"]', 'TestUndocumentDefinition');
      });
   });
}
