import { assert, Util } from '../../../util.js';
import testConfig       from '../../../testConfig.js';

if (testConfig.category.html && testConfig.html.category.document && testConfig.html.document.category.access)
{
   for (const target of testConfig.targets)
   {
      /** @test {SingleDocBuilder} */
      describe('TestAccessFunction:', () =>
      {
         const doc = Util.readDoc(target.name, 'function/index.html');

         describe('in summary: ', () =>
         {
            /** @test {SingleDocBuilder#_buildSingleDoc} */
            it('has public accessor.', () =>
            {
               Util.find(doc,
                '[data-ice="summary"] [href="function/index.html#static-function-testAccessFunctionPublic"]', (doc) =>
               {
                  doc = doc.parents('[data-ice="target"]');
                  assert.includes(doc, null, 'public testAccessFunctionPublic()');
               });
            });

            /** @test {SingleDocBuilder#_buildSingleDoc} */
            it('has protected accessor.', () =>
            {
               Util.find(doc,
                '[data-ice="summary"] [href="function/index.html#static-function-testAccessFunctionProtected"]',
                 (doc) =>
               {
                  doc = doc.parents('[data-ice="target"]');
                  assert.includes(doc, null, 'protected testAccessFunctionProtected()');
               });
            });

            /** @test {SingleDocBuilder#_buildSingleDoc} */
            it('has private accessor.', () =>
            {
               Util.find(doc,
                '[data-ice="summary"] [href="function/index.html#static-function-testAccessFunctionPrivate"]', (doc) =>
               {
                  doc = doc.parents('[data-ice="target"]');
                  assert.includes(doc, null, 'private testAccessFunctionPrivate()');
               });
            });

            /** @test {SingleDocBuilder#_buildSingleDoc} */
            it('has auto private accessor.', () =>
            {
               Util.find(doc,
                '[data-ice="summary"] [href="function/index.html#static-function-_testAccessFunctionAutoPrivate"]',
                 (doc) =>
               {
                  doc = doc.parents('[data-ice="target"]');
                  assert.includes(doc, null, 'private _testAccessFunctionAutoPrivate()');
               });
            });
         });

         describe('in detail: ', () =>
         {
            /** @test {SingleDocBuilder#_buildSingleDoc} */
            it('has public accessor.', () =>
            {
               assert.includes(doc, '[data-ice="detail"] #static-function-testAccessFunctionPublic',
                'public testAccessFunctionPublic()');
            });

            /** @test {SingleDocBuilder#_buildSingleDoc} */
            it('has protected accessor.', () =>
            {
               assert.includes(doc, '[data-ice="detail"] #static-function-testAccessFunctionProtected',
                'protected testAccessFunctionProtected()');
            });

            /** @test {SingleDocBuilder#_buildSingleDoc} */
            it('has private accessor.', () =>
            {
               assert.includes(doc, '[data-ice="detail"] #static-function-testAccessFunctionPrivate',
                'private testAccessFunctionPrivate()');
            });

            /** @test {SingleDocBuilder#_buildSingleDoc} */
            it('has auto private accessor.', () =>
            {
               assert.includes(doc, '[data-ice="detail"] #static-function-_testAccessFunctionAutoPrivate',
                'private _testAccessFunctionAutoPrivate()');
            });
         });
      });
   }
}
