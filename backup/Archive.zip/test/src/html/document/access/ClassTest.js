import { assert, Util } from '../../../util.js';
import testConfig       from '../../../testConfig.js';

if (testConfig.category.html && testConfig.html.category.document && testConfig.html.document.category.access)
{
   for (const target of testConfig.targets)
   {
      /** @test {ClassDocBuilder} */
      describe('TestAccessClass:', () =>
      {
         describe('in header:', () =>
         {
            /** @test {ClassDocBuilder#_buildClassDoc} */
            it('has public accessor.', () =>
            {
               const doc = Util.readDoc(target.name,
                'class/test/fixture/package/src/access/Class.js~TestAccessClassPublic.html');

               assert.includes(doc, '.header-notice [data-ice="access"]', 'public');
            });

            /** @test {ClassDocBuilder#_buildClassDoc} */
            it('has protected accessor.', () =>
            {
               const doc = Util.readDoc(target.name,
                'class/test/fixture/package/src/access/Class.js~TestAccessClassProtected.html');

               assert.includes(doc, '.header-notice [data-ice="access"]', 'protected');
            });

            /** @test {ClassDocBuilder#_buildClassDoc} */
            it('has private accessor.', () =>
            {
               const doc = Util.readDoc(target.name,
                'class/test/fixture/package/src/access/Class.js~TestAccessClassPrivate.html');

               assert.includes(doc, '.header-notice [data-ice="access"]', 'private');
            });

            /** @test {ClassDocBuilder#_buildClassDoc} */
            it('has auto private accessor.', () =>
            {
               const doc = Util.readDoc(target.name,
                'class/test/fixture/package/src/access/Class.js~_TestAccessClassAutoPrivate.html');

               assert.includes(doc, '.header-notice [data-ice="access"]', 'private');
            });
         });
      });
   }
}
