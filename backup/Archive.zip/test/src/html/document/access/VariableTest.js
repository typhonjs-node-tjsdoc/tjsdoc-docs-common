import { assert, Util } from '../../../util.js';
import testConfig       from '../../../testConfig.js';

if (testConfig.category.html && testConfig.html.category.document && testConfig.html.document.category.access)
{
   for (const target of testConfig.targets)
   {
      /** @test {SingleDocBuilder} */
      describe('TestAccessVariable:', () =>
      {
         const doc = Util.readDoc(target.name, 'variable/index.html');

         /** @test {SingleDocBuilder#_buildSingleDoc} */
         describe('in summary: ', () =>
         {
            it('has public accessor.', () =>
            {
               Util.find(doc,
                '[data-ice="summary"] [href="variable/index.html#static-variable-testAccessVariablePublic"]', (doc) =>
               {
                  doc = doc.parents('[data-ice="target"]');
                  assert.includes(doc, null, 'public testAccessVariablePublic:');
               });
            });

            it('has protected accessor.', () =>
            {
               Util.find(doc,
                '[data-ice="summary"] [href="variable/index.html#static-variable-testAccessVariableProtected"]',
                 (doc) =>
               {
                  doc = doc.parents('[data-ice="target"]');
                  assert.includes(doc, null, 'protected testAccessVariableProtected:');
               });
            });

            it('has private accessor.', () =>
            {
               Util.find(doc,
                '[data-ice="summary"] [href="variable/index.html#static-variable-testAccessVariablePrivate"]', (doc) =>
               {
                  doc = doc.parents('[data-ice="target"]');
                  assert.includes(doc, null, 'private testAccessVariablePrivate:');
               });
            });

            it('has auto private accessor.', () =>
            {
               Util.find(doc,
                '[data-ice="summary"] [href="variable/index.html#static-variable-_testAccessVariableAutoPrivate"]',
                 (doc) =>
               {
                  doc = doc.parents('[data-ice="target"]');
                  assert.includes(doc, null, 'private _testAccessVariableAutoPrivate:');
               });
            });
         });

         /** @test {SingleDocBuilder#_buildSingleDoc} */
         describe('in detail: ', () =>
         {
            it('has public accessor.', () =>
            {
               assert.includes(doc, '[data-ice="detail"] #static-variable-testAccessVariablePublic',
                'public testAccessVariablePublic:');
            });

            it('has protected accessor.', () =>
            {
               assert.includes(doc, '[data-ice="detail"] #static-variable-testAccessVariableProtected',
                'protected testAccessVariableProtected:');
            });

            it('has private accessor.', () =>
            {
               assert.includes(doc, '[data-ice="detail"] #static-variable-testAccessVariablePrivate',
                'private testAccessVariablePrivate:');
            });

            it('has auto private accessor.', () =>
            {
               assert.includes(doc, '[data-ice="detail"] #static-variable-_testAccessVariableAutoPrivate',
                'private _testAccessVariableAutoPrivate:');
            });
         });
      });
   }
}
