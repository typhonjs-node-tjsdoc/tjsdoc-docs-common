import { readDoc, assert, findParent } from './../../../util.js';
import testConfig                      from '../../../testConfig.js';

if (testConfig.category.html && testConfig.html.category.document && testConfig.html.document.category.type)
{
   /**
    * @test {ParamParser#parseParamValue}
    * @test {ParamParser#parseParam}
    */
   describe('TestTypeOptional', () =>
   {
      const doc = readDoc('class/src/type/Optional.js~TestTypeOptional.html');

      it('has optional attribute.', () =>
      {
         findParent(doc, '[id="instance-method-method1"]', '[data-ice="detail"]', (doc) =>
         {
            assert.includes(doc, '.params [data-ice="property"]:nth-child(1)', 'optional');
         });
      });
   });
}
