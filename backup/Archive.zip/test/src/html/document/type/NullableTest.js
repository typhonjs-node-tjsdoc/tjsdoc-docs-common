import { readDoc, assert, findParent } from './../../../util.js';
import testConfig                      from '../../../testConfig.js';

if (testConfig.category.html && testConfig.html.category.document && testConfig.html.document.category.type)
{
   /**
    * @test {ParamParser#parseParamValue}
    * @test {ParamParser#parseParam}
    */
   describe('TestTypeNullable', () =>
   {
      const doc = readDoc('class/src/type/Nullable.js~TypeTestNullable.html');

      it('has nullable value.', () =>
      {
         findParent(doc, '[id="instance-method-method1"]', '[data-ice="detail"]', (doc) =>
         {
            assert.includes(doc, '.params [data-ice="property"]:nth-child(1)', 'nullable: true');
            assert.includes(doc, '.params [data-ice="property"]:nth-child(2)', 'nullable: false');
         });
      });
   });
}
