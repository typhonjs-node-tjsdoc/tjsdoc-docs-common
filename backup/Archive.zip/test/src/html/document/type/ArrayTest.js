import { readDoc, assert, findParent } from './../../../util.js';
import testConfig                      from '../../../testConfig.js';

if (testConfig.category.html && testConfig.html.category.document && testConfig.html.document.category.type)
{
   /**
    * @test {ParamParser#parseParamValue}
    * @test {ParamParser#parseParam}
    */
   describe('TestTypeArray', () =>
   {
      const doc = readDoc('class/src/type/Array.js~TestTypeArray.html');

      it('has array type.', () =>
      {
         findParent(doc, '[data-ice="summary"] [href$="#instance-method-method1"]', '[data-ice="target"]', (doc) =>
         {
            assert.includes(doc, null, 'method1(p1: number[])');
         });
      });
   });
}
