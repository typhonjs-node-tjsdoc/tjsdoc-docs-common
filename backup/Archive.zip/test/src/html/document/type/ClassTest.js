import { readDoc, assert, findParent } from './../../../util.js';
import testConfig                      from '../../../testConfig.js';

if (testConfig.category.html && testConfig.html.category.document && testConfig.html.document.category.type)
{
   /**
    * @test {ParamParser#parseParamValue}
    * @test {ParamParser#parseParam}
    */
   describe('TestTypeClass', () =>
   {
      const doc = readDoc('class/src/type/Class.js~TestTypeClass.html');

      it('has class type.', () =>
      {
         findParent(doc, '[data-ice="summary"] [href$="#instance-method-method1"]', '[data-ice="target"]', (doc) =>
         {
            assert.includes(doc, null, 'method1(p1: TestTypeClassInner)');
            assert.includes(doc, 'a[href="class/src/type/Class.js~TestTypeClassInner.html"]', 'TestTypeClassInner');
         });
      });
   });
}
