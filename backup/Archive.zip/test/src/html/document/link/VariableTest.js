import { readDoc, assert, findParent } from './../../../util.js';
import testConfig                      from '../../../testConfig.js';

if (testConfig.category.html && testConfig.html.category.document && testConfig.html.document.category.link)
{
   /** @test {DocResolver#_resolveLink} */
   describe('testLinkVariable', () =>
   {
      const doc = readDoc('variable/index.html');

      it('has link.', () =>
      {
         findParent(doc, '[id="static-variable-testLinkVariable"]', '[data-ice="detail"]', (doc) =>
         {
            assert.includes(doc, '[data-ice="description"] a[href="class/src/link/Class.js~TestLinkClass.html"]',
             'TestLinkClass');
         });
      });
   });
}
