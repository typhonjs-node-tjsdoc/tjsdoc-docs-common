import { readDoc, assert, find } from './../../../util.js';
import testConfig                from '../../../testConfig.js';

if (testConfig.category.html && testConfig.html.category.document && testConfig.html.document.category.extends)
{
   /** @test {ClassDoc#@extends} */
   describe('TestExtendsProperty', () =>
   {
      const doc = readDoc('class/src/extends/Property.js~TestExtendsProperty.html');

      it('has extends chain.', () =>
      {
         find(doc, '.self-detail [data-ice="extendsChain"]', (doc) =>
         {
            assert.includes(doc, null, 'TestExtendsPropertyPackage~obj.TestExtendsPropertyInner → TestExtendsProperty');
         });
      });
   });
}
