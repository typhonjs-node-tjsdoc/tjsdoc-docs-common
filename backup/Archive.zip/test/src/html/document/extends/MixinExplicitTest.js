import { readDoc, assert, find } from './../../../util.js';
import testConfig                from '../../../testConfig.js';

if (testConfig.category.html && testConfig.html.category.document && testConfig.html.document.category.extends)
{
   /**
    * @test {ClassDoc#@extends}
    * @test {DocResolver#_resolveNecessary}
    */
   describe('TestExtendsMixin', () =>
   {
      const doc = readDoc('class/src/extends/MixinExplicit.js~TextExplicitMixin.html');

      it('has extends chain.', () =>
      {
         find(doc, '.self-detail [data-ice="mixinExtends"]', (doc) =>
         {
            assert.includes(doc, null, 'TestExplicitMixin1, TestExplicitMixin2');

            assert.includes(doc, 'a[href="class/src/extends/MixinExplicit.js~TestExplicitMixin1.html"]',
             'TestExplicitMixin1');

            assert.includes(doc, 'a[href="class/src/extends/MixinExplicit.js~TestExplicitMixin2.html"]',
             'TestExplicitMixin2');
         });
      });
   });
}
