import { readDoc, assert, find } from './../../../util.js';
import testConfig                from '../../../testConfig.js';

if (testConfig.category.html && testConfig.html.category.document && testConfig.html.document.category.extends)
{
   /**
    * @test {ClassDoc#@extends}
    * @test {DocResolver#_resolveNecessary}
    */
   describe('TestExtendsMixin', () =>
   {
      const doc = readDoc('class/src/extends/Mixin.js~TestExtendsMixin.html');

      it('has expression extends.', () =>
      {
         find(doc, '.self-detail [data-ice="expressionExtends"]', (doc) =>
         {
            assert.includes(doc, 'pre code',
             'class TestExtendsMixin extends mixin(TestExtendsMixinInner1, TestExtendsMixinInner2)');
         });
      });

      it('has extends chain.', () =>
      {
         find(doc, '.self-detail [data-ice="mixinExtends"]', (doc) =>
         {
            assert.includes(doc, null, 'TestExtendsMixinInner1, TestExtendsMixinInner2');

            assert.includes(doc, 'a[href="class/src/extends/Mixin.js~TestExtendsMixinInner1.html"]',
             'TestExtendsMixinInner1');

            assert.includes(doc, 'a[href="class/src/extends/Mixin.js~TestExtendsMixinInner2.html"]',
             'TestExtendsMixinInner2');
         });
      });
   });
}
