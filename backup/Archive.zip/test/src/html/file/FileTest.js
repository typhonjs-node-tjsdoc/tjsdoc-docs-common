import { readDoc, assert } from './../../util.js';
import testConfig          from '../../testConfig.js';

if (testConfig.category.html && testConfig.html.category.file)
{
   /** @test {FileDocBuilder} */
   describe('test source code file', () =>
   {
      const doc = readDoc('file/src/desc/Class.js.html');

      it('has source code.', () =>
      {
         assert.includes(doc, 'body [data-ice="title"]', 'src/desc/Class.js');
         assert.includes(doc, 'code[data-ice="content"]', 'export default class TestDescClass {');
      });
   });
}
