import fs                              from 'fs';

import { readDoc, assert, findParent } from './../../util.js';
import testConfig                      from '../../testConfig.js';

if (testConfig.category.html && testConfig.html.category.coverage)
{
   /** @test {CoverageBuilder} */
   describe('test coverage', () =>
   {
      const doc = readDoc('source.html');
      const badge = fs.readFileSync('./test/fixture/dest/esdoc/badge.svg', { encoding: 'utf8' }).toString();

      it('has coverage summary', () =>
      {
         assert(badge.includes('79%'));
         assert.includes(doc, '[data-ice="coverageBadge"]', './badge.svg', 'src');
         assert.includes(doc, '[data-ice="totalCoverageCount"]', '284/356');
         assert.equal(doc.find('[data-ice="file"] [data-ice="coverage"]').length, 121);
      });

      /* eslint-disable max-statements */
      it('has coverage details', () =>
      {
         let count = 0;

         /**
          * Helper function to simplify the construction of the selector and callback method to check an expected value
          * when invoking `findParent`.
          *
          * @param {string}   filePath - Local file path to load relative to './test/fixture/dest/esdoc-access'.
          *
          * @param {*}        expect - expected value.
          */
         function test(filePath, expect)
         {
            findParent(doc, `a[href="${filePath}"]`, '[data-ice="file"]', (doc) =>
            {
               assert.includes(doc, '.coverage', expect);
               count++;
            });
         }

         test('file/src/abstract/Definition.js.html', '100 %3/3');
         test('file/src/abstract/Override.js.html', '100 %3/3');
         test('file/src/access/Class.js.html', '100 %4/4');
         test('file/src/access/Function.js.html', '100 %4/4');
         test('file/src/access/Method.js.html', '100 %5/5');
         test('file/src/access/Property.js.html#errorLines=6', '83 %5/6');
         test('file/src/access/Variable.js.html', '100 %4/4');
         test('file/src/async/Function.js.html', '100 %1/1');
         test('file/src/async/Method.js.html', '100 %2/2');
         test('file/src/class/Definition.js.html', '100 %8/8');
         test('file/src/classproperty/Definition.js.html', '100 %3/3');
         test('file/src/computed/Method.js.html', '100 %11/11');
         test('file/src/computed/Property.js.html', '100 %12/12');
         test('file/src/decorator/Definition.js.html', '100 %7/7');
         test('file/src/deprecated/Class.js.html#errorLines=7', '75 %3/4');
         test('file/src/deprecated/Function.js.html', '100 %1/1');
         test('file/src/deprecated/Variable.js.html', '100 %1/1');
         test('file/src/desc/Class.js.html', '100 %4/4');
         test('file/src/desc/Function.js.html', '100 %1/1');
         test('file/src/desc/Markdown.js.html', '100 %1/1');
         test('file/src/desc/MultiLine.js.html', '100 %4/4');
         test('file/src/desc/Variable.js.html', '100 %1/1');
         test('file/src/destructuring/Array.js.html', '100 %2/2');
         test('file/src/destructuring/Object.js.html', '100 %2/2');
         test('file/src/duplication/Definition.js.html', '100 %5/5');
         test('file/src/emits/Function.js.html#errorLines=7', '50 %1/2');
         test('file/src/emits/Method.js.html#errorLines=14,16', '50 %2/4');
         test('file/src/example/Caption.js.html', '100 %1/1');
         test('file/src/example/Class.js.html', '100 %4/4');
         test('file/src/example/Function.js.html', '100 %1/1');
         test('file/src/example/Variable.js.html', '100 %1/1');
         test('file/src/experimental/Class.js.html', '100 %4/4');
         test('file/src/experimental/Function.js.html', '100 %1/1');
         test('file/src/experimental/Variable.js.html', '100 %1/1');
         test('file/src/exponentiationoperator/Definition.js.html', '100 %2/2');
         test('file/src/export/AnonymousClass.js.html', '100 %1/1');
         test('file/src/export/AnonymousFunction.js.html', '100 %1/1');
         test('file/src/export/ArrowFunction.js.html#errorLines=18', '75 %3/4');
         test('file/src/export/Class.js.html#errorLines=25', '80 %4/5');
         test('file/src/export/ClassIndirectDefault.js.html', '100 %1/1');
         test('file/src/export/Default.js.html', '100 %1/1');
         test('file/src/export/Extends.js.html', '100 %2/2');
         test('file/src/export/Function.js.html#errorLines=33', '83 %5/6');
         test('file/src/export/FunctionIndirectDefault.js.html', '100 %1/1');
         test('file/src/export/Multiple.js.html', '100 %2/2');
         test('file/src/export/Named.js.html', '100 %1/1');
         test('file/src/export/NewExpression.js.html', '100 %4/4');
         test('file/src/export/NewExpressionIndirect.js.html', '100 %2/2');
         test('file/src/export/NewExpressionProperty.js.html', '100 %2/2');
         test('file/src/export/Variable.js.html#errorLines=23,24', '66 %4/6');
         test('file/src/export/VariableIndirectDefault.js.html', '100 %1/1');
         test('file/src/extends/Builtin.js.html#errorLines=6', '50 %1/2');
         test('file/src/extends/Deep.js.html#errorLines=1,12,14,16,18,22,24,26,28,3,30,33,35,37,39,43,45,47,49,5,51,54,56,58,60,7,9', '0 %0/27');
         test('file/src/extends/Expression.js.html#errorLines=11', '66 %2/3');
         test('file/src/extends/Inner.js.html#errorLines=1', '83 %5/6');
         test('file/src/extends/Mixin.js.html#errorLines=11,19', '66 %4/6');
         test('file/src/extends/MixinExplicit.js.html', '100 %3/3');
         test('file/src/extends/Outer.js.html', '100 %2/2');
         test('file/src/extends/Property.js.html', '100 %1/1');
         test('file/src/external/Definition.js.html', '-');
         test('file/src/generator/Function.js.html', '100 %1/1');
         test('file/src/generator/Method.js.html', '100 %2/2');
         test('file/src/guess/Param.js.html#errorLines=10,12,14,16,18,20,22,24,6,8', '9 %1/11');
         test('file/src/guess/Property.js.html#errorLines=10,12,14,6,8', '16 %1/6');
         test('file/src/guess/Return.js.html#errorLines=11,16,21,26,6', '16 %1/6');
         test('file/src/guess/Variable.js.html#errorLines=1,3,5,7', '0 %0/4');
         test('file/src/ignore/Class.js.html', '100 %2/2');
         test('file/src/ignore/Function.js.html', '-');
         test('file/src/ignore/Variable.js.html', '-');
         test('file/src/interface/Definition.js.html', '100 %2/2');
         test('file/src/interface/Implements.js.html', '100 %5/5');
         test('file/src/invalid/DocSyntax.js.html', '-');
         test('file/src/jsx/Definition.js.html', '100 %2/2');
         test('file/src/link/Class.js.html', '100 %4/4');
         test('file/src/link/Function.js.html', '100 %1/1');
         test('file/src/link/Variable.js.html', '100 %1/1');
         test('file/src/lint/Invalid.js.html', '100 %5/5');
         test('file/src/listens/Function.js.html', '100 %2/2');
         test('file/src/listens/Method.js.html', '100 %4/4');
         test('file/src/param/Function.js.html', '100 %1/1');
         test('file/src/param/Method.js.html', '100 %2/2');
         test('file/src/property/Return.js.html', '100 %2/2');
         test('file/src/return/Function.js.html', '100 %2/2');
         test('file/src/return/Method.js.html', '100 %3/3');
         test('file/src/see/Class.js.html', '100 %4/4');
         test('file/src/see/Function.js.html', '100 %1/1');
         test('file/src/see/Variable.js.html', '100 %1/1');
         test('file/src/since/Class.js.html', '100 %4/4');
         test('file/src/since/Function.js.html', '100 %1/1');
         test('file/src/since/Variable.js.html', '100 %1/1');
         test('file/src/throws/Function.js.html', '100 %2/2');
         test('file/src/throws/Method.js.html', '100 %4/4');
         test('file/src/todo/Class.js.html', '100 %4/4');
         test('file/src/todo/Function.js.html', '100 %1/1');
         test('file/src/todo/Variable.js.html', '100 %1/1');
         test('file/src/trailingcomma/Definition.js.html', '100 %3/3');
         test('file/src/type/Array.js.html', '100 %2/2');
         test('file/src/type/Class.js.html#errorLines=11,2', '33 %1/3');
         test('file/src/type/Complex.js.html#errorLines=2', '85 %6/7');
         test('file/src/type/Default.js.html', '100 %3/3');
         test('file/src/type/External.js.html', '100 %2/2');
         test('file/src/type/Function.js.html', '100 %2/2');
         test('file/src/type/Generics.js.html', '100 %2/2');
         test('file/src/type/Literal.js.html', '100 %2/2');
         test('file/src/type/Nullable.js.html#errorLines=2', '50 %1/2');
         test('file/src/type/Object.js.html', '100 %2/2');
         test('file/src/type/Optional.js.html', '100 %2/2');
         test('file/src/type/Record.js.html', '100 %2/2');
         test('file/src/type/Spread.js.html', '100 %3/3');
         test('file/src/type/Typedef.js.html', '100 %2/2');
         test('file/src/type/Union.js.html', '100 %2/2');
         test('file/src/typedef/Definition.js.html', '-');
         test('file/src/undocument/Definition.js.html#errorLines=2', '0 %0/1');
         test('file/src/unknown/Definition.js.html', '100 %1/1');
         test('file/src/variable/ArrayPattern.js.html', '100 %1/1');
         test('file/src/variable/Definition.js.html', '100 %1/1');
         test('file/src/variable/ObjectPattern.js.html', '100 %1/1');
         test('file/src/version/Class.js.html', '100 %4/4');
         test('file/src/version/Function.js.html', '100 %1/1');
         test('file/src/version/Variable.js.html', '100 %1/1');

         assert.equal(count, 120);
      });
   });
}
