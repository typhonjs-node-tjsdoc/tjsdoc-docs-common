import { readDoc as _readDoc, assert, cli }  from '../util.js';
import testConfig                            from '../testconfig.js';

if (testConfig.category.config && testConfig.config.tests.coverage)
{
   /** @test {CoverageBuilder} */
   describe('test config.coverage: false', () =>
   {
      cli('./test/fixture/config/esdoc-coverage.json');

      /**
       * Helper function to change the directory when invoking `_readDoc`.
       *
       * @param {string}   filePath - Local file path to load relative to './test/fixture/dest/esdoc-coverage'.
       *
       * @returns {*}
       */
      function readDoc(filePath)
      {
         return _readDoc(filePath, './test/fixture/dest/esdoc-coverage');
      }

      it('does not have coverage', () =>
      {
         const doc = readDoc('source.html');
         assert.throws(() =>
         {
            assert.includes(doc, '[data-ice="coverageBadge"]', './badge.svg', 'src');
         });
      });
   });
}
