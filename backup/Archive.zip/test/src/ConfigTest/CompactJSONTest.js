import { readFile, assert, cli } from '../util.js';
import testConfig                from '../testconfig.js';

if (testConfig.category.config && testConfig.config.tests.compactJSON)
{
   /** @test {publish} */
   describe('test config.compactJSON: true, config.outputAST: true, config.outputDocData: true', () =>
   {
      cli('./test/fixture/config/tjsdoc-compactJSON.json');

      it('does have ast data.', () =>
      {
         assert.doesNotThrow(() =>
         {
            const astDataLines = readFile('ast/source/Desc/Class.js.json',
             './test/fixture/dest/tjsdoc-compactJSON').match(/^.+$/gm);

            const docDataLines = readFile('docData.json', './test/fixture/dest/tjsdoc-compactJSON').match(/^.+$/gm);

            assert.isArray(astDataLines);
            assert.isArray(docDataLines);

            // Ensure that there is only one line.
            assert.lengthOf(astDataLines, 1);
            assert.lengthOf(docDataLines, 1);
         });
      });
   });
}
