import { readDoc as _readDoc, assert, cli }  from '../util.js';
import testConfig                            from '../testconfig.js';

if (testConfig.category.config && testConfig.config.tests.styles)
{
   /** @test {DocBuilder#_buildLayoutDoc} */
   describe('test config.styles: ["./test/fixture/style/custom.css"]', () =>
   {
      cli('./test/fixture/config/esdoc-styles.json');

      /**
       * Helper function to change the directory when invoking `_readDoc`.
       *
       * @param {string}   filePath - Local file path to load relative to './test/fixture/dest/esdoc-styles'.
       *
       * @returns {*}
       */
      function readDoc(filePath)
      {
         return _readDoc(filePath, './test/fixture/dest/esdoc-styles');
      }

      it('has custom style', () =>
      {
         const doc = readDoc('index.html');
         assert.includes(doc, '[data-ice="userStyle"]', 'user/css/0-custom.css', 'href');
      });
   });
}
