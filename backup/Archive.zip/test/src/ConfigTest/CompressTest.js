import { readFile, assert, cli } from '../util.js';
import testConfig                from '../testconfig.js';

//if (testConfig.category.config && testConfig.config.tests.compactJSON)
{
   /** @test {publish} */
   describe('test config.compressOutput: true', () =>
   {
      cli('./test/fixture/config/tjsdoc-compress.json', false);

      it('does have ast data.', (done) =>
      {
         // Must set a timeout so that `archive` NPM module may finalize and close file.
         setTimeout(() =>
         {
            //assert.doesNotThrow(() =>
            //{
            //   readFile('docs.zip', './test/fixture/dest/tjsdoc-compress');
            //});

            done();
         }, 1000);
      });
   });
}
