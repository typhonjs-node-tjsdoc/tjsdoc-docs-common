import { readDoc as _readDoc, assert, cli }  from '../util.js';
import testConfig                            from '../testconfig.js';

if (testConfig.category.config && testConfig.config.tests.undocumentIdentifier)
{
   /** @test {DocResolver#_resolveUndocumentIdentifier} */
   describe('test config.undocumentIdentifier: false', () =>
   {
      cli('./test/fixture/config/esdoc-undocumentIdentifier.json');

      /**
       * Helper function to change the directory when invoking `_readDoc`.
       *
       * @param {string}   filePath - Local file path to load relative to './test/fixture/dest/esdoc-undocumentIdentifier'.
       *
       * @returns {*}
       */
      function readDoc(filePath)
      {
         return _readDoc(filePath, './test/fixture/dest/esdoc-undocumentIdentifier');
      }

      it('does not have undocument identifier', () =>
      {
         assert.throws(() =>
         {
            readDoc('class/src/Undocument/Definition.js~TestUndocumentDefinition.html');
         });
      });
   });
}
