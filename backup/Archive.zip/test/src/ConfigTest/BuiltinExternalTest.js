import { readDoc as _readDoc, assert, cli }  from '../util.js';
import testConfig                            from '../testconfig.js';

if (testConfig.category.config && testConfig.config.tests.builtinExternal)
{
   /** @test {ESDoc._useBuiltinExternal} */
   describe('test config.builtinExternal: false', () =>
   {
      cli('./test/fixture/config/esdoc-builtinExternal.json');

      /**
       * Helper function to change the directory when invoking `_readDoc`.
       *
       * @param {string}   filePath - Local file path to load relative to './test/fixture/dest/esdoc-builtinExternal'.
       *
       * @returns {*}
       */
      function readDoc(filePath)
      {
         return _readDoc(filePath, './test/fixture/dest/esdoc-builtinExternal');
      }

      it('does not have builtin external link', () =>
      {
         const doc = readDoc('class/src/Type/Array.js~TestTypeArray.html');
         assert.throws(() =>
         {
            assert.includes(doc,
             'a[href="https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number"]',
               'number');
         });
      });
   });
}
