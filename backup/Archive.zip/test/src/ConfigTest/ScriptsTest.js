import { readDoc as _readDoc, assert, cli }  from '../util.js';
import testConfig                            from '../testconfig.js';

if (testConfig.category.config && testConfig.config.tests.scripts)
{
   /** @test {DocBuilder#_buildLayoutDoc} */
   describe('test config.scripts: ["./test/fixture/script/custom.js"]', () =>
   {
      cli('./test/fixture/config/esdoc-scripts.json');

      /**
       * Helper function to change the directory when invoking `_readDoc`.
       *
       * @param {string}   filePath - Local file path to load relative to './test/fixture/dest/esdoc-scripts'.
       *
       * @returns {*}
       */
      function readDoc(filePath)
      {
         return _readDoc(filePath, './test/fixture/dest/esdoc-scripts');
      }

      it('has custom script', () =>
      {
         const doc = readDoc('index.html');

         assert.includes(doc, '[data-ice="userScript"]', 'user/script/0-custom.js', 'src');
      });
   });
}
