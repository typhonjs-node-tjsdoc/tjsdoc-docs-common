import { readFile, assert, cli } from '../util.js';
import testConfig                from '../testconfig.js';

if (testConfig.category.config && testConfig.config.tests.includesAST)
{
   /** @test {publish} */
   describe('test config.outputAST: true', () =>
   {
      cli('./test/fixture/config/tjsdoc-includeAST.json');

      it('does have ast data.', () =>
      {
         assert.doesNotThrow(() =>
         {
            readFile('ast/source/Desc/Class.js.json', './test/fixture/dest/tjsdoc-includeAST');
         });
      });
   });
}
