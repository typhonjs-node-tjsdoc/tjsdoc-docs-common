import { readDoc as _readDoc, assert, cli }  from '../util.js';
import testConfig                            from '../testconfig.js';

if (testConfig.category.config && testConfig.config.tests.unexportIdentifier)
{
   /** @test {DocResolver#_resolveUnexportIdentifier} */
   describe('test config.unexportIdentifier: true', () =>
   {
      cli('./test/fixture/config/esdoc-unexportIdentifier.json');

      /**
       * Helper function to change the directory when invoking `_readDoc`.
       *
       * @param {string}   filePath - Local file path to load relative to './test/fixture/dest/esdoc-unexportIdentifier'.
       *
       * @returns {*}
       */
      function readDoc(filePath)
      {
         return _readDoc(filePath, './test/fixture/dest/esdoc-unexportIdentifier');
      }

      it('has unexport identifier', () =>
      {
         const doc = readDoc('class/src/Export/Class.js~TestExportClass6.html');
         assert.includes(doc, '.self-detail [data-ice="name"]', 'TestExportClass6');
         assert.notIncludes(doc, '.header-notice', 'import');
      });
   });
}
