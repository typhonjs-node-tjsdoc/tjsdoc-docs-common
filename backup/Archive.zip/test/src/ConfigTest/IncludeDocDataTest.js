import { readFile, assert, cli } from '../util.js';
import testConfig                from '../testconfig.js';

if (testConfig.category.config && testConfig.config.tests.includeDocData)
{
   /** @test {publish} */
   describe('test config.outputDocData: true', () =>
   {
      cli('./test/fixture/config/tjsdoc-includeDocData.json');

      it('does not have ast data.', () =>
      {
         assert.doesNotThrow(() => { readFile('docData.json', './test/fixture/dest/tjsdoc-includeDocData'); });
      });
   });
}
