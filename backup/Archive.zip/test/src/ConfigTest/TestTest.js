import { readDoc as _readDoc, assert, cli }  from '../util.js';
import testConfig                            from '../testconfig.js';

if (testConfig.category.config && testConfig.config.tests.test)
{
   /** @test {publish} */
   describe('test config.test: null', () =>
   {
      cli('./test/fixture/config/esdoc-test.json');

      /**
       * Helper function to change the directory when invoking `_readDoc`.
       *
       * @param {string}   filePath - Local file path to load relative to './test/fixture/dest/esdoc-test'.
       *
       * @returns {*}
       */
      function readDoc(filePath)
      {
         return _readDoc(filePath, './test/fixture/dest/esdoc-test');
      }

      it('does not have test integration', () =>
      {
         assert.throws(() =>
         {
            readDoc('test.html');
         });
      });
   });
}
