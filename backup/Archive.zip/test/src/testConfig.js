/**
 * Defines which modules to run tests. Please note that setting `generateMain` to false doesn't build documentation
 * for the main demo test code. The next level of tests which can be disabled are `testConfig.category` followed
 * by further tests or categories in `testConfig.config`, `testConfig.doc`, `testConfig.html` and `testConfig.parser`.
 *
 * @type {{}}
 */
const testConfig =
{
   // Deletes `./test/fixture/dest/` if true on initializing tests.
   deleteMain: false,

   // Generates the main TJSDoc test output. Note: many tests will fail without main generation.
   generateMain: false,

   // Enables the main categories of tests.
   category:
   {
      config: false,
      doc: false,
      html: false,
      parser: false,
      utils: true
   },

   // Enables specific config tests.
   config:
   {
      tests:
      {
         access: true,
         alternatePublisher: true,
         alternateRuntime: true,
         autoPrivate: true,
         builtinExternal: true,
         cli: true,
         compactData: true,
         compress: true,
         compressAllSeparate: true,
         compressData: true,
         compressZip: true,
         coverage: true,
         emptyDestination: true,
         excludePackage: true,
         excludes: true,
         findConfigPath: true,
         includeSource: true,
         manual: true,
         outputASTData: true,
         outputDocData: true,
         plugins: true,
         scripts: true,
         styles: true,
         test: true,
         undocumentIdentifier: true,
         unexportIdentifier: true
      }
   },

   // Enables specific doc tests.
   doc:
   {
      tests:
      {
         lintDocLogger: true,
         search: true,
         tagsKnown: true,
         tagsUnknown: true,
         undocument: true
      }
   },

   // There are several html sub-categories and each can be enabled independently.
   html:
   {
      category:
      {
         coverage: true,
         document: true,
         file: true,
         identifiers: true,
         index: true,
         manual: true,
         nav: true,
         test: true
      },

      // There are many documentation tests and each html document sub-category can be enabled independently.
      document:
      {
         category:
         {
            'abstract': true,
            'access': true,
            'async': true,
            'classProperty': true,
            'class': true,
            'computed': true,
            'decorator': true,
            'deprecated': true,
            'desc': true,
            'destructuring': true,
            'duplication': true,
            'emits': true,
            'example': true,
            'experimental': true,
            'exponentialOperator': true,
            'export': true,
            'extends': true,
            'external': true,
            'generator': true,
            'guess': true,
            'ignore': true,
            'interface': true,
            'jsx': true,
            'link': true,
            'listens': true,
            'param': true,
            'property': true,
            'return': true,
            'see': true,
            'since': true,
            'throws': true,
            'todo': true,
            'trailingComma': true,
            'typedef': true,
            'type': true,
            'undocument': true,
            'variable': true,
            'version': true
         }
      }
   },

   // Enables specific parser tests.
   parser:
   {
      tests:
      {
         babylonParser: true,
         commentParser: true,
         paramParser: true
      }
   },

   // Enables specific utils tests.
   utils:
   {
      tests:
      {
         configResolver: true,
         invalidCodeLogger: false
      }
   }
};

export default testConfig;
