import fs         from 'fs-extra';

import TJSDoc     from '../../src/TJSDoc.js';
import testConfig from './testConfig.js';

// Potentially remove any existing generated test docs.
if (testConfig.deleteMain) { fs.removeSync('./test/fixture/dest/'); }

if (testConfig.generateMain)
{
   const configFilePath = './test/fixture/package/esdoc.json';
   const configJSON = fs.readFileSync(configFilePath, { encode: 'utf8' });
   const config = JSON.parse(configJSON);

   TJSDoc.generate(config);
}
