import fs         from 'fs-extra';

import testConfig from './testConfig.js';
import TJSDoc     from '../../src/TJSDoc.js';
import { Util }   from './util.js';

// Potentially remove any existing generated test docs.
if (testConfig.emptyDest) { fs.emptyDirSync('./test/fixture/dest/'); }

if (testConfig.generateMain)
{
   for (const target of testConfig.targets)
   {
      console.log(`generating main test: ${target.name}`);

      const configFilePath = './test/fixture/package/tjsdoc.json';
      const configJSON = fs.readFileSync(configFilePath, { encode: 'utf8' });
      const config = JSON.parse(configJSON);

      Util.modTargetConfig(config, target.name);

      // TODO: when modules are published remove and or move to the config file.
      config.runtime = target.runtime;
      config.publisher = './tjsdoc-publisher-static-html/src/publish.js';

      TJSDoc.generate(config);
   }
}
