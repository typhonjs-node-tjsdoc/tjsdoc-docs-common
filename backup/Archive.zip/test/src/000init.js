import fs         from 'fs-extra';

import TJSDoc     from '../../src/TJSDoc.js';
import testConfig from './testconfig.js';

// Remove any existing generated test docs.
fs.removeSync('./test/fixture/dest/');

if (testConfig.generateMain)
{
   const configFilePath = './test/fixture/package/esdoc.json';
   const configJSON = fs.readFileSync(configFilePath, { encode: 'utf8' });
   const config = JSON.parse(configJSON);

   config.publisher = './test/src/testPublish.js';

   TJSDoc.generate(config);
}
