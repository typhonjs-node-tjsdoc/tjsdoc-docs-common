import { readFile, assert, cli } from '../util.js';
import testConfig                from '../testConfig.js';

if (testConfig.category.config && testConfig.config.tests.outputASTData)
{
   /** @test {publish} */
   describe('test config.outputASTData: true', () =>
   {
      Util.cli(target.cli, './test/fixture/config/tjsdoc-outputASTData.json');

      it('outputs ast data.', () =>
      {
         assert.doesNotThrow(() =>
         {
            readFile('ast/test/fixture/package/src/desc/Class.js.json', './test/fixture/dest/tjsdoc-outputASTData');
         });
      });
   });
}
