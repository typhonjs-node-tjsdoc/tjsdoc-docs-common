import { readFile, assert, cli } from '../util.js';
import testConfig                from '../testConfig.js';

if (testConfig.category.config && testConfig.config.tests.outputDocData)
{
   /** @test {publish} */
   describe('test config.outputDocData: true', () =>
   {
      Util.cli(target.cli, './test/fixture/config/tjsdoc-outputDocData.json');

      it('outputs ast data.', () =>
      {
         assert.doesNotThrow(() => { readFile('docData.json', './test/fixture/dest/tjsdoc-outputDocData'); });
      });
   });
}
