import { assert, Util }  from '../util.js';
import testConfig                            from '../testConfig.js';

if (testConfig.category.config && testConfig.config.tests.unexportIdentifier)
{
   /** @test {DocResolver#_resolveUnexportIdentifier} */
   describe('test config.unexportIdentifier: true', () =>
   {
      Util.cli(target.cli, './test/fixture/config/tjsdoc-unexportIdentifier.json');

      /**
       * Helper function to change the directory when invoking `_readDoc`.
       *
       * @param {string}   filePath - Local file path to load relative to './test/fixture/dest/tjsdoc-unexportIdentifier'.
       *
       * @returns {*}
       */
      function readDoc(filePath)
      {
         return _readDoc(filePath, './test/fixture/dest/tjsdoc-unexportIdentifier');
      }

      it('has unexport identifier', () =>
      {
         const doc = readDoc('class/test/fixture/package/src/export/Class.js~TestExportClass6.html');
         assert.includes(doc, '.self-detail [data-ice="name"]', 'TestExportClass6');
         assert.notIncludes(doc, '.header-notice', 'import');
      });
   });
}
