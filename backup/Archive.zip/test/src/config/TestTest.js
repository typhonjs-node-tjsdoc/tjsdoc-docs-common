import { assert, Util }  from '../util.js';
import testConfig                            from '../testConfig.js';

if (testConfig.category.config && testConfig.config.tests.test)
{
   /** @test {publish} */
   describe('test config.test: null', () =>
   {
      Util.cli(target.cli, './test/fixture/config/tjsdoc-test.json');

      /**
       * Helper function to change the directory when invoking `_readDoc`.
       *
       * @param {string}   filePath - Local file path to load relative to './test/fixture/dest/tjsdoc-test'.
       *
       * @returns {*}
       */
      function readDoc(filePath)
      {
         return _readDoc(filePath, './test/fixture/dest/tjsdoc-test');
      }

      it('does not have test integration', () =>
      {
         assert.throws(() =>
         {
            readDoc('test.html');
         });
      });
   });
}
