import fs               from 'fs';

import { assert, cli }  from '../util.js';
import testConfig       from '../testConfig.js';

if (testConfig.category.config && testConfig.config.tests.compressAllSeparate)
{
   /** @test {publish} */
   describe('test config.compressData: true, config.compressOutput: true, config.outputASTData: true, '
    + 'config.outputDocData: true, config.separateDataArchives: true', () =>
   {
      cli('./test/fixture/config/tjsdoc-compressAllSeparate.json');

      it('compresses all output, AST and doc data separately', (done) =>
      {
         // Must set a timeout so that `archive` NPM module may finalize and close file.
         setTimeout(() =>
         {
            const entries = fs.readdirSync('./test/fixture/dest/tjsdoc-compressAllSeparate');

            // Make sure there are exactly 3 entries with compressed docs, ast, and doc data.
            assert.lengthOf(entries, 3);
            assert.isAtLeast(entries.indexOf('ast.tar.gz'), 0);
            assert.isAtLeast(entries.indexOf('docs.tar.gz'), 0);
            assert.isAtLeast(entries.indexOf('docData.tar.gz'), 0);

            done();
         }, 1000);
      });
   });
}
