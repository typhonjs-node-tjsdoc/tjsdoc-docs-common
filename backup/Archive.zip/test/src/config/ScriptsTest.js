import { assert, Util }  from '../util.js';
import testConfig                            from '../testConfig.js';

if (testConfig.category.config && testConfig.config.tests.scripts)
{
   /** @test {DocBuilder#_buildLayoutDoc} */
   describe('test config.scripts: ["./test/fixture/script/custom.js"]', () =>
   {
      Util.cli(target.cli, './test/fixture/config/tjsdoc-scripts.json');

      /**
       * Helper function to change the directory when invoking `_readDoc`.
       *
       * @param {string}   filePath - Local file path to load relative to './test/fixture/dest/tjsdoc-scripts'.
       *
       * @returns {*}
       */
      function readDoc(filePath)
      {
         return _readDoc(filePath, './test/fixture/dest/tjsdoc-scripts');
      }

      it('has custom script', () =>
      {
         const doc = readDoc('index.html');

         assert.includes(doc, '[data-ice="userScript"]', 'user/script/0-custom.js', 'src');
      });
   });
}
