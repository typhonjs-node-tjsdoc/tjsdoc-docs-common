import { assert, Util }  from '../util.js';
import testConfig                            from '../testConfig.js';

if (testConfig.category.config && testConfig.config.tests.builtinExternal)
{
   describe('test config.builtinVirtual: false', () =>
   {
      Util.cli(target.cli, './test/fixture/config/tjsdoc-builtinVirtual.json');

      /**
       * Helper function to change the directory when invoking `_readDoc`.
       *
       * @param {string}   filePath - Local file path to load relative to './test/fixture/dest/tjsdoc-builtinVirtual'.
       *
       * @returns {*}
       */
      function readDoc(filePath)
      {
         return _readDoc(filePath, './test/fixture/dest/tjsdoc-builtinVirtual');
      }

      it('does not have builtin external link', () =>
      {
         const doc = readDoc('class/test/fixture/package/src/type/Array.js~TestTypeArray.html');
         assert.throws(() =>
         {
            assert.includes(doc,
             'a[href="https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number"]',
               'number');
         });
      });
   });
}
