import { readFile, assert, cli } from '../util.js';
import testConfig                from '../testConfig.js';

if (testConfig.category.config && testConfig.config.tests.excludePackage)
{
   /** @test {publish} */
   describe('test config.copyPackage: false', () =>
   {
      cli('./test/fixture/config/tjsdoc-excludePackage.json');

      it('does not have ast data.', () =>
      {
         assert.throws(() => { readFile('package.json', './test/fixture/dest/tjsdoc-excludePackage'); });
      });
   });
}
