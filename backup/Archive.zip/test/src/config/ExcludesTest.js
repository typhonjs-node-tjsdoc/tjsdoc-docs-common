import { readDoc as _readDoc, assert, cli }  from '../util.js';
import testConfig                            from '../testConfig.js';

if (testConfig.category.config && testConfig.config.tests.excludes)
{
   /** @test {ESDoc.generate} */
   describe('test config.excludes: ["Class\\.js"]', () =>
   {
      cli('./test/fixture/config/esdoc-excludes.json');

      /**
       * Helper function to change the directory when invoking `_readDoc`.
       *
       * @param {string}   filePath - Local file path to load relative to './test/fixture/dest/esdoc-excludes'.
       *
       * @returns {*}
       */
      function readDoc(filePath)
      {
         return _readDoc(filePath, './test/fixture/dest/esdoc-excludes');
      }

      it('does not have excluded identifier', () =>
      {
         assert.throws(() =>
         {
            readDoc('class/src/desc/Class.js~TestDescClass.html');
         });
      });
   });
}
