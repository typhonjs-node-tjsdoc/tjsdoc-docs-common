import { assert, Util }  from '../util.js';
import testConfig                            from '../testConfig.js';

if (testConfig.category.config && testConfig.config.tests.excludes)
{
   describe('test config.excludes: ["Class\\.js"]', () =>
   {
      Util.cli(target.cli, './test/fixture/config/tjsdoc-excludes.json');

      /**
       * Helper function to change the directory when invoking `_readDoc`.
       *
       * @param {string}   filePath - Local file path to load relative to './test/fixture/dest/tjsdoc-excludes'.
       *
       * @returns {*}
       */
      function readDoc(filePath)
      {
         return _readDoc(filePath, './test/fixture/dest/tjsdoc-excludes');
      }

      it('does not have excluded identifier', () =>
      {
         assert.throws(() =>
         {
            readDoc('class/src/desc/Class.js~TestDescClass.html');
         });
      });
   });
}
