import fs                        from 'fs-extra';

import { readFile, assert, cli } from '../util.js';
import testConfig                from '../testConfig.js';

if (testConfig.category.config && testConfig.config.tests.emptyDestination)
{
   /** @test {publish} */
   describe('test config.emptyDestination: true', () =>
   {
      // Write a dummy data file to verify that empty destination works before invoking TJSDoc.
      fs.ensureDirSync('./test/fixture/dest/tjsdoc-emptyDestination');
      fs.writeFileSync('./test/fixture/dest/tjsdoc-emptyDestination/DUMMY_DATA', 'DUMMY_DATA');

      Util.cli(target.cli, './test/fixture/config/tjsdoc-emptyDestination.json');

      it('destination emptied.', () =>
      {
         // Verify that DUMMY_DATA is deleted.
         assert.throws(() => { readFile('DUMMY_DATA', './test/fixture/dest/tjsdoc-emptyDestination'); });
      });
   });
}
