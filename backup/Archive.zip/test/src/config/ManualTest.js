import { readDoc as _readDoc, assert, cli }  from '../util.js';
import testConfig                            from '../testConfig.js';

if (testConfig.category.config && testConfig.config.tests.manual)
{
   /** @test {ManualDocBuilder} */
   describe('test config.manual: null', () =>
   {
      cli('./test/fixture/config/esdoc-manual.json');

      /**
       * Helper function to change the directory when invoking `_readDoc`.
       *
       * @param {string}   filePath - Local file path to load relative to './test/fixture/dest/esdoc-manual'.
       *
       * @returns {*}
       */
      function readDoc(filePath)
      {
         return _readDoc(filePath, './test/fixture/dest/esdoc-manual');
      }

      it('does not have manual.', () =>
      {
         assert.throws(() =>
         {
            readDoc('manual/index.html');
         });
      });
   });
}
