import fs               from 'fs';

import { assert, cli }  from '../util.js';
import testConfig       from '../testConfig.js';

if (testConfig.category.config && testConfig.config.tests.compressZip)
{
   /** @test {publish} */
   describe('test config.compressFormat: "zip", config.compressOutput: true', () =>
   {
      cli('./test/fixture/config/tjsdoc-compressZip.json');

      it('compresses as docs.zip', (done) =>
      {
         // Must set a timeout so that `archive` NPM module may finalize and close file.
         setTimeout(() =>
         {
            const entries = fs.readdirSync('./test/fixture/dest/tjsdoc-compressZip');

            // Make sure there is only 1 entry.
            assert.lengthOf(entries, 1);
            assert.strictEqual(entries[0], 'docs.zip');

            done();
         }, 1000);
      });
   });
}
