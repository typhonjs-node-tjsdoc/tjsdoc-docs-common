import path                      from 'path';
import process                   from 'process';

import { readDoc, assert, cli }  from '../util.js';
import testConfig                from '../testConfig.js';

if (testConfig.category.config && testConfig.config.tests.findConfigPath)
{
   describe('test finding config path:', () =>
   {
      const cwd = process.cwd();

      const cliPath = path.resolve('./tjsdoc-babylon/src/TJSDocBabylonCLI.js');

      process.chdir('./test/fixture/config/find-.tjsdoc.json/');
      Util.cli(target.cli, null, true, cliPath);
      process.chdir(cwd);

      process.chdir('./test/fixture/config/find-.tjsdoc.js/');
      Util.cli(target.cli, null, true, cliPath);
      process.chdir(cwd);

      process.chdir('./test/fixture/config/find-.tjsdocrc.json/');
      Util.cli(target.cli, null, true, cliPath);
      process.chdir(cwd);

      process.chdir('./test/fixture/config/find-.tjsdocrc.js/');
      Util.cli(target.cli, null, true, cliPath);
      process.chdir(cwd);

      process.chdir('./test/fixture/config/find-.tjsdocrc/');
      Util.cli(target.cli, null, true, cliPath);
      process.chdir(cwd);

      process.chdir('./test/fixture/config/find-package.json/');
      Util.cli(target.cli, null, true, cliPath);
      process.chdir(cwd);

      it('can find .tjsdoc.json', () =>
      {
         const doc = readDoc('class/,,/,,/package/src/access/Class.js~TestAccessClassPublic.html',
          './test/fixture/dest/find-.tjsdoc.json');

         assert.includes(doc, '.self-detail [data-ice="name"]', 'TestAccessClassPublic');
      });

      it('can find .tjsdoc.js', () =>
      {
         const doc = readDoc('class/,,/,,/package/src/access/Class.js~TestAccessClassPublic.html',
          './test/fixture/dest/find-.tjsdoc.js');

         assert.includes(doc, '.self-detail [data-ice="name"]', 'TestAccessClassPublic');
      });

      it('can find .tjsdocrc.json', () =>
      {
         const doc = readDoc('class/,,/,,/package/src/access/Class.js~TestAccessClassPublic.html',
          './test/fixture/dest/find-.tjsdocrc.json');

         assert.includes(doc, '.self-detail [data-ice="name"]', 'TestAccessClassPublic');
      });

      it('can find .tjsdocrc.js', () =>
      {
         const doc = readDoc('class/,,/,,/package/src/access/Class.js~TestAccessClassPublic.html',
          './test/fixture/dest/find-.tjsdocrc.js');

         assert.includes(doc, '.self-detail [data-ice="name"]', 'TestAccessClassPublic');
      });

      it('can find .tjsdocrc', () =>
      {
         const doc = readDoc('class/,,/,,/package/src/access/Class.js~TestAccessClassPublic.html',
          './test/fixture/dest/find-.tjsdocrc');

         assert.includes(doc, '.self-detail [data-ice="name"]', 'TestAccessClassPublic');
      });

      it('can find package.js', () =>
      {
         const doc = readDoc('class/,,/,,/package/src/access/Class.js~TestAccessClassPublic.html',
          './test/fixture/dest/find-package.json');

         assert.includes(doc, '.self-detail [data-ice="name"]', 'TestAccessClassPublic');
      });
   });
}
