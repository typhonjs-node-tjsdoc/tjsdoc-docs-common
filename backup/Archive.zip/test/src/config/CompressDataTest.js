import fs               from 'fs';

import { assert, cli }  from '../util.js';
import testConfig       from '../testConfig.js';

if (testConfig.category.config && testConfig.config.tests.compressData)
{
   /** @test {publish} */
   describe('test config.compressData: true, config.outputASTData: true, config.outputDocData: true', () =>
   {
      cli('./test/fixture/config/tjsdoc-compressData.json');

      it('compresses as AST and docData.json', (done) =>
      {
         // Must set a timeout so that `archive` NPM module may finalize and close file.
         setTimeout(() =>
         {
            const entries = fs.readdirSync('./test/fixture/dest/tjsdoc-compressData');

            // Make sure there are multiple files / directories and compressed ast and doc data.
            assert.isAtLeast(entries.length, 8);
            assert.isAtLeast(entries.indexOf('ast.tar.gz'), 0);
            assert.isAtLeast(entries.indexOf('docData.tar.gz'), 0);

            done();
         }, 1000);
      });
   });
}
