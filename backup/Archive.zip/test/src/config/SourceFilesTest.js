import { assert, Util }  from '../util.js';
import testConfig                            from '../testConfig.js';

if (testConfig.category.config && testConfig.config.tests.sourceFiles)
{
   /** @test {ManualDocBuilder} */
   describe('test config.sourceFiles', () =>
   {
      Util.cli(target.cli, './test/fixture/config/tjsdoc-sourceFiles.js');

      /**
       * Helper function to change the directory when invoking `_readDoc`.
       *
       * @param {string}   filePath - Local file path to load relative to './test/fixture/dest/tjsdoc-sourceFiles'.
       *
       * @returns {*}
       */
      function readDoc(filePath)
      {
         return _readDoc(filePath, './test/fixture/dest/tjsdoc-sourceFiles');
      }

      it('Generates docs from sourceFiles', () =>
      {
         assert.doesNotThrow(() => readDoc('class/test/fixture/package/src/desc/Class.js~TestDescClass.html'));
         assert.doesNotThrow(() => readDoc('class/test/fixture/package/src/desc/Markdown.js~TestDescMarkdown.html'));
         assert.doesNotThrow(() => readDoc('class/test/fixture/package/src/desc/MultiLine.js~TestDescMultiLine.html'));
      });
   });
}
