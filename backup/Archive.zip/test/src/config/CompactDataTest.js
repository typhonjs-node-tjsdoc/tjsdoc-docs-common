import { readFile, assert, cli } from '../util.js';
import testConfig                from '../testConfig.js';

if (testConfig.category.config && testConfig.config.tests.compactData)
{
   /** @test {publish} */
   describe('test config.compactData: true, config.outputASTData: true, config.outputDocData: true', () =>
   {
      Util.cli(target.cli, './test/fixture/config/tjsdoc-compactData.json');

      it('does have ast data.', () =>
      {
         assert.doesNotThrow(() =>
         {
            const astDataLines = readFile('ast/test/fixture/package/src/desc/Class.js.json',
             './test/fixture/dest/tjsdoc-compactData').match(/^.+$/gm);

            const docDataLines = readFile('docData.json', './test/fixture/dest/tjsdoc-compactData').match(/^.+$/gm);

            assert.isArray(astDataLines);
            assert.isArray(docDataLines);

            // Ensure that there is only one line.
            assert.lengthOf(astDataLines, 1);
            assert.lengthOf(docDataLines, 1);
         });
      });
   });
}
