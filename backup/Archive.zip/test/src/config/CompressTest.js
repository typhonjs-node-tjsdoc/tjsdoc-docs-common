import fs               from 'fs';

import { assert, cli }  from '../util.js';
import testConfig       from '../testConfig.js';

if (testConfig.category.config && testConfig.config.tests.compress)
{
   /** @test {publish} */
   describe('test config.compressOutput: true', () =>
   {
      cli('./test/fixture/config/tjsdoc-compress.json');

      it('compresses as docs.tar.gz', (done) =>
      {
         // Must set a timeout so that `archive` NPM module may finalize and close file.
         setTimeout(() =>
         {
            const entries = fs.readdirSync('./test/fixture/dest/tjsdoc-compress');

            // Make sure there is only 1 entry.
            assert.lengthOf(entries, 1);
            assert.strictEqual(entries[0], 'docs.tar.gz');

            done();
         }, 1000);
      });
   });
}
