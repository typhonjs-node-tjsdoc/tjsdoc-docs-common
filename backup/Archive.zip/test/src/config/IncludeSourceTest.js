import { readDoc as _readDoc, assert, cli }  from '../util.js';
import testConfig                            from '../testConfig.js';

if (testConfig.category.config && testConfig.config.tests.includeSource)
{
   /** @test {publish} */
   describe('test config.includeSource: false', () =>
   {
      cli('./test/fixture/config/esdoc-includeSource.json');

      /**
       * Helper function to change the directory when invoking `_readDoc`.
       *
       * @param {string}   filePath - Local file path to load relative to './test/fixture/dest/esdoc-includeSource'.
       *
       * @returns {*}
       */
      function readDoc(filePath)
      {
         return _readDoc(filePath, './test/fixture/dest/esdoc-includeSource');
      }

      it('does not have source code.', () =>
      {
         const doc = readDoc('file/src/desc/Class.js.html');
         assert.includes(doc, '[data-ice="content"]', 'src/desc/Class.js');
         assert.includes(doc, '[data-ice="content"]', 'Sorry, this documentation does not provide source code.');
         assert.notIncludes(doc, '[data-ice="content"]', 'class TestDescClass');
      });
   });
}
