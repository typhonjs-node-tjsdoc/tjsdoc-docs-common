import { assert, cli }  from '../util.js';
import testConfig       from '../testConfig.js';

if (testConfig.category.config && testConfig.config.tests.alternateRuntime)
{
   /** @test {DocResolver#_resolveAccess} */
   describe('test alternate config.runtime', () =>
   {
      Util.cli(target.cli, './test/fixture/config/tjsdoc-alternateRuntime.json');

      it('ran alternate publisher', () =>
      {
         assert.isTrue(global.$$tjsdoc_alternate_runtime);
      });
   });
}


