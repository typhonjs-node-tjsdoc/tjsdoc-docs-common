import { assert }    from 'chai';

import BabylonParser from '../../../src/babylon/parser/BabylonParser.js';
import testConfig    from '../testconfig.js';

if (testConfig.category.parser && testConfig.parser.tests.babylonParser)
{
   /** @test {BabylonParser} */
   describe('BabylonParser', () =>
   {
      it('can parse "do expressions"', () =>
      {
         const ast = BabylonParser.parseFile('./test/fixture/syntax/DoExpressions.js');
         assert(ast.program.sourceType === 'module');
      });

      it('can parse "function bind"', () =>
      {
         const ast = BabylonParser.parseFile('./test/fixture/syntax/FunctionBind.js');
         assert(ast.program.sourceType === 'module');
      });

      it('can parse "function sent"', () =>
      {
         const ast = BabylonParser.parseFile('./test/fixture/syntax/FunctionSent.js');
         assert(ast.program.sourceType === 'module');
      });

      it('can parse "async generators"', () =>
      {
         const ast = BabylonParser.parseFile('./test/fixture/syntax/AsyncGenerators.js');
         assert(ast.program.sourceType === 'module');
      });

      it('can parse "export extensions"', () =>
      {
         const ast = BabylonParser.parseFile('./test/fixture/syntax/ExportExtensions.js');
         assert(ast.program.sourceType === 'module');
      });

      it('can parse "dynamic import"', () =>
      {
         const ast = BabylonParser.parseFile('./test/fixture/syntax/DynamicImport.js');
         assert(ast.program.sourceType === 'script');
      });
   });
}
