import { assert }    from 'chai';

import ParamParser   from '../../../src/babylon/parser/ParamParser.js';
import testConfig    from '../testconfig.js';

if (testConfig.category.parser && testConfig.parser.tests.paramParser)
{
   const paramParser = new ParamParser();

   /** @test {ParamParser} */
   describe('ParamParser:', () =>
   {
      /** @test {ParamParser#parseParamValue} */
      it('parse param value.', () =>
      {
         const value = '{number} p1 this is desc';
         const { typeText, paramName, paramDesc } = paramParser.parseParamValue(value);

         assert.equal(typeText, 'number');
         assert.equal(paramName, 'p1');
         assert.equal(paramDesc, 'this is desc');
      });

      /** @test {ParamParser#parseParamValue} */
      it('parse param value with hyphen prefix.', () =>
      {
         const value = '{number} p1 - this is desc';
         const { typeText, paramName, paramDesc } = paramParser.parseParamValue(value);

         assert.equal(typeText, 'number');
         assert.equal(paramName, 'p1');
         assert.equal(paramDesc, 'this is desc');
      });

      /** @test {ParamParser#parseParamValue} */
      it('parse param value without param name', () =>
      {
         const value = '{number} this is desc';
         const { typeText, paramDesc } = paramParser.parseParamValue(value, { type: true, name: false, desc: true });

         assert.equal(typeText, 'number');
         assert.equal(paramDesc, 'this is desc');
      });

      /** @test {ParamParser#parseParamValue} */
      it('parse param value without param desc', () =>
      {
         const value = '{number} p1';
         const { typeText, paramName } = paramParser.parseParamValue(value, { type: true, name: true, desc: false });

         assert.equal(typeText, 'number');
         assert.equal(paramName, 'p1');
      });

      /** @test {ParamParser#parseParamValue} */
      it('parse param value with complex', () =>
      {
         const value = '{!(number|string|boolean[])} [p1=10] this is desc';
         const { typeText, paramName, paramDesc } = paramParser.parseParamValue(value);

         assert.equal(typeText, '!(number|string|boolean[])');
         assert.equal(paramName, '[p1=10]');
         assert.equal(paramDesc, 'this is desc');
      });

      /** @test {ParamParser#parseParam} */
      /** @test {ParamParser#parseParamValue} */
      /** @test {ParamParser#parseParamFromValue} */
      it('parse param.', () =>
      {
         const value = '{number} p1 this is desc';

         const result = paramParser.parseParamFromValue(paramParser.parseParamValue(value));

         assert.deepEqual(result, {
            nullable: null,
            types: ['number'],
            spread: false,
            optional: false,
            name: 'p1',
            description: 'this is desc'
         });

         const result2 = paramParser.parseParam(value);

         assert.deepEqual(result2, {
            nullable: null,
            types: ['number'],
            spread: false,
            optional: false,
            name: 'p1',
            description: 'this is desc'
         });
      });

      /** @test {ParamParser#parseParam} */
      /** @test {ParamParser#parseParamValue} */
      /** @test {ParamParser#parseParamFromValue} */
      it('parse param with complex.', () =>
      {
         const value = '{?(number|string|boolean[])} [p1] this is desc';

         const result = paramParser.parseParamFromValue(paramParser.parseParamValue(value));

         assert.deepEqual(result, {
            nullable: true,
            types: ['number', 'string', 'boolean[]'],
            spread: false,
            optional: true,
            name: 'p1',
            description: 'this is desc'
         });

         const result2 = paramParser.parseParam(value);

         assert.deepEqual(result2, {
            nullable: true,
            types: ['number', 'string', 'boolean[]'],
            spread: false,
            optional: true,
            name: 'p1',
            description: 'this is desc'
         });
      });

      /** @test {ParamParser#parseParamValue} */
      /** @test {ParamParser#parseParamFromValue} */
      it('parse param with object ({}) as default.', () =>
      {
         const value = '{!(number|string|boolean[])} [p1={}] this is desc';

         const result = paramParser.parseParamFromValue(paramParser.parseParamValue(value));

         assert.deepEqual(result, {
            nullable: false,
            types: ['number', 'string', 'boolean[]'],
            spread: false,
            optional: true,
            name: 'p1',
            description: 'this is desc',
            defaultValue: '{}',
            defaultRaw: {}
         });

         const result2 = paramParser.parseParamFromValue(paramParser.parseParamValue(value));

         assert.deepEqual(result2, {
            nullable: false,
            types: ['number', 'string', 'boolean[]'],
            spread: false,
            optional: true,
            name: 'p1',
            description: 'this is desc',
            defaultValue: '{}',
            defaultRaw: {}
         });
      });

      /** @test {ParamParser#parseParamValue} */
      /** @test {ParamParser#parseParamFromValue} */
      it('parse param with complex.', () =>
      {
         const value = '{...number} [p1=[10,20,30]] this is desc';

         const result = paramParser.parseParamFromValue(paramParser.parseParamValue(value));

         assert.deepEqual(result, {
            nullable: null,
            types: ['...number'],
            spread: true,
            optional: true,
            name: 'p1',
            description: 'this is desc',
            defaultValue: '[10,20,30]',
            defaultRaw: [10, 20, 30]
         });

         const result2 = paramParser.parseParamFromValue(paramParser.parseParamValue(value));

         assert.deepEqual(result2, {
            nullable: null,
            types: ['...number'],
            spread: true,
            optional: true,
            name: 'p1',
            description: 'this is desc',
            defaultValue: '[10,20,30]',
            defaultRaw: [10, 20, 30]
         });
      });

      /** @test {ParamParser#parseParamValue} */
      /** @test {ParamParser#parseParamFromValue} */
      it('parse param even if description has {}.', () =>
      {
         const value = '{number} p1 foo {a: number} bar';

         const result = paramParser.parseParamFromValue(paramParser.parseParamValue(value));

         assert.deepEqual(result, {
            nullable: null,
            types: ['number'],
            spread: false,
            optional: false,
            name: 'p1',
            description: 'foo {a: number} bar'
         });

         const result2 = paramParser.parseParamFromValue(paramParser.parseParamValue(value));

         assert.deepEqual(result2, {
            nullable: null,
            types: ['number'],
            spread: false,
            optional: false,
            name: 'p1',
            description: 'foo {a: number} bar'
         });
      });

      /** @test {ParamParser#parseParam} */
      /** @test {ParamParser#parseParamValue} */
      /** @test {ParamParser#parseParamFromValue} */
      it('throws error when empty type.', () =>
      {
         const value = '{} foo bar';

         try
         {
            paramParser.parseParamFromValue(paramParser.parseParamValue(value));
         }
         catch (err)
         {
            assert.equal(err.message, 'Empty Type found name=foo desc=bar');

            return;
         }

         try
         {
            paramParser.parseParam(value);
         }
         catch (err)
         {
            assert.equal(err.message, 'Empty Type found name=foo desc=bar');

            return;
         }

         assert(false);
      });
   });
}
