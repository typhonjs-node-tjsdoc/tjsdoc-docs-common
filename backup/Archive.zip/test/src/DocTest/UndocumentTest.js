import { assert } from '../util.js';
import testConfig from '../testconfig.js';

if (testConfig.category.doc && testConfig.doc.tests.tagsUnknown)
{
   /**
    * @test {DocFactory#_traverseComments}
    * @test {AbstractDoc#@desc}
    * @test {DocResolver#_resolveUndocumentIdentifier}
    */
   describe('test undocument', () =>
   {
      it('has undocument tag.', () =>
      {
         const doc = global.$$tjsdoc_db.find({ name: 'TestUndocumentDefinition', undocument: true })[0];

         assert.equal(doc.undocument, true);
      });
   });
}
