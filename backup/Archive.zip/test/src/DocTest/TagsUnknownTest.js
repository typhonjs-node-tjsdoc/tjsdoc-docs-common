import { assert } from '../util.js';
import testConfig from '../testconfig.js';

if (testConfig.category.doc && testConfig.doc.tests.tagsUnknown)
{
   /** @test {AbstractDoc#@_unknown} */
   describe('test unknown tags', () =>
   {
      it('has unknown tags (TestUnknownDefinition).', () =>
      {
         const doc = global.$$tjsdoc_db.find({ name: 'TestUnknownDefinition' })[0];

         assert.equal(doc.tagsUnknown.length, 1);

         const index = doc.tagsUnknown.findIndex((tag) => tag.tagName === '@foobar');

         assert.isAtLeast(index, 0);
         assert.equal(doc.tagsUnknown[index].tagValue, 'this is unknown tag.');
      });
   });
}
