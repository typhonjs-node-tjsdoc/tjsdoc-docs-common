import { readDoc }   from './../../../util.js';
import testConfig    from '../../../testconfig.js';

if (testConfig.category.html && testConfig.html.category.document && testConfig.html.document.category.export)
{
   /** @test {DocResolver#_resolveNecessary} */
   describe('TestExportExtendsInner', () =>
   {
      it('is documented.', () =>
      {
         readDoc('class/src/Export/Extends.js~TestExportExtendsInner.html');
      });
   });
}
