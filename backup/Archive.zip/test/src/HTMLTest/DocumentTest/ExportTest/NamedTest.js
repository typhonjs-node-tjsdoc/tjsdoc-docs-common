import { readDoc, assert } from './../../../util.js';
import testConfig          from '../../../testconfig.js';

if (testConfig.category.html && testConfig.html.category.document && testConfig.html.document.category.export)
{
   /**
    * @test {AbstractDoc#@_export}
    * @test {ClassDocBuilder@_buildClassDoc}
    */
   describe('TestExportNamed', () =>
   {
      it('has named import path.', () =>
      {
         const doc = readDoc('class/src/Export/Named.js~TestExportNamed.html');

         assert.includes(doc, '.header-notice [data-ice="importPath"]',
          `import {TestExportNamed} from 'esdoc-test-fixture/src/Export/Named.js'`);
      });
   });
}
