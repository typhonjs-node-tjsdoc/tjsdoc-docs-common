import TyphonEvents  from 'backbone-esnext-events/src/TyphonEvents';
import { assert }    from 'chai';
import PluginManager from 'typhonjs-plugin-manager';

import testConfig    from '../testConfig.js';

const s_TEST = { source: 'src', destination: 'docs' };

const s_TEST_BASIC_FILE = { 'extends': './node_modules/tjsdoc-tests/config/basic.json' };
const s_TEST_BASIC_NPM = { 'extends': 'tjsdoc-tests/config/basic.json' };

const s_TEST_EXTENDS_BASIC_FILE = { 'extends': ['./node_modules/tjsdoc-tests/config/extends/extends-basic.json'] };
const s_TEST_EXTENDS_BASIC_FILE_ARRAY = { 'extends': './node_modules/tjsdoc-tests/config/extends/extends-basic-array.js' };
const s_TEST_EXTENDS_BASIC_FILE_CIRCULAR = { 'extends': './node_modules/tjsdoc-tests/config/extends/extends-basic-circular-0.json' };
const s_TEST_EXTENDS_BASIC_NPM = { 'extends': 'tjsdoc-tests/config/extends/extends-basic.json' };
const s_TEST_EXTENDS_BASIC_NPM_ARRAY = { 'extends': 'tjsdoc-tests/config/extends/extends-basic-array.js' };
const s_TEST_EXTENDS_BASIC_NPM_CIRCULAR = { 'extends': 'tjsdoc-tests/config/extends/extends-basic-circular-0.json' };

const s_TEST_EXTENDS_SUBDIR_FILE = { 'extends': ['./node_modules/tjsdoc-tests/config/extends/extends-subdir.json'] };
const s_TEST_EXTENDS_SUBDIR_FILE_CIRCULAR = { 'extends': ['./node_modules/tjsdoc-tests/config/extends/extends-subdir-circular.json'] };
const s_TEST_EXTENDS_SUBDIR_NPM = { 'extends': 'tjsdoc-tests/config/extends/extends-subdir.json' };
const s_TEST_EXTENDS_SUBDIR_NPM_CIRCULAR = { 'extends': ['tjsdoc-tests/config/extends/extends-subdir-circular.json'] };

const s_TEST_EXTENDS_SUBNPM = { 'extends': 'tjsdoc-tests/config/extends/extends-subnpm.json' };
const s_TEST_EXTENDS_SUBNPM_CIRCULAR = { 'extends': 'tjsdoc-tests/config/extends/extends-subnpm-circular.json' };

const s_VERIFY = `{"source":"src","destination":"docs","access":["public","protected","private"],"compressFormat":"tar.gz","excludes":[],"index":"./README.md","logLevel":"info","package":"./package.json","plugins":[],"scripts":[],"styles":[],"autoPrivate":true,"builtinVirtual":true,"compactData":false,"compressData":false,"compressOutput":false,"copyPackage":true,"coverage":true,"debug":false,"emptyDestination":false,"includeSource":true,"lint":true,"outputASTData":false,"outputDocData":false,"separateDataArchives":false,"undocumentIdentifier":true,"unexportIdentifier":false,"includes":["\\\\.(js|jsx|jsm)$"],"pathExtensions":[".js",".jsx",".jsm"]}`;
const s_VERIFY_BASIC_FILE = `{"source":"src","destination":"docs","access":["public","protected","private"],"compressFormat":"tar.gz","excludes":[],"index":"./README.md","logLevel":"info","package":"./package.json","plugins":[],"scripts":[],"styles":[],"autoPrivate":true,"builtinVirtual":true,"compactData":false,"compressData":false,"compressOutput":false,"copyPackage":true,"coverage":true,"debug":false,"emptyDestination":false,"includeSource":true,"lint":true,"outputASTData":false,"outputDocData":false,"separateDataArchives":false,"undocumentIdentifier":true,"unexportIdentifier":false,"includes":["\\\\.(js|jsx|jsm)$"],"pathExtensions":[".js",".jsx",".jsm"]}`;
const s_VERIFY_BASIC_NPM = `{"source":"src","destination":"docs","extends":["tjsdoc-tests/config/basic.json"],"access":["public","protected","private"],"compressFormat":"tar.gz","excludes":[],"index":"./README.md","logLevel":"info","package":"./package.json","plugins":[],"scripts":[],"styles":[],"autoPrivate":true,"builtinVirtual":true,"compactData":false,"compressData":false,"compressOutput":false,"copyPackage":true,"coverage":true,"debug":false,"emptyDestination":false,"includeSource":true,"lint":true,"outputASTData":false,"outputDocData":false,"separateDataArchives":false,"undocumentIdentifier":true,"unexportIdentifier":false,"includes":["\\\\.(js|jsx|jsm)$"],"pathExtensions":[".js",".jsx",".jsm"]}`;

const s_VERIFY_EXTENDS_BASIC_FILE = `{"extends-level-2":true,"plugins":[{"name":"plugin-level2","target":"level1-target"},{"name":"plugin-level1","target":"level0-target"},{"name":"plugin-basic"},{"name":"plugin-level0","target":"basic-target"}],"extends-level-1":true,"extends-level-0":true,"source":"src","destination":"docs","extends-basic":true,"access":["public","protected","private"],"compressFormat":"tar.gz","excludes":[],"index":"./README.md","logLevel":"info","package":"./package.json","scripts":[],"styles":[],"autoPrivate":true,"builtinVirtual":true,"compactData":false,"compressData":false,"compressOutput":false,"copyPackage":true,"coverage":true,"debug":false,"emptyDestination":false,"includeSource":true,"lint":true,"outputASTData":false,"outputDocData":false,"separateDataArchives":false,"undocumentIdentifier":true,"unexportIdentifier":false,"includes":["\\\\.(js|jsx|jsm)$"],"pathExtensions":[".js",".jsx",".jsm"]}`;
const s_VERIFY_EXTENDS_BASIC_FILE_ARRAY = `{"source":"src","destination":"docs","extends-level-2":true,"plugins":[{"name":"plugin-level0","target":"basic-target"},{"name":"plugin-basic"},{"name":"plugin-level1","target":"level0-target"},{"name":"plugin-level2","target":"level1-target"}],"extends-level-1":true,"extends-level-0":true,"extends-basic":true,"extends-basic-array":true,"access":["public","protected","private"],"compressFormat":"tar.gz","excludes":[],"index":"./README.md","logLevel":"info","package":"./package.json","scripts":[],"styles":[],"autoPrivate":true,"builtinVirtual":true,"compactData":false,"compressData":false,"compressOutput":false,"copyPackage":true,"coverage":true,"debug":false,"emptyDestination":false,"includeSource":true,"lint":true,"outputASTData":false,"outputDocData":false,"separateDataArchives":false,"undocumentIdentifier":true,"unexportIdentifier":false,"includes":["\\\\.(js|jsx|jsm)$"],"pathExtensions":[".js",".jsx",".jsm"]}`;
const s_VERIFY_EXTENDS_BASIC_FILE_CIRCULAR = `{"extends-basic-circular-1":true,"plugins":[{"name":"plugin-basic-circular1"},{"name":"plugin-basic-circular0"}],"source":"src","destination":"docs","extends-basic-circular-0":true,"access":["public","protected","private"],"compressFormat":"tar.gz","excludes":[],"index":"./README.md","logLevel":"info","package":"./package.json","scripts":[],"styles":[],"autoPrivate":true,"builtinVirtual":true,"compactData":false,"compressData":false,"compressOutput":false,"copyPackage":true,"coverage":true,"debug":false,"emptyDestination":false,"includeSource":true,"lint":true,"outputASTData":false,"outputDocData":false,"separateDataArchives":false,"undocumentIdentifier":true,"unexportIdentifier":false,"includes":["\\\\.(js|jsx|jsm)$"],"pathExtensions":[".js",".jsx",".jsm"]}`;
const s_VERIFY_EXTENDS_BASIC_NPM = `{"extends-level-2":true,"plugins":[{"name":"plugin-level2","target":"level1-target"},{"name":"plugin-level1","target":"level0-target"},{"name":"plugin-basic"},{"name":"plugin-level0","target":"basic-target"}],"extends-level-1":true,"extends-level-0":true,"source":"src","destination":"docs","extends-basic":true,"extends":["tjsdoc-tests/config/extends/extends-basic.json","tjsdoc-tests/config/extends/extends-basic-level-0.json","tjsdoc-tests/config/extends/extends-basic-level-1.json","tjsdoc-tests/config/extends/extends-basic-level-2.json"],"access":["public","protected","private"],"compressFormat":"tar.gz","excludes":[],"index":"./README.md","logLevel":"info","package":"./package.json","scripts":[],"styles":[],"autoPrivate":true,"builtinVirtual":true,"compactData":false,"compressData":false,"compressOutput":false,"copyPackage":true,"coverage":true,"debug":false,"emptyDestination":false,"includeSource":true,"lint":true,"outputASTData":false,"outputDocData":false,"separateDataArchives":false,"undocumentIdentifier":true,"unexportIdentifier":false,"includes":["\\\\.(js|jsx|jsm)$"],"pathExtensions":[".js",".jsx",".jsm"]}`;
const s_VERIFY_EXTENDS_BASIC_NPM_ARRAY = `{"source":"src","destination":"docs","extends-level-2":true,"plugins":[{"name":"plugin-level0","target":"basic-target"},{"name":"plugin-basic"},{"name":"plugin-level1","target":"level0-target"},{"name":"plugin-level2","target":"level1-target"}],"extends-level-1":true,"extends-level-0":true,"extends-basic":true,"extends-basic-array":true,"extends":["tjsdoc-tests/config/extends/extends-basic-array.json","tjsdoc-tests/config/extends/extends-basic.json","tjsdoc-tests/config/extends/extends-basic-level-0.json","tjsdoc-tests/config/extends/extends-basic-level-1.json","tjsdoc-tests/config/extends/extends-basic-level-2.json","tjsdoc-tests/config/basic.json"],"access":["public","protected","private"],"compressFormat":"tar.gz","excludes":[],"index":"./README.md","logLevel":"info","package":"./package.json","scripts":[],"styles":[],"autoPrivate":true,"builtinVirtual":true,"compactData":false,"compressData":false,"compressOutput":false,"copyPackage":true,"coverage":true,"debug":false,"emptyDestination":false,"includeSource":true,"lint":true,"outputASTData":false,"outputDocData":false,"separateDataArchives":false,"undocumentIdentifier":true,"unexportIdentifier":false,"includes":["\\\\.(js|jsx|jsm)$"],"pathExtensions":[".js",".jsx",".jsm"]}`;
const s_VERIFY_EXTENDS_BASIC_NPM_CIRCULAR = `{"extends-basic-circular-1":true,"plugins":[{"name":"plugin-basic-circular1"},{"name":"plugin-basic-circular0"}],"source":"src","destination":"docs","extends-basic-circular-0":true,"extends":["tjsdoc-tests/config/extends/extends-basic-circular-0.json","tjsdoc-tests/config/extends/extends-basic-circular-1.json"],"access":["public","protected","private"],"compressFormat":"tar.gz","excludes":[],"index":"./README.md","logLevel":"info","package":"./package.json","scripts":[],"styles":[],"autoPrivate":true,"builtinVirtual":true,"compactData":false,"compressData":false,"compressOutput":false,"copyPackage":true,"coverage":true,"debug":false,"emptyDestination":false,"includeSource":true,"lint":true,"outputASTData":false,"outputDocData":false,"separateDataArchives":false,"undocumentIdentifier":true,"unexportIdentifier":false,"includes":["\\\\.(js|jsx|jsm)$"],"pathExtensions":[".js",".jsx",".jsm"]}`;

const s_VERIFY_EXTENDS_SUBDIR_FILE = `{"extends-subdir-level-2":true,"plugins":[{"name":"plugin-level2","target":"level1-target"},{"name":"plugin-level0"},{"name":"plugin-level1","target":"level0-target"},{"name":"plugin-subdir"},{"name":"plugin-subdir2"}],"extends-subdir-level-1":true,"extends-subdir-level-0":true,"extends-subdir":true,"access":["public","protected","private"],"compressFormat":"tar.gz","excludes":[],"index":"./README.md","logLevel":"info","package":"./package.json","scripts":[],"styles":[],"autoPrivate":true,"builtinVirtual":true,"compactData":false,"compressData":false,"compressOutput":false,"copyPackage":true,"coverage":true,"debug":false,"emptyDestination":false,"includeSource":true,"lint":true,"outputASTData":false,"outputDocData":false,"separateDataArchives":false,"undocumentIdentifier":true,"unexportIdentifier":false,"includes":["\\\\.(js|jsx|jsm)$"],"pathExtensions":[".js",".jsx",".jsm"]}`;
const s_VERIFY_EXTENDS_SUBDIR_FILE_CIRCULAR = `{"extends-subdir-level-2":true,"plugins":[{"name":"plugin-level2","target":"level1-target"},{"name":"plugin-level0"},{"name":"plugin-level1","target":"level0-target"},{"name":"plugin-subdir"},{"name":"plugin-subdir2"}],"extends-subdir-level-1":true,"extends-subdir-level-0":true,"extends-subdir":true,"access":["public","protected","private"],"compressFormat":"tar.gz","excludes":[],"index":"./README.md","logLevel":"info","package":"./package.json","scripts":[],"styles":[],"autoPrivate":true,"builtinVirtual":true,"compactData":false,"compressData":false,"compressOutput":false,"copyPackage":true,"coverage":true,"debug":false,"emptyDestination":false,"includeSource":true,"lint":true,"outputASTData":false,"outputDocData":false,"separateDataArchives":false,"undocumentIdentifier":true,"unexportIdentifier":false,"includes":["\\\\.(js|jsx|jsm)$"],"pathExtensions":[".js",".jsx",".jsm"]}`;
const s_VERIFY_EXTENDS_SUBDIR_NPM = `{"extends-subdir-level-2":true,"plugins":[{"name":"plugin-level2","target":"level1-target"},{"name":"plugin-level0"},{"name":"plugin-level1","target":"level0-target"},{"name":"plugin-subdir"},{"name":"plugin-subdir2"}],"extends-subdir-level-1":true,"extends-subdir-level-0":true,"extends-subdir":true,"extends":["tjsdoc-tests/config/extends/extends-subdir.json","tjsdoc-tests/config/extends/level0/extends-subdir-level-0.json","tjsdoc-tests/config/extends/level0/level1/extends-subdir-level-1.json","tjsdoc-tests/config/extends/level0/level1/level2/extends-subdir-level-2.json"],"access":["public","protected","private"],"compressFormat":"tar.gz","excludes":[],"index":"./README.md","logLevel":"info","package":"./package.json","scripts":[],"styles":[],"autoPrivate":true,"builtinVirtual":true,"compactData":false,"compressData":false,"compressOutput":false,"copyPackage":true,"coverage":true,"debug":false,"emptyDestination":false,"includeSource":true,"lint":true,"outputASTData":false,"outputDocData":false,"separateDataArchives":false,"undocumentIdentifier":true,"unexportIdentifier":false,"includes":["\\\\.(js|jsx|jsm)$"],"pathExtensions":[".js",".jsx",".jsm"]}`;
const s_VERIFY_EXTENDS_SUBDIR_NPM_CIRCULAR = `{"extends-subdir-level-2":true,"plugins":[{"name":"plugin-level2","target":"level1-target"},{"name":"plugin-level0"},{"name":"plugin-level1","target":"level0-target"},{"name":"plugin-subdir"},{"name":"plugin-subdir2"}],"extends-subdir-level-1":true,"extends-subdir-level-0":true,"extends-subdir":true,"extends":["tjsdoc-tests/config/extends/extends-subdir-circular.json","tjsdoc-tests/config/extends/level0/extends-subdir-level-0.json","tjsdoc-tests/config/extends/level0/level1/extends-subdir-level-1.json","tjsdoc-tests/config/extends/level0/level1/level2/extends-subdir-level-2.json"],"access":["public","protected","private"],"compressFormat":"tar.gz","excludes":[],"index":"./README.md","logLevel":"info","package":"./package.json","scripts":[],"styles":[],"autoPrivate":true,"builtinVirtual":true,"compactData":false,"compressData":false,"compressOutput":false,"copyPackage":true,"coverage":true,"debug":false,"emptyDestination":false,"includeSource":true,"lint":true,"outputASTData":false,"outputDocData":false,"separateDataArchives":false,"undocumentIdentifier":true,"unexportIdentifier":false,"includes":["\\\\.(js|jsx|jsm)$"],"pathExtensions":[".js",".jsx",".jsm"]}`;

const s_VERIFY_EXTENDS_SUBNPM = `{"extends-subnpm-level-2":true,"plugins":[{"name":"plugin-level2","target":"level1-target"},{"name":"plugin-level0"},{"name":"plugin-level1","target":"level0-target"},{"name":"plugin-subnpm"},{"name":"plugin-subnpm2"}],"extends-subnpm-level-1":true,"extends-subnpm-level-0":true,"extends-subnpm":true,"extends":["tjsdoc-tests/config/extends/extends-subnpm.json","tjsdoc-tests/config/extends/level0/extends-subnpm-level-0.json","tjsdoc-tests/config/extends/level0/level1/extends-subnpm-level-1.json","tjsdoc-tests/config/extends/level0/level1/level2/extends-subnpm-level-2.json"],"access":["public","protected","private"],"compressFormat":"tar.gz","excludes":[],"index":"./README.md","logLevel":"info","package":"./package.json","scripts":[],"styles":[],"autoPrivate":true,"builtinVirtual":true,"compactData":false,"compressData":false,"compressOutput":false,"copyPackage":true,"coverage":true,"debug":false,"emptyDestination":false,"includeSource":true,"lint":true,"outputASTData":false,"outputDocData":false,"separateDataArchives":false,"undocumentIdentifier":true,"unexportIdentifier":false,"includes":["\\\\.(js|jsx|jsm)$"],"pathExtensions":[".js",".jsx",".jsm"]}`;
const s_VERIFY_EXTENDS_SUBNPM_CIRCULAR = `{"extends-subnpm-level-2":true,"plugins":[{"name":"plugin-level2","target":"level1-target"},{"name":"plugin-level0"},{"name":"plugin-level1","target":"level0-target"},{"name":"plugin-subnpm"},{"name":"plugin-subnpm2"}],"extends-subnpm-level-1":true,"extends-subnpm-level-0":true,"extends-subnpm":true,"extends":["tjsdoc-tests/config/extends/extends-subnpm-circular.json","tjsdoc-tests/config/extends/level0/extends-subnpm-circular-level-0.json","tjsdoc-tests/config/extends/level0/level1/extends-subnpm-circular-level-1.json","tjsdoc-tests/config/extends/level0/level1/level2/extends-subnpm-circular-level-2.json"],"access":["public","protected","private"],"compressFormat":"tar.gz","excludes":[],"index":"./README.md","logLevel":"info","package":"./package.json","scripts":[],"styles":[],"autoPrivate":true,"builtinVirtual":true,"compactData":false,"compressData":false,"compressOutput":false,"copyPackage":true,"coverage":true,"debug":false,"emptyDestination":false,"includeSource":true,"lint":true,"outputASTData":false,"outputDocData":false,"separateDataArchives":false,"undocumentIdentifier":true,"unexportIdentifier":false,"includes":["\\\\.(js|jsx|jsm)$"],"pathExtensions":[".js",".jsx",".jsm"]}`;

if (testConfig.category.utils && testConfig.utils.tests.configResolver)
{
   const eventbus = new TyphonEvents();

   const pluginManager = new PluginManager({ eventbus });

   pluginManager.add({ name: './src/babylon/plugin.js' });

   /** @test {ConfigResolver} */
   describe('ConfigResolver', () =>
   {
      it('throws on no data', () =>
      {
         assert.throws(() => eventbus.trigger('tjsdoc:config:resolve'));
      });

      it('sets default values', () =>
      {
         const config = eventbus.triggerSync('tjsdoc:config:resolve', s_TEST);

         // Must check publisher separately as it is an absolute path; then delete it.
         assert(config.publisher.endsWith('/publisher/publish.js'));
         delete config.publisher;

         assert.strictEqual(JSON.stringify(config), s_VERIFY);
      });

      it('basic resolve (file)', () =>
      {
         const config = eventbus.triggerSync('tjsdoc:config:resolve', s_TEST_BASIC_FILE);

         // Must check publisher separately as it is an absolute path; then delete it.
         assert(config.publisher.endsWith('/publisher/publish.js'));
         delete config.publisher;

         // Must delete extends array as it has resolved file names.
         assert.isArray(config.extends);
         assert.lengthOf(config.extends, 1);
         delete config.extends;

         assert.strictEqual(JSON.stringify(config), s_VERIFY_BASIC_FILE);
      });

      it('basic resolve (module)', () =>
      {
         const config = eventbus.triggerSync('tjsdoc:config:resolve', s_TEST_BASIC_NPM);

         // Must check publisher separately as it is an absolute path; then delete it.
         assert(config.publisher.endsWith('/publisher/publish.js'));
         delete config.publisher;

         assert.strictEqual(JSON.stringify(config), s_VERIFY_BASIC_NPM);
      });

      it('basic extends resolve (file)', () =>
      {
         const config = eventbus.triggerSync('tjsdoc:config:resolve', s_TEST_EXTENDS_BASIC_FILE);

         // Must check publisher separately as it is an absolute path; then delete it.
         assert(config.publisher.endsWith('/publisher/publish.js'));
         delete config.publisher;

         // Must delete extends array as it has resolved file names.
         assert.isArray(config.extends);
         assert.lengthOf(config.extends, 4);
         delete config.extends;

         assert.strictEqual(JSON.stringify(config), s_VERIFY_EXTENDS_BASIC_FILE);
      });

      it('basic array extends resolve (file)', () =>
      {
         const config = eventbus.triggerSync('tjsdoc:config:resolve', s_TEST_EXTENDS_BASIC_FILE_ARRAY);

         // Must check publisher separately as it is an absolute path; then delete it.
         assert(config.publisher.endsWith('/publisher/publish.js'));
         delete config.publisher;

         // Must delete extends array as it has resolved file names.
         assert.isArray(config.extends);
         assert.lengthOf(config.extends, 6);
         delete config.extends;

         assert.strictEqual(JSON.stringify(config), s_VERIFY_EXTENDS_BASIC_FILE_ARRAY);
      });

      it('basic circular resolve (file)', () =>
      {
         const config = eventbus.triggerSync('tjsdoc:config:resolve', s_TEST_EXTENDS_BASIC_FILE_CIRCULAR);

         // Must check publisher separately as it is an absolute path; then delete it.
         assert(config.publisher.endsWith('/publisher/publish.js'));
         delete config.publisher;

         // Must delete extends array as it has resolved file names.
         assert.isArray(config.extends);
         assert.lengthOf(config.extends, 2);
         delete config.extends;

         assert.strictEqual(JSON.stringify(config), s_VERIFY_EXTENDS_BASIC_FILE_CIRCULAR);
      });

      it('basic extends resolve (module)', () =>
      {
         const config = eventbus.triggerSync('tjsdoc:config:resolve', s_TEST_EXTENDS_BASIC_NPM);

         // Must check publisher separately as it is an absolute path; then delete it.
         assert(config.publisher.endsWith('/publisher/publish.js'));
         delete config.publisher;

         assert.strictEqual(JSON.stringify(config), s_VERIFY_EXTENDS_BASIC_NPM);
      });

      it('basic array extends resolve (module)', () =>
      {
         const config = eventbus.triggerSync('tjsdoc:config:resolve', s_TEST_EXTENDS_BASIC_NPM_ARRAY);

         // Must check publisher separately as it is an absolute path; then delete it.
         assert(config.publisher.endsWith('/publisher/publish.js'));
         delete config.publisher;

         //console.log('!! config: ' + JSON.stringify(config));

         assert.strictEqual(JSON.stringify(config), s_VERIFY_EXTENDS_BASIC_NPM_ARRAY);
      });

      it('basic circular extends resolve (module)', () =>
      {
         const config = eventbus.triggerSync('tjsdoc:config:resolve', s_TEST_EXTENDS_BASIC_NPM_CIRCULAR);

         // Must check publisher separately as it is an absolute path; then delete it.
         assert(config.publisher.endsWith('/publisher/publish.js'));
         delete config.publisher;

         assert.strictEqual(JSON.stringify(config), s_VERIFY_EXTENDS_BASIC_NPM_CIRCULAR);
      });

      it('subdir extends resolve (file)', () =>
      {
         const config = eventbus.triggerSync('tjsdoc:config:resolve', s_TEST_EXTENDS_SUBDIR_FILE);

         // Must check publisher separately as it is an absolute path; then delete it.
         assert(config.publisher.endsWith('/publisher/publish.js'));
         delete config.publisher;

         // Must delete extends array as it has resolved file names.
         assert.isArray(config.extends);
         assert.lengthOf(config.extends, 4);
         delete config.extends;

         assert.strictEqual(JSON.stringify(config), s_VERIFY_EXTENDS_SUBDIR_FILE);
      });

      it('subdir circular extends resolve (file)', () =>
      {
         const config = eventbus.triggerSync('tjsdoc:config:resolve', s_TEST_EXTENDS_SUBDIR_FILE_CIRCULAR);

         // Must check publisher separately as it is an absolute path; then delete it.
         assert(config.publisher.endsWith('/publisher/publish.js'));
         delete config.publisher;

         // Must delete extends array as it has resolved file names.
         assert.isArray(config.extends);
         assert.lengthOf(config.extends, 4);
         delete config.extends;

         assert.strictEqual(JSON.stringify(config), s_VERIFY_EXTENDS_SUBDIR_FILE_CIRCULAR);
      });

      it('subdir extends resolve (module)', () =>
      {
         const config = eventbus.triggerSync('tjsdoc:config:resolve', s_TEST_EXTENDS_SUBDIR_NPM);

         // Must check publisher separately as it is an absolute path; then delete it.
         assert(config.publisher.endsWith('/publisher/publish.js'));
         delete config.publisher;

         assert.strictEqual(JSON.stringify(config), s_VERIFY_EXTENDS_SUBDIR_NPM);
      });

      it('subdir circular extends resolve (module)', () =>
      {
         const config = eventbus.triggerSync('tjsdoc:config:resolve', s_TEST_EXTENDS_SUBDIR_NPM_CIRCULAR);

         // Must check publisher separately as it is an absolute path; then delete it.
         assert(config.publisher.endsWith('/publisher/publish.js'));
         delete config.publisher;

         assert.strictEqual(JSON.stringify(config), s_VERIFY_EXTENDS_SUBDIR_NPM_CIRCULAR);
      });

      it('subnpm extends resolve (module)', () =>
      {
         const config = eventbus.triggerSync('tjsdoc:config:resolve', s_TEST_EXTENDS_SUBNPM);

         // Must check publisher separately as it is an absolute path; then delete it.
         assert(config.publisher.endsWith('/publisher/publish.js'));
         delete config.publisher;

         assert.strictEqual(JSON.stringify(config), s_VERIFY_EXTENDS_SUBNPM);
      });

      it('subnpm circular extends resolve (module)', () =>
      {
         const config = eventbus.triggerSync('tjsdoc:config:resolve', s_TEST_EXTENDS_SUBNPM_CIRCULAR);

         // Must check publisher separately as it is an absolute path; then delete it.
         assert(config.publisher.endsWith('/publisher/publish.js'));
         delete config.publisher;

         assert.strictEqual(JSON.stringify(config), s_VERIFY_EXTENDS_SUBNPM_CIRCULAR);
      });
   });
}
