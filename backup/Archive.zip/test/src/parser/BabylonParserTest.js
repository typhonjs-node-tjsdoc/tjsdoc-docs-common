import TyphonEvents  from 'backbone-esnext-events/src/TyphonEvents';
import { assert }    from 'chai';
import PluginManager from 'typhonjs-plugin-manager';

import testConfig    from '../testConfig.js';

if (testConfig.category.parser && testConfig.parser.tests.babylonParser)
{
   const eventbus = new TyphonEvents();

   const pluginManager = new PluginManager({ eventbus });

   // Add BabylonParser plugin.
   pluginManager.add({ name: './src/babylon/parser/BabylonParser.js' });

   /** @test {BabylonParser} */
   describe('BabylonParser', () =>
   {
      it('can parse "do expressions"', () =>
      {
         const ast = eventbus.triggerSync('tjsdoc:parse:file', './test/fixture/syntax/DoExpressions.js');
         assert(ast.program.sourceType === 'module');
      });

      it('can parse "function bind"', () =>
      {
         const ast = eventbus.triggerSync('tjsdoc:parse:file', './test/fixture/syntax/FunctionBind.js');
         assert(ast.program.sourceType === 'module');
      });

      it('can parse "function sent"', () =>
      {
         const ast = eventbus.triggerSync('tjsdoc:parse:file', './test/fixture/syntax/FunctionSent.js');
         assert(ast.program.sourceType === 'module');
      });

      it('can parse "async generators"', () =>
      {
         const ast = eventbus.triggerSync('tjsdoc:parse:file', './test/fixture/syntax/AsyncGenerators.js');
         assert(ast.program.sourceType === 'module');
      });

      it('can parse "export extensions"', () =>
      {
         const ast = eventbus.triggerSync('tjsdoc:parse:file', './test/fixture/syntax/ExportExtensions.js');
         assert(ast.program.sourceType === 'module');
      });

      it('can parse "dynamic import"', () =>
      {
         const ast = eventbus.triggerSync('tjsdoc:parse:file', './test/fixture/syntax/DynamicImport.js');
         assert(ast.program.sourceType === 'script');
      });

      it('throws with no code to parse', () =>
      {
         assert.throw(() => eventbus.triggerSync('tjsdoc:parse:code'));
      });

      it('throws with no file to parse', () =>
      {
         assert.throw(() => eventbus.triggerSync('tjsdoc:parse:file'));
      });
   });
}
