import fs         from 'fs';

import DocDB      from '../../../src/common/doc/utils/DocDB.js';

import { assert } from '../util.js';
import testConfig from '../testConfig.js';

if (testConfig.category.doc && testConfig.doc.tests.tagsUnknown)
{
   /**
    * @test {DocFactory#_traverseComments}
    * @test {AbstractDoc#@desc}
    * @test {DocResolver#_resolveUndocumentIdentifier}
    */
   describe('test undocument', () =>
   {
      it('has undocument tag.', () =>
      {
         const docDB = new DocDB(JSON.parse(fs.readFileSync('./test/fixture/dest/esdoc/docData.json')));

         const doc = docDB.find({ name: 'TestUndocumentDefinition', undocument: true })[0];

         assert.equal(doc.undocument, true);
      });
   });
}
