import DocDB            from 'tjsdoc-runtime-common/src/doc/utils/DocDB.js';

import { assert, Util } from '../util.js';
import testConfig       from '../testConfig.js';

if (testConfig.category.doc && testConfig.doc.tests.undocument)
{
   for (const target of testConfig.targets)
   {
      /**
       * @test {DocFactory#_traverseComments}
       * @test {AbstractDoc#@desc}
       * @test {DocResolver#_resolveUndocumentIdentifier}
       */
      describe('test undocument', () =>
      {
         it('has undocument tag.', () =>
         {
            const docDB = new DocDB(Util.readJSON(target.name, 'docData.json'));

            const doc = docDB.find({ name: 'TestUndocumentDefinition', undocument: true })[0];

            assert.equal(doc.undocument, true);
         });
      });
   }
}
