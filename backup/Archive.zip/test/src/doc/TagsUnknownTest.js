import fs         from 'fs';

import DocDB      from '../../../src/common/doc/utils/DocDB.js';

import { assert } from '../util.js';
import testConfig from '../testConfig.js';

if (testConfig.category.doc && testConfig.doc.tests.tagsUnknown)
{
   /** @test {AbstractDoc#@_unknown} */
   describe('test unknown tags', () =>
   {
      it('has unknown tags (TestUnknownDefinition).', () =>
      {
         const docDB = new DocDB(JSON.parse(fs.readFileSync('./test/fixture/dest/esdoc/docData.json')));

         const doc = docDB.find({ name: 'TestUnknownDefinition' })[0];

         assert.equal(doc.tagsUnknown.length, 1);

         const index = doc.tagsUnknown.findIndex((tag) => tag.tagName === '@foobar');

         assert.isAtLeast(index, 0);
         assert.equal(doc.tagsUnknown[index].tagValue, 'this is unknown tag.');
      });
   });
}
