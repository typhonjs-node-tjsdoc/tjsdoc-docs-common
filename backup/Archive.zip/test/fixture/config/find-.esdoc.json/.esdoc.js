module.exports = {
  "source": "../../package/src",
  "destination": "../../dest/find-.esdoc.js",
  "access": ["public", "protected"],
  "includes": ["Access/.*\\.js"],
  "index": "../../package/README.md",
  "package": ".../../package/package.json"
};
