module.exports = {
  "source": "../../package/src",
  "destination": "../../dest/find-.esdoc.js",
  "access": ["public", "protected"],
  "includes": ["access/.*\\.js"],
  "index": "../../package/README.md",
  "package": "../../package/package.json"
};
