module.exports = {
  "source": "../../package/src",
  "destination": "../../dest/find-.tjsdocrc.js",
  "access": ["public", "protected"],
  "includes": ["access/.*\\.js"],
  "index": "../../package/README.md",
  "package": "../../package/package.json"
};
