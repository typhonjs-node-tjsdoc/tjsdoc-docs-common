/* eslint-disable */
/**
 * This is TestDestructuringObjectDefault.
 */
export default class TestGuessObjectDestructureDefault
{
   method1({ some, ...rest } = {}) {}

   method2() {}
}
