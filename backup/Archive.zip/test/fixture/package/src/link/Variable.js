/**
 * this is testLinkVariable.
 * link to {@link TestLinkClass}
 * @type {number}
 */
export const testLinkVariable = 123;
