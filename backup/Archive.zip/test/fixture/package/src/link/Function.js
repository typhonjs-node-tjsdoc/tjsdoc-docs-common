/**
 * this is testLinkFunction.
 * link to {@link TestLinkClass}
 * link to {@link TestLinkClass#p1}
 * link to {@link TestLinkClass#method1}
 */
export default function testLinkFunction() {}
