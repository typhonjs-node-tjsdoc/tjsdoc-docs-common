/* eslint-disable valid-jsdoc, no-unused-vars */
/**
 * @param {} p
 */
function testInvalidCodeSyntax(p) {}
