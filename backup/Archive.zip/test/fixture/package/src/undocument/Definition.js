// this is undocument.
export default class TestUndocumentDefinition {}
