// this is undocument.
export default class TestUndocumentDefinition {} // eslint-disable-line require-jsdoc
