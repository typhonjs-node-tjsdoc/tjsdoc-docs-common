/**
 * This is TestGuessProperty.
 */
export default class TestGuessProperty
{
   /**
    * This is constructor.
    */
   constructor()
   {
      this.p1 = 123;

      this.p2 = [123, 456];

      this.p3 = { x1: 123, x2: 'text' };

      this.p4 = `text`;
   }
}
