export const testGuessVariable1 = 123;

export const testGuessVariable2 = [123, 456];

export const testGuessVariable3 = { x1: 123, x2: "text" };

export const testGuessVariable4 = `text`;
