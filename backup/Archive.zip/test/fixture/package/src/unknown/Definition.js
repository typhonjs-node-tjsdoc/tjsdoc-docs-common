/**
 * this is TestUnknownDefinition.
 * @foobar this is unknown tag.
 */
export default class TestUnknownDefinition {}
