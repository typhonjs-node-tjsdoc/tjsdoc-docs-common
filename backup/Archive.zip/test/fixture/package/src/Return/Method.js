/**
 * this is TestReturnMethod.
 */
export default class TestReturnMethod
{
   /**
    * this is method1.
    * @returns {number} - this is return value.
    */
   method1()
   {
      return 123;
   }

   /**
    * this is method2.
    * @returns {TestClassDefinition} - this is return value.
    */
   method2()
   {
      return void 0;
   }
}
