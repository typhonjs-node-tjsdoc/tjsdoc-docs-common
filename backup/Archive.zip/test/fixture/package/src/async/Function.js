/**
 * this is testAsyncFunction.
 */
export default async function testAsyncFunction() {}
