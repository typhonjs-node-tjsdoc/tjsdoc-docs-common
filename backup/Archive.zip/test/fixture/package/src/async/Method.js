/**
 * this is TestAsyncMethod.
 */
export default class TestAsyncMethod
{
   /**
    * this is async method1.
    */
   async method1() {}
}
