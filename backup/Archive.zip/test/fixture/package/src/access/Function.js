/**
 * this is testAccessFunctionPublic.
 * @public
 */
export default function testAccessFunctionPublic() {}

/**
 * this is testAccessFunctionProtected.
 * @protected
 */
export function testAccessFunctionProtected() {}

/**
 * this is testAccessFunctionPrivate.
 * @private
 */
export function testAccessFunctionPrivate() {}

/**
 * this is testAccessFunctionAutoPrivate.
 */
export function _testAccessFunctionAutoPrivate() {}
