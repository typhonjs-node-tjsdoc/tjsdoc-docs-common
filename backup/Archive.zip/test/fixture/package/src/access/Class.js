/**
 * this is TestAccessClassPublic.
 * @public
 */
export default class TestAccessClassPublic {}

/**
 * this is TestAccessClassProtected.
 * @protected
 */
export class TestAccessClassProtected {}

/**
 * this is TestAccessClassPrivate.
 * @private
 */
export class TestAccessClassPrivate {}

/**
 * this is TestAccessClassAutoPrivate.
 */
export class _TestAccessClassAutoPrivate {}
