/**
 * this is TestPropertyReturn.
 */
export default class TestPropertyReturn
{
   /**
    * this is method1.
    * @return {Object} - this is return value.
    * @property {number} x1 - this is x1 of return value.
    * @property {TestClassDefinition} x2 - this is x2 of return value.
    */
   method1()
   {
      return {};
   }
}
