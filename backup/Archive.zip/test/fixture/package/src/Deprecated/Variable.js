/**
 * this is testDeprecatedVariable.
 * @deprecated
 */
export const testDeprecatedVariable = 123;
