/**
 * this is testExampleFunction.
 * @example
 * const foo = 123;
 */
export default function testExampleFunction() {}
