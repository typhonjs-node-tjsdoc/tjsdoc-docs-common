/**
 * this is TestExampleCaption.
 * @example <caption>this is caption</caption>
 * const foo = 123;
 * console.log(foo);
 */
export default class TestExampleCaption {}
