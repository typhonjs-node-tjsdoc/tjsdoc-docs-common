/**
 * this is TestGeneratorMethod.
 */
export default class TestGeneratorMethod
{
   /**
    * this is generator method1.
    */
   *method1() {}
}
