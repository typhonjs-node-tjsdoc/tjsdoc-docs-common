/* eslint-disable no-unused-vars */
/**
 * this is TestTypeUnion.
 */
export default class TestTypeUnion
{
   /**
    * this is method1.
    * @param {number|string} p1 - this is number or string p1.
    */
   method1(p1) {}
}
