/* eslint-disable no-unused-vars */
/**
 * this is TestTypeOptional.
 */
export default class TestTypeOptional
{
   /**
    * this is method1.
    * @param {number} [p1] - this is optional number p1.
    */
   method1(p1) {}
}
