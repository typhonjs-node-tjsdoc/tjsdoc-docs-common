/* eslint-disable no-unused-vars */
/**
 * this is TestTypeFunction.
 */
export default class TestTypeFunction
{
   /**
    * this is method1.
    * @param {function(x1: number, x2: string): boolean} p1 - this is function p1.
    */
   method1(p1) {}
}
