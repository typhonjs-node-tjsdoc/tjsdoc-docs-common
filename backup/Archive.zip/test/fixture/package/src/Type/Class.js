/* eslint-disable no-unused-vars */
export default class TestTypeClass
{
   /**
    * this is method1.
    * @param {TestTypeClassInner} p1 - this is class p1.
    */
   method1(p1) {}
}

export class TestTypeClassInner {}
