/* eslint-disable no-unused-vars */
/**
 * this is TestTypeExternal
 */
export default class TestTypeExternal
{
   /**
    * this is method1.
    * @param {XMLHttpRequest} p1 - this external p1.
    */
   method1(p1) {}
}
