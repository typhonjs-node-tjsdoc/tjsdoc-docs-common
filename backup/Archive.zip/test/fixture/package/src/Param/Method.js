/* eslint-disable no-unused-vars */
/**
 * this is TestParamMethod.
 */
export default class TestParamMethod
{
   /**
    * this is method1.
    * @param {number} p1 - this is p1.
    * @param {TestClassDefinition} p2 - this is p2.
    */
   method1(p1, p2) {}
}
