/**
 * this is TestExportNamed.
 */
export class TestExportNamed {}

export {};
