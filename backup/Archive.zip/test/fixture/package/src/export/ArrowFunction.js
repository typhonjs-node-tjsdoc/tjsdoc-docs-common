/* eslint-disable no-unused-vars */
/**
 * this is ArrowFunction.
 */
export default () => {};

/**
 * this is testExportArrowFunction2.
 */
export const testExportArrowFunction2 = () => {};

/**
 * this is testExportArrowFunction3.
 */
const testExportArrowFunction3 = () => {};

// this is undocument
export const testExportArrowFunction4 = () => {};

/**
 * this is testExportArrowFunction5.
 */
const testExportArrowFunction5 = () => {};
export { testExportArrowFunction5 };
