/**
 * this is testExportFunctionIndirectDefault
 */
function testExportFunctionIndirectDefault() {}

export default testExportFunctionIndirectDefault;
