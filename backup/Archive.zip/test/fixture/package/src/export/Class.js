/* eslint-disable no-unused-vars */
/**
 * this is TestExportClass1.
 */
export default class TestExportClass1 {}

/**
 * this is TestExportClass2.
 */
export class TestExportClass2 {}

/**
 * this is TestExportClass3.
 */
class TestExportClass3 {}
export { TestExportClass3 };

/**
 * this is TestExportClass4.
 */
const TestExportClass4 = class {};
export { TestExportClass4 };

// this is undocument.
export class TestExportClass5 {} // eslint-disable-line require-jsdoc

/**
 * this is TestExportClass6.
 */
class TestExportClass6 {}

