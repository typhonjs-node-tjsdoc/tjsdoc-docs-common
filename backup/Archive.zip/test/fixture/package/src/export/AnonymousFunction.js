/**
 * this is anonymous function.
 */
export default function() {}
