/**
 * this is TestExportDefault.
 */
export default class TestExportDefault {}
