/**
 * this is testExportVariableIndirectDefault.
 * @type {{x1: number, x2: string}}
 */
const testExportVariableIndirectDefault = {};
export default testExportVariableIndirectDefault;
