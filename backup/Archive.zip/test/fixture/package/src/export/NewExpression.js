/**
 * this is TestExportNewExpression.
 */
class TestExportNewExpression {}

/**
 * this is instance of TestExportNewExpression.
 */
export default new TestExportNewExpression();

/**
 * this is TestExportNewExpression2.
 */
class TestExportNewExpression2 {}

/**
 * this is instance of TestExportNewExpression2.
 */
export const testExportNewExpression2 = new TestExportNewExpression2();
