/**
 * this is TestExportNewExpressionIndirect.
 */
class TestExportNewExpressionIndirect {}

/**
 * @ignore
 */
const testExportNewExpressionIndirect = new TestExportNewExpressionIndirect();

/**
 * this is instance of TestExportNewExpressionIndirect.
 */
export default testExportNewExpressionIndirect;

