/* eslint-disable no-unused-vars, require-jsdoc */
/**
 * this is testExportFunction1.
 */
export default function testExportFunction1() {}

/**
 * this is testExportFunction2.
 */
export function testExportFunction2() {}

/**
 * this is testExportFunction3.
 */
export const testExportFunction3 = function() {};

/**
 * this is testExportFunction4.
 */
function testExportFunction4() {}

/**
 * this is testExportFunction5.
 */
const testExportFunction5 = function() {};

/**
 * this is testExportFunction6.
 */
export function *testExportFunction6() {}

// this is undocument
export function testExportFunction7() {}

/**
 * this is testExportFunction8.
 */
function testExportFunction8() {}
export { testExportFunction8 };
