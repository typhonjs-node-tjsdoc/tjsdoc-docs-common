/**
 * this is TestExportMultiple
 */
class TestExportMultiple {}

/**
 * this is instance of TestExportMultiple.
 */
const testExportMultiple = new TestExportMultiple();

export { TestExportMultiple, testExportMultiple };
