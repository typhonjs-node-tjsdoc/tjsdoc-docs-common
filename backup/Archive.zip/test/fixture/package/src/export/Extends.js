/**
 * this is TestExportExtendsInner.
 */
class TestExportExtendsInner {}

/**
 * this is TestExportExtends.
 */
export class TestExportExtends extends TestExportExtendsInner {}
