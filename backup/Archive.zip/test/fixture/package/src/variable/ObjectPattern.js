/**
 * this is testVariableObjectPattern1.
 * @type {number}
 */
export const { testVariableObjectPattern1, testVariableObjectPattern2 } =
{
   testVariableObjectPattern1: 1,
   testVariableObjectPattern2: 2
};
