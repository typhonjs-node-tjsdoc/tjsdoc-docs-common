/**
 * this is testVariableArrayPattern1.
 * @type {number}
 */
export const [testVariableArrayPattern1, testVariableArrayPattern2] = [1, 2];
