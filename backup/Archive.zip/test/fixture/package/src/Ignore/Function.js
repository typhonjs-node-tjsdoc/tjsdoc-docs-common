/**
 * this is testIgnoreFunction.
 * @ignore
 */
export default function testIgnoreFunction() {}
