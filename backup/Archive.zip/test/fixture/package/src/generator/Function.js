/**
 * this is testGeneratorFunction.
 */
export default function *testGeneratorFunction() {}
