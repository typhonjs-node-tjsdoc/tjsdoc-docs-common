/**
 * this is testVariableDefinition.
 * @type {number}
 */
export const testVariableDefinition = 123;
