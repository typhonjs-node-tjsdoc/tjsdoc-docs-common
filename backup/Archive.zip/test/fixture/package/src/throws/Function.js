/**
 * this is testThrowsFunction.
 * @throws {TestThrowsFunctionError}
 */
export default function testThrowsFunction() {}

/**
 * this is TestThrowsFunctionError.
 */
export class TestThrowsFunctionError {}
