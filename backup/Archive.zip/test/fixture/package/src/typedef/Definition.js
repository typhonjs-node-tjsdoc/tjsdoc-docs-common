/**
 * this is TestTypedefDefinition.
 * @typedef {Object} TestTypedefDefinition
 * @property {number} p1 - this is p1.
 */
