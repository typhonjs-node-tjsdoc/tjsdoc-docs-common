/**
 * this is TestDescMultiLine.
 */
export default class TestDescMultiLine
{
   /**
    * this is method1.
    * this is second line.
    */
   method1() {}

   /**
    * this is method2. this is second sentence.
    */
   method2() {}

   /**
    * this is
    * method3. this is second sentence.
    */
   method3() {}
}
