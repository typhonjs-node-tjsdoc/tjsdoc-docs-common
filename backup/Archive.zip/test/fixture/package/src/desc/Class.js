/**
 * @desc this is TestDescClass.
 */
export default class TestDescClass
{
   /**
    * @desc this is constructor.
    */
   constructor()
   {
      /**
       * @desc this is p1.
       * @type {number}
       */
      this.p1 = 123;
   }

   /**
    * @desc this is method1.
    */
   method1() {}
}
