/**
 * @desc this is testDescVariable.
 * @type {number}
 */
export const testDescVariable = 123;
