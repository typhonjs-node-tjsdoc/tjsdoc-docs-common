/**
 * this is testIgnoreVariable.
 * @type {number}
 * @ignore
 */
export const testIgnoreVariable = 123;
