/**
 * this is testReturnFunction1.
 * @returns {TestClassDefinition} - this is return value.
 */
export default function testReturnFunction1() { return void 0; }

/**
 * this is testReturnFunction2.
 * @returns {number} - this is return value.
 */
export function testReturnFunction2() { return 42; }
