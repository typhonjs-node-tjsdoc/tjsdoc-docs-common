/**
 * this is testListensFunction.
 * @listens {TestListensFunctionEvent}
 */
export default function testListensFunction() {}

/**
 * this is TestListensFunctionEvent.
 */
export class TestListensFunctionEvent {}
