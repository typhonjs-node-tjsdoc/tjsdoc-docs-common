/**
 * this is TestJSXDefinition.
 */
export default class TestJSXDefinition
{
   /**
    * this is method1.
    * @returns {string}
    */
   method1()
   {
      return <div > Hello < / div >;
   }
}
