/**
 * This is testEmitsFunction.
 * @emits {TestEmitsFunctionEvent}
 */
export default function testEmitsFunction() {}

/**
 * This is TestEmitsFunctionEvent.
 */
export class TestEmitsFunctionEvent {}
