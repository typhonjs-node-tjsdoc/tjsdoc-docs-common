/**
 * this is testEmitsFunction.
 * @emits {TestEmitsFunctionEvent}
 */
export default function testEmitsFunction() {}

export class TestEmitsFunctionEvent {}
