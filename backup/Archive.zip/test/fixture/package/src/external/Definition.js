/**
 * @external {TestExternalDefinition} http://example.com
 */
