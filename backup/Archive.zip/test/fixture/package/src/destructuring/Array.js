/* eslint-disable valid-jsdoc */
/**
 * this is TestDestructuringArray.
 */
export default class TestDestructuringArray
{
   /**
    * this is method1.
    * @param {number[]} p - this is p.
    * @param {number} p[0] - this is first of p.
    * @param {number} p[1] - this is second of p.
    */
   method1([p1, p2]) {} // eslint-disable-line no-unused-vars
}
