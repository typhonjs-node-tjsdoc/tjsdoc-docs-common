/**
 * this is testSinceVariable.
 * @type {number}
 * @since 1.2.3
 */
export const testSinceVariable = 123;
