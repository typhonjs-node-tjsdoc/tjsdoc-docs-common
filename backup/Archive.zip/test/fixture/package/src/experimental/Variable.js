/**
 * this is testExperimentalVariable.
 * @type {number}
 * @experimental
 */
export const testExperimentalVariable = 123;
