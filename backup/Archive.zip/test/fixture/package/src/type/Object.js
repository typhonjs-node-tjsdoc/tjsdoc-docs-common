/* eslint-disable no-unused-vars */
/**
 * this is TestTypeObject.
 */
export default class TestTypeObject
{
   /**
    * this is method1.
    * @param {Object} p1 - this is object p1.
    * @param {number} p1.x1 - this is number x1.
    */
   method1(p1) {}
}
