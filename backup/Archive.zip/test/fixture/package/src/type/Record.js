/* eslint-disable no-unused-vars */
/**
 * this is TestTypeRecord.
 */
export default class TestTypeRecord
{
   /**
    * this is method1.
    * @param {{x1: number, x2: string}} p1 - this is record p1.
    */
   method1(p1) {}
}
