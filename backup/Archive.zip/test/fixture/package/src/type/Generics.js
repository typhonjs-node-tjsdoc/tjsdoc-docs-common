/* eslint-disable no-unused-vars */
/**
 * this is TestTypeGenerics.
 */
export default class TestTypeGenerics
{
   /**
    * this is method1.
    * @param {Array<number>} p1 - this is array p1.
    * @param {Map<number, string>} p2 - this map p2.
    * @param {Promise<number[], Error>} p3 - this is promise p3.
    */
   method1(p1, p2, p3) {}
}
