/* eslint-disable no-unused-vars */
/**
 * this is TestTypeLiteral.
 */
export default class TestTypeLiteral
{
   /**
    * this is method1.
    * @param {number} p1 - this is number p1.
    * @param {string} p2 - this is string p2.
    * @param {boolean} p3 - this is boolean p3.
    */
   method1(p1, p2, p3) {}
}
