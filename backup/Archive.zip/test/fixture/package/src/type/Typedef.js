/* eslint-disable no-unused-vars */
/**
 * @typedef {Object} TestTypeTypedefInner
 */

/**
 * this is TestTypedef.
 */
export default class TestTypeTypedef
{
   /**
    * this is method1.
    * @param {TestTypeTypedefInner} p1 - this is typedef p1.
    */
   method1(p1) {}
}
