/**
 * This is TestTypeClass.
 */
export default class TestTypeClass
{
   /**
    * This is method1.
    * @param {TestTypeClassInner} p1 - this is class p1.
    */
   method1(p1) {} // eslint-disable-line no-unused-vars
}

/**
 * This is TestTypeClassInner.
 */
export class TestTypeClassInner {}
