/* eslint-disable no-unused-vars */
/**
 * this is TestTypeArray.
 */
export default class TestTypeArray
{
   /**
    * this is method1.
    * @param {number[]} p1 - this is number array p1.
    */
   method1(p1) {}
}
