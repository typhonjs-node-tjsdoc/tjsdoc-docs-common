/**
 * this is TestInterfaceDefinition
 * @interface
 */
export default class TestInterfaceDefinition
{
   /**
    * this is interface method1.
    */
   method1() {}
}
