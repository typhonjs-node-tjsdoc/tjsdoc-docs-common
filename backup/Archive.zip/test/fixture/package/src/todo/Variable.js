/**
 * this is testTodoVariable.
 * @todo this is todo.
 */
export const testTodoVariable = 123;
