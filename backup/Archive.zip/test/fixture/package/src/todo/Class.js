/**
 * this is TestTodoClass.
 * @todo this is first todo.
 * @todo this is second todo.
 */
export default class TestTodoClass
{
   /**
    * this is constructor.
    * @todo this is todo.
    */
   constructor()
   {
      /**
       * this is p1.
       * @type {number}
       * @todo this is todo.
       */
      this.p1 = 123;
   }

   /**
    * this is method1.
    * @todo this is todo.
    */
   method1() {}
}
