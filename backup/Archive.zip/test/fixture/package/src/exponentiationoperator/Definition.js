/**
 * this is TestExponentiationOperatorDefinition.
 */
export default class TestExponentiationOperatorDefinition
{
   /**
    * this is method1.
    * @return {number}
    */
   method1()
   {
      return 2 ** 3;
   }
}
