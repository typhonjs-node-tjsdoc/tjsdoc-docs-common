/**
 * this is anonymous class.
 */
export default class {}
