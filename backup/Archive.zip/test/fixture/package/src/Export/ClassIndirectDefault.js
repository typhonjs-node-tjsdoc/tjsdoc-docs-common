/**
 * this is TestExportClassIndirectDefault.
 */
class TestExportClassIndirectDefault {}

export default TestExportClassIndirectDefault;
