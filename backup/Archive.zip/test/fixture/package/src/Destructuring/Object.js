/**
 * this is TestDestructuringObject.
 */
export default class TestDestructuringObject
{
   /**
    * this is method1.
    * @param {Object} p - this is object p.
    * @param {number} p.p1 - this is property p1 of p.
    * @param {string} p.p2 - this is property p2 of p.
    */
   method1({ p1, p2 }) {} // eslint-disable-line no-unused-vars
}
