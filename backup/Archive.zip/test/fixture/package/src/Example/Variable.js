/**
 * this is testExampleVariable.
 * @type {number}
 * @example
 * const foo = 123;
 */
export const testExampleVariable = 123;
