/* eslint-disable no-unused-vars */
/**
 * this is testParamFunction.
 * @param {number} p1 - this is p1.
 * @param {TestClassDefinition} p2 - this is p2.
 */
export default function testParamFunction(p1, p2) {}
