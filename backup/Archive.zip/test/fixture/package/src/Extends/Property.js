import obj from 'TestExtendsPropertyPackage';

/**
 * this is TestExtendsProperty.
 */
export default class TestExtendsProperty extends obj.TestExtendsPropertyInner {}
