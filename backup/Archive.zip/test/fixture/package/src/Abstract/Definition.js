/**
 * this is TestAbstractDefinition.
 */
export default class TestAbstractDefinition
{
   /**
    * this is abstract method1.
    * @abstract
    */
   method1() {}

   /**
    * this is abstract method2.
    * @abstract
    */
   method2() {}
}
