/**
 * this is TestClassPropertyDefinition.
 * @todo test `Access`, `Deprecated`, `Desc`, `Duplication`, `Example`, `Experimental`, `Guess`, `Ignore`, `Link`, `See`, `Since`, `Todo` and `Version`.
 */
export default class TestClassPropertyDefinition
{
   /**
    * this is static p1.
    * @type {number}
    */
   static p1 = 123;

   /**
    * this is p1.
    * @type {number}
    */
   p1 = 123;
}
