/**
 * this is testSeeVariable.
 * @type {number}
 * @see http://example.com
 */
export const testSeeVariable = 123;
