/**
 * this is testDeprecatedFunction.
 * @deprecated
 */
export default function testDeprecatedFunction() {}
