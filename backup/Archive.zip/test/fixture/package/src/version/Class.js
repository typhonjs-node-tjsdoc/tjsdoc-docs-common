/**
 * this is TestVersionClass.
 * @version 1.2.3
 */
export default class TestVersionClass
{
   /**
    * this is constructor.
    * @version 1.2.3
    */
   constructor()
   {
      /**
       * this is p1.
       * @type {number}
       * @version 1.2.3
       */
      this.p1 = 123;
   }

   /**
    * this is method1.
    * @version 1.2.3
    */
   method1() {}
}
