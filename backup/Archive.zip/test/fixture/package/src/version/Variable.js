/**
 * this is testVersionVariable.
 * @type {number}
 * @version 1.2.3
 */
export const testVersionVariable = 123;
