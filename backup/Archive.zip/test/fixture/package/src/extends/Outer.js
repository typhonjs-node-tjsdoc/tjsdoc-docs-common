import TestExtendsBuiltin from './Builtin.js';

/**
 * this is TextExtendsOuter.
 */
export default class TestExtendsOuter extends TestExtendsBuiltin
{
   /**
    * this is method1.
    */
   method1() {}
}
