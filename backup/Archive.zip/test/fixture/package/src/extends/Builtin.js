/**
 * this is TestExtendsBuiltin.
 */
export default class TestExtendsBuiltin extends Array
{
   /**
    * This is method1.
    */
   method1() {}
}
