/**
 * this is TestExtendsBuiltin.
 */
export default class TestExtendsBuiltin extends Array
{
   method1() {}
}
