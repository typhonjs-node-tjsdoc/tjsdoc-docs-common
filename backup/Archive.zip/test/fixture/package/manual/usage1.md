# Usage

```sh
esdoc -c esdoc.json
```

``esdoc.json``

```json
{
  "source": "./src",
  "destination": "./doc"
}
```
