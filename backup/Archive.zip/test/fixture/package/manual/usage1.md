# Usage

```sh
tjsdoc -c .tjsdocrc
```

``.tjsdocrc``

```json
{
  "source": "./src",
  "destination": "./doc"
  "runtime": "tjsdoc-babylon"
  "publisher": "tjsdoc-publisher-static-html"
}
```
