# FAQ

- [Goal](#goal)

## Goal
ESDoc has two goals.
The first goal is reducing the cost to write an documentation, it is able to continuously maintenance.
The second goal is without looking the source code of a library, it is to be able to use the library.
