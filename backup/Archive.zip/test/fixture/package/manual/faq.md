# FAQ

- [Goal](#goal)

## Goal
TJSDoc has several goals:

- Provide exceptional documentation generation for ES6+ and Typescript projects.
- Provide extensive configuration options and moddable runtime with expasive plugin capabilities.
