# Example

## Minimum Config
```json
{
  "source": "./src",
  "destination": "./doc"
}
```

## Integration Test Code Into Documentation
```json
{
  "source": "./src",
  "destination": "./doc",
  "test": {
    "type": "mocha",
    "source": "./test"
  }
}
```
