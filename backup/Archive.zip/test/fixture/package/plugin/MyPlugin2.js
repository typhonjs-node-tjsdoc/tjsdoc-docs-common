import { callInfo } from './MyPlugin1.js';

/**
 * Tracks that `onStart` has been invoked from `MyPlugin2`.
 */
export function onStart()
{
   callInfo.handlerNames.onStart.push('MyPlugin2');
}

/**
 * Tracks that `onHandleConfig` has been invoked from `MyPlugin2`.
 */
export function onHandleConfig()
{
   callInfo.handlerNames.onHandleConfig.push('MyPlugin2');
}

/**
 * Tracks that `onHandleCode` has been invoked from `MyPlugin2`.
 */
export function onHandleCode()
{
   callInfo.handlerNames.onHandleCode.push('MyPlugin2');
}

/**
 * Tracks that `onHandleCodeParser` has been invoked from `MyPlugin2`.
 */
export function onHandleCodeParser()
{
   callInfo.handlerNames.onHandleCodeParser.push('MyPlugin2');
}

/**
 * Tracks that `onHandleAST` has been invoked from `MyPlugin2`.
 */
export function onHandleAST()
{
   callInfo.handlerNames.onHandleAST.push('MyPlugin2');
}

/**
 * Tracks that `onHandleTag` has been invoked from `MyPlugin2`.
 */
export function onHandleTag()
{
   callInfo.handlerNames.onHandleTag.push('MyPlugin2');
}

/**
 * Tracks that `onHandleHTML` has been invoked from `MyPlugin2`.
 */
export function onHandleHTML()
{
   callInfo.handlerNames.onHandleHTML.push('MyPlugin2');
}

/**
 * Tracks that `onComplete` has been invoked from `MyPlugin2`.
 */
export function onComplete()
{
   callInfo.handlerNames.onComplete.push('MyPlugin2');
}
