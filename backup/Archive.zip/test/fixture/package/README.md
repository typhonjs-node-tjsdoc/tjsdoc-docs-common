[![Build Status](https://travis-ci.org/esdoc/esdoc.svg?branch=master)](https://travis-ci.org/esdoc/esdoc)
[![Coverage Status](https://coveralls.io/repos/esdoc/esdoc/badge.svg)](https://coveralls.io/r/esdoc/esdoc)

# ESDoc Test Fixture
this is ESDoc Test Fixture README.

- item1
- item2
- item3

1st line.
second line.

http://github.com/h13i32maru/esdoc

```javascript
export default class Foo {
  static get foo() {}
  
  constructor(p1) {
  }
}
var foo = 123;
```

| First Header  | Second Header |
| ------------- | ------------- |
| Content Cell  | Content Cell  |
| Content Cell  | Content Cell  |

**text**

~~text~~

# text
## text
### text
#### text
##### text
