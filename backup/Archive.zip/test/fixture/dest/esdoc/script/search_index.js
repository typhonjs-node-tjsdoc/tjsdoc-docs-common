window.esdocSearchIndex = [
  [
    "esdoc-test-fixture/test/fixture/package/src/export/anonymousclass.js~anonymousclass",
    "class/test/fixture/package/src/export/AnonymousClass.js~AnonymousClass.html",
    "<span>AnonymousClass</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/export/AnonymousClass.js</span>",
    "class"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/export/anonymousfunction.js~anonymousfunction",
    "function/index.html#static-function-AnonymousFunction",
    "<span>AnonymousFunction</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/export/AnonymousFunction.js</span>",
    "function"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/export/arrowfunction.js~arrowfunction",
    "function/index.html#static-function-ArrowFunction",
    "<span>ArrowFunction</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/export/ArrowFunction.js</span>",
    "function"
  ],
  [
    "testabstractdefinition#method1",
    "class/test/fixture/package/src/abstract/Definition.js~TestAbstractDefinition.html#instance-method-method1",
    "<span>TestAbstractDefinition#method1</span> <span class=\"search-result-import-path\">test/fixture/package/src/abstract/Definition.js</span>",
    "method"
  ],
  [
    "testabstractdefinition#method2",
    "class/test/fixture/package/src/abstract/Definition.js~TestAbstractDefinition.html#instance-method-method2",
    "<span>TestAbstractDefinition#method2</span> <span class=\"search-result-import-path\">test/fixture/package/src/abstract/Definition.js</span>",
    "method"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/abstract/definition.js~testabstractdefinition",
    "class/test/fixture/package/src/abstract/Definition.js~TestAbstractDefinition.html",
    "<span>TestAbstractDefinition</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/abstract/Definition.js</span>",
    "class"
  ],
  [
    "testabstractoverride#method1",
    "class/test/fixture/package/src/abstract/Override.js~TestAbstractOverride.html#instance-method-method1",
    "<span>TestAbstractOverride#method1</span> <span class=\"search-result-import-path\">test/fixture/package/src/abstract/Override.js</span>",
    "method"
  ],
  [
    "testabstractoverride#method2",
    "class/test/fixture/package/src/abstract/Override.js~TestAbstractOverride.html#instance-method-method2",
    "<span>TestAbstractOverride#method2</span> <span class=\"search-result-import-path\">test/fixture/package/src/abstract/Override.js</span>",
    "method"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/abstract/override.js~testabstractoverride",
    "class/test/fixture/package/src/abstract/Override.js~TestAbstractOverride.html",
    "<span>TestAbstractOverride</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/abstract/Override.js</span>",
    "class"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/access/class.js~testaccessclassprivate",
    "class/test/fixture/package/src/access/Class.js~TestAccessClassPrivate.html",
    "<span>TestAccessClassPrivate</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/access/Class.js</span>",
    "class"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/access/class.js~testaccessclassprotected",
    "class/test/fixture/package/src/access/Class.js~TestAccessClassProtected.html",
    "<span>TestAccessClassProtected</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/access/Class.js</span>",
    "class"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/access/class.js~testaccessclasspublic",
    "class/test/fixture/package/src/access/Class.js~TestAccessClassPublic.html",
    "<span>TestAccessClassPublic</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/access/Class.js</span>",
    "class"
  ],
  [
    "testaccessmethod#_method4",
    "class/test/fixture/package/src/access/Method.js~TestAccessMethod.html#instance-method-_method4",
    "<span>TestAccessMethod#_method4</span> <span class=\"search-result-import-path\">test/fixture/package/src/access/Method.js</span>",
    "method"
  ],
  [
    "testaccessmethod#method1",
    "class/test/fixture/package/src/access/Method.js~TestAccessMethod.html#instance-method-method1",
    "<span>TestAccessMethod#method1</span> <span class=\"search-result-import-path\">test/fixture/package/src/access/Method.js</span>",
    "method"
  ],
  [
    "testaccessmethod#method2",
    "class/test/fixture/package/src/access/Method.js~TestAccessMethod.html#instance-method-method2",
    "<span>TestAccessMethod#method2</span> <span class=\"search-result-import-path\">test/fixture/package/src/access/Method.js</span>",
    "method"
  ],
  [
    "testaccessmethod#method3",
    "class/test/fixture/package/src/access/Method.js~TestAccessMethod.html#instance-method-method3",
    "<span>TestAccessMethod#method3</span> <span class=\"search-result-import-path\">test/fixture/package/src/access/Method.js</span>",
    "method"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/access/method.js~testaccessmethod",
    "class/test/fixture/package/src/access/Method.js~TestAccessMethod.html",
    "<span>TestAccessMethod</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/access/Method.js</span>",
    "class"
  ],
  [
    "testaccessproperty#_p4",
    "class/test/fixture/package/src/access/Property.js~TestAccessProperty.html#instance-member-_p4",
    "<span>TestAccessProperty#_p4</span> <span class=\"search-result-import-path\">test/fixture/package/src/access/Property.js</span>",
    "member"
  ],
  [
    "testaccessproperty#constructor",
    "class/test/fixture/package/src/access/Property.js~TestAccessProperty.html#instance-constructor-constructor",
    "<span>TestAccessProperty#constructor</span> <span class=\"search-result-import-path\">test/fixture/package/src/access/Property.js</span>",
    "method"
  ],
  [
    "testaccessproperty#p1",
    "class/test/fixture/package/src/access/Property.js~TestAccessProperty.html#instance-member-p1",
    "<span>TestAccessProperty#p1</span> <span class=\"search-result-import-path\">test/fixture/package/src/access/Property.js</span>",
    "member"
  ],
  [
    "testaccessproperty#p2",
    "class/test/fixture/package/src/access/Property.js~TestAccessProperty.html#instance-member-p2",
    "<span>TestAccessProperty#p2</span> <span class=\"search-result-import-path\">test/fixture/package/src/access/Property.js</span>",
    "member"
  ],
  [
    "testaccessproperty#p3",
    "class/test/fixture/package/src/access/Property.js~TestAccessProperty.html#instance-member-p3",
    "<span>TestAccessProperty#p3</span> <span class=\"search-result-import-path\">test/fixture/package/src/access/Property.js</span>",
    "member"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/access/property.js~testaccessproperty",
    "class/test/fixture/package/src/access/Property.js~TestAccessProperty.html",
    "<span>TestAccessProperty</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/access/Property.js</span>",
    "class"
  ],
  [
    "testasyncmethod#method1",
    "class/test/fixture/package/src/async/Method.js~TestAsyncMethod.html#instance-method-method1",
    "<span>TestAsyncMethod#method1</span> <span class=\"search-result-import-path\">test/fixture/package/src/async/Method.js</span>",
    "method"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/async/method.js~testasyncmethod",
    "class/test/fixture/package/src/async/Method.js~TestAsyncMethod.html",
    "<span>TestAsyncMethod</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/async/Method.js</span>",
    "class"
  ],
  [
    "testclassdefinition#constructor",
    "class/test/fixture/package/src/class/Definition.js~TestClassDefinition.html#instance-constructor-constructor",
    "<span>TestClassDefinition#constructor</span> <span class=\"search-result-import-path\">test/fixture/package/src/class/Definition.js</span>",
    "method"
  ],
  [
    "testclassdefinition#method1",
    "class/test/fixture/package/src/class/Definition.js~TestClassDefinition.html#instance-method-method1",
    "<span>TestClassDefinition#method1</span> <span class=\"search-result-import-path\">test/fixture/package/src/class/Definition.js</span>",
    "method"
  ],
  [
    "testclassdefinition#p1",
    "class/test/fixture/package/src/class/Definition.js~TestClassDefinition.html#instance-member-p1",
    "<span>TestClassDefinition#p1</span> <span class=\"search-result-import-path\">test/fixture/package/src/class/Definition.js</span>",
    "member"
  ],
  [
    "testclassdefinition#value1",
    "class/test/fixture/package/src/class/Definition.js~TestClassDefinition.html#instance-get-value1",
    "<span>TestClassDefinition#value1</span> <span class=\"search-result-import-path\">test/fixture/package/src/class/Definition.js</span>",
    "member"
  ],
  [
    "testclassdefinition#value2",
    "class/test/fixture/package/src/class/Definition.js~TestClassDefinition.html#instance-set-value2",
    "<span>TestClassDefinition#value2</span> <span class=\"search-result-import-path\">test/fixture/package/src/class/Definition.js</span>",
    "member"
  ],
  [
    "testclassdefinition.method1",
    "class/test/fixture/package/src/class/Definition.js~TestClassDefinition.html#static-method-method1",
    "<span>TestClassDefinition.method1</span> <span class=\"search-result-import-path\">test/fixture/package/src/class/Definition.js</span>",
    "method"
  ],
  [
    "testclassdefinition.p1",
    "class/test/fixture/package/src/class/Definition.js~TestClassDefinition.html#static-member-p1",
    "<span>TestClassDefinition.p1</span> <span class=\"search-result-import-path\">test/fixture/package/src/class/Definition.js</span>",
    "member"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/class/definition.js~testclassdefinition",
    "class/test/fixture/package/src/class/Definition.js~TestClassDefinition.html",
    "<span>TestClassDefinition</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/class/Definition.js</span>",
    "class"
  ],
  [
    "testclasspropertydefinition#p1",
    "class/test/fixture/package/src/classproperty/Definition.js~TestClassPropertyDefinition.html#instance-member-p1",
    "<span>TestClassPropertyDefinition#p1</span> <span class=\"search-result-import-path\">test/fixture/package/src/classproperty/Definition.js</span>",
    "member"
  ],
  [
    "testclasspropertydefinition.p1",
    "class/test/fixture/package/src/classproperty/Definition.js~TestClassPropertyDefinition.html#static-member-p1",
    "<span>TestClassPropertyDefinition.p1</span> <span class=\"search-result-import-path\">test/fixture/package/src/classproperty/Definition.js</span>",
    "member"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/classproperty/definition.js~testclasspropertydefinition",
    "class/test/fixture/package/src/classproperty/Definition.js~TestClassPropertyDefinition.html",
    "<span>TestClassPropertyDefinition</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/classproperty/Definition.js</span>",
    "class"
  ],
  [
    "testcomputedmethod#['foo']",
    "class/test/fixture/package/src/computed/Method.js~TestComputedMethod.html#instance-method-['foo']",
    "<span>TestComputedMethod#['foo']</span> <span class=\"search-result-import-path\">test/fixture/package/src/computed/Method.js</span>",
    "method"
  ],
  [
    "testcomputedmethod#[symbol.iterator]",
    "class/test/fixture/package/src/computed/Method.js~TestComputedMethod.html#instance-method-[Symbol.iterator]",
    "<span>TestComputedMethod#[Symbol.iterator]</span> <span class=\"search-result-import-path\">test/fixture/package/src/computed/Method.js</span>",
    "method"
  ],
  [
    "testcomputedmethod#[`${foo}`]",
    "class/test/fixture/package/src/computed/Method.js~TestComputedMethod.html#instance-method-[`${foo}`]",
    "<span>TestComputedMethod#[`${foo}`]</span> <span class=\"search-result-import-path\">test/fixture/package/src/computed/Method.js</span>",
    "method"
  ],
  [
    "testcomputedmethod#[foo + bar]",
    "class/test/fixture/package/src/computed/Method.js~TestComputedMethod.html#instance-method-[foo + bar]",
    "<span>TestComputedMethod#[foo + bar]</span> <span class=\"search-result-import-path\">test/fixture/package/src/computed/Method.js</span>",
    "method"
  ],
  [
    "testcomputedmethod#[foo()]",
    "class/test/fixture/package/src/computed/Method.js~TestComputedMethod.html#instance-method-[foo()]",
    "<span>TestComputedMethod#[foo()]</span> <span class=\"search-result-import-path\">test/fixture/package/src/computed/Method.js</span>",
    "method"
  ],
  [
    "testcomputedmethod#[foo.bar()]",
    "class/test/fixture/package/src/computed/Method.js~TestComputedMethod.html#instance-method-[foo.bar()]",
    "<span>TestComputedMethod#[foo.bar()]</span> <span class=\"search-result-import-path\">test/fixture/package/src/computed/Method.js</span>",
    "method"
  ],
  [
    "testcomputedmethod#[foo.bar.baz]",
    "class/test/fixture/package/src/computed/Method.js~TestComputedMethod.html#instance-method-[foo.bar.baz]",
    "<span>TestComputedMethod#[foo.bar.baz]</span> <span class=\"search-result-import-path\">test/fixture/package/src/computed/Method.js</span>",
    "method"
  ],
  [
    "testcomputedmethod#[foo.bar]",
    "class/test/fixture/package/src/computed/Method.js~TestComputedMethod.html#instance-method-[foo.bar]",
    "<span>TestComputedMethod#[foo.bar]</span> <span class=\"search-result-import-path\">test/fixture/package/src/computed/Method.js</span>",
    "method"
  ],
  [
    "testcomputedmethod#[foo.p + bar]",
    "class/test/fixture/package/src/computed/Method.js~TestComputedMethod.html#instance-method-[foo.p + bar]",
    "<span>TestComputedMethod#[foo.p + bar]</span> <span class=\"search-result-import-path\">test/fixture/package/src/computed/Method.js</span>",
    "method"
  ],
  [
    "testcomputedmethod#[foo]",
    "class/test/fixture/package/src/computed/Method.js~TestComputedMethod.html#instance-method-[foo]",
    "<span>TestComputedMethod#[foo]</span> <span class=\"search-result-import-path\">test/fixture/package/src/computed/Method.js</span>",
    "method"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/computed/method.js~testcomputedmethod",
    "class/test/fixture/package/src/computed/Method.js~TestComputedMethod.html",
    "<span>TestComputedMethod</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/computed/Method.js</span>",
    "class"
  ],
  [
    "testcomputedproperty#['foo']",
    "class/test/fixture/package/src/computed/Property.js~TestComputedProperty.html#instance-member-['foo']",
    "<span>TestComputedProperty#['foo']</span> <span class=\"search-result-import-path\">test/fixture/package/src/computed/Property.js</span>",
    "member"
  ],
  [
    "testcomputedproperty#[symbol.iterator]",
    "class/test/fixture/package/src/computed/Property.js~TestComputedProperty.html#instance-member-[Symbol.iterator]",
    "<span>TestComputedProperty#[Symbol.iterator]</span> <span class=\"search-result-import-path\">test/fixture/package/src/computed/Property.js</span>",
    "member"
  ],
  [
    "testcomputedproperty#[`${foo}`]",
    "class/test/fixture/package/src/computed/Property.js~TestComputedProperty.html#instance-member-[`${foo}`]",
    "<span>TestComputedProperty#[`${foo}`]</span> <span class=\"search-result-import-path\">test/fixture/package/src/computed/Property.js</span>",
    "member"
  ],
  [
    "testcomputedproperty#[foo + bar]",
    "class/test/fixture/package/src/computed/Property.js~TestComputedProperty.html#instance-member-[foo + bar]",
    "<span>TestComputedProperty#[foo + bar]</span> <span class=\"search-result-import-path\">test/fixture/package/src/computed/Property.js</span>",
    "member"
  ],
  [
    "testcomputedproperty#[foo()]",
    "class/test/fixture/package/src/computed/Property.js~TestComputedProperty.html#instance-member-[foo()]",
    "<span>TestComputedProperty#[foo()]</span> <span class=\"search-result-import-path\">test/fixture/package/src/computed/Property.js</span>",
    "member"
  ],
  [
    "testcomputedproperty#[foo.bar()]",
    "class/test/fixture/package/src/computed/Property.js~TestComputedProperty.html#instance-member-[foo.bar()]",
    "<span>TestComputedProperty#[foo.bar()]</span> <span class=\"search-result-import-path\">test/fixture/package/src/computed/Property.js</span>",
    "member"
  ],
  [
    "testcomputedproperty#[foo.bar.baz]",
    "class/test/fixture/package/src/computed/Property.js~TestComputedProperty.html#instance-member-[foo.bar.baz]",
    "<span>TestComputedProperty#[foo.bar.baz]</span> <span class=\"search-result-import-path\">test/fixture/package/src/computed/Property.js</span>",
    "member"
  ],
  [
    "testcomputedproperty#[foo.bar]",
    "class/test/fixture/package/src/computed/Property.js~TestComputedProperty.html#instance-member-[foo.bar]",
    "<span>TestComputedProperty#[foo.bar]</span> <span class=\"search-result-import-path\">test/fixture/package/src/computed/Property.js</span>",
    "member"
  ],
  [
    "testcomputedproperty#[foo.p + bar]",
    "class/test/fixture/package/src/computed/Property.js~TestComputedProperty.html#instance-member-[foo.p + bar]",
    "<span>TestComputedProperty#[foo.p + bar]</span> <span class=\"search-result-import-path\">test/fixture/package/src/computed/Property.js</span>",
    "member"
  ],
  [
    "testcomputedproperty#[foo]",
    "class/test/fixture/package/src/computed/Property.js~TestComputedProperty.html#instance-member-[foo]",
    "<span>TestComputedProperty#[foo]</span> <span class=\"search-result-import-path\">test/fixture/package/src/computed/Property.js</span>",
    "member"
  ],
  [
    "testcomputedproperty#constructor",
    "class/test/fixture/package/src/computed/Property.js~TestComputedProperty.html#instance-constructor-constructor",
    "<span>TestComputedProperty#constructor</span> <span class=\"search-result-import-path\">test/fixture/package/src/computed/Property.js</span>",
    "method"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/computed/property.js~testcomputedproperty",
    "class/test/fixture/package/src/computed/Property.js~TestComputedProperty.html",
    "<span>TestComputedProperty</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/computed/Property.js</span>",
    "class"
  ],
  [
    "testdecoratordefinition#method1",
    "class/test/fixture/package/src/decorator/Definition.js~TestDecoratorDefinition.html#instance-method-method1",
    "<span>TestDecoratorDefinition#method1</span> <span class=\"search-result-import-path\">test/fixture/package/src/decorator/Definition.js</span>",
    "method"
  ],
  [
    "testdecoratordefinition#value1",
    "class/test/fixture/package/src/decorator/Definition.js~TestDecoratorDefinition.html#instance-get-value1",
    "<span>TestDecoratorDefinition#value1</span> <span class=\"search-result-import-path\">test/fixture/package/src/decorator/Definition.js</span>",
    "member"
  ],
  [
    "testdecoratordefinition#value2",
    "class/test/fixture/package/src/decorator/Definition.js~TestDecoratorDefinition.html#instance-set-value2",
    "<span>TestDecoratorDefinition#value2</span> <span class=\"search-result-import-path\">test/fixture/package/src/decorator/Definition.js</span>",
    "member"
  ],
  [
    "testdecoratordefinition.method1",
    "class/test/fixture/package/src/decorator/Definition.js~TestDecoratorDefinition.html#static-method-method1",
    "<span>TestDecoratorDefinition.method1</span> <span class=\"search-result-import-path\">test/fixture/package/src/decorator/Definition.js</span>",
    "method"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/decorator/definition.js~testdecoratordefinition",
    "class/test/fixture/package/src/decorator/Definition.js~TestDecoratorDefinition.html",
    "<span>TestDecoratorDefinition</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/decorator/Definition.js</span>",
    "class"
  ],
  [
    "testdeprecatedclass#constructor",
    "class/test/fixture/package/src/deprecated/Class.js~TestDeprecatedClass.html#instance-constructor-constructor",
    "<span>TestDeprecatedClass#constructor</span> <span class=\"search-result-import-path\">test/fixture/package/src/deprecated/Class.js</span>",
    "method"
  ],
  [
    "testdeprecatedclass#method1",
    "class/test/fixture/package/src/deprecated/Class.js~TestDeprecatedClass.html#instance-method-method1",
    "<span>TestDeprecatedClass#method1</span> <span class=\"search-result-import-path\">test/fixture/package/src/deprecated/Class.js</span>",
    "method"
  ],
  [
    "testdeprecatedclass#p1",
    "class/test/fixture/package/src/deprecated/Class.js~TestDeprecatedClass.html#instance-member-p1",
    "<span>TestDeprecatedClass#p1</span> <span class=\"search-result-import-path\">test/fixture/package/src/deprecated/Class.js</span>",
    "member"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/deprecated/class.js~testdeprecatedclass",
    "class/test/fixture/package/src/deprecated/Class.js~TestDeprecatedClass.html",
    "<span>TestDeprecatedClass</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/deprecated/Class.js</span>",
    "class"
  ],
  [
    "testdescclass#constructor",
    "class/test/fixture/package/src/desc/Class.js~TestDescClass.html#instance-constructor-constructor",
    "<span>TestDescClass#constructor</span> <span class=\"search-result-import-path\">test/fixture/package/src/desc/Class.js</span>",
    "method"
  ],
  [
    "testdescclass#method1",
    "class/test/fixture/package/src/desc/Class.js~TestDescClass.html#instance-method-method1",
    "<span>TestDescClass#method1</span> <span class=\"search-result-import-path\">test/fixture/package/src/desc/Class.js</span>",
    "method"
  ],
  [
    "testdescclass#p1",
    "class/test/fixture/package/src/desc/Class.js~TestDescClass.html#instance-member-p1",
    "<span>TestDescClass#p1</span> <span class=\"search-result-import-path\">test/fixture/package/src/desc/Class.js</span>",
    "member"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/desc/class.js~testdescclass",
    "class/test/fixture/package/src/desc/Class.js~TestDescClass.html",
    "<span>TestDescClass</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/desc/Class.js</span>",
    "class"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/desc/markdown.js~testdescmarkdown",
    "class/test/fixture/package/src/desc/Markdown.js~TestDescMarkdown.html",
    "<span>TestDescMarkdown</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/desc/Markdown.js</span>",
    "class"
  ],
  [
    "testdescmultiline#method1",
    "class/test/fixture/package/src/desc/MultiLine.js~TestDescMultiLine.html#instance-method-method1",
    "<span>TestDescMultiLine#method1</span> <span class=\"search-result-import-path\">test/fixture/package/src/desc/MultiLine.js</span>",
    "method"
  ],
  [
    "testdescmultiline#method2",
    "class/test/fixture/package/src/desc/MultiLine.js~TestDescMultiLine.html#instance-method-method2",
    "<span>TestDescMultiLine#method2</span> <span class=\"search-result-import-path\">test/fixture/package/src/desc/MultiLine.js</span>",
    "method"
  ],
  [
    "testdescmultiline#method3",
    "class/test/fixture/package/src/desc/MultiLine.js~TestDescMultiLine.html#instance-method-method3",
    "<span>TestDescMultiLine#method3</span> <span class=\"search-result-import-path\">test/fixture/package/src/desc/MultiLine.js</span>",
    "method"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/desc/multiline.js~testdescmultiline",
    "class/test/fixture/package/src/desc/MultiLine.js~TestDescMultiLine.html",
    "<span>TestDescMultiLine</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/desc/MultiLine.js</span>",
    "class"
  ],
  [
    "testdestructuringarray#method1",
    "class/test/fixture/package/src/destructuring/Array.js~TestDestructuringArray.html#instance-method-method1",
    "<span>TestDestructuringArray#method1</span> <span class=\"search-result-import-path\">test/fixture/package/src/destructuring/Array.js</span>",
    "method"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/destructuring/array.js~testdestructuringarray",
    "class/test/fixture/package/src/destructuring/Array.js~TestDestructuringArray.html",
    "<span>TestDestructuringArray</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/destructuring/Array.js</span>",
    "class"
  ],
  [
    "testdestructuringobject#method1",
    "class/test/fixture/package/src/destructuring/Object.js~TestDestructuringObject.html#instance-method-method1",
    "<span>TestDestructuringObject#method1</span> <span class=\"search-result-import-path\">test/fixture/package/src/destructuring/Object.js</span>",
    "method"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/destructuring/object.js~testdestructuringobject",
    "class/test/fixture/package/src/destructuring/Object.js~TestDestructuringObject.html",
    "<span>TestDestructuringObject</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/destructuring/Object.js</span>",
    "class"
  ],
  [
    "testduplicationdefinition#constructor",
    "class/test/fixture/package/src/duplication/Definition.js~TestDuplicationDefinition.html#instance-constructor-constructor",
    "<span>TestDuplicationDefinition#constructor</span> <span class=\"search-result-import-path\">test/fixture/package/src/duplication/Definition.js</span>",
    "method"
  ],
  [
    "testduplicationdefinition#onclick",
    "class/test/fixture/package/src/duplication/Definition.js~TestDuplicationDefinition.html#instance-method-onClick",
    "<span>TestDuplicationDefinition#onClick</span> <span class=\"search-result-import-path\">test/fixture/package/src/duplication/Definition.js</span>",
    "method"
  ],
  [
    "testduplicationdefinition#value",
    "class/test/fixture/package/src/duplication/Definition.js~TestDuplicationDefinition.html#instance-set-value",
    "<span>TestDuplicationDefinition#value</span> <span class=\"search-result-import-path\">test/fixture/package/src/duplication/Definition.js</span>",
    "member"
  ],
  [
    "testduplicationdefinition#value",
    "class/test/fixture/package/src/duplication/Definition.js~TestDuplicationDefinition.html#instance-get-value",
    "<span>TestDuplicationDefinition#value</span> <span class=\"search-result-import-path\">test/fixture/package/src/duplication/Definition.js</span>",
    "member"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/duplication/definition.js~testduplicationdefinition",
    "class/test/fixture/package/src/duplication/Definition.js~TestDuplicationDefinition.html",
    "<span>TestDuplicationDefinition</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/duplication/Definition.js</span>",
    "class"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/emits/function.js~testemitsfunctionevent",
    "class/test/fixture/package/src/emits/Function.js~TestEmitsFunctionEvent.html",
    "<span>TestEmitsFunctionEvent</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/emits/Function.js</span>",
    "class"
  ],
  [
    "testemitsmethod#method1",
    "class/test/fixture/package/src/emits/Method.js~TestEmitsMethod.html#instance-method-method1",
    "<span>TestEmitsMethod#method1</span> <span class=\"search-result-import-path\">test/fixture/package/src/emits/Method.js</span>",
    "method"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/emits/method.js~testemitsmethod",
    "class/test/fixture/package/src/emits/Method.js~TestEmitsMethod.html",
    "<span>TestEmitsMethod</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/emits/Method.js</span>",
    "class"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/emits/method.js~testemitsmethodevent1",
    "class/test/fixture/package/src/emits/Method.js~TestEmitsMethodEvent1.html",
    "<span>TestEmitsMethodEvent1</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/emits/Method.js</span>",
    "class"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/emits/method.js~testemitsmethodevent2",
    "class/test/fixture/package/src/emits/Method.js~TestEmitsMethodEvent2.html",
    "<span>TestEmitsMethodEvent2</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/emits/Method.js</span>",
    "class"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/example/caption.js~testexamplecaption",
    "class/test/fixture/package/src/example/Caption.js~TestExampleCaption.html",
    "<span>TestExampleCaption</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/example/Caption.js</span>",
    "class"
  ],
  [
    "testexampleclass#constructor",
    "class/test/fixture/package/src/example/Class.js~TestExampleClass.html#instance-constructor-constructor",
    "<span>TestExampleClass#constructor</span> <span class=\"search-result-import-path\">test/fixture/package/src/example/Class.js</span>",
    "method"
  ],
  [
    "testexampleclass#method1",
    "class/test/fixture/package/src/example/Class.js~TestExampleClass.html#instance-method-method1",
    "<span>TestExampleClass#method1</span> <span class=\"search-result-import-path\">test/fixture/package/src/example/Class.js</span>",
    "method"
  ],
  [
    "testexampleclass#p1",
    "class/test/fixture/package/src/example/Class.js~TestExampleClass.html#instance-member-p1",
    "<span>TestExampleClass#p1</span> <span class=\"search-result-import-path\">test/fixture/package/src/example/Class.js</span>",
    "member"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/example/class.js~testexampleclass",
    "class/test/fixture/package/src/example/Class.js~TestExampleClass.html",
    "<span>TestExampleClass</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/example/Class.js</span>",
    "class"
  ],
  [
    "testexperimentalclass#constructor",
    "class/test/fixture/package/src/experimental/Class.js~TestExperimentalClass.html#instance-constructor-constructor",
    "<span>TestExperimentalClass#constructor</span> <span class=\"search-result-import-path\">test/fixture/package/src/experimental/Class.js</span>",
    "method"
  ],
  [
    "testexperimentalclass#method1",
    "class/test/fixture/package/src/experimental/Class.js~TestExperimentalClass.html#instance-method-method1",
    "<span>TestExperimentalClass#method1</span> <span class=\"search-result-import-path\">test/fixture/package/src/experimental/Class.js</span>",
    "method"
  ],
  [
    "testexperimentalclass#p1",
    "class/test/fixture/package/src/experimental/Class.js~TestExperimentalClass.html#instance-member-p1",
    "<span>TestExperimentalClass#p1</span> <span class=\"search-result-import-path\">test/fixture/package/src/experimental/Class.js</span>",
    "member"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/experimental/class.js~testexperimentalclass",
    "class/test/fixture/package/src/experimental/Class.js~TestExperimentalClass.html",
    "<span>TestExperimentalClass</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/experimental/Class.js</span>",
    "class"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/extends/mixinexplicit.js~testexplicitmixin1",
    "class/test/fixture/package/src/extends/MixinExplicit.js~TestExplicitMixin1.html",
    "<span>TestExplicitMixin1</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/extends/MixinExplicit.js</span>",
    "class"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/extends/mixinexplicit.js~testexplicitmixin2",
    "class/test/fixture/package/src/extends/MixinExplicit.js~TestExplicitMixin2.html",
    "<span>TestExplicitMixin2</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/extends/MixinExplicit.js</span>",
    "class"
  ],
  [
    "testexponentiationoperatordefinition#method1",
    "class/test/fixture/package/src/exponentiationoperator/Definition.js~TestExponentiationOperatorDefinition.html#instance-method-method1",
    "<span>TestExponentiationOperatorDefinition#method1</span> <span class=\"search-result-import-path\">test/fixture/package/src/exponentiationoperator/Definition.js</span>",
    "method"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/exponentiationoperator/definition.js~testexponentiationoperatordefinition",
    "class/test/fixture/package/src/exponentiationoperator/Definition.js~TestExponentiationOperatorDefinition.html",
    "<span>TestExponentiationOperatorDefinition</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/exponentiationoperator/Definition.js</span>",
    "class"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/export/class.js~testexportclass1",
    "class/test/fixture/package/src/export/Class.js~TestExportClass1.html",
    "<span>TestExportClass1</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/export/Class.js</span>",
    "class"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/export/class.js~testexportclass2",
    "class/test/fixture/package/src/export/Class.js~TestExportClass2.html",
    "<span>TestExportClass2</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/export/Class.js</span>",
    "class"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/export/class.js~testexportclass3",
    "class/test/fixture/package/src/export/Class.js~TestExportClass3.html",
    "<span>TestExportClass3</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/export/Class.js</span>",
    "class"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/export/class.js~testexportclass4",
    "class/test/fixture/package/src/export/Class.js~TestExportClass4.html",
    "<span>TestExportClass4</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/export/Class.js</span>",
    "class"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/export/class.js~testexportclass5",
    "class/test/fixture/package/src/export/Class.js~TestExportClass5.html",
    "<span>TestExportClass5</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/export/Class.js</span>",
    "class"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/export/classindirectdefault.js~testexportclassindirectdefault",
    "class/test/fixture/package/src/export/ClassIndirectDefault.js~TestExportClassIndirectDefault.html",
    "<span>TestExportClassIndirectDefault</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/export/ClassIndirectDefault.js</span>",
    "class"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/export/default.js~testexportdefault",
    "class/test/fixture/package/src/export/Default.js~TestExportDefault.html",
    "<span>TestExportDefault</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/export/Default.js</span>",
    "class"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/export/extends.js~testexportextends",
    "class/test/fixture/package/src/export/Extends.js~TestExportExtends.html",
    "<span>TestExportExtends</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/export/Extends.js</span>",
    "class"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/export/extends.js~testexportextendsinner",
    "class/test/fixture/package/src/export/Extends.js~TestExportExtendsInner.html",
    "<span>TestExportExtendsInner</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/export/Extends.js</span>",
    "class"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/export/multiple.js~testexportmultiple",
    "class/test/fixture/package/src/export/Multiple.js~TestExportMultiple.html",
    "<span>TestExportMultiple</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/export/Multiple.js</span>",
    "class"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/export/named.js~testexportnamed",
    "class/test/fixture/package/src/export/Named.js~TestExportNamed.html",
    "<span>TestExportNamed</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/export/Named.js</span>",
    "class"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/export/newexpression.js~testexportnewexpression2",
    "class/test/fixture/package/src/export/NewExpression.js~TestExportNewExpression2.html",
    "<span>TestExportNewExpression2</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/export/NewExpression.js</span>",
    "class"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/export/newexpression.js~testexportnewexpression",
    "class/test/fixture/package/src/export/NewExpression.js~TestExportNewExpression.html",
    "<span>TestExportNewExpression</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/export/NewExpression.js</span>",
    "class"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/export/newexpressionindirect.js~testexportnewexpressionindirect",
    "class/test/fixture/package/src/export/NewExpressionIndirect.js~TestExportNewExpressionIndirect.html",
    "<span>TestExportNewExpressionIndirect</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/export/NewExpressionIndirect.js</span>",
    "class"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/export/newexpressionproperty.js~testexportnewexpressionproperty",
    "class/test/fixture/package/src/export/NewExpressionProperty.js~TestExportNewExpressionProperty.html",
    "<span>TestExportNewExpressionProperty</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/export/NewExpressionProperty.js</span>",
    "class"
  ],
  [
    "testextendsbuiltin#method1",
    "class/test/fixture/package/src/extends/Builtin.js~TestExtendsBuiltin.html#instance-method-method1",
    "<span>TestExtendsBuiltin#method1</span> <span class=\"search-result-import-path\">test/fixture/package/src/extends/Builtin.js</span>",
    "method"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/extends/builtin.js~testextendsbuiltin",
    "class/test/fixture/package/src/extends/Builtin.js~TestExtendsBuiltin.html",
    "<span>TestExtendsBuiltin</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/extends/Builtin.js</span>",
    "class"
  ],
  [
    "testextendsdeeprectangle#methodrectangle",
    "class/test/fixture/package/src/extends/Deep.js~TestExtendsDeepRectangle.html#instance-method-methodRectangle",
    "<span>TestExtendsDeepRectangle#methodRectangle</span> <span class=\"search-result-import-path\">test/fixture/package/src/extends/Deep.js</span>",
    "method"
  ],
  [
    "testextendsdeeprectangle#prectangle",
    "class/test/fixture/package/src/extends/Deep.js~TestExtendsDeepRectangle.html#instance-member-pRectangle",
    "<span>TestExtendsDeepRectangle#pRectangle</span> <span class=\"search-result-import-path\">test/fixture/package/src/extends/Deep.js</span>",
    "member"
  ],
  [
    "testextendsdeeprectangle#valuerectangle",
    "class/test/fixture/package/src/extends/Deep.js~TestExtendsDeepRectangle.html#instance-set-valueRectangle",
    "<span>TestExtendsDeepRectangle#valueRectangle</span> <span class=\"search-result-import-path\">test/fixture/package/src/extends/Deep.js</span>",
    "member"
  ],
  [
    "testextendsdeeprectangle#valuerectangle",
    "class/test/fixture/package/src/extends/Deep.js~TestExtendsDeepRectangle.html#instance-get-valueRectangle",
    "<span>TestExtendsDeepRectangle#valueRectangle</span> <span class=\"search-result-import-path\">test/fixture/package/src/extends/Deep.js</span>",
    "member"
  ],
  [
    "testextendsdeeprectangle.staticmethodrectangle",
    "class/test/fixture/package/src/extends/Deep.js~TestExtendsDeepRectangle.html#static-method-staticMethodRectangle",
    "<span>TestExtendsDeepRectangle.staticMethodRectangle</span> <span class=\"search-result-import-path\">test/fixture/package/src/extends/Deep.js</span>",
    "method"
  ],
  [
    "testextendsdeeprectangle.staticprectangle",
    "class/test/fixture/package/src/extends/Deep.js~TestExtendsDeepRectangle.html#static-member-staticPRectangle",
    "<span>TestExtendsDeepRectangle.staticPRectangle</span> <span class=\"search-result-import-path\">test/fixture/package/src/extends/Deep.js</span>",
    "member"
  ],
  [
    "testextendsdeeprectangle.staticvaluerectangle",
    "class/test/fixture/package/src/extends/Deep.js~TestExtendsDeepRectangle.html#static-get-staticValueRectangle",
    "<span>TestExtendsDeepRectangle.staticValueRectangle</span> <span class=\"search-result-import-path\">test/fixture/package/src/extends/Deep.js</span>",
    "member"
  ],
  [
    "testextendsdeeprectangle.staticvaluerectangle",
    "class/test/fixture/package/src/extends/Deep.js~TestExtendsDeepRectangle.html#static-set-staticValueRectangle",
    "<span>TestExtendsDeepRectangle.staticValueRectangle</span> <span class=\"search-result-import-path\">test/fixture/package/src/extends/Deep.js</span>",
    "member"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/extends/deep.js~testextendsdeeprectangle",
    "class/test/fixture/package/src/extends/Deep.js~TestExtendsDeepRectangle.html",
    "<span>TestExtendsDeepRectangle</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/extends/Deep.js</span>",
    "class"
  ],
  [
    "testextendsdeepshape#methodshape",
    "class/test/fixture/package/src/extends/Deep.js~TestExtendsDeepShape.html#instance-method-methodShape",
    "<span>TestExtendsDeepShape#methodShape</span> <span class=\"search-result-import-path\">test/fixture/package/src/extends/Deep.js</span>",
    "method"
  ],
  [
    "testextendsdeepshape#pshape",
    "class/test/fixture/package/src/extends/Deep.js~TestExtendsDeepShape.html#instance-member-pShape",
    "<span>TestExtendsDeepShape#pShape</span> <span class=\"search-result-import-path\">test/fixture/package/src/extends/Deep.js</span>",
    "member"
  ],
  [
    "testextendsdeepshape#valueshape",
    "class/test/fixture/package/src/extends/Deep.js~TestExtendsDeepShape.html#instance-set-valueShape",
    "<span>TestExtendsDeepShape#valueShape</span> <span class=\"search-result-import-path\">test/fixture/package/src/extends/Deep.js</span>",
    "member"
  ],
  [
    "testextendsdeepshape#valueshape",
    "class/test/fixture/package/src/extends/Deep.js~TestExtendsDeepShape.html#instance-get-valueShape",
    "<span>TestExtendsDeepShape#valueShape</span> <span class=\"search-result-import-path\">test/fixture/package/src/extends/Deep.js</span>",
    "member"
  ],
  [
    "testextendsdeepshape.staticmethodshape",
    "class/test/fixture/package/src/extends/Deep.js~TestExtendsDeepShape.html#static-method-staticMethodShape",
    "<span>TestExtendsDeepShape.staticMethodShape</span> <span class=\"search-result-import-path\">test/fixture/package/src/extends/Deep.js</span>",
    "method"
  ],
  [
    "testextendsdeepshape.staticpshape",
    "class/test/fixture/package/src/extends/Deep.js~TestExtendsDeepShape.html#static-member-staticPShape",
    "<span>TestExtendsDeepShape.staticPShape</span> <span class=\"search-result-import-path\">test/fixture/package/src/extends/Deep.js</span>",
    "member"
  ],
  [
    "testextendsdeepshape.staticvalueshape",
    "class/test/fixture/package/src/extends/Deep.js~TestExtendsDeepShape.html#static-get-staticValueShape",
    "<span>TestExtendsDeepShape.staticValueShape</span> <span class=\"search-result-import-path\">test/fixture/package/src/extends/Deep.js</span>",
    "member"
  ],
  [
    "testextendsdeepshape.staticvalueshape",
    "class/test/fixture/package/src/extends/Deep.js~TestExtendsDeepShape.html#static-set-staticValueShape",
    "<span>TestExtendsDeepShape.staticValueShape</span> <span class=\"search-result-import-path\">test/fixture/package/src/extends/Deep.js</span>",
    "member"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/extends/deep.js~testextendsdeepshape",
    "class/test/fixture/package/src/extends/Deep.js~TestExtendsDeepShape.html",
    "<span>TestExtendsDeepShape</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/extends/Deep.js</span>",
    "class"
  ],
  [
    "testextendsdeepsquare#methodsquare",
    "class/test/fixture/package/src/extends/Deep.js~TestExtendsDeepSquare.html#instance-method-methodSquare",
    "<span>TestExtendsDeepSquare#methodSquare</span> <span class=\"search-result-import-path\">test/fixture/package/src/extends/Deep.js</span>",
    "method"
  ],
  [
    "testextendsdeepsquare#psquare",
    "class/test/fixture/package/src/extends/Deep.js~TestExtendsDeepSquare.html#instance-member-pSquare",
    "<span>TestExtendsDeepSquare#pSquare</span> <span class=\"search-result-import-path\">test/fixture/package/src/extends/Deep.js</span>",
    "member"
  ],
  [
    "testextendsdeepsquare#valuesquare",
    "class/test/fixture/package/src/extends/Deep.js~TestExtendsDeepSquare.html#instance-get-valueSquare",
    "<span>TestExtendsDeepSquare#valueSquare</span> <span class=\"search-result-import-path\">test/fixture/package/src/extends/Deep.js</span>",
    "member"
  ],
  [
    "testextendsdeepsquare#valuesquare",
    "class/test/fixture/package/src/extends/Deep.js~TestExtendsDeepSquare.html#instance-set-valueSquare",
    "<span>TestExtendsDeepSquare#valueSquare</span> <span class=\"search-result-import-path\">test/fixture/package/src/extends/Deep.js</span>",
    "member"
  ],
  [
    "testextendsdeepsquare.staticmethodsquare",
    "class/test/fixture/package/src/extends/Deep.js~TestExtendsDeepSquare.html#static-method-staticMethodSquare",
    "<span>TestExtendsDeepSquare.staticMethodSquare</span> <span class=\"search-result-import-path\">test/fixture/package/src/extends/Deep.js</span>",
    "method"
  ],
  [
    "testextendsdeepsquare.staticpsquare",
    "class/test/fixture/package/src/extends/Deep.js~TestExtendsDeepSquare.html#static-member-staticPSquare",
    "<span>TestExtendsDeepSquare.staticPSquare</span> <span class=\"search-result-import-path\">test/fixture/package/src/extends/Deep.js</span>",
    "member"
  ],
  [
    "testextendsdeepsquare.staticvaluesquare",
    "class/test/fixture/package/src/extends/Deep.js~TestExtendsDeepSquare.html#static-get-staticValueSquare",
    "<span>TestExtendsDeepSquare.staticValueSquare</span> <span class=\"search-result-import-path\">test/fixture/package/src/extends/Deep.js</span>",
    "member"
  ],
  [
    "testextendsdeepsquare.staticvaluesquare",
    "class/test/fixture/package/src/extends/Deep.js~TestExtendsDeepSquare.html#static-set-staticValueSquare",
    "<span>TestExtendsDeepSquare.staticValueSquare</span> <span class=\"search-result-import-path\">test/fixture/package/src/extends/Deep.js</span>",
    "member"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/extends/deep.js~testextendsdeepsquare",
    "class/test/fixture/package/src/extends/Deep.js~TestExtendsDeepSquare.html",
    "<span>TestExtendsDeepSquare</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/extends/Deep.js</span>",
    "class"
  ],
  [
    "testextendsexpression#method1",
    "class/test/fixture/package/src/extends/Expression.js~TestExtendsExpression.html#instance-method-method1",
    "<span>TestExtendsExpression#method1</span> <span class=\"search-result-import-path\">test/fixture/package/src/extends/Expression.js</span>",
    "method"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/extends/expression.js~testextendsexpression",
    "class/test/fixture/package/src/extends/Expression.js~TestExtendsExpression.html",
    "<span>TestExtendsExpression</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/extends/Expression.js</span>",
    "class"
  ],
  [
    "testextendsinner#method1",
    "class/test/fixture/package/src/extends/Inner.js~TestExtendsInner.html#instance-method-method1",
    "<span>TestExtendsInner#method1</span> <span class=\"search-result-import-path\">test/fixture/package/src/extends/Inner.js</span>",
    "method"
  ],
  [
    "testextendsinner#method3",
    "class/test/fixture/package/src/extends/Inner.js~TestExtendsInner.html#instance-method-method3",
    "<span>TestExtendsInner#method3</span> <span class=\"search-result-import-path\">test/fixture/package/src/extends/Inner.js</span>",
    "method"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/extends/inner.js~testextendsinner",
    "class/test/fixture/package/src/extends/Inner.js~TestExtendsInner.html",
    "<span>TestExtendsInner</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/extends/Inner.js</span>",
    "class"
  ],
  [
    "testextendsmixin#method3",
    "class/test/fixture/package/src/extends/Mixin.js~TestExtendsMixin.html#instance-method-method3",
    "<span>TestExtendsMixin#method3</span> <span class=\"search-result-import-path\">test/fixture/package/src/extends/Mixin.js</span>",
    "method"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/extends/mixin.js~testextendsmixin",
    "class/test/fixture/package/src/extends/Mixin.js~TestExtendsMixin.html",
    "<span>TestExtendsMixin</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/extends/Mixin.js</span>",
    "class"
  ],
  [
    "testextendsmixininner1#method1",
    "class/test/fixture/package/src/extends/Mixin.js~TestExtendsMixinInner1.html#instance-method-method1",
    "<span>TestExtendsMixinInner1#method1</span> <span class=\"search-result-import-path\">test/fixture/package/src/extends/Mixin.js</span>",
    "method"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/extends/mixin.js~testextendsmixininner1",
    "class/test/fixture/package/src/extends/Mixin.js~TestExtendsMixinInner1.html",
    "<span>TestExtendsMixinInner1</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/extends/Mixin.js</span>",
    "class"
  ],
  [
    "testextendsmixininner2#method2",
    "class/test/fixture/package/src/extends/Mixin.js~TestExtendsMixinInner2.html#instance-method-method2",
    "<span>TestExtendsMixinInner2#method2</span> <span class=\"search-result-import-path\">test/fixture/package/src/extends/Mixin.js</span>",
    "method"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/extends/mixin.js~testextendsmixininner2",
    "class/test/fixture/package/src/extends/Mixin.js~TestExtendsMixinInner2.html",
    "<span>TestExtendsMixinInner2</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/extends/Mixin.js</span>",
    "class"
  ],
  [
    "testextendsouter#method1",
    "class/test/fixture/package/src/extends/Outer.js~TestExtendsOuter.html#instance-method-method1",
    "<span>TestExtendsOuter#method1</span> <span class=\"search-result-import-path\">test/fixture/package/src/extends/Outer.js</span>",
    "method"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/extends/outer.js~testextendsouter",
    "class/test/fixture/package/src/extends/Outer.js~TestExtendsOuter.html",
    "<span>TestExtendsOuter</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/extends/Outer.js</span>",
    "class"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/extends/property.js~testextendsproperty",
    "class/test/fixture/package/src/extends/Property.js~TestExtendsProperty.html",
    "<span>TestExtendsProperty</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/extends/Property.js</span>",
    "class"
  ],
  [
    "testgeneratormethod#method1",
    "class/test/fixture/package/src/generator/Method.js~TestGeneratorMethod.html#instance-method-method1",
    "<span>TestGeneratorMethod#method1</span> <span class=\"search-result-import-path\">test/fixture/package/src/generator/Method.js</span>",
    "method"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/generator/method.js~testgeneratormethod",
    "class/test/fixture/package/src/generator/Method.js~TestGeneratorMethod.html",
    "<span>TestGeneratorMethod</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/generator/Method.js</span>",
    "class"
  ],
  [
    "testguessobjectdestructuredefault#method2",
    "class/test/fixture/package/src/guess/ObjectDefaultParam.js~TestGuessObjectDestructureDefault.html#instance-method-method2",
    "<span>TestGuessObjectDestructureDefault#method2</span> <span class=\"search-result-import-path\">test/fixture/package/src/guess/ObjectDefaultParam.js</span>",
    "method"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/guess/objectdefaultparam.js~testguessobjectdestructuredefault",
    "class/test/fixture/package/src/guess/ObjectDefaultParam.js~TestGuessObjectDestructureDefault.html",
    "<span>TestGuessObjectDestructureDefault</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/guess/ObjectDefaultParam.js</span>",
    "class"
  ],
  [
    "testguessparam#method10",
    "class/test/fixture/package/src/guess/Param.js~TestGuessParam.html#instance-method-method10",
    "<span>TestGuessParam#method10</span> <span class=\"search-result-import-path\">test/fixture/package/src/guess/Param.js</span>",
    "method"
  ],
  [
    "testguessparam#method1",
    "class/test/fixture/package/src/guess/Param.js~TestGuessParam.html#instance-method-method1",
    "<span>TestGuessParam#method1</span> <span class=\"search-result-import-path\">test/fixture/package/src/guess/Param.js</span>",
    "method"
  ],
  [
    "testguessparam#method2",
    "class/test/fixture/package/src/guess/Param.js~TestGuessParam.html#instance-method-method2",
    "<span>TestGuessParam#method2</span> <span class=\"search-result-import-path\">test/fixture/package/src/guess/Param.js</span>",
    "method"
  ],
  [
    "testguessparam#method3",
    "class/test/fixture/package/src/guess/Param.js~TestGuessParam.html#instance-method-method3",
    "<span>TestGuessParam#method3</span> <span class=\"search-result-import-path\">test/fixture/package/src/guess/Param.js</span>",
    "method"
  ],
  [
    "testguessparam#method4",
    "class/test/fixture/package/src/guess/Param.js~TestGuessParam.html#instance-method-method4",
    "<span>TestGuessParam#method4</span> <span class=\"search-result-import-path\">test/fixture/package/src/guess/Param.js</span>",
    "method"
  ],
  [
    "testguessparam#method5",
    "class/test/fixture/package/src/guess/Param.js~TestGuessParam.html#instance-method-method5",
    "<span>TestGuessParam#method5</span> <span class=\"search-result-import-path\">test/fixture/package/src/guess/Param.js</span>",
    "method"
  ],
  [
    "testguessparam#method6",
    "class/test/fixture/package/src/guess/Param.js~TestGuessParam.html#instance-method-method6",
    "<span>TestGuessParam#method6</span> <span class=\"search-result-import-path\">test/fixture/package/src/guess/Param.js</span>",
    "method"
  ],
  [
    "testguessparam#method7",
    "class/test/fixture/package/src/guess/Param.js~TestGuessParam.html#instance-method-method7",
    "<span>TestGuessParam#method7</span> <span class=\"search-result-import-path\">test/fixture/package/src/guess/Param.js</span>",
    "method"
  ],
  [
    "testguessparam#method8",
    "class/test/fixture/package/src/guess/Param.js~TestGuessParam.html#instance-method-method8",
    "<span>TestGuessParam#method8</span> <span class=\"search-result-import-path\">test/fixture/package/src/guess/Param.js</span>",
    "method"
  ],
  [
    "testguessparam#method9",
    "class/test/fixture/package/src/guess/Param.js~TestGuessParam.html#instance-method-method9",
    "<span>TestGuessParam#method9</span> <span class=\"search-result-import-path\">test/fixture/package/src/guess/Param.js</span>",
    "method"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/guess/param.js~testguessparam",
    "class/test/fixture/package/src/guess/Param.js~TestGuessParam.html",
    "<span>TestGuessParam</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/guess/Param.js</span>",
    "class"
  ],
  [
    "testguessproperty#constructor",
    "class/test/fixture/package/src/guess/Property.js~TestGuessProperty.html#instance-constructor-constructor",
    "<span>TestGuessProperty#constructor</span> <span class=\"search-result-import-path\">test/fixture/package/src/guess/Property.js</span>",
    "method"
  ],
  [
    "testguessproperty#p1",
    "class/test/fixture/package/src/guess/Property.js~TestGuessProperty.html#instance-member-p1",
    "<span>TestGuessProperty#p1</span> <span class=\"search-result-import-path\">test/fixture/package/src/guess/Property.js</span>",
    "member"
  ],
  [
    "testguessproperty#p2",
    "class/test/fixture/package/src/guess/Property.js~TestGuessProperty.html#instance-member-p2",
    "<span>TestGuessProperty#p2</span> <span class=\"search-result-import-path\">test/fixture/package/src/guess/Property.js</span>",
    "member"
  ],
  [
    "testguessproperty#p3",
    "class/test/fixture/package/src/guess/Property.js~TestGuessProperty.html#instance-member-p3",
    "<span>TestGuessProperty#p3</span> <span class=\"search-result-import-path\">test/fixture/package/src/guess/Property.js</span>",
    "member"
  ],
  [
    "testguessproperty#p4",
    "class/test/fixture/package/src/guess/Property.js~TestGuessProperty.html#instance-member-p4",
    "<span>TestGuessProperty#p4</span> <span class=\"search-result-import-path\">test/fixture/package/src/guess/Property.js</span>",
    "member"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/guess/property.js~testguessproperty",
    "class/test/fixture/package/src/guess/Property.js~TestGuessProperty.html",
    "<span>TestGuessProperty</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/guess/Property.js</span>",
    "class"
  ],
  [
    "testguessreturn#method1",
    "class/test/fixture/package/src/guess/Return.js~TestGuessReturn.html#instance-method-method1",
    "<span>TestGuessReturn#method1</span> <span class=\"search-result-import-path\">test/fixture/package/src/guess/Return.js</span>",
    "method"
  ],
  [
    "testguessreturn#method2",
    "class/test/fixture/package/src/guess/Return.js~TestGuessReturn.html#instance-method-method2",
    "<span>TestGuessReturn#method2</span> <span class=\"search-result-import-path\">test/fixture/package/src/guess/Return.js</span>",
    "method"
  ],
  [
    "testguessreturn#method3",
    "class/test/fixture/package/src/guess/Return.js~TestGuessReturn.html#instance-method-method3",
    "<span>TestGuessReturn#method3</span> <span class=\"search-result-import-path\">test/fixture/package/src/guess/Return.js</span>",
    "method"
  ],
  [
    "testguessreturn#method4",
    "class/test/fixture/package/src/guess/Return.js~TestGuessReturn.html#instance-method-method4",
    "<span>TestGuessReturn#method4</span> <span class=\"search-result-import-path\">test/fixture/package/src/guess/Return.js</span>",
    "method"
  ],
  [
    "testguessreturn#method5",
    "class/test/fixture/package/src/guess/Return.js~TestGuessReturn.html#instance-method-method5",
    "<span>TestGuessReturn#method5</span> <span class=\"search-result-import-path\">test/fixture/package/src/guess/Return.js</span>",
    "method"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/guess/return.js~testguessreturn",
    "class/test/fixture/package/src/guess/Return.js~TestGuessReturn.html",
    "<span>TestGuessReturn</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/guess/Return.js</span>",
    "class"
  ],
  [
    "testignoreclass2#constructor",
    "class/test/fixture/package/src/ignore/Class.js~TestIgnoreClass2.html#instance-constructor-constructor",
    "<span>TestIgnoreClass2#constructor</span> <span class=\"search-result-import-path\">test/fixture/package/src/ignore/Class.js</span>",
    "method"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/ignore/class.js~testignoreclass2",
    "class/test/fixture/package/src/ignore/Class.js~TestIgnoreClass2.html",
    "<span>TestIgnoreClass2</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/ignore/Class.js</span>",
    "class"
  ],
  [
    "testinterfacedefinition#method1",
    "class/test/fixture/package/src/interface/Definition.js~TestInterfaceDefinition.html#instance-method-method1",
    "<span>TestInterfaceDefinition#method1</span> <span class=\"search-result-import-path\">test/fixture/package/src/interface/Definition.js</span>",
    "method"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/interface/definition.js~testinterfacedefinition",
    "class/test/fixture/package/src/interface/Definition.js~TestInterfaceDefinition.html",
    "<span>TestInterfaceDefinition</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/interface/Definition.js</span>",
    "class"
  ],
  [
    "testinterfaceimplements#method1",
    "class/test/fixture/package/src/interface/Implements.js~TestInterfaceImplements.html#instance-method-method1",
    "<span>TestInterfaceImplements#method1</span> <span class=\"search-result-import-path\">test/fixture/package/src/interface/Implements.js</span>",
    "method"
  ],
  [
    "testinterfaceimplements#method2",
    "class/test/fixture/package/src/interface/Implements.js~TestInterfaceImplements.html#instance-method-method2",
    "<span>TestInterfaceImplements#method2</span> <span class=\"search-result-import-path\">test/fixture/package/src/interface/Implements.js</span>",
    "method"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/interface/implements.js~testinterfaceimplements",
    "class/test/fixture/package/src/interface/Implements.js~TestInterfaceImplements.html",
    "<span>TestInterfaceImplements</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/interface/Implements.js</span>",
    "class"
  ],
  [
    "testinterfaceimplementsinner#method2",
    "class/test/fixture/package/src/interface/Implements.js~TestInterfaceImplementsInner.html#instance-method-method2",
    "<span>TestInterfaceImplementsInner#method2</span> <span class=\"search-result-import-path\">test/fixture/package/src/interface/Implements.js</span>",
    "method"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/interface/implements.js~testinterfaceimplementsinner",
    "class/test/fixture/package/src/interface/Implements.js~TestInterfaceImplementsInner.html",
    "<span>TestInterfaceImplementsInner</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/interface/Implements.js</span>",
    "class"
  ],
  [
    "testjsxdefinition#method1",
    "class/test/fixture/package/src/jsx/Definition.js~TestJSXDefinition.html#instance-method-method1",
    "<span>TestJSXDefinition#method1</span> <span class=\"search-result-import-path\">test/fixture/package/src/jsx/Definition.js</span>",
    "method"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/jsx/definition.js~testjsxdefinition",
    "class/test/fixture/package/src/jsx/Definition.js~TestJSXDefinition.html",
    "<span>TestJSXDefinition</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/jsx/Definition.js</span>",
    "class"
  ],
  [
    "testlinkclass#constructor",
    "class/test/fixture/package/src/link/Class.js~TestLinkClass.html#instance-constructor-constructor",
    "<span>TestLinkClass#constructor</span> <span class=\"search-result-import-path\">test/fixture/package/src/link/Class.js</span>",
    "method"
  ],
  [
    "testlinkclass#method1",
    "class/test/fixture/package/src/link/Class.js~TestLinkClass.html#instance-method-method1",
    "<span>TestLinkClass#method1</span> <span class=\"search-result-import-path\">test/fixture/package/src/link/Class.js</span>",
    "method"
  ],
  [
    "testlinkclass#p1",
    "class/test/fixture/package/src/link/Class.js~TestLinkClass.html#instance-member-p1",
    "<span>TestLinkClass#p1</span> <span class=\"search-result-import-path\">test/fixture/package/src/link/Class.js</span>",
    "member"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/link/class.js~testlinkclass",
    "class/test/fixture/package/src/link/Class.js~TestLinkClass.html",
    "<span>TestLinkClass</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/link/Class.js</span>",
    "class"
  ],
  [
    "testlintinvalid#method1",
    "class/test/fixture/package/src/lint/Invalid.js~TestLintInvalid.html#instance-method-method1",
    "<span>TestLintInvalid#method1</span> <span class=\"search-result-import-path\">test/fixture/package/src/lint/Invalid.js</span>",
    "method"
  ],
  [
    "testlintinvalid#method2",
    "class/test/fixture/package/src/lint/Invalid.js~TestLintInvalid.html#instance-method-method2",
    "<span>TestLintInvalid#method2</span> <span class=\"search-result-import-path\">test/fixture/package/src/lint/Invalid.js</span>",
    "method"
  ],
  [
    "testlintinvalid#method3",
    "class/test/fixture/package/src/lint/Invalid.js~TestLintInvalid.html#instance-method-method3",
    "<span>TestLintInvalid#method3</span> <span class=\"search-result-import-path\">test/fixture/package/src/lint/Invalid.js</span>",
    "method"
  ],
  [
    "testlintinvalid#method4",
    "class/test/fixture/package/src/lint/Invalid.js~TestLintInvalid.html#instance-method-method4",
    "<span>TestLintInvalid#method4</span> <span class=\"search-result-import-path\">test/fixture/package/src/lint/Invalid.js</span>",
    "method"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/lint/invalid.js~testlintinvalid",
    "class/test/fixture/package/src/lint/Invalid.js~TestLintInvalid.html",
    "<span>TestLintInvalid</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/lint/Invalid.js</span>",
    "class"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/listens/function.js~testlistensfunctionevent",
    "class/test/fixture/package/src/listens/Function.js~TestListensFunctionEvent.html",
    "<span>TestListensFunctionEvent</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/listens/Function.js</span>",
    "class"
  ],
  [
    "testlistensmethod#method1",
    "class/test/fixture/package/src/listens/Method.js~TestListensMethod.html#instance-method-method1",
    "<span>TestListensMethod#method1</span> <span class=\"search-result-import-path\">test/fixture/package/src/listens/Method.js</span>",
    "method"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/listens/method.js~testlistensmethod",
    "class/test/fixture/package/src/listens/Method.js~TestListensMethod.html",
    "<span>TestListensMethod</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/listens/Method.js</span>",
    "class"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/listens/method.js~testlistensmethodevent1",
    "class/test/fixture/package/src/listens/Method.js~TestListensMethodEvent1.html",
    "<span>TestListensMethodEvent1</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/listens/Method.js</span>",
    "class"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/listens/method.js~testlistensmethodevent2",
    "class/test/fixture/package/src/listens/Method.js~TestListensMethodEvent2.html",
    "<span>TestListensMethodEvent2</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/listens/Method.js</span>",
    "class"
  ],
  [
    "testparammethod#method1",
    "class/test/fixture/package/src/param/Method.js~TestParamMethod.html#instance-method-method1",
    "<span>TestParamMethod#method1</span> <span class=\"search-result-import-path\">test/fixture/package/src/param/Method.js</span>",
    "method"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/param/method.js~testparammethod",
    "class/test/fixture/package/src/param/Method.js~TestParamMethod.html",
    "<span>TestParamMethod</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/param/Method.js</span>",
    "class"
  ],
  [
    "testpropertyreturn#method1",
    "class/test/fixture/package/src/property/Return.js~TestPropertyReturn.html#instance-method-method1",
    "<span>TestPropertyReturn#method1</span> <span class=\"search-result-import-path\">test/fixture/package/src/property/Return.js</span>",
    "method"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/property/return.js~testpropertyreturn",
    "class/test/fixture/package/src/property/Return.js~TestPropertyReturn.html",
    "<span>TestPropertyReturn</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/property/Return.js</span>",
    "class"
  ],
  [
    "testreturnmethod#method1",
    "class/test/fixture/package/src/return/Method.js~TestReturnMethod.html#instance-method-method1",
    "<span>TestReturnMethod#method1</span> <span class=\"search-result-import-path\">test/fixture/package/src/return/Method.js</span>",
    "method"
  ],
  [
    "testreturnmethod#method2",
    "class/test/fixture/package/src/return/Method.js~TestReturnMethod.html#instance-method-method2",
    "<span>TestReturnMethod#method2</span> <span class=\"search-result-import-path\">test/fixture/package/src/return/Method.js</span>",
    "method"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/return/method.js~testreturnmethod",
    "class/test/fixture/package/src/return/Method.js~TestReturnMethod.html",
    "<span>TestReturnMethod</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/return/Method.js</span>",
    "class"
  ],
  [
    "testseeclass#constructor",
    "class/test/fixture/package/src/see/Class.js~TestSeeClass.html#instance-constructor-constructor",
    "<span>TestSeeClass#constructor</span> <span class=\"search-result-import-path\">test/fixture/package/src/see/Class.js</span>",
    "method"
  ],
  [
    "testseeclass#method1",
    "class/test/fixture/package/src/see/Class.js~TestSeeClass.html#instance-method-method1",
    "<span>TestSeeClass#method1</span> <span class=\"search-result-import-path\">test/fixture/package/src/see/Class.js</span>",
    "method"
  ],
  [
    "testseeclass#p1",
    "class/test/fixture/package/src/see/Class.js~TestSeeClass.html#instance-member-p1",
    "<span>TestSeeClass#p1</span> <span class=\"search-result-import-path\">test/fixture/package/src/see/Class.js</span>",
    "member"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/see/class.js~testseeclass",
    "class/test/fixture/package/src/see/Class.js~TestSeeClass.html",
    "<span>TestSeeClass</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/see/Class.js</span>",
    "class"
  ],
  [
    "testsinceclass#constructor",
    "class/test/fixture/package/src/since/Class.js~TestSinceClass.html#instance-constructor-constructor",
    "<span>TestSinceClass#constructor</span> <span class=\"search-result-import-path\">test/fixture/package/src/since/Class.js</span>",
    "method"
  ],
  [
    "testsinceclass#method1",
    "class/test/fixture/package/src/since/Class.js~TestSinceClass.html#instance-method-method1",
    "<span>TestSinceClass#method1</span> <span class=\"search-result-import-path\">test/fixture/package/src/since/Class.js</span>",
    "method"
  ],
  [
    "testsinceclass#p1",
    "class/test/fixture/package/src/since/Class.js~TestSinceClass.html#instance-member-p1",
    "<span>TestSinceClass#p1</span> <span class=\"search-result-import-path\">test/fixture/package/src/since/Class.js</span>",
    "member"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/since/class.js~testsinceclass",
    "class/test/fixture/package/src/since/Class.js~TestSinceClass.html",
    "<span>TestSinceClass</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/since/Class.js</span>",
    "class"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/throws/function.js~testthrowsfunctionerror",
    "class/test/fixture/package/src/throws/Function.js~TestThrowsFunctionError.html",
    "<span>TestThrowsFunctionError</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/throws/Function.js</span>",
    "class"
  ],
  [
    "testthrowsmethod#method1",
    "class/test/fixture/package/src/throws/Method.js~TestThrowsMethod.html#instance-method-method1",
    "<span>TestThrowsMethod#method1</span> <span class=\"search-result-import-path\">test/fixture/package/src/throws/Method.js</span>",
    "method"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/throws/method.js~testthrowsmethod",
    "class/test/fixture/package/src/throws/Method.js~TestThrowsMethod.html",
    "<span>TestThrowsMethod</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/throws/Method.js</span>",
    "class"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/throws/method.js~testthrowsmethoderror1",
    "class/test/fixture/package/src/throws/Method.js~TestThrowsMethodError1.html",
    "<span>TestThrowsMethodError1</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/throws/Method.js</span>",
    "class"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/throws/method.js~testthrowsmethoderror2",
    "class/test/fixture/package/src/throws/Method.js~TestThrowsMethodError2.html",
    "<span>TestThrowsMethodError2</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/throws/Method.js</span>",
    "class"
  ],
  [
    "testtodoclass#constructor",
    "class/test/fixture/package/src/todo/Class.js~TestTodoClass.html#instance-constructor-constructor",
    "<span>TestTodoClass#constructor</span> <span class=\"search-result-import-path\">test/fixture/package/src/todo/Class.js</span>",
    "method"
  ],
  [
    "testtodoclass#method1",
    "class/test/fixture/package/src/todo/Class.js~TestTodoClass.html#instance-method-method1",
    "<span>TestTodoClass#method1</span> <span class=\"search-result-import-path\">test/fixture/package/src/todo/Class.js</span>",
    "method"
  ],
  [
    "testtodoclass#p1",
    "class/test/fixture/package/src/todo/Class.js~TestTodoClass.html#instance-member-p1",
    "<span>TestTodoClass#p1</span> <span class=\"search-result-import-path\">test/fixture/package/src/todo/Class.js</span>",
    "member"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/todo/class.js~testtodoclass",
    "class/test/fixture/package/src/todo/Class.js~TestTodoClass.html",
    "<span>TestTodoClass</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/todo/Class.js</span>",
    "class"
  ],
  [
    "testtrailingcommadefinition#method1",
    "class/test/fixture/package/src/trailingcomma/Definition.js~TestTrailingCommaDefinition.html#instance-method-method1",
    "<span>TestTrailingCommaDefinition#method1</span> <span class=\"search-result-import-path\">test/fixture/package/src/trailingcomma/Definition.js</span>",
    "method"
  ],
  [
    "testtrailingcommadefinition#method2",
    "class/test/fixture/package/src/trailingcomma/Definition.js~TestTrailingCommaDefinition.html#instance-method-method2",
    "<span>TestTrailingCommaDefinition#method2</span> <span class=\"search-result-import-path\">test/fixture/package/src/trailingcomma/Definition.js</span>",
    "method"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/trailingcomma/definition.js~testtrailingcommadefinition",
    "class/test/fixture/package/src/trailingcomma/Definition.js~TestTrailingCommaDefinition.html",
    "<span>TestTrailingCommaDefinition</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/trailingcomma/Definition.js</span>",
    "class"
  ],
  [
    "testtypearray#method1",
    "class/test/fixture/package/src/type/Array.js~TestTypeArray.html#instance-method-method1",
    "<span>TestTypeArray#method1</span> <span class=\"search-result-import-path\">test/fixture/package/src/type/Array.js</span>",
    "method"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/type/array.js~testtypearray",
    "class/test/fixture/package/src/type/Array.js~TestTypeArray.html",
    "<span>TestTypeArray</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/type/Array.js</span>",
    "class"
  ],
  [
    "testtypeclass#method1",
    "class/test/fixture/package/src/type/Class.js~TestTypeClass.html#instance-method-method1",
    "<span>TestTypeClass#method1</span> <span class=\"search-result-import-path\">test/fixture/package/src/type/Class.js</span>",
    "method"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/type/class.js~testtypeclass",
    "class/test/fixture/package/src/type/Class.js~TestTypeClass.html",
    "<span>TestTypeClass</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/type/Class.js</span>",
    "class"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/type/class.js~testtypeclassinner",
    "class/test/fixture/package/src/type/Class.js~TestTypeClassInner.html",
    "<span>TestTypeClassInner</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/type/Class.js</span>",
    "class"
  ],
  [
    "testtypecomplex#method1",
    "class/test/fixture/package/src/type/Complex.js~TestTypeComplex.html#instance-method-method1",
    "<span>TestTypeComplex#method1</span> <span class=\"search-result-import-path\">test/fixture/package/src/type/Complex.js</span>",
    "method"
  ],
  [
    "testtypecomplex#method2",
    "class/test/fixture/package/src/type/Complex.js~TestTypeComplex.html#instance-method-method2",
    "<span>TestTypeComplex#method2</span> <span class=\"search-result-import-path\">test/fixture/package/src/type/Complex.js</span>",
    "method"
  ],
  [
    "testtypecomplex#method3",
    "class/test/fixture/package/src/type/Complex.js~TestTypeComplex.html#instance-method-method3",
    "<span>TestTypeComplex#method3</span> <span class=\"search-result-import-path\">test/fixture/package/src/type/Complex.js</span>",
    "method"
  ],
  [
    "testtypecomplex#method4",
    "class/test/fixture/package/src/type/Complex.js~TestTypeComplex.html#instance-method-method4",
    "<span>TestTypeComplex#method4</span> <span class=\"search-result-import-path\">test/fixture/package/src/type/Complex.js</span>",
    "method"
  ],
  [
    "testtypecomplex#method5",
    "class/test/fixture/package/src/type/Complex.js~TestTypeComplex.html#instance-method-method5",
    "<span>TestTypeComplex#method5</span> <span class=\"search-result-import-path\">test/fixture/package/src/type/Complex.js</span>",
    "method"
  ],
  [
    "testtypecomplex#method6",
    "class/test/fixture/package/src/type/Complex.js~TestTypeComplex.html#instance-method-method6",
    "<span>TestTypeComplex#method6</span> <span class=\"search-result-import-path\">test/fixture/package/src/type/Complex.js</span>",
    "method"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/type/complex.js~testtypecomplex",
    "class/test/fixture/package/src/type/Complex.js~TestTypeComplex.html",
    "<span>TestTypeComplex</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/type/Complex.js</span>",
    "class"
  ],
  [
    "testtypedefault#method1",
    "class/test/fixture/package/src/type/Default.js~TestTypeDefault.html#instance-method-method1",
    "<span>TestTypeDefault#method1</span> <span class=\"search-result-import-path\">test/fixture/package/src/type/Default.js</span>",
    "method"
  ],
  [
    "testtypedefault#method2",
    "class/test/fixture/package/src/type/Default.js~TestTypeDefault.html#instance-method-method2",
    "<span>TestTypeDefault#method2</span> <span class=\"search-result-import-path\">test/fixture/package/src/type/Default.js</span>",
    "method"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/type/default.js~testtypedefault",
    "class/test/fixture/package/src/type/Default.js~TestTypeDefault.html",
    "<span>TestTypeDefault</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/type/Default.js</span>",
    "class"
  ],
  [
    "testtypeexternal#method1",
    "class/test/fixture/package/src/type/External.js~TestTypeExternal.html#instance-method-method1",
    "<span>TestTypeExternal#method1</span> <span class=\"search-result-import-path\">test/fixture/package/src/type/External.js</span>",
    "method"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/type/external.js~testtypeexternal",
    "class/test/fixture/package/src/type/External.js~TestTypeExternal.html",
    "<span>TestTypeExternal</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/type/External.js</span>",
    "class"
  ],
  [
    "testtypefunction#method1",
    "class/test/fixture/package/src/type/Function.js~TestTypeFunction.html#instance-method-method1",
    "<span>TestTypeFunction#method1</span> <span class=\"search-result-import-path\">test/fixture/package/src/type/Function.js</span>",
    "method"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/type/function.js~testtypefunction",
    "class/test/fixture/package/src/type/Function.js~TestTypeFunction.html",
    "<span>TestTypeFunction</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/type/Function.js</span>",
    "class"
  ],
  [
    "testtypegenerics#method1",
    "class/test/fixture/package/src/type/Generics.js~TestTypeGenerics.html#instance-method-method1",
    "<span>TestTypeGenerics#method1</span> <span class=\"search-result-import-path\">test/fixture/package/src/type/Generics.js</span>",
    "method"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/type/generics.js~testtypegenerics",
    "class/test/fixture/package/src/type/Generics.js~TestTypeGenerics.html",
    "<span>TestTypeGenerics</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/type/Generics.js</span>",
    "class"
  ],
  [
    "testtypeliteral#method1",
    "class/test/fixture/package/src/type/Literal.js~TestTypeLiteral.html#instance-method-method1",
    "<span>TestTypeLiteral#method1</span> <span class=\"search-result-import-path\">test/fixture/package/src/type/Literal.js</span>",
    "method"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/type/literal.js~testtypeliteral",
    "class/test/fixture/package/src/type/Literal.js~TestTypeLiteral.html",
    "<span>TestTypeLiteral</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/type/Literal.js</span>",
    "class"
  ],
  [
    "testtypeobject#method1",
    "class/test/fixture/package/src/type/Object.js~TestTypeObject.html#instance-method-method1",
    "<span>TestTypeObject#method1</span> <span class=\"search-result-import-path\">test/fixture/package/src/type/Object.js</span>",
    "method"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/type/object.js~testtypeobject",
    "class/test/fixture/package/src/type/Object.js~TestTypeObject.html",
    "<span>TestTypeObject</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/type/Object.js</span>",
    "class"
  ],
  [
    "testtypeoptional#method1",
    "class/test/fixture/package/src/type/Optional.js~TestTypeOptional.html#instance-method-method1",
    "<span>TestTypeOptional#method1</span> <span class=\"search-result-import-path\">test/fixture/package/src/type/Optional.js</span>",
    "method"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/type/optional.js~testtypeoptional",
    "class/test/fixture/package/src/type/Optional.js~TestTypeOptional.html",
    "<span>TestTypeOptional</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/type/Optional.js</span>",
    "class"
  ],
  [
    "testtyperecord#method1",
    "class/test/fixture/package/src/type/Record.js~TestTypeRecord.html#instance-method-method1",
    "<span>TestTypeRecord#method1</span> <span class=\"search-result-import-path\">test/fixture/package/src/type/Record.js</span>",
    "method"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/type/record.js~testtyperecord",
    "class/test/fixture/package/src/type/Record.js~TestTypeRecord.html",
    "<span>TestTypeRecord</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/type/Record.js</span>",
    "class"
  ],
  [
    "testtypespread#method1",
    "class/test/fixture/package/src/type/Spread.js~TestTypeSpread.html#instance-method-method1",
    "<span>TestTypeSpread#method1</span> <span class=\"search-result-import-path\">test/fixture/package/src/type/Spread.js</span>",
    "method"
  ],
  [
    "testtypespread#method2",
    "class/test/fixture/package/src/type/Spread.js~TestTypeSpread.html#instance-method-method2",
    "<span>TestTypeSpread#method2</span> <span class=\"search-result-import-path\">test/fixture/package/src/type/Spread.js</span>",
    "method"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/type/spread.js~testtypespread",
    "class/test/fixture/package/src/type/Spread.js~TestTypeSpread.html",
    "<span>TestTypeSpread</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/type/Spread.js</span>",
    "class"
  ],
  [
    "testtypetypedef#method1",
    "class/test/fixture/package/src/type/Typedef.js~TestTypeTypedef.html#instance-method-method1",
    "<span>TestTypeTypedef#method1</span> <span class=\"search-result-import-path\">test/fixture/package/src/type/Typedef.js</span>",
    "method"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/type/typedef.js~testtypetypedef",
    "class/test/fixture/package/src/type/Typedef.js~TestTypeTypedef.html",
    "<span>TestTypeTypedef</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/type/Typedef.js</span>",
    "class"
  ],
  [
    "testtypeunion#method1",
    "class/test/fixture/package/src/type/Union.js~TestTypeUnion.html#instance-method-method1",
    "<span>TestTypeUnion#method1</span> <span class=\"search-result-import-path\">test/fixture/package/src/type/Union.js</span>",
    "method"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/type/union.js~testtypeunion",
    "class/test/fixture/package/src/type/Union.js~TestTypeUnion.html",
    "<span>TestTypeUnion</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/type/Union.js</span>",
    "class"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/undocument/definition.js~testundocumentdefinition",
    "class/test/fixture/package/src/undocument/Definition.js~TestUndocumentDefinition.html",
    "<span>TestUndocumentDefinition</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/undocument/Definition.js</span>",
    "class"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/unknown/definition.js~testunknowndefinition",
    "class/test/fixture/package/src/unknown/Definition.js~TestUnknownDefinition.html",
    "<span>TestUnknownDefinition</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/unknown/Definition.js</span>",
    "class"
  ],
  [
    "testversionclass#constructor",
    "class/test/fixture/package/src/version/Class.js~TestVersionClass.html#instance-constructor-constructor",
    "<span>TestVersionClass#constructor</span> <span class=\"search-result-import-path\">test/fixture/package/src/version/Class.js</span>",
    "method"
  ],
  [
    "testversionclass#method1",
    "class/test/fixture/package/src/version/Class.js~TestVersionClass.html#instance-method-method1",
    "<span>TestVersionClass#method1</span> <span class=\"search-result-import-path\">test/fixture/package/src/version/Class.js</span>",
    "method"
  ],
  [
    "testversionclass#p1",
    "class/test/fixture/package/src/version/Class.js~TestVersionClass.html#instance-member-p1",
    "<span>TestVersionClass#p1</span> <span class=\"search-result-import-path\">test/fixture/package/src/version/Class.js</span>",
    "member"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/version/class.js~testversionclass",
    "class/test/fixture/package/src/version/Class.js~TestVersionClass.html",
    "<span>TestVersionClass</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/version/Class.js</span>",
    "class"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/extends/mixinexplicit.js~textexplicitmixin",
    "class/test/fixture/package/src/extends/MixinExplicit.js~TextExplicitMixin.html",
    "<span>TextExplicitMixin</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/extends/MixinExplicit.js</span>",
    "class"
  ],
  [
    "typetestnullable#method1",
    "class/test/fixture/package/src/type/Nullable.js~TypeTestNullable.html#instance-method-method1",
    "<span>TypeTestNullable#method1</span> <span class=\"search-result-import-path\">test/fixture/package/src/type/Nullable.js</span>",
    "method"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/type/nullable.js~typetestnullable",
    "class/test/fixture/package/src/type/Nullable.js~TypeTestNullable.html",
    "<span>TypeTestNullable</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/type/Nullable.js</span>",
    "class"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/access/class.js~_testaccessclassautoprivate",
    "class/test/fixture/package/src/access/Class.js~_TestAccessClassAutoPrivate.html",
    "<span>_TestAccessClassAutoPrivate</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/access/Class.js</span>",
    "class"
  ],
  [
    "_testextendsinner#method1",
    "class/test/fixture/package/src/extends/Inner.js~_TestExtendsInner.html#instance-method-method1",
    "<span>_TestExtendsInner#method1</span> <span class=\"search-result-import-path\">test/fixture/package/src/extends/Inner.js</span>",
    "method"
  ],
  [
    "_testextendsinner#method2",
    "class/test/fixture/package/src/extends/Inner.js~_TestExtendsInner.html#instance-method-method2",
    "<span>_TestExtendsInner#method2</span> <span class=\"search-result-import-path\">test/fixture/package/src/extends/Inner.js</span>",
    "method"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/extends/inner.js~_testextendsinner",
    "class/test/fixture/package/src/extends/Inner.js~_TestExtendsInner.html",
    "<span>_TestExtendsInner</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/extends/Inner.js</span>",
    "class"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/access/function.js~_testaccessfunctionautoprivate",
    "function/index.html#static-function-_testAccessFunctionAutoPrivate",
    "<span>_testAccessFunctionAutoPrivate</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/access/Function.js</span>",
    "function"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/access/variable.js~_testaccessvariableautoprivate",
    "variable/index.html#static-variable-_testAccessVariableAutoPrivate",
    "<span>_testAccessVariableAutoPrivate</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/access/Variable.js</span>",
    "variable"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/access/function.js~testaccessfunctionprivate",
    "function/index.html#static-function-testAccessFunctionPrivate",
    "<span>testAccessFunctionPrivate</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/access/Function.js</span>",
    "function"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/access/function.js~testaccessfunctionprotected",
    "function/index.html#static-function-testAccessFunctionProtected",
    "<span>testAccessFunctionProtected</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/access/Function.js</span>",
    "function"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/access/function.js~testaccessfunctionpublic",
    "function/index.html#static-function-testAccessFunctionPublic",
    "<span>testAccessFunctionPublic</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/access/Function.js</span>",
    "function"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/access/variable.js~testaccessvariableprivate",
    "variable/index.html#static-variable-testAccessVariablePrivate",
    "<span>testAccessVariablePrivate</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/access/Variable.js</span>",
    "variable"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/access/variable.js~testaccessvariableprotected",
    "variable/index.html#static-variable-testAccessVariableProtected",
    "<span>testAccessVariableProtected</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/access/Variable.js</span>",
    "variable"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/access/variable.js~testaccessvariablepublic",
    "variable/index.html#static-variable-testAccessVariablePublic",
    "<span>testAccessVariablePublic</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/access/Variable.js</span>",
    "variable"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/async/function.js~testasyncfunction",
    "function/index.html#static-function-testAsyncFunction",
    "<span>testAsyncFunction</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/async/Function.js</span>",
    "function"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/decorator/definition.js~testdecoratorannotation1",
    "function/index.html#static-function-testDecoratorAnnotation1",
    "<span>testDecoratorAnnotation1</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/decorator/Definition.js</span>",
    "function"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/decorator/definition.js~testdecoratorannotation2",
    "function/index.html#static-function-testDecoratorAnnotation2",
    "<span>testDecoratorAnnotation2</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/decorator/Definition.js</span>",
    "function"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/deprecated/function.js~testdeprecatedfunction",
    "function/index.html#static-function-testDeprecatedFunction",
    "<span>testDeprecatedFunction</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/deprecated/Function.js</span>",
    "function"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/deprecated/variable.js~testdeprecatedvariable",
    "variable/index.html#static-variable-testDeprecatedVariable",
    "<span>testDeprecatedVariable</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/deprecated/Variable.js</span>",
    "variable"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/desc/function.js~testdescfunction",
    "function/index.html#static-function-testDescFunction",
    "<span>testDescFunction</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/desc/Function.js</span>",
    "function"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/desc/variable.js~testdescvariable",
    "variable/index.html#static-variable-testDescVariable",
    "<span>testDescVariable</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/desc/Variable.js</span>",
    "variable"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/emits/function.js~testemitsfunction",
    "function/index.html#static-function-testEmitsFunction",
    "<span>testEmitsFunction</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/emits/Function.js</span>",
    "function"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/example/function.js~testexamplefunction",
    "function/index.html#static-function-testExampleFunction",
    "<span>testExampleFunction</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/example/Function.js</span>",
    "function"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/example/variable.js~testexamplevariable",
    "variable/index.html#static-variable-testExampleVariable",
    "<span>testExampleVariable</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/example/Variable.js</span>",
    "variable"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/experimental/function.js~testexperimentalfunction",
    "function/index.html#static-function-testExperimentalFunction",
    "<span>testExperimentalFunction</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/experimental/Function.js</span>",
    "function"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/experimental/variable.js~testexperimentalvariable",
    "variable/index.html#static-variable-testExperimentalVariable",
    "<span>testExperimentalVariable</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/experimental/Variable.js</span>",
    "variable"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/export/arrowfunction.js~testexportarrowfunction2",
    "function/index.html#static-function-testExportArrowFunction2",
    "<span>testExportArrowFunction2</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/export/ArrowFunction.js</span>",
    "function"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/export/arrowfunction.js~testexportarrowfunction4",
    "function/index.html#static-function-testExportArrowFunction4",
    "<span>testExportArrowFunction4</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/export/ArrowFunction.js</span>",
    "function"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/export/arrowfunction.js~testexportarrowfunction5",
    "function/index.html#static-function-testExportArrowFunction5",
    "<span>testExportArrowFunction5</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/export/ArrowFunction.js</span>",
    "function"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/export/function.js~testexportfunction1",
    "function/index.html#static-function-testExportFunction1",
    "<span>testExportFunction1</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/export/Function.js</span>",
    "function"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/export/function.js~testexportfunction2",
    "function/index.html#static-function-testExportFunction2",
    "<span>testExportFunction2</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/export/Function.js</span>",
    "function"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/export/function.js~testexportfunction3",
    "function/index.html#static-function-testExportFunction3",
    "<span>testExportFunction3</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/export/Function.js</span>",
    "function"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/export/function.js~testexportfunction6",
    "function/index.html#static-function-testExportFunction6",
    "<span>testExportFunction6</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/export/Function.js</span>",
    "function"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/export/function.js~testexportfunction7",
    "function/index.html#static-function-testExportFunction7",
    "<span>testExportFunction7</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/export/Function.js</span>",
    "function"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/export/function.js~testexportfunction8",
    "function/index.html#static-function-testExportFunction8",
    "<span>testExportFunction8</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/export/Function.js</span>",
    "function"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/export/functionindirectdefault.js~testexportfunctionindirectdefault",
    "function/index.html#static-function-testExportFunctionIndirectDefault",
    "<span>testExportFunctionIndirectDefault</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/export/FunctionIndirectDefault.js</span>",
    "function"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/export/multiple.js~testexportmultiple",
    "variable/index.html#static-variable-testExportMultiple",
    "<span>testExportMultiple</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/export/Multiple.js</span>",
    "variable"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/export/newexpression.js~testexportnewexpression2",
    "variable/index.html#static-variable-testExportNewExpression2",
    "<span>testExportNewExpression2</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/export/NewExpression.js</span>",
    "variable"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/export/newexpression.js~testexportnewexpression",
    "variable/index.html#static-variable-testExportNewExpression",
    "<span>testExportNewExpression</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/export/NewExpression.js</span>",
    "variable"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/export/newexpressionindirect.js~testexportnewexpressionindirect",
    "variable/index.html#static-variable-testExportNewExpressionIndirect",
    "<span>testExportNewExpressionIndirect</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/export/NewExpressionIndirect.js</span>",
    "variable"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/export/newexpressionproperty.js~testexportnewexpressionproperty",
    "variable/index.html#static-variable-testExportNewExpressionProperty",
    "<span>testExportNewExpressionProperty</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/export/NewExpressionProperty.js</span>",
    "variable"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/export/variable.js~testexportvariable1",
    "variable/index.html#static-variable-testExportVariable1",
    "<span>testExportVariable1</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/export/Variable.js</span>",
    "variable"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/export/variable.js~testexportvariable2",
    "variable/index.html#static-variable-testExportVariable2",
    "<span>testExportVariable2</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/export/Variable.js</span>",
    "variable"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/export/variable.js~testexportvariable4",
    "variable/index.html#static-variable-testExportVariable4",
    "<span>testExportVariable4</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/export/Variable.js</span>",
    "variable"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/export/variable.js~testexportvariable5",
    "variable/index.html#static-variable-testExportVariable5",
    "<span>testExportVariable5</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/export/Variable.js</span>",
    "variable"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/export/variable.js~testexportvariable6",
    "variable/index.html#static-variable-testExportVariable6",
    "<span>testExportVariable6</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/export/Variable.js</span>",
    "variable"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/export/variable.js~testexportvariable7",
    "variable/index.html#static-variable-testExportVariable7",
    "<span>testExportVariable7</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/export/Variable.js</span>",
    "variable"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/export/variableindirectdefault.js~testexportvariableindirectdefault",
    "variable/index.html#static-variable-testExportVariableIndirectDefault",
    "<span>testExportVariableIndirectDefault</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/export/VariableIndirectDefault.js</span>",
    "variable"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/extends/expression.js~testextendsexpressioninner",
    "function/index.html#static-function-testExtendsExpressionInner",
    "<span>testExtendsExpressionInner</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/extends/Expression.js</span>",
    "function"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/generator/function.js~testgeneratorfunction",
    "function/index.html#static-function-testGeneratorFunction",
    "<span>testGeneratorFunction</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/generator/Function.js</span>",
    "function"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/guess/variable.js~testguessvariable1",
    "variable/index.html#static-variable-testGuessVariable1",
    "<span>testGuessVariable1</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/guess/Variable.js</span>",
    "variable"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/guess/variable.js~testguessvariable2",
    "variable/index.html#static-variable-testGuessVariable2",
    "<span>testGuessVariable2</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/guess/Variable.js</span>",
    "variable"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/guess/variable.js~testguessvariable3",
    "variable/index.html#static-variable-testGuessVariable3",
    "<span>testGuessVariable3</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/guess/Variable.js</span>",
    "variable"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/guess/variable.js~testguessvariable4",
    "variable/index.html#static-variable-testGuessVariable4",
    "<span>testGuessVariable4</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/guess/Variable.js</span>",
    "variable"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/link/function.js~testlinkfunction",
    "function/index.html#static-function-testLinkFunction",
    "<span>testLinkFunction</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/link/Function.js</span>",
    "function"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/link/variable.js~testlinkvariable",
    "variable/index.html#static-variable-testLinkVariable",
    "<span>testLinkVariable</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/link/Variable.js</span>",
    "variable"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/listens/function.js~testlistensfunction",
    "function/index.html#static-function-testListensFunction",
    "<span>testListensFunction</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/listens/Function.js</span>",
    "function"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/param/function.js~testparamfunction",
    "function/index.html#static-function-testParamFunction",
    "<span>testParamFunction</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/param/Function.js</span>",
    "function"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/return/function.js~testreturnfunction1",
    "function/index.html#static-function-testReturnFunction1",
    "<span>testReturnFunction1</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/return/Function.js</span>",
    "function"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/return/function.js~testreturnfunction2",
    "function/index.html#static-function-testReturnFunction2",
    "<span>testReturnFunction2</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/return/Function.js</span>",
    "function"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/see/function.js~testseefunction",
    "function/index.html#static-function-testSeeFunction",
    "<span>testSeeFunction</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/see/Function.js</span>",
    "function"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/see/variable.js~testseevariable",
    "variable/index.html#static-variable-testSeeVariable",
    "<span>testSeeVariable</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/see/Variable.js</span>",
    "variable"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/since/function.js~testsincefunction",
    "function/index.html#static-function-testSinceFunction",
    "<span>testSinceFunction</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/since/Function.js</span>",
    "function"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/since/variable.js~testsincevariable",
    "variable/index.html#static-variable-testSinceVariable",
    "<span>testSinceVariable</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/since/Variable.js</span>",
    "variable"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/throws/function.js~testthrowsfunction",
    "function/index.html#static-function-testThrowsFunction",
    "<span>testThrowsFunction</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/throws/Function.js</span>",
    "function"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/todo/function.js~testtodofunction",
    "function/index.html#static-function-testTodoFunction",
    "<span>testTodoFunction</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/todo/Function.js</span>",
    "function"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/todo/variable.js~testtodovariable",
    "variable/index.html#static-variable-testTodoVariable",
    "<span>testTodoVariable</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/todo/Variable.js</span>",
    "variable"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/variable/arraypattern.js~testvariablearraypattern1",
    "variable/index.html#static-variable-testVariableArrayPattern1",
    "<span>testVariableArrayPattern1</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/variable/ArrayPattern.js</span>",
    "variable"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/variable/definition.js~testvariabledefinition",
    "variable/index.html#static-variable-testVariableDefinition",
    "<span>testVariableDefinition</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/variable/Definition.js</span>",
    "variable"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/variable/objectpattern.js~testvariableobjectpattern1",
    "variable/index.html#static-variable-testVariableObjectPattern1",
    "<span>testVariableObjectPattern1</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/variable/ObjectPattern.js</span>",
    "variable"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/version/function.js~testversionfunction",
    "function/index.html#static-function-testVersionFunction",
    "<span>testVersionFunction</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/version/Function.js</span>",
    "function"
  ],
  [
    "esdoc-test-fixture/test/fixture/package/src/version/variable.js~testversionvariable",
    "variable/index.html#static-variable-testVersionVariable",
    "<span>testVersionVariable</span> <span class=\"search-result-import-path\">esdoc-test-fixture/test/fixture/package/src/version/Variable.js</span>",
    "variable"
  ],
  [
    "array",
    "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array",
    "Array",
    "external"
  ],
  [
    "arraybuffer",
    "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ArrayBuffer",
    "ArrayBuffer",
    "external"
  ],
  [
    "audiocontext",
    "https://developer.mozilla.org/en/docs/Web/API/AudioContext",
    "AudioContext",
    "external"
  ],
  [
    "boolean",
    "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean",
    "Boolean",
    "external"
  ],
  [
    "canvasrenderingcontext2d",
    "https://developer.mozilla.org/en-US/docs/Web/API/CanvasRenderingContext2D",
    "CanvasRenderingContext2D",
    "external"
  ],
  [
    "dataview",
    "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/DataView",
    "DataView",
    "external"
  ],
  [
    "date",
    "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Date",
    "Date",
    "external"
  ],
  [
    "documentfragment",
    "https://developer.mozilla.org/en-US/docs/Web/API/DocumentFragment",
    "DocumentFragment",
    "external"
  ],
  [
    "element",
    "https://developer.mozilla.org/en-US/docs/Web/API/Element",
    "Element",
    "external"
  ],
  [
    "error",
    "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Error",
    "Error",
    "external"
  ],
  [
    "evalerror",
    "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/EvalError",
    "EvalError",
    "external"
  ],
  [
    "event",
    "https://developer.mozilla.org/en-US/docs/Web/API/Event",
    "Event",
    "external"
  ],
  [
    "float32array",
    "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Float32Array",
    "Float32Array",
    "external"
  ],
  [
    "float64array",
    "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Float64Array",
    "Float64Array",
    "external"
  ],
  [
    "function",
    "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function",
    "Function",
    "external"
  ],
  [
    "generator",
    "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Generator",
    "Generator",
    "external"
  ],
  [
    "generatorfunction",
    "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/GeneratorFunction",
    "GeneratorFunction",
    "external"
  ],
  [
    "infinity",
    "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Infinity",
    "Infinity",
    "external"
  ],
  [
    "int16array",
    "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int16Array",
    "Int16Array",
    "external"
  ],
  [
    "int32array",
    "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int32Array",
    "Int32Array",
    "external"
  ],
  [
    "int8array",
    "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Int8Array",
    "Int8Array",
    "external"
  ],
  [
    "internalerror",
    "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/InternalError",
    "InternalError",
    "external"
  ],
  [
    "json",
    "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/JSON",
    "JSON",
    "external"
  ],
  [
    "map",
    "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Map",
    "Map",
    "external"
  ],
  [
    "nan",
    "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/NaN",
    "NaN",
    "external"
  ],
  [
    "node",
    "https://developer.mozilla.org/en-US/docs/Web/API/Node",
    "Node",
    "external"
  ],
  [
    "nodelist",
    "https://developer.mozilla.org/en-US/docs/Web/API/NodeList",
    "NodeList",
    "external"
  ],
  [
    "number",
    "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number",
    "Number",
    "external"
  ],
  [
    "object",
    "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object",
    "Object",
    "external"
  ],
  [
    "promise",
    "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Promise",
    "Promise",
    "external"
  ],
  [
    "proxy",
    "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Proxy",
    "Proxy",
    "external"
  ],
  [
    "rangeerror",
    "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RangeError",
    "RangeError",
    "external"
  ],
  [
    "referenceerror",
    "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ReferenceError",
    "ReferenceError",
    "external"
  ],
  [
    "reflect",
    "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Reflect",
    "Reflect",
    "external"
  ],
  [
    "regexp",
    "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RegExp",
    "RegExp",
    "external"
  ],
  [
    "set",
    "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Set",
    "Set",
    "external"
  ],
  [
    "string",
    "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String",
    "String",
    "external"
  ],
  [
    "symbol",
    "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Symbol",
    "Symbol",
    "external"
  ],
  [
    "syntaxerror",
    "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/SyntaxError",
    "SyntaxError",
    "external"
  ],
  [
    "testexternaldefinition",
    "http://example.com",
    "TestExternalDefinition",
    "external"
  ],
  [
    "testtypetypedefinner",
    "typedef/index.html#static-typedef-TestTypeTypedefInner",
    "TestTypeTypedefInner",
    "typedef"
  ],
  [
    "testtypedefdefinition",
    "typedef/index.html#static-typedef-TestTypedefDefinition",
    "TestTypedefDefinition",
    "typedef"
  ],
  [
    "typeerror",
    "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/TypeError",
    "TypeError",
    "external"
  ],
  [
    "urierror",
    "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/URIError",
    "URIError",
    "external"
  ],
  [
    "uint16array",
    "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint16Array",
    "Uint16Array",
    "external"
  ],
  [
    "uint32array",
    "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint32Array",
    "Uint32Array",
    "external"
  ],
  [
    "uint8array",
    "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint8Array",
    "Uint8Array",
    "external"
  ],
  [
    "uint8clampedarray",
    "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Uint8ClampedArray",
    "Uint8ClampedArray",
    "external"
  ],
  [
    "testdescclass test/fixture/package/src/desc/class.js~testdescclass,testdescclass",
    "test-file/test/fixture/package/test/DescTest.js.html#lineNumber2",
    "Use describe style mocha interface",
    "test"
  ],
  [
    "testdescclass#p1 test/fixture/package/src/desc/class.js~testdescclass#p1,testdescclass#p1",
    "test-file/test/fixture/package/test/DescTest.js.html#lineNumber10",
    "Use describe style mocha interface Nested describe",
    "test"
  ],
  [
    "testdescvariable test/fixture/package/src/desc/variable.js~testdescvariable,testdescvariable",
    "test-file/test/fixture/package/test/DescTest.js.html#lineNumber13",
    "Use describe style mocha interface Nested describe Nested it in describe",
    "test"
  ],
  [
    "testdescclass#method1 test/fixture/package/src/desc/class.js~testdescclass#method1,testdescclass#method1",
    "test-file/test/fixture/package/test/DescTest.js.html#lineNumber19",
    "Use describe style mocha interface Use context style mocha interface",
    "test"
  ],
  [
    "testdescfunction test/fixture/package/src/desc/function.js~testdescfunction,testdescfunction",
    "test-file/test/fixture/package/test/DescTest.js.html#lineNumber22",
    "Use describe style mocha interface Use context style mocha interface Nested it in context",
    "test"
  ],
  [
    "testdescclass#constructor test/fixture/package/src/desc/class.js~testdescclass#constructor,testdescclass#constructor",
    "test-file/test/fixture/package/test/DescTest.js.html#lineNumber5",
    "Use describe style mocha interface Use it style mocha interface",
    "test"
  ],
  [
    "testdescclass test/fixture/package/src/desc/class.js~testdescclass,testdescclass",
    "test-file/test/fixture/package/test/DescTest.js.html#lineNumber29",
    "Use suite style mocha interface",
    "test"
  ],
  [
    "testdescclass#p1 test/fixture/package/src/desc/class.js~testdescclass#p1,testdescclass#p1",
    "test-file/test/fixture/package/test/DescTest.js.html#lineNumber37",
    "Use suite style mocha interface Nested suite",
    "test"
  ],
  [
    "testdescclass#method1 test/fixture/package/src/desc/class.js~testdescclass#method1,testdescclass#method1",
    "test-file/test/fixture/package/test/DescTest.js.html#lineNumber40",
    "Use suite style mocha interface Nested suite Nested test",
    "test"
  ],
  [
    "testdescclass#constructor test/fixture/package/src/desc/class.js~testdescclass#constructor,testdescclass#constructor",
    "test-file/test/fixture/package/test/DescTest.js.html#lineNumber32",
    "Use suite style mocha interface Use test style mocha interface",
    "test"
  ],
  [
    "weakmap",
    "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakMap",
    "WeakMap",
    "external"
  ],
  [
    "weakset",
    "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakSet",
    "WeakSet",
    "external"
  ],
  [
    "xmlhttprequest",
    "https://developer.mozilla.org/en/docs/Web/API/XMLHttpRequest",
    "XMLHttpRequest",
    "external"
  ],
  [
    "boolean",
    "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Boolean",
    "boolean",
    "external"
  ],
  [
    "function",
    "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function",
    "function",
    "external"
  ],
  [
    "null",
    "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/null",
    "null",
    "external"
  ],
  [
    "number",
    "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number",
    "number",
    "external"
  ],
  [
    "object",
    "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object",
    "object",
    "external"
  ],
  [
    "string",
    "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String",
    "string",
    "external"
  ],
  [
    "test/fixture/package/src/abstract/definition.js",
    "file/test/fixture/package/src/abstract/Definition.js.html",
    "test/fixture/package/src/abstract/Definition.js",
    "file"
  ],
  [
    "test/fixture/package/src/abstract/override.js",
    "file/test/fixture/package/src/abstract/Override.js.html",
    "test/fixture/package/src/abstract/Override.js",
    "file"
  ],
  [
    "test/fixture/package/src/access/class.js",
    "file/test/fixture/package/src/access/Class.js.html",
    "test/fixture/package/src/access/Class.js",
    "file"
  ],
  [
    "test/fixture/package/src/access/function.js",
    "file/test/fixture/package/src/access/Function.js.html",
    "test/fixture/package/src/access/Function.js",
    "file"
  ],
  [
    "test/fixture/package/src/access/method.js",
    "file/test/fixture/package/src/access/Method.js.html",
    "test/fixture/package/src/access/Method.js",
    "file"
  ],
  [
    "test/fixture/package/src/access/property.js",
    "file/test/fixture/package/src/access/Property.js.html",
    "test/fixture/package/src/access/Property.js",
    "file"
  ],
  [
    "test/fixture/package/src/access/variable.js",
    "file/test/fixture/package/src/access/Variable.js.html",
    "test/fixture/package/src/access/Variable.js",
    "file"
  ],
  [
    "test/fixture/package/src/async/function.js",
    "file/test/fixture/package/src/async/Function.js.html",
    "test/fixture/package/src/async/Function.js",
    "file"
  ],
  [
    "test/fixture/package/src/async/method.js",
    "file/test/fixture/package/src/async/Method.js.html",
    "test/fixture/package/src/async/Method.js",
    "file"
  ],
  [
    "test/fixture/package/src/class/definition.js",
    "file/test/fixture/package/src/class/Definition.js.html",
    "test/fixture/package/src/class/Definition.js",
    "file"
  ],
  [
    "test/fixture/package/src/classproperty/definition.js",
    "file/test/fixture/package/src/classproperty/Definition.js.html",
    "test/fixture/package/src/classproperty/Definition.js",
    "file"
  ],
  [
    "test/fixture/package/src/computed/method.js",
    "file/test/fixture/package/src/computed/Method.js.html",
    "test/fixture/package/src/computed/Method.js",
    "file"
  ],
  [
    "test/fixture/package/src/computed/property.js",
    "file/test/fixture/package/src/computed/Property.js.html",
    "test/fixture/package/src/computed/Property.js",
    "file"
  ],
  [
    "test/fixture/package/src/decorator/definition.js",
    "file/test/fixture/package/src/decorator/Definition.js.html",
    "test/fixture/package/src/decorator/Definition.js",
    "file"
  ],
  [
    "test/fixture/package/src/deprecated/class.js",
    "file/test/fixture/package/src/deprecated/Class.js.html",
    "test/fixture/package/src/deprecated/Class.js",
    "file"
  ],
  [
    "test/fixture/package/src/deprecated/function.js",
    "file/test/fixture/package/src/deprecated/Function.js.html",
    "test/fixture/package/src/deprecated/Function.js",
    "file"
  ],
  [
    "test/fixture/package/src/deprecated/variable.js",
    "file/test/fixture/package/src/deprecated/Variable.js.html",
    "test/fixture/package/src/deprecated/Variable.js",
    "file"
  ],
  [
    "test/fixture/package/src/desc/class.js",
    "file/test/fixture/package/src/desc/Class.js.html",
    "test/fixture/package/src/desc/Class.js",
    "file"
  ],
  [
    "test/fixture/package/src/desc/function.js",
    "file/test/fixture/package/src/desc/Function.js.html",
    "test/fixture/package/src/desc/Function.js",
    "file"
  ],
  [
    "test/fixture/package/src/desc/markdown.js",
    "file/test/fixture/package/src/desc/Markdown.js.html",
    "test/fixture/package/src/desc/Markdown.js",
    "file"
  ],
  [
    "test/fixture/package/src/desc/multiline.js",
    "file/test/fixture/package/src/desc/MultiLine.js.html",
    "test/fixture/package/src/desc/MultiLine.js",
    "file"
  ],
  [
    "test/fixture/package/src/desc/variable.js",
    "file/test/fixture/package/src/desc/Variable.js.html",
    "test/fixture/package/src/desc/Variable.js",
    "file"
  ],
  [
    "test/fixture/package/src/destructuring/array.js",
    "file/test/fixture/package/src/destructuring/Array.js.html",
    "test/fixture/package/src/destructuring/Array.js",
    "file"
  ],
  [
    "test/fixture/package/src/destructuring/object.js",
    "file/test/fixture/package/src/destructuring/Object.js.html",
    "test/fixture/package/src/destructuring/Object.js",
    "file"
  ],
  [
    "test/fixture/package/src/duplication/definition.js",
    "file/test/fixture/package/src/duplication/Definition.js.html",
    "test/fixture/package/src/duplication/Definition.js",
    "file"
  ],
  [
    "test/fixture/package/src/emits/function.js",
    "file/test/fixture/package/src/emits/Function.js.html",
    "test/fixture/package/src/emits/Function.js",
    "file"
  ],
  [
    "test/fixture/package/src/emits/method.js",
    "file/test/fixture/package/src/emits/Method.js.html",
    "test/fixture/package/src/emits/Method.js",
    "file"
  ],
  [
    "test/fixture/package/src/example/caption.js",
    "file/test/fixture/package/src/example/Caption.js.html",
    "test/fixture/package/src/example/Caption.js",
    "file"
  ],
  [
    "test/fixture/package/src/example/class.js",
    "file/test/fixture/package/src/example/Class.js.html",
    "test/fixture/package/src/example/Class.js",
    "file"
  ],
  [
    "test/fixture/package/src/example/function.js",
    "file/test/fixture/package/src/example/Function.js.html",
    "test/fixture/package/src/example/Function.js",
    "file"
  ],
  [
    "test/fixture/package/src/example/variable.js",
    "file/test/fixture/package/src/example/Variable.js.html",
    "test/fixture/package/src/example/Variable.js",
    "file"
  ],
  [
    "test/fixture/package/src/experimental/class.js",
    "file/test/fixture/package/src/experimental/Class.js.html",
    "test/fixture/package/src/experimental/Class.js",
    "file"
  ],
  [
    "test/fixture/package/src/experimental/function.js",
    "file/test/fixture/package/src/experimental/Function.js.html",
    "test/fixture/package/src/experimental/Function.js",
    "file"
  ],
  [
    "test/fixture/package/src/experimental/variable.js",
    "file/test/fixture/package/src/experimental/Variable.js.html",
    "test/fixture/package/src/experimental/Variable.js",
    "file"
  ],
  [
    "test/fixture/package/src/exponentiationoperator/definition.js",
    "file/test/fixture/package/src/exponentiationoperator/Definition.js.html",
    "test/fixture/package/src/exponentiationoperator/Definition.js",
    "file"
  ],
  [
    "test/fixture/package/src/export/anonymousclass.js",
    "file/test/fixture/package/src/export/AnonymousClass.js.html",
    "test/fixture/package/src/export/AnonymousClass.js",
    "file"
  ],
  [
    "test/fixture/package/src/export/anonymousfunction.js",
    "file/test/fixture/package/src/export/AnonymousFunction.js.html",
    "test/fixture/package/src/export/AnonymousFunction.js",
    "file"
  ],
  [
    "test/fixture/package/src/export/arrowfunction.js",
    "file/test/fixture/package/src/export/ArrowFunction.js.html",
    "test/fixture/package/src/export/ArrowFunction.js",
    "file"
  ],
  [
    "test/fixture/package/src/export/class.js",
    "file/test/fixture/package/src/export/Class.js.html",
    "test/fixture/package/src/export/Class.js",
    "file"
  ],
  [
    "test/fixture/package/src/export/classindirectdefault.js",
    "file/test/fixture/package/src/export/ClassIndirectDefault.js.html",
    "test/fixture/package/src/export/ClassIndirectDefault.js",
    "file"
  ],
  [
    "test/fixture/package/src/export/default.js",
    "file/test/fixture/package/src/export/Default.js.html",
    "test/fixture/package/src/export/Default.js",
    "file"
  ],
  [
    "test/fixture/package/src/export/extends.js",
    "file/test/fixture/package/src/export/Extends.js.html",
    "test/fixture/package/src/export/Extends.js",
    "file"
  ],
  [
    "test/fixture/package/src/export/function.js",
    "file/test/fixture/package/src/export/Function.js.html",
    "test/fixture/package/src/export/Function.js",
    "file"
  ],
  [
    "test/fixture/package/src/export/functionindirectdefault.js",
    "file/test/fixture/package/src/export/FunctionIndirectDefault.js.html",
    "test/fixture/package/src/export/FunctionIndirectDefault.js",
    "file"
  ],
  [
    "test/fixture/package/src/export/multiple.js",
    "file/test/fixture/package/src/export/Multiple.js.html",
    "test/fixture/package/src/export/Multiple.js",
    "file"
  ],
  [
    "test/fixture/package/src/export/named.js",
    "file/test/fixture/package/src/export/Named.js.html",
    "test/fixture/package/src/export/Named.js",
    "file"
  ],
  [
    "test/fixture/package/src/export/newexpression.js",
    "file/test/fixture/package/src/export/NewExpression.js.html",
    "test/fixture/package/src/export/NewExpression.js",
    "file"
  ],
  [
    "test/fixture/package/src/export/newexpressionindirect.js",
    "file/test/fixture/package/src/export/NewExpressionIndirect.js.html",
    "test/fixture/package/src/export/NewExpressionIndirect.js",
    "file"
  ],
  [
    "test/fixture/package/src/export/newexpressionproperty.js",
    "file/test/fixture/package/src/export/NewExpressionProperty.js.html",
    "test/fixture/package/src/export/NewExpressionProperty.js",
    "file"
  ],
  [
    "test/fixture/package/src/export/variable.js",
    "file/test/fixture/package/src/export/Variable.js.html",
    "test/fixture/package/src/export/Variable.js",
    "file"
  ],
  [
    "test/fixture/package/src/export/variableindirectdefault.js",
    "file/test/fixture/package/src/export/VariableIndirectDefault.js.html",
    "test/fixture/package/src/export/VariableIndirectDefault.js",
    "file"
  ],
  [
    "test/fixture/package/src/extends/builtin.js",
    "file/test/fixture/package/src/extends/Builtin.js.html",
    "test/fixture/package/src/extends/Builtin.js",
    "file"
  ],
  [
    "test/fixture/package/src/extends/deep.js",
    "file/test/fixture/package/src/extends/Deep.js.html",
    "test/fixture/package/src/extends/Deep.js",
    "file"
  ],
  [
    "test/fixture/package/src/extends/expression.js",
    "file/test/fixture/package/src/extends/Expression.js.html",
    "test/fixture/package/src/extends/Expression.js",
    "file"
  ],
  [
    "test/fixture/package/src/extends/inner.js",
    "file/test/fixture/package/src/extends/Inner.js.html",
    "test/fixture/package/src/extends/Inner.js",
    "file"
  ],
  [
    "test/fixture/package/src/extends/mixin.js",
    "file/test/fixture/package/src/extends/Mixin.js.html",
    "test/fixture/package/src/extends/Mixin.js",
    "file"
  ],
  [
    "test/fixture/package/src/extends/mixinexplicit.js",
    "file/test/fixture/package/src/extends/MixinExplicit.js.html",
    "test/fixture/package/src/extends/MixinExplicit.js",
    "file"
  ],
  [
    "test/fixture/package/src/extends/outer.js",
    "file/test/fixture/package/src/extends/Outer.js.html",
    "test/fixture/package/src/extends/Outer.js",
    "file"
  ],
  [
    "test/fixture/package/src/extends/property.js",
    "file/test/fixture/package/src/extends/Property.js.html",
    "test/fixture/package/src/extends/Property.js",
    "file"
  ],
  [
    "test/fixture/package/src/external/definition.js",
    "file/test/fixture/package/src/external/Definition.js.html",
    "test/fixture/package/src/external/Definition.js",
    "file"
  ],
  [
    "test/fixture/package/src/generator/function.js",
    "file/test/fixture/package/src/generator/Function.js.html",
    "test/fixture/package/src/generator/Function.js",
    "file"
  ],
  [
    "test/fixture/package/src/generator/method.js",
    "file/test/fixture/package/src/generator/Method.js.html",
    "test/fixture/package/src/generator/Method.js",
    "file"
  ],
  [
    "test/fixture/package/src/guess/objectdefaultparam.js",
    "file/test/fixture/package/src/guess/ObjectDefaultParam.js.html",
    "test/fixture/package/src/guess/ObjectDefaultParam.js",
    "file"
  ],
  [
    "test/fixture/package/src/guess/param.js",
    "file/test/fixture/package/src/guess/Param.js.html",
    "test/fixture/package/src/guess/Param.js",
    "file"
  ],
  [
    "test/fixture/package/src/guess/property.js",
    "file/test/fixture/package/src/guess/Property.js.html",
    "test/fixture/package/src/guess/Property.js",
    "file"
  ],
  [
    "test/fixture/package/src/guess/return.js",
    "file/test/fixture/package/src/guess/Return.js.html",
    "test/fixture/package/src/guess/Return.js",
    "file"
  ],
  [
    "test/fixture/package/src/guess/variable.js",
    "file/test/fixture/package/src/guess/Variable.js.html",
    "test/fixture/package/src/guess/Variable.js",
    "file"
  ],
  [
    "test/fixture/package/src/ignore/class.js",
    "file/test/fixture/package/src/ignore/Class.js.html",
    "test/fixture/package/src/ignore/Class.js",
    "file"
  ],
  [
    "test/fixture/package/src/ignore/function.js",
    "file/test/fixture/package/src/ignore/Function.js.html",
    "test/fixture/package/src/ignore/Function.js",
    "file"
  ],
  [
    "test/fixture/package/src/ignore/variable.js",
    "file/test/fixture/package/src/ignore/Variable.js.html",
    "test/fixture/package/src/ignore/Variable.js",
    "file"
  ],
  [
    "test/fixture/package/src/interface/definition.js",
    "file/test/fixture/package/src/interface/Definition.js.html",
    "test/fixture/package/src/interface/Definition.js",
    "file"
  ],
  [
    "test/fixture/package/src/interface/implements.js",
    "file/test/fixture/package/src/interface/Implements.js.html",
    "test/fixture/package/src/interface/Implements.js",
    "file"
  ],
  [
    "test/fixture/package/src/invalid/docsyntax.js",
    "file/test/fixture/package/src/invalid/DocSyntax.js.html",
    "test/fixture/package/src/invalid/DocSyntax.js",
    "file"
  ],
  [
    "test/fixture/package/src/jsx/definition.js",
    "file/test/fixture/package/src/jsx/Definition.js.html",
    "test/fixture/package/src/jsx/Definition.js",
    "file"
  ],
  [
    "test/fixture/package/src/link/class.js",
    "file/test/fixture/package/src/link/Class.js.html",
    "test/fixture/package/src/link/Class.js",
    "file"
  ],
  [
    "test/fixture/package/src/link/function.js",
    "file/test/fixture/package/src/link/Function.js.html",
    "test/fixture/package/src/link/Function.js",
    "file"
  ],
  [
    "test/fixture/package/src/link/variable.js",
    "file/test/fixture/package/src/link/Variable.js.html",
    "test/fixture/package/src/link/Variable.js",
    "file"
  ],
  [
    "test/fixture/package/src/lint/invalid.js",
    "file/test/fixture/package/src/lint/Invalid.js.html",
    "test/fixture/package/src/lint/Invalid.js",
    "file"
  ],
  [
    "test/fixture/package/src/listens/function.js",
    "file/test/fixture/package/src/listens/Function.js.html",
    "test/fixture/package/src/listens/Function.js",
    "file"
  ],
  [
    "test/fixture/package/src/listens/method.js",
    "file/test/fixture/package/src/listens/Method.js.html",
    "test/fixture/package/src/listens/Method.js",
    "file"
  ],
  [
    "test/fixture/package/src/param/function.js",
    "file/test/fixture/package/src/param/Function.js.html",
    "test/fixture/package/src/param/Function.js",
    "file"
  ],
  [
    "test/fixture/package/src/param/method.js",
    "file/test/fixture/package/src/param/Method.js.html",
    "test/fixture/package/src/param/Method.js",
    "file"
  ],
  [
    "test/fixture/package/src/property/return.js",
    "file/test/fixture/package/src/property/Return.js.html",
    "test/fixture/package/src/property/Return.js",
    "file"
  ],
  [
    "test/fixture/package/src/return/function.js",
    "file/test/fixture/package/src/return/Function.js.html",
    "test/fixture/package/src/return/Function.js",
    "file"
  ],
  [
    "test/fixture/package/src/return/method.js",
    "file/test/fixture/package/src/return/Method.js.html",
    "test/fixture/package/src/return/Method.js",
    "file"
  ],
  [
    "test/fixture/package/src/see/class.js",
    "file/test/fixture/package/src/see/Class.js.html",
    "test/fixture/package/src/see/Class.js",
    "file"
  ],
  [
    "test/fixture/package/src/see/function.js",
    "file/test/fixture/package/src/see/Function.js.html",
    "test/fixture/package/src/see/Function.js",
    "file"
  ],
  [
    "test/fixture/package/src/see/variable.js",
    "file/test/fixture/package/src/see/Variable.js.html",
    "test/fixture/package/src/see/Variable.js",
    "file"
  ],
  [
    "test/fixture/package/src/since/class.js",
    "file/test/fixture/package/src/since/Class.js.html",
    "test/fixture/package/src/since/Class.js",
    "file"
  ],
  [
    "test/fixture/package/src/since/function.js",
    "file/test/fixture/package/src/since/Function.js.html",
    "test/fixture/package/src/since/Function.js",
    "file"
  ],
  [
    "test/fixture/package/src/since/variable.js",
    "file/test/fixture/package/src/since/Variable.js.html",
    "test/fixture/package/src/since/Variable.js",
    "file"
  ],
  [
    "test/fixture/package/src/throws/function.js",
    "file/test/fixture/package/src/throws/Function.js.html",
    "test/fixture/package/src/throws/Function.js",
    "file"
  ],
  [
    "test/fixture/package/src/throws/method.js",
    "file/test/fixture/package/src/throws/Method.js.html",
    "test/fixture/package/src/throws/Method.js",
    "file"
  ],
  [
    "test/fixture/package/src/todo/class.js",
    "file/test/fixture/package/src/todo/Class.js.html",
    "test/fixture/package/src/todo/Class.js",
    "file"
  ],
  [
    "test/fixture/package/src/todo/function.js",
    "file/test/fixture/package/src/todo/Function.js.html",
    "test/fixture/package/src/todo/Function.js",
    "file"
  ],
  [
    "test/fixture/package/src/todo/variable.js",
    "file/test/fixture/package/src/todo/Variable.js.html",
    "test/fixture/package/src/todo/Variable.js",
    "file"
  ],
  [
    "test/fixture/package/src/trailingcomma/definition.js",
    "file/test/fixture/package/src/trailingcomma/Definition.js.html",
    "test/fixture/package/src/trailingcomma/Definition.js",
    "file"
  ],
  [
    "test/fixture/package/src/type/array.js",
    "file/test/fixture/package/src/type/Array.js.html",
    "test/fixture/package/src/type/Array.js",
    "file"
  ],
  [
    "test/fixture/package/src/type/class.js",
    "file/test/fixture/package/src/type/Class.js.html",
    "test/fixture/package/src/type/Class.js",
    "file"
  ],
  [
    "test/fixture/package/src/type/complex.js",
    "file/test/fixture/package/src/type/Complex.js.html",
    "test/fixture/package/src/type/Complex.js",
    "file"
  ],
  [
    "test/fixture/package/src/type/default.js",
    "file/test/fixture/package/src/type/Default.js.html",
    "test/fixture/package/src/type/Default.js",
    "file"
  ],
  [
    "test/fixture/package/src/type/external.js",
    "file/test/fixture/package/src/type/External.js.html",
    "test/fixture/package/src/type/External.js",
    "file"
  ],
  [
    "test/fixture/package/src/type/function.js",
    "file/test/fixture/package/src/type/Function.js.html",
    "test/fixture/package/src/type/Function.js",
    "file"
  ],
  [
    "test/fixture/package/src/type/generics.js",
    "file/test/fixture/package/src/type/Generics.js.html",
    "test/fixture/package/src/type/Generics.js",
    "file"
  ],
  [
    "test/fixture/package/src/type/literal.js",
    "file/test/fixture/package/src/type/Literal.js.html",
    "test/fixture/package/src/type/Literal.js",
    "file"
  ],
  [
    "test/fixture/package/src/type/nullable.js",
    "file/test/fixture/package/src/type/Nullable.js.html",
    "test/fixture/package/src/type/Nullable.js",
    "file"
  ],
  [
    "test/fixture/package/src/type/object.js",
    "file/test/fixture/package/src/type/Object.js.html",
    "test/fixture/package/src/type/Object.js",
    "file"
  ],
  [
    "test/fixture/package/src/type/optional.js",
    "file/test/fixture/package/src/type/Optional.js.html",
    "test/fixture/package/src/type/Optional.js",
    "file"
  ],
  [
    "test/fixture/package/src/type/record.js",
    "file/test/fixture/package/src/type/Record.js.html",
    "test/fixture/package/src/type/Record.js",
    "file"
  ],
  [
    "test/fixture/package/src/type/spread.js",
    "file/test/fixture/package/src/type/Spread.js.html",
    "test/fixture/package/src/type/Spread.js",
    "file"
  ],
  [
    "test/fixture/package/src/type/typedef.js",
    "file/test/fixture/package/src/type/Typedef.js.html",
    "test/fixture/package/src/type/Typedef.js",
    "file"
  ],
  [
    "test/fixture/package/src/type/union.js",
    "file/test/fixture/package/src/type/Union.js.html",
    "test/fixture/package/src/type/Union.js",
    "file"
  ],
  [
    "test/fixture/package/src/typedef/definition.js",
    "file/test/fixture/package/src/typedef/Definition.js.html",
    "test/fixture/package/src/typedef/Definition.js",
    "file"
  ],
  [
    "test/fixture/package/src/undocument/definition.js",
    "file/test/fixture/package/src/undocument/Definition.js.html",
    "test/fixture/package/src/undocument/Definition.js",
    "file"
  ],
  [
    "test/fixture/package/src/unknown/definition.js",
    "file/test/fixture/package/src/unknown/Definition.js.html",
    "test/fixture/package/src/unknown/Definition.js",
    "file"
  ],
  [
    "test/fixture/package/src/variable/arraypattern.js",
    "file/test/fixture/package/src/variable/ArrayPattern.js.html",
    "test/fixture/package/src/variable/ArrayPattern.js",
    "file"
  ],
  [
    "test/fixture/package/src/variable/definition.js",
    "file/test/fixture/package/src/variable/Definition.js.html",
    "test/fixture/package/src/variable/Definition.js",
    "file"
  ],
  [
    "test/fixture/package/src/variable/objectpattern.js",
    "file/test/fixture/package/src/variable/ObjectPattern.js.html",
    "test/fixture/package/src/variable/ObjectPattern.js",
    "file"
  ],
  [
    "test/fixture/package/src/version/class.js",
    "file/test/fixture/package/src/version/Class.js.html",
    "test/fixture/package/src/version/Class.js",
    "file"
  ],
  [
    "test/fixture/package/src/version/function.js",
    "file/test/fixture/package/src/version/Function.js.html",
    "test/fixture/package/src/version/Function.js",
    "file"
  ],
  [
    "test/fixture/package/src/version/variable.js",
    "file/test/fixture/package/src/version/Variable.js.html",
    "test/fixture/package/src/version/Variable.js",
    "file"
  ],
  [
    "test/fixture/package/test/desctest.js",
    "test-file/test/fixture/package/test/DescTest.js.html",
    "test/fixture/package/test/DescTest.js",
    "testFile"
  ],
  [
    "undefined",
    "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/undefined",
    "undefined",
    "external"
  ]
]