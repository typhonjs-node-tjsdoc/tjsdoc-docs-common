export default class Foo
{
   *method()
   {
      console.log(function.sent);
   }
}
