export * as ns from 'mod';
export v from "mod";
export vv, {x, y as w} from "mod";
export default from "mod";
