export default class Foo
{
   method1()
   {
      const a = do
      {
         if (x > 10)
         {
            'big';
         }
         else
         {
            'small';
         }
      };
   }
}
