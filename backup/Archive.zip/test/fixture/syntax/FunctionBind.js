/**
 * The foo function.
 */
function foo() {}

/**
 * Class foo.
 */
export default class Foo
{
   /**
    * Method
    */
   method()
   {
      this::foo();
   }
}
