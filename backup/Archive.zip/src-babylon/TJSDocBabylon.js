import path       from 'path';
import TJSDoc     from 'tjsdoc';

import ConfigData from 'tjsdoc/src/ConfigData.js';

/**
 * Provides an overridden version of TJSDoc with a default runtime assigned to `tjsdoc-babylon`.
 * @inheritdoc
 */
export default class TJSDocBabylon extends TJSDoc
{
   static tjsdocPackagePath = path.resolve(__dirname, '../package.json');

   /**
    * @inheritdoc
    */
   static generate(config)
   {
      super.generate(Object.assign(
      {
         runtime: `${__dirname}/TJSDocBabylon.js`,
         publisher: path.resolve(__dirname, '../src-publisher/publish.js')
      }, config));
   }
}

/**
 * Adds all Babylon runtime plugins.
 *
 * @param {PluginEvent} ev - The plugin event.
 *
 * @ignore
 */
export function onPluginLoad(ev)
{
   const eventbus = ev.eventbus;
   const dirPath = path.resolve(__dirname);

   eventbus.trigger('plugins:add', { name: 'tjsdoc-common-runtime', target: `${dirPath}/../src/TJSDoc.js` });
   eventbus.trigger('plugins:add', { name: `${dirPath}/doc/` });
   eventbus.trigger('plugins:add', { name: `${dirPath}/parser/` });

   // Adds an instance of typhonjs-config-resolver with overridden common TJSDoc config resolver data for usage with
   // Babylon / JS source code.
   eventbus.trigger('plugins:add', { name: 'tjsdoc-config-resolver', target: 'typhonjs-config-resolver', options:
   {
      eventPrepend: 'tjsdoc',

      resolverData: ConfigData.createResolverData(ev.eventbus,
      {
         defaultValues:
         {
            'includes': ['\\.(js|jsx|jsm)$'],
            'pathExtensions': ['.js', '.jsx', '.jsm'],
            'test.includes': ['\\.(js|jsx|jsm)$']
         }
      })
   } });
}
