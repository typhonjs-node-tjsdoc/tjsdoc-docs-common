import path       from 'path';

/**
 * Adds all Babylon runtime parser plugins.
 *
 * @param {PluginEvent} ev - The plugin event.
 *
 * @ignore
 */
export function onPluginLoad(ev)
{
   const eventbus = ev.eventbus;
   const dirPath = path.resolve(__dirname);

   eventbus.trigger('plugins:add', { name: `${dirPath}/BabylonASTUtil.js` });
   eventbus.trigger('plugins:add', { name: `${dirPath}/BabylonParser.js` });
   eventbus.trigger('plugins:add', { name: `${dirPath}/CommentParser.js` });
   eventbus.trigger('plugins:add', { name: `${dirPath}/ParamParser.js` });
}
