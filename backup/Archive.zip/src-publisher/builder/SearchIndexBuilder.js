/**
 * Search index builder for identifiers.
 */
export default class SearchIndexBuilder
{
   /**
    * Executes writing search index.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    */
   static exec(eventbus)
   {
      const searchIndex = [];
      const docs = eventbus.triggerSync('tjsdoc:docs:find', {});

      for (const doc of docs)
      {
         let indexText;
         let url;
         let displayText;

         if (doc.importPath)
         {
            displayText = `<span>${doc.name}</span> <span class="search-result-import-path">${doc.importPath}</span>`;
            indexText = `${doc.importPath}~${doc.name}`.toLowerCase();

            url = eventbus.triggerSync('tjsdoc:publisher:get:doc:url', doc);
         }
         else
         {
            switch (doc.kind)
            {
               // Skip processing any memory docs.
               case 'memory':
                  continue;

               case 'external':
                  displayText = doc.name;
                  indexText = displayText.toLowerCase();

                  url = doc.externalLink;
                  break;

               case 'testDescribe':
               case 'testIt':
               {
                  displayText = doc.testFullDescription;
                  indexText = [...(doc.testTargets || []), ...(doc._custom_test_targets || [])].join(' ').toLowerCase();

                  const filePath = doc.longname.split('~')[0];
                  const fileDoc = eventbus.triggerSync('tjsdoc:docs:find', { kind: 'testFile', longname: filePath })[0];

                  url = `${eventbus.triggerSync('tjsdoc:publisher:get:doc:url', fileDoc)}#lineNumber${doc.lineNumber}`;
                  break;
               }

               case 'constructor':
               case 'method':
               case 'get':
               case 'set':
               case 'member':
               {
                  const filePath = doc.longname.split('~')[0];
                  const memberName = doc.longname.split('~')[1];

                  displayText = `<span>${memberName}</span> <span class="search-result-import-path">${filePath}</span>`;
                  indexText = memberName.toLowerCase();

                  url = eventbus.triggerSync('tjsdoc:publisher:get:doc:url', doc);
                  break;
               }

               case 'typedef':
                  displayText = doc.name;
                  indexText = displayText.toLowerCase();

                  url = eventbus.triggerSync('tjsdoc:publisher:get:doc:url', doc);
                  break;

               default:
                  displayText = doc.longname;
                  indexText = displayText.toLowerCase();

                  url = eventbus.triggerSync('tjsdoc:publisher:get:doc:url', doc);
                  break;
            }
         }

         let kind = doc.kind;

         switch (kind)
         {
            case 'constructor':
               kind = 'method';
               break;

            case 'get':
            case 'set':
               kind = 'member';
               break;

            case 'testDescribe':
            case 'testIt':
               kind = 'test';
               break;
         }

         searchIndex.push([indexText, url, displayText, kind]);
      }

      searchIndex.sort((a, b) => a[2] === b[2] ? 0 : a[2] < b[2] ? -1 : 1);

      // Allow any plugins to modify the search index JSON before serializing.
      eventbus.triggerSync('plugins:invoke:sync:event', 'onHandleSearchIndex', void 0, { searchIndex });

      const javascript = `window.esdocSearchIndex = ${JSON.stringify(searchIndex, null, 2)}`;

      eventbus.trigger('tjsdoc:util:write:file', javascript, 'script/search_index.js');
   }
}
