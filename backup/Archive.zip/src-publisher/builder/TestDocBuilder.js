/**
 * Test file output HTML builder.
 */
export default class TestDocBuilder
{
   /**
    * Executes building output HTML.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    */
   static exec(eventbus)
   {
      const testDescribeDoc = eventbus.triggerSync('tjsdoc:docs:find', { kind: 'testDescribe' })[0];

      if (!testDescribeDoc) { return; }

      const ice = eventbus.triggerSync('tjsdoc:publisher:get:ice:cap:layout');
      const fileName = eventbus.triggerSync('tjsdoc:publisher:get:doc:file:name', testDescribeDoc);
      const baseUrl = eventbus.triggerSync('tjsdoc:publisher:get:file:url:base', fileName);
      const title = eventbus.triggerSync('tjsdoc:publisher:get:title', 'Test');

      ice.load('content', TestDocBuilder._buildTestDocHTML(eventbus));
      ice.attr('baseUrl', 'href', baseUrl);
      ice.text('title', title);

      eventbus.trigger('tjsdoc:util:file:write', ice.html, fileName);
   }

   /**
    * Build whole test file output HTML.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    *
    * @returns {string} HTML of whole test file.
    * @private
    */
   static _buildTestDocHTML(eventbus)
   {
      const ice = eventbus.triggerSync('tjsdoc:publisher:get:ice:cap:template', 'test.html');
      const testDescribeHTML = TestDocBuilder._buildTestDescribeDocHTML(eventbus);

      ice.load('tests', testDescribeHTML);

      return ice.html;
   }

   /**
    * Build test describe list HTML.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    *
    * @param {number}      [depth=0] - test depth.
    *
    * @param {string}      [memberof] - target test.
    *
    * @returns {string} html of describe list.
    * @private
    */
   static _buildTestDescribeDocHTML(eventbus, depth = 0, memberof = void 0)
   {
      const cond = { kind: 'testDescribe', testDepth: depth };

      if (memberof) { cond.memberof = memberof; }

      const describeDocs = eventbus.triggerSync('tjsdoc:docs:find:sorted', 'testId asec', cond);

      let padding;
      let html = '';

      for (const describeDoc of describeDocs)
      {
         const ice = eventbus.triggerSync('tjsdoc:publisher:get:ice:cap:template', 'testDescribe.html');

         const testCount = eventbus.triggerSync('tjsdoc:docs:find',
         {
            kind: 'testIt',
            longname: { regex: new RegExp(`^${describeDoc.longname}\\.`) }
         }).length;

         padding = 10 * (depth + 1);

         ice.attr('testDescribe', 'data-test-depth', depth);

         ice.into('testDescribe', describeDoc, (describeDoc, ice) =>
         {
            const descriptionHTML = eventbus.triggerSync('tjsdoc:publisher:get:doc:html:file:link', describeDoc,
             describeDoc.description);

            let testTargetsHTML = [];

            for (const testTarget of describeDoc._custom_test_targets || [])
            {
               testTargetsHTML.push(eventbus.triggerSync('tjsdoc:publisher:get:doc:html:link', testTarget[0],
                testTarget[1]));
            }

            testTargetsHTML = testTargetsHTML.join('\n') || '-';

            ice.load('testDescription', descriptionHTML);
            ice.attr('testDescription', 'style', `padding-left: ${padding}px`);
            ice.load('testTarget', testTargetsHTML);
            ice.text('testCount', testCount);
         });

         padding = 10 * (depth + 2);

         const itDocs = eventbus.triggerSync('tjsdoc:docs:find:sorted', 'testId asec',
         {
            kind: 'testIt',
            testDepth: depth + 1,
            memberof: describeDoc.longname
         });

         ice.loop('testIt', itDocs, (i, itDoc, ice) =>
         {
            const descriptionHTML = eventbus.triggerSync('tjsdoc:publisher:get:doc:html:file:link', itDoc,
             itDoc.description);

            let testTargetsHTML = [];

            for (const testTarget of itDoc._custom_test_targets || [])
            {
               testTargetsHTML.push(eventbus.triggerSync('tjsdoc:publisher:get:doc:html:link', testTarget[0],
                testTarget[1]));
            }

            testTargetsHTML = testTargetsHTML.join('\n') || '-';

            ice.attr('testIt', 'data-test-depth', depth + 1);
            ice.load('testDescription', descriptionHTML);
            ice.attr('testDescription', 'style', `padding-left: ${padding}px`);
            ice.load('testTarget', testTargetsHTML);
         });

         const innerDescribeHTML = TestDocBuilder._buildTestDescribeDocHTML(eventbus, depth + 1, describeDoc.longname);

         html += `\n${ice.html}\n${innerDescribeHTML}`;
      }

      return html;
   }
}
