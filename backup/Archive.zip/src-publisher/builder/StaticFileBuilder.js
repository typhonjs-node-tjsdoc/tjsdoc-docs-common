import path from 'path';

/**
 * Static file output builder.
 */
export default class StaticFileBuilder
{
   /**
    * Copies all static resources from template.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    */
   static exec(eventbus)
   {
      eventbus.trigger('typhonjs:util:file:copy', path.resolve(__dirname, '../template/css'), './css');
      eventbus.trigger('typhonjs:util:file:copy', path.resolve(__dirname, '../template/script'), './script');
      eventbus.trigger('typhonjs:util:file:copy', path.resolve(__dirname, '../template/image'), './image');

      const config = eventbus.triggerSync('tjsdoc:get:config');

      // see DocBuilder#_buildLayoutDoc
      const scripts = config.scripts || [];

      for (let i = 0; i < scripts.length; i++)
      {
         const userScript = scripts[i];
         const name = `./user/script/${i}-${path.basename(userScript)}`;

         eventbus.trigger('typhonjs:util:file:copy', userScript, name);
      }

      const styles = config.styles || [];

      for (let i = 0; i < styles.length; i++)
      {
         const userStyle = styles[i];
         const name = `./user/css/${i}-${path.basename(userStyle)}`;

         eventbus.trigger('typhonjs:util:file:copy', userStyle, name);
      }
   }
}
