/**
 * parse ``@example`` value.
 * ``@example`` value can have ``<caption>`` tag.
 *
 * @param {string} example - target example value.
 *
 * @returns {{body: string, caption: string}} parsed example value.
 */
export default function parseExample(example)
{
   let body = example;
   let caption = '';

   const regexp = new RegExp('^<caption>(.*?)</caption>\n'); // eslint-disable-line no-control-regex
   const matched = example.match(regexp);

   if (matched)
   {
      body = example.replace(regexp, '');
      caption = matched[1].trim();
   }

   return { body, caption };
}
